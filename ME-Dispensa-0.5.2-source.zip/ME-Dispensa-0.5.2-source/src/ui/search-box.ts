// The search box shared by the Library and 🔍: ✕, keys and marked results.

import { t } from "../shared/i18n";
import type { Range } from "../qr/search";
import { el, icon } from "./dom";

export interface SearchBoxKeys {
  /** ↑ -1, ↓ +1. */
  move(by: number): void;
  /** `edit`: Ctrl/⌘ held. */
  enter(edit: boolean): void;
  /** Emptied by ✕ or Del. */
  cleared(): void;
}

/** `onInput` also fires mid-composition (Hangul). */
export function searchBox(opts: { value: string; placeholder: string; label: string; key?: string; part?: string; onInput(text: string): void } & SearchBoxKeys): { box: HTMLElement; input: HTMLInputElement } {
  const input = el("input", { type: "text", class: "search-input", value: opts.value, placeholder: opts.placeholder, "aria-label": opts.label, autocomplete: "off", spellcheck: "false", enterkeyhint: "search", "data-key": opts.key });
  const clear = el(
    "button",
    {
      type: "button",
      class: "search-clear",
      title: t("Clear", "지우기"),
      "aria-label": t("Clear the search", "찾을 글 지우기"),
      hidden: !opts.value,
      onclick: () => {
        input.value = "";
        clear.hidden = true;
        opts.onInput("");
        opts.cleared();
        input.focus();
      },
    },
    icon("x"),
  );
  input.addEventListener("input", () => {
    clear.hidden = !input.value;
    opts.onInput(input.value);
  });
  input.addEventListener("keydown", (e) => {
    // keep keys from the page's shortcuts; Esc goes on to close the window
    if (e.key !== "Escape") e.stopPropagation();
    // IME composing
    if (e.isComposing || e.keyCode === 229) return;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      opts.move(e.key === "ArrowDown" ? 1 : -1);
    } else if (e.key === "Enter") {
      e.preventDefault();
      opts.enter(e.ctrlKey || e.metaKey);
    } else if (e.key === "Delete" && input.value && input.selectionStart === input.value.length && input.selectionEnd === input.value.length) {
      // Del at the end clears all
      e.preventDefault();
      clear.click();
    }
  });
  const box = el("div", { class: "search-box", part: opts.part }, icon("search"), input, clear);
  return { box, input };
}

/** `text` with the found ranges in <mark>. */
export function marked(text: string, ranges: Range[] | undefined): DocumentFragment {
  const out = document.createDocumentFragment();
  let at = 0;
  for (const [s, e] of ranges ?? []) {
    if (s < at || e <= s) continue;
    if (s > at) out.append(text.slice(at, s));
    out.append(el("mark", { class: "found" }, text.slice(s, e)));
    at = e;
  }
  if (at < text.length) out.append(text.slice(at));
  return out;
}

/** Used in both shadow roots. */
export const SEARCH_BOX_CSS = `
.search-box { position: relative; display: flex; align-items: center; }
.search-box > svg { position: absolute; left: 8px; width: 14px; height: 14px; color: var(--d-muted); pointer-events: none; }
.search-box > input.search-input { width: 100%; padding-left: 28px; padding-right: 28px; }
.search-box > .search-clear { position: absolute; right: 3px; padding: 3px; border-color: transparent; background: none; color: var(--d-muted); }
.search-box > .search-clear[hidden] { display: none; }
.search-box > .search-clear svg { width: 13px; height: 13px; }
mark.found { background: color-mix(in srgb, var(--d-accent) 32%, transparent); color: inherit; border-radius: 2px; padding: 0 1px; }
`;
