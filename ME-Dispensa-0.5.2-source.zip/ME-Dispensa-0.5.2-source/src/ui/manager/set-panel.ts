// The top of the Library's right column: the selected set's name, where it is on, its look and menu.

import { t } from "../../shared/i18n";
import { duplicateSet } from "../../qr/copy";
import { addToDock, layoutOf, onDock, pruneDock, removeFromDock, setLayout } from "../../qr/dock";
import type { QrSet, QrState } from "../../qr/model";
import { elsewhere, forgetSet, isOnForCharacter, isOnForChat, setForCharacter, setForChat } from "../../qr/scopes";
import { el, icon } from "../dom";
import { section, setting, toggle } from "../../shared/form";
import { dropMenu } from "../menu";
import type { ManagerContext } from "./context";
import type { QrFiles } from "./import-export";

const HELP = () => ({
  places: t("Where its QRs auto-run", "자동 실행이 도는 곳"),
  plain: t(
    "For a QR that is plain text (no '/')\n· Don't send: input only\n· Add to input text: after the typed text\n· Put before: before the typed text",
    "'/' 없는 글 QR을 누를 때\n· 보내지 않기: 입력창에만\n· 입력창 글에 붙이기: 쓰던 글 뒤에\n· 앞에 붙이기: 쓰던 글 앞에",
  ),
});

export function setPanel(ctx: ManagerContext, set: QrSet, files: QrFiles): HTMLElement[] {
  const mutate = (fn: (s: QrSet, st: QrState) => void) => ctx.mutateSet(set, fn);
  const state = ctx.state;
  const top = el(
    "div",
    { class: "row" },
    el("input", {
      type: "text",
      value: set.icon ?? "",
      placeholder: "📁",
      maxlength: "8",
      style: "width:3.2em;text-align:center",
      title: t("Dock bubble icon (one emoji)", "Dock 버블 아이콘 (이모지 하나)"),
      "data-key": "set-icon",
      "aria-label": t("Set icon", "세트 아이콘"),
      oninput: (e: Event) => mutate((s) => (s.icon = (e.target as HTMLInputElement).value.trim() || undefined)),
    }),
    el("input", { type: "text", class: "grow", value: set.name, "data-key": "set-name", "aria-label": t("Set name", "세트 이름"), oninput: (e: Event) => mutate((s) => (s.name = (e.target as HTMLInputElement).value)) }),
    el("button", { onclick: () => files.exportSet(set) }, icon("upload"), t("Export", "내보내기")),
    setMenu(ctx, set),
  );

  // where it is on
  const chat = ctx.scope.chatId;
  const sw = (on: boolean, change: (v: boolean) => void, label: string, key: string, disabled = false) => {
    const box = toggle(on, change, label, key);
    if (disabled) box.querySelector("input")!.disabled = true;
    return box;
  };
  const other = elsewhere(state, set.id, ctx.scope);
  const otherNote = [other.chats ? t(`${other.chats} other chats`, `다른 채팅 ${other.chats}곳`) : "", other.characters ? t(`${other.characters} other characters`, `다른 캐릭터 ${other.characters}명`) : ""].filter(Boolean).join(", ");
  const places = section(
    t("Auto-run in", "켜는 칸"),
    HELP().places,
    [],
    setting(t("Global", "전체"), sw(set.enabled, (v) => mutate((s) => (s.enabled = v)), t("Global", "전체"), "place-all")),
    setting(
      t("This chat", "이 채팅"),
      sw(isOnForChat(state, set.id, chat), (v) => chat && mutate((s, st) => setForChat(st, chat, s.id, v)), t("This chat", "이 채팅"), "place-chat", !chat),
      chat ? undefined : t("Available with a chat open", "채팅을 연 상태에서 선택 가능"),
    ),
    ...ctx.scope.characterIds.map((c) =>
      setting(t(`Character: ${ctx.characterName(c)}`, `캐릭터: ${ctx.characterName(c)}`), sw(isOnForCharacter(state, set.id, c), (v) => mutate((s, st) => setForCharacter(st, c, s.id, v)), t(`Character ${ctx.characterName(c, "")}`, `캐릭터 ${ctx.characterName(c, "")}`), `place-char-${c}`)),
    ),
    otherNote ? el("div", { class: "note" }, t(`Also on in ${otherNote}`, `${otherNote}에서도 켜짐`)) : null,
  );

  // on the Dock: off, one folder bubble, or a bubble per QR
  const docked = (state.dock ?? []).find((e) => e.kind === "set" && e.setId === set.id);
  const dockPlace = docked ? layoutOf(docked, set) : "off";
  const onDockRow = setting(
    t("On the Dock", "Dock에 놓기"),
    el(
      "select",
      {
        "data-key": "set-dock",
        "aria-label": t("On the Dock", "Dock에 놓기"),
        onchange: (e: Event) => {
          const v = (e.target as HTMLSelectElement).value;
          mutate((s, st) => {
            if (v === "off") return removeFromDock(st, { kind: "set", setId: s.id });
            if (!onDock(st, { kind: "set", setId: s.id })) addToDock(st, { kind: "set", setId: s.id });
            setLayout(st, s.id, v as "folder" | "row");
          });
        },
      },
      ...([["off", t("Off", "안 놓기")], ["folder", t("Folder", "폴더")], ["row", t("Row", "한 줄")]] as const).map(([v, label]) => el("option", { value: v, selected: v === dockPlace }, label)),
    ),
    t("Folder: one bubble · Row: a bubble per QR. The order is in ⚙ settings", "폴더: 버블 하나 · 한 줄: QR마다 버블. 순서는 ⚙ 설정에서"),
  );

  // how it looks
  const looks = section(
    t("Look", "모양"),
    undefined,
    [],
    onDockRow,
    setting(
      t("Color", "색"),
      set.color
        ? [
            el("input", { type: "color", value: toHex(set.color) ?? "#7c6cf0", "aria-label": t("Set color", "세트 색"), "data-key": "set-color", onchange: (e: Event) => mutate((s) => (s.color = (e.target as HTMLInputElement).value)) }),
            el("button", { type: "button", onclick: () => mutate((s) => (delete s.color, delete s.colorBorderOnly)) }, t("Remove color", "색 없애기")),
          ]
        : el("button", { type: "button", "data-key": "set-color-add", onclick: () => mutate((s) => (s.color = "#7c6cf0")) }, t("Add color", "색 칠하기")),
      t("Color of the Dock bubble", "Dock 버블에 칠할 색"),
    ),
    set.color ? setting(t("Border only", "테두리만 칠하기"), toggle(!!set.colorBorderOnly, (v) => mutate((s) => (v ? (s.colorBorderOnly = true) : delete s.colorBorderOnly)), t("Border only", "테두리만 칠하기"), "set-border")) : null,
  );

  const plain = ctx.fold(
    `set-plain-${set.id}`,
    t("How text QRs send", "글 QR 보내는 방식"),
    [set.disableSend, set.injectInput].filter(Boolean).length,
    HELP().plain,
    setting(t("Don't send", "보내지 않기"), toggle(!!set.disableSend, (v) => mutate((s) => (s.disableSend = v)), t("Don't send", "보내지 않기"), "set-nosend")),
    setting(t("Add to input text", "입력창 글에 붙이기"), toggle(!!set.injectInput, (v) => mutate((s) => (s.injectInput = v)), t("Add to input text", "입력창 글에 붙이기"), "set-inject")),
    set.injectInput ? setting(t("Put before", "앞에 붙이기"), toggle(!!set.placeBeforeInput, (v) => mutate((s) => (s.placeBeforeInput = v)), t("Put before", "앞에 붙이기"), "set-before")) : null,
  );
  return [top, el("div", { style: "margin-top:10px" }, places, looks), plain];
}

function setMenu(ctx: ManagerContext, set: QrSet): HTMLElement {
  const { store, ui } = ctx.deps;
  return dropMenu(icon("more"), t("Set menu", "세트 메뉴"), [
    {
      label: t("Duplicate set", "세트 복제"),
      run: () => {
        const copy = duplicateSet(set, ctx.state);
        store.update((st) => st.sets.splice(st.sets.findIndex((s) => s.id === set.id) + 1, 0, copy));
        ctx.selectedSet = copy.id;
        ctx.selectedItem = null;
        ctx.render();
        ui.toast(t(`Made "${copy.name}".`, `"${copy.name}"을 만들었어요.`), "success");
      },
    },
    "-",
    {
      label: t("Delete set", "세트 삭제"),
      danger: true,
      run: async () => {
        if (!(await ui.popup(t(`Delete the set "${set.name}" and its ${set.items.length} QRs?`, `"${set.name}" 세트와 QR ${set.items.length}개를 삭제할까요?`), { okButton: t("Delete", "삭제"), cancelButton: t("Cancel", "취소") }))) return;
        store.update((st) => {
          st.sets = st.sets.filter((x) => x.id !== set.id);
          forgetSet(st, set.id);
          pruneDock(st);
        });
        ctx.selectedSet = ctx.state.sets[0]?.id ?? null;
        ctx.render();
      },
    },
  ]);
}

/** "#rrggbb" for the color picker. */
function toHex(color: string | undefined): string | undefined {
  if (!color) return undefined;
  if (/^#[0-9a-f]{6}$/i.test(color)) return color;
  const m = /rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)/i.exec(color);
  return m ? `#${[m[1], m[2], m[3]].map((n) => Number(n).toString(16).padStart(2, "0")).join("")}` : undefined;
}
