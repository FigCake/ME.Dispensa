// The window's ⚙ Dispensa settings, under the header's button (the whole screen on a phone): the AI
// Dispensa calls itself, and the Dock: what is on it in order, and its 🍰 / 📝 bubbles. Sets and QRs
// are put on the Dock from their own panels in the Library.

import { t } from "../../shared/i18n";
import { dockFlow, layoutOf, removeFromDock, setLayout, shownDock } from "../../qr/dock";
import { DOCK_SPAN, type DockFlow, type DockLayout } from "../../qr/model";
import { el, icon } from "../dom";
import { dragHandle, moveTo } from "../drag";
import { section, setting, toggle } from "../../shared/form";
import type { ManagerContext } from "./context";

export function settingsPop(ctx: ManagerContext, parts: { ai: HTMLElement | null; bubbles: HTMLElement[] }, close: () => void): HTMLElement {
  return el(
    "div",
    { class: "set-pop", role: "dialog", "aria-label": t("Dispensa settings", "Dispensa 설정") },
    el(
      "div",
      { class: "pop-h" },
      el("strong", { class: "grow" }, t("Dispensa settings", "Dispensa 설정")),
      el("button", { class: "icon", title: t("Close", "닫기"), "aria-label": t("Close settings", "설정 닫기"), onclick: close }, icon("x")),
    ),
    el("div", { class: "cards" }, parts.ai, dockCard(ctx, parts.bubbles)),
  );
}

function dockCard(ctx: ManagerContext, bubbles: HTMLElement[]): HTMLElement {
  const { store } = ctx.deps;
  const shown = shownDock(store.value);
  const list = el("div", { class: "list dock-list" });
  shown.forEach(({ entry, set, item }, i) => {
    const name = item?.label ?? set.name;
    const handle = el("button", { class: "drag", type: "button", title: t("Drag (or ↑↓) to reorder", "끌어서(또는 ↑↓) 순서 바꾸기"), "aria-label": t(`Reorder ${name}`, `${name} 순서 바꾸기`), "data-key": `drag-dock-${i}` }, icon("grip"));
    const glyph = (item ? item.icon : set.icon)?.trim();
    const row = el(
      "div",
      { class: "set-row" },
      handle,
      el(
        "button",
        {
          class: "entry",
          title: item ? t("Edit", "편집") : t("Open set", "세트 열기"),
          onclick: () => (item ? ctx.openItem(set.id, item.id) : ((ctx.selectedSet = set.id), (ctx.selectedItem = null), ctx.open("qr"))),
        },
        glyph ? el("span", {}, glyph) : icon(item ? "play" : "folder"),
        el("span", { class: "grow" }, name),
        el("span", { class: "meta" }, item ? `QR · ${set.name}` : t(`Set · ${set.items.filter((x) => !x.hidden).length}`, `세트 · ${set.items.filter((x) => !x.hidden).length}`)),
      ),
      item
        ? el("span")
        : el(
            "select",
            {
              class: "layout",
              title: t("Folder: one bubble · Row: a bubble per QR", "폴더: 버블 하나 · 한 줄: QR마다 버블"),
              "aria-label": t(`${set.name} layout`, `${set.name} 놓는 모양`),
              "data-key": `dock-layout-${i}`,
              onchange: (e: Event) => store.update((x) => setLayout(x, set.id, (e.target as HTMLSelectElement).value as DockLayout)),
            },
            el("option", { value: "folder", selected: layoutOf(entry, set) === "folder" }, t("Folder", "폴더")),
            el("option", { value: "row", selected: layoutOf(entry, set) === "row" }, t("Row", "한 줄")),
          ),
      el("button", { class: "icon", title: t("Remove from the Dock", "Dock에서 빼기"), "aria-label": t(`Remove ${name}`, `${name} 빼기`), onclick: () => store.update((x) => removeFromDock(x, entry)) }, icon("x")),
    );
    dragHandle(handle, row, ".set-row", (from, to) =>
      store.update((x) => {
        const entries = shownDock(x).map((e) => e.entry);
        moveTo(entries, from, to);
        x.dock = entries;
      }),
    );
    list.append(row);
  });
  // other extensions' bubbles: taken off here, put back from their own settings
  const groups = ctx.deps.dockGroups?.() ?? [];
  for (const g of groups) {
    list.append(
      el(
        "div",
        { class: "set-row" },
        el("span", { class: "drag" }),
        el("span", { class: "entry", style: "cursor:default" }, g.icon ? el("span", {}, g.icon) : icon("folder"), el("span", { class: "grow" }, g.name), el("span", { class: "meta" }, String(g.count))),
        g.remove ? el("button", { class: "icon", title: t("Remove from the Dock", "Dock에서 빼기"), "aria-label": t(`Remove ${g.name}`, `${g.name} 빼기`), onclick: () => g.remove!() }, icon("x")) : el("span"),
      ),
    );
  }
  if (!shown.length && !groups.length) list.append(el("div", { class: "note" }, t("Empty", "비어 있음")));
  const card = section(
    "Dock",
    t(
      "The same shortcuts in every chat, in this order\n· Put a set or a QR on it with 'On the Dock' in the QR library",
      "모든 채팅에서 같은 바로가기, 이 순서대로\n· 세트·QR은 QR 보관함의 'Dock에 놓기'로 넣어요",
    ),
    [],
    list,
    ...bubbles,
    overflowSetting(ctx),
    setting(
      t("🔍 Search bubble", "🔍 찾기 버블"),
      toggle(store.value.dockSearch !== false, (v) => store.update((x) => (v ? delete x.dockSearch : (x.dockSearch = false))), t("Show 🔍 bubble", "🔍 버블 보이기"), "dock-search"),
      t("Empty: recent runs on this device", "비우면 이 기기의 최근 실행"),
    ),
  );
  card.classList.add("card");
  return card;
}

/** Dock overflow and span. */
function overflowSetting(ctx: ManagerContext): HTMLElement {
  const { store } = ctx.deps;
  const { flow, span } = dockFlow(store.value);
  const flowSelect = el(
    "select",
    {
      class: "layout",
      "aria-label": t("When bubbles overflow", "넘칠 때"),
      "data-key": "dock-flow",
      onchange: (e: Event) => {
        const v = (e.target as HTMLSelectElement).value as DockFlow;
        store.update((x) => {
          // spans differ per flow: start from the default
          delete x.dockSpan;
          if (v === "wrap") delete x.dockFlow;
          else x.dockFlow = v;
        });
      },
    },
    el("option", { value: "wrap", selected: flow === "wrap" }, t("Wrap", "줄바꿈")),
    el("option", { value: "x", selected: flow === "x" }, t("Scroll sideways", "가로 스크롤")),
    el("option", { value: "y", selected: flow === "y" }, t("Scroll up and down", "세로 스크롤")),
  );
  const range = flow === "wrap" ? null : DOCK_SPAN[flow];
  const spanSelect = range
    ? el(
        "select",
        {
          class: "layout",
          "aria-label": flow === "x" ? t("Bubbles in view", "보이는 버블 수") : t("Lines in view", "보이는 줄 수"),
          "data-key": "dock-span",
          onchange: (e: Event) => store.update((x) => (x.dockSpan = Number((e.target as HTMLSelectElement).value))),
        },
        ...Array.from({ length: range.max - range.min + 1 }, (_, i) => range.min + i).map((n) =>
          el("option", { value: String(n), selected: n === span }, flow === "x" ? t(`${n} bubbles`, `${n}개`) : t(`${n} lines`, `${n}줄`)),
        ),
      )
    : null;
  return setting(
    t("When bubbles overflow", "넘칠 때"),
    spanSelect ? [flowSelect, spanSelect] : flowSelect,
    t("Scrolling keeps 🔍 ⏹ ⚙ at the end", "스크롤해도 🔍 ⏹ ⚙는 끝에 고정"),
  );
}
