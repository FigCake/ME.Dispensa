// The Library's right column: the selected set's panel, its QRs, the open QR's editor, "New QR".

import { t } from "../../shared/i18n";
import { cloneItem } from "../../qr/copy";
import { addToDock, onDock, removeFromDock } from "../../qr/dock";
import { type QrItem, type QrSet, newItem, withSteps } from "../../qr/model";
import { newStepQr } from "../../qr/steps";
import { el, icon } from "../dom";
import { dragHandle, moveTo } from "../drag";
import { dropMenu } from "../menu";
import type { ManagerContext } from "./context";
import type { QrFiles } from "./import-export";
import type { ItemEditor } from "./item-editor";
import { setPanel } from "./set-panel";

export function itemColumn(ctx: ManagerContext, editor: ItemEditor, files: QrFiles): HTMLElement {
  const set = ctx.state.sets.find((s) => s.id === ctx.selectedSet);
  const col = el("div", { class: "col" });
  if (!set) {
    col.append(el("div", { class: "empty" }, t("Pick a set or make a new one.", "세트를 고르거나 새로 만드세요.")));
    return col;
  }
  col.append(...setPanel(ctx, set, files));
  col.append(
    el(
      "div",
      { class: "row", style: "margin:14px 0 6px" },
      el("div", { class: "section", style: "margin:0" }, t(`${set.items.length} QRs`, `QR ${set.items.length}개`)),
      el("span", { class: "grow" }),
      el("button", { type: "button", onclick: () => void files.paste(set) }, icon("clipboard"), t("Paste", "붙여넣기")),
    ),
  );
  const list = el("div", { class: "list" });
  set.items.forEach((item) => {
    const handle = el("button", { class: "drag", type: "button", title: t("Drag (or ↑↓) to reorder", "끌어서(또는 ↑↓) 순서 바꾸기"), "aria-label": t(`Reorder ${item.label}`, `${item.label} 순서 바꾸기`), "data-key": `drag-qr-${item.id}` }, icon("grip"));
    const marks = [...itemMarks(item), item.hidden ? t("Hidden", "숨김") : ""].filter(Boolean);
    const row = el(
      "div",
      { class: "qrow" },
      handle,
      el(
        "button",
        {
          class: `entry${item.id === ctx.selectedItem ? " sel" : ""}`,
          onclick: () => {
            ctx.selectedItem = ctx.selectedItem === item.id ? null : item.id;
            ctx.render();
          },
        },
        item.icon?.trim() ? el("span", {}, item.icon.trim()) : icon("play"),
        el("span", { class: "grow" }, item.label || t("(no name)", "(이름 없음)")),
        marks.length ? el("span", { class: "marks", title: MARKS_TITLE() }, marks.join(" ")) : null,
        item.unsupported?.length ? el("span", { class: "warn", title: item.unsupported.join(", ") }, "⚠") : null,
        item.dialect === "st" ? el("span", { class: "meta", title: item.note ?? "" }, t("From #0", "0번부터")) : null,
      ),
      el("button", { class: "icon", title: t("Run", "실행"), "aria-label": t(`Run ${item.label}`, `${item.label} 실행`), onclick: () => ctx.deps.run(set, item) }, icon("play")),
      itemMenu(ctx, files, set, item),
    );
    dragHandle(handle, row, ".qrow", (from, to) => ctx.mutateSet(set, (s) => moveTo(s.items, from, to)));
    list.append(row);
    if (item.id === ctx.selectedItem) list.append(editor.render(set, item));
  });
  col.append(
    list,
    el(
      "div",
      { class: "row", style: "margin-top:8px" },
      newQrMenu((item) => {
        ctx.mutateSet(set, (s) => s.items.push(item));
        ctx.selectedItem = item.id;
        ctx.render();
      }),
    ),
  );
  return col;
}

/** "New QR" with the kinds a QR can start as (each is still a plain QR). */
function newQrMenu(add: (item: QrItem) => void): HTMLElement {
  return dropMenu(
    el("span", { class: "row", style: "gap:5px" }, icon("plus"), el("span", { class: "label" }, t("New QR", "새 QR"))),
    t("New QR", "새 QR"),
    [
      { label: t("QR", "일반 QR"), run: () => add(newItem(t("New QR", "새 QR"), "")) },
      {
        label: t("Easy choice QR", "쉬운 선택지 QR"),
        run: () => add(withSteps({ ...newItem(t("New easy choice QR", "새 쉬운 선택지 QR"), ""), steps: newStepQr(), icon: "🧭" })),
      },
      { label: t("Visualizer QR", "비주얼라이저 QR"), run: () => add({ ...newItem(t("New page", "새 페이지"), "/visz "), icon: "🌟" }) },
    ],
    true,
  );
}

/** ⚡ auto-run, 📚 lorebook link, ☰ sub menu. */
export function itemMarks(item: QrItem): string[] {
  return [item.auto && Object.values(item.auto).some(Boolean) ? "⚡" : "", item.automationId ? "📚" : "", item.contextList?.length ? "☰" : ""].filter(Boolean);
}

export const MARKS_TITLE = () => t("⚡ auto-run · 📚 lorebook link · ☰ sub menu", "⚡ 자동 실행 · 📚 로어북 연결 · ☰ 하위 메뉴");

/** A QR's ⋯ menu, in its set's list and in search results. */
export function itemMenu(ctx: ManagerContext, files: QrFiles, set: QrSet, item: QrItem): HTMLElement {
  const own = { kind: "qr", setId: set.id, itemId: item.id } as const;
  const docked = onDock(ctx.state, own);
  return dropMenu(icon("more"), t(`${item.label} menu`, `${item.label} 메뉴`), [
    { label: t("Copy", "복사"), run: () => void files.copyItem(item, false, set) },
    { label: t("Cut", "잘라내기"), run: () => void files.copyItem(item, true, set) },
    {
      label: t("Duplicate", "복제"),
      run: () => {
        const copy = cloneItem(item);
        copy.label = t(`${item.label} copy`, `${item.label} 복사본`);
        ctx.mutateSet(set, (s) => s.items.splice(s.items.findIndex((i) => i.id === item.id) + 1, 0, copy));
        ctx.selectedItem = copy.id;
        ctx.render();
      },
    },
    { label: t("Move to another set…", "다른 세트로 옮기기…"), run: () => void transferItems(ctx, [{ set, item }], false) },
    { label: t("Copy to another set…", "다른 세트로 복사…"), run: () => void transferItems(ctx, [{ set, item }], true) },
    "-",
    {
      // same as the editor's switch
      label: docked ? t("Remove from the Dock", "Dock에서 빼기") : t("Own bubble on the Dock", "Dock에 따로 놓기"),
      run: () => ctx.deps.store.update((st) => (docked ? removeFromDock : addToDock)(st, own)),
    },
    { label: t("Export this QR", "이 QR만 내보내기"), sub: ".mqr.json", run: () => files.exportItem(item) },
    "-",
    { label: t("Delete QR", "QR 삭제"), danger: true, run: () => ctx.removeItem(set, item) },
  ]);
}

/** Moves or copies QRs to a picked set; false if cancelled. */
export async function transferItems(ctx: ManagerContext, picked: { set: QrSet; item: QrItem }[], copy: boolean): Promise<boolean> {
  const { store, ui } = ctx.deps;
  if (!picked.length) return false;
  const from = new Set(picked.map((p) => p.set.id));
  // all from one set: that set isn't offered
  const others = ctx.state.sets.filter((s) => !(from.size === 1 && from.has(s.id)));
  if (!others.length) {
    ui.toast(t("No other set to move it to. Make another set first.", "옮길 다른 세트가 없어요. 먼저 세트를 하나 더 만드세요."), "warning");
    return false;
  }
  const labels = others.map((s, i) => `${s.name}${others.filter((o) => o.name === s.name).length > 1 ? ` (${i + 1})` : ""}`);
  const what = picked.length === 1 ? t(`"${picked[0].item.label}"`, `"${picked[0].item.label}"`) : t(`${picked.length} QRs`, `QR ${picked.length}개`);
  const [choice] = (await ui.pick?.(t(`Pick a set to ${copy ? "copy" : "move"} ${what} to.`, `${what}을 ${copy ? "복사할" : "옮길"} 세트를 고르세요.`), labels)) ?? [];
  const target = choice ? others[labels.indexOf(choice)] : undefined;
  if (!target) return false;
  store.update((st) => {
    const to = st.sets.find((s) => s.id === target.id);
    if (!to) return;
    for (const { set, item } of picked) {
      const src = st.sets.find((s) => s.id === set.id);
      const live = src?.items.find((i) => i.id === item.id);
      if (!src || !live) continue;
      if (copy) to.items.push(cloneItem(live));
      else if (src.id !== to.id) {
        src.items = src.items.filter((i) => i.id !== live.id);
        to.items.push(live);
      }
    }
  });
  if (!copy && picked.length === 1) {
    ctx.selectedSet = target.id;
    ctx.selectedItem = picked[0].item.id;
  }
  ctx.render();
  ui.toast(
    picked.length === 1
      ? t(`${copy ? "Copied" : "Moved"} to the set "${target.name}".`, `"${target.name}" 세트로 ${copy ? "복사했어요" : "옮겼어요"}.`)
      : t(`${copy ? "Copied" : "Moved"} ${what} to the set "${target.name}".`, `${what}을 "${target.name}" 세트로 ${copy ? "복사했어요" : "옮겼어요"}.`),
    "success",
  );
  return true;
}
