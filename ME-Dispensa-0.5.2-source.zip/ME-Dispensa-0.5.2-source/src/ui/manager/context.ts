// What the Dispensa window's views share (as `ctx`): dependencies, the selection and
// redrawing. QrManager (index.ts) implements it.

import type { GalleryDeps } from "../gallery-view";
import type { MemoStore } from "../../memo/store";
import type { BoardViewDeps } from "../board-view";
import type { SetNames } from "../../qr/import";
import type { QrItem, QrSet, QrState } from "../../qr/model";
import type { SearchIndex } from "../../qr/search";
import type { ChatScope } from "../../qr/scopes";
import type { QrStore } from "../../qr/store";
import type { HostUI } from "../../stscript/host";
import type { Debugger } from "../../stscript/interpreter";
import type { CommandRegistry } from "../../stscript/registry";
import type { ViszStore } from "../../visz/store";

export interface ManagerDeps {
  store: QrStore;
  registry: CommandRegistry;
  ui: HostUI;
  run(set: QrSet, item: QrItem): void;
  /** Run or debug from the editor; the result comes back. */
  runInEditor(set: QrSet, item: QrItem, options: { signal: AbortSignal; debug?: Debugger }): Promise<{ pipe: string; aborted?: string }>;
  characterName(id: string): Promise<string>;
  connections(): Promise<{ id: string; name: string }[]>;
  promptPresets?(): Promise<{ id: string; name: string }[]>;
  viszStore?: ViszStore;
  /** Other extensions' bubbles on the Dock (Fornello's scripts); `remove` takes one off. */
  dockGroups?(): { id: string; name: string; icon: string; count: number; remove?(): void }[];
  /** The Gallery tab (shown larger than in the Dock's menu). */
  gallery?: Omit<GalleryDeps, "ui" | "close" | "openWide">;
  memo?: {
    store: MemoStore;
    sendOoc(text: string): Promise<boolean>;
    putInInput(text: string): void;
    makePage(text: string): Promise<boolean>;
    runForGallery: BoardViewDeps["runForGallery"];
    openPage: BoardViewDeps["openPage"];
    fonts(): Promise<string[]>;
    useFont(family: string): void;
    /** Board pictures in the Global Gallery's Dispensa folder. */
    images: BoardViewDeps["images"];
  };
}

/** "visz" is the Library with its Visualizer panel, "dock" the Library with ⚙ settings open (both were tabs). */
export type ManagerTab = "qr" | "dock" | "memo" | "board" | "gallery" | "visz";

export interface ManagerContext {
  readonly deps: ManagerDeps;
  readonly state: QrState;
  /** The chat on screen, for the chat and character switches. */
  readonly scope: ChatScope;
  /** While the window is open. */
  readonly root: ShadowRoot | null;
  selectedSet: string | null;
  selectedItem: string | null;
  /** Library search text, kept through redraws. */
  searchQuery: string;
  /** Result chosen with ↑↓. */
  searchActive: number;
  /** Ticked QR ids. */
  readonly searchPicked: Set<string>;
  /** Rebuilt only after a change. */
  searchIndex(): SearchIndex;
  /** The Library's right column shows the Visualizer panel (null: no visualizer here). */
  viszOpen: boolean | null;
  /** `fallback` while the name is unknown. */
  characterName(id: string, fallback?: string): string;
  readonly setName: SetNames;
  /** Bytes of all stores together: they share Marinara's limit. */
  storageUsed(): number;
  render(): void;
  open(tab?: ManagerTab): void;
  openItem(setId: string, itemId: string): void;
  close(): void;
  mutateSet(set: QrSet, fn: (s: QrSet, st: QrState) => void): void;
  /** Also unselects it. */
  removeItem(set: QrSet, item: QrItem): void;
  mutateItem(set: QrSet, item: QrItem, fn: (i: QrItem) => void): void;
  /** A folded part that stays open through redraws. */
  fold(key: string, title: string, count: number, help: string | undefined, ...kids: (Node | null)[]): HTMLElement;
}
