// The Dock's 🔍 window: recent runs when empty, else matching sets and QRs. One element
// across the Dock's redraws, so the box keeps its text and focus.

import { t } from "../shared/i18n";
import { type MenuGroup, contextMenu, hasMenu } from "../qr/context";
import type { QrItem, QrSet, QrState } from "../qr/model";
import { type ItemHit, type Range, type SearchIndex, buildIndex, search } from "../qr/search";
import { el, firstGrapheme } from "./dom";
import { marked, searchBox } from "./search-box";

export interface DockSearchDeps {
  state(): QrState | null;
  /** Cached index; built per search without it. */
  index?(): SearchIndex;
  /** QRs run by hand, newest first; a sub menu run with its chained `run` and parents. */
  recent?(): { set: QrSet; item: QrItem; run?: QrItem; path?: string[]; via?: string[] }[];
  /** `via`: a sub menu entry's parent QR ids, top first. */
  run(set: QrSet, item: QrItem, via?: string[]): void;
  edit?(set: QrSet, item: QrItem): void;
}

/** Sets and QRs shown at most. */
const LIMIT = 30;
const RECENT_SHOWN = 8;
/** Pause after typing before searching. */
const WAIT_MS = 80;

type Row =
  | { kind: "set"; set: QrSet; marks?: Range[] }
  | { kind: "item"; set: QrSet; item: QrItem; run: QrItem; path: string[]; via: string[]; hidden: boolean; marks?: Range[]; line?: ItemHit["line"]; showSet: boolean };

export class DockSearch {
  readonly element: HTMLElement;
  private readonly input: HTMLInputElement;
  private readonly list: HTMLElement;
  private query = "";
  /** A set or a sub menu opened from the results. */
  private openSet: string | null = null;
  private openMenu: { set: QrSet; item: QrItem } | null = null;
  private active = 0;
  private rows: Row[] = [];
  private timer: ReturnType<typeof setTimeout> | null = null;
  private caret: [number | null, number | null] | null = null;

  constructor(private readonly deps: DockSearchDeps) {
    const { box, input } = searchBox({
      value: "",
      placeholder: t("Search QRs", "QR 찾기"),
      label: t("Search QRs", "QR 찾기"),
      onInput: (text) => {
        this.query = text;
        this.openSet = null;
        this.openMenu = null;
        if (this.timer) clearTimeout(this.timer);
        // empty: recent runs at once; text: wait for a pause
        if (!text.trim()) this.draw();
        else this.timer = setTimeout(() => ((this.timer = null), this.draw()), WAIT_MS);
      },
      move: (by) => this.move(by),
      enter: (edit) => {
        if (this.timer) {
          // Enter before the pause: search now
          clearTimeout(this.timer);
          this.timer = null;
          this.draw();
        }
        this.activate(this.rows[this.active], edit);
      },
      cleared: () => undefined,
    });
    this.input = input;
    this.list = el("div", { class: "search-list", role: "listbox", "aria-label": t("Search results", "찾은 결과") });
    this.element = el("div", { class: "pop search-pop", part: "search-pop", role: "dialog", "aria-label": t("Search QRs", "QR 찾기") }, box, this.list);
  }

  /** Fresh on each opening; focus unless opened by touch (no keyboard pop-up). */
  opened(focus: boolean): void {
    this.query = "";
    this.input.value = "";
    this.input.dispatchEvent(new Event("input"));
    this.openSet = null;
    this.openMenu = null;
    this.draw();
    if (focus) this.input.focus({ preventScroll: true });
  }

  /** Before a Dock redraw: notes focus and caret. */
  keepFocus(): boolean {
    const root = this.element.getRootNode() as ShadowRoot | Document;
    const has = root.activeElement === this.input;
    this.caret = has ? [this.input.selectionStart, this.input.selectionEnd] : null;
    return has;
  }

  /** After the redraw. */
  restoreFocus(): void {
    if (!this.caret) return;
    this.input.focus({ preventScroll: true });
    if (this.caret[0] !== null) this.input.setSelectionRange(this.caret[0], this.caret[1]);
    this.caret = null;
  }

  dispose(): void {
    if (this.timer) clearTimeout(this.timer);
  }

  private move(by: number): void {
    if (!this.rows.length) return;
    this.active = (this.active + by + this.rows.length) % this.rows.length;
    this.list.querySelectorAll(".row-main").forEach((b, i) => b.classList.toggle("active", i === this.active));
    this.list.querySelectorAll(".row-main")[this.active]?.scrollIntoView({ block: "nearest" });
  }

  private activate(row: Row | undefined, edit: boolean): void {
    if (!row) return;
    if (row.kind === "set") {
      this.openSet = row.set.id;
      this.active = 0;
      this.draw();
      return;
    }
    if (edit && this.deps.edit) {
      this.deps.edit(row.set, row.item);
      return;
    }
    // a menu-only QR opens its menu, as on the Dock
    const state = this.deps.state();
    if (!row.run.script.trim() && state && hasMenu(state, row.item)) {
      this.openMenu = { set: row.set, item: row.item };
      this.active = 0;
      this.draw();
      return;
    }
    this.deps.run(row.set, row.run, row.via.length ? row.via : undefined);
  }

  private compute(): { rows: Row[]; heads: Map<number, string>; back?: string; empty: string } {
    const state = this.deps.state();
    const heads = new Map<number, string>();
    if (!state) return { rows: [], heads, empty: "" };
    if (this.openMenu) {
      const { set, item } = this.openMenu;
      const rows: Row[] = [];
      const add = (groups: MenuGroup[], path: string[], via: string[]) => {
        for (const g of groups) {
          if (!path.length && g.entries.length) heads.set(rows.length, g.set.name);
          for (const entry of g.entries) {
            rows.push({ kind: "item", set: entry.set, item: entry.item, run: entry.run, path, via, hidden: false, showSet: false });
            add(entry.children, [...path, entry.item.label], [...via, entry.item.id]);
          }
        }
      };
      add(contextMenu(state, set, item), [], [item.id]);
      return { rows, heads, back: item.label, empty: t("Nothing in this menu", "이 메뉴는 비어 있어요") };
    }
    if (this.openSet) {
      const set = state.sets.find((s) => s.id === this.openSet);
      if (set) {
        const rows: Row[] = set.items.map((item) => ({ kind: "item", set, item, run: item, path: [], via: [], hidden: !!item.hidden, showSet: false }));
        return { rows, heads, back: set.name, empty: t("This set has no QRs", "이 세트에는 QR이 없어요") };
      }
      this.openSet = null;
    }
    if (!this.query.trim()) {
      const recent = (this.deps.recent?.() ?? []).slice(0, RECENT_SHOWN);
      const rows: Row[] = recent.map(({ set, item, run, path, via }) => ({ kind: "item", set, item, run: run ?? item, path: path ?? [], via: via ?? [], hidden: !via?.length && !!item.hidden, showSet: true }));
      if (rows.length) heads.set(0, t("Recent", "최근 실행"));
      return { rows, heads, empty: t("No QRs run yet", "아직 실행한 QR이 없어요") };
    }
    const index = this.deps.index?.() ?? buildIndex(state);
    const found = search(index, this.query, { body: true, limit: LIMIT });
    const rows: Row[] = [
      ...found.sets.map((h): Row => ({ kind: "set", set: h.set, marks: h.marks })),
      ...found.items.map((h): Row => ({ kind: "item", set: h.set, item: h.item, run: h.run, path: h.path, via: h.via, hidden: h.hidden, marks: h.marks.name, line: h.line, showSet: true })),
    ];
    if (found.sets.length) heads.set(0, t("Sets", "세트"));
    if (found.items.length) heads.set(found.sets.length, t("QR", "QR"));
    return { rows, heads, empty: t("Nothing found", "찾은 게 없어요") };
  }

  draw(): void {
    const { rows, heads, back, empty } = this.compute();
    this.rows = rows;
    this.active = Math.max(0, Math.min(this.active, rows.length - 1));
    const out: Node[] = [];
    if (back) {
      out.push(
        el(
          "div",
          { class: "head" },
          el("button", { class: "more back", type: "button", title: t("Back", "뒤로"), "aria-label": t("Back", "뒤로"), onclick: (e: Event) => (e.stopPropagation(), (this.openSet = null), (this.openMenu = null), (this.active = 0), this.draw()) }, "‹"),
          back,
        ),
      );
    }
    rows.forEach((row, i) => {
      const head = heads.get(i);
      if (head) out.push(el("div", { class: "group-h" }, head));
      out.push(this.row(row, i));
    });
    if (!rows.length) out.push(el("div", { class: "empty-note" }, empty));
    this.list.replaceChildren(...out);
  }

  private row(row: Row, i: number): HTMLElement {
    const cls = `row-main${i === this.active ? " active" : ""}`;
    if (row.kind === "set") {
      const count = row.set.items.filter((x) => !x.hidden).length;
      return el(
        "div",
        { class: "entry-row" },
        el(
          "button",
          { class: cls, part: "item", role: "option", title: row.set.name, onclick: (e: Event) => (e.stopPropagation(), (this.active = i), this.activate(row, false)) },
          document.createTextNode(`${row.set.icon?.trim() || "📁"} `),
          el("span", { class: "t" }, el("span", { class: "lab" }, marked(row.set.name, row.marks))),
          el("span", { class: "tag" }, String(count)),
          el("span", { class: "go", "aria-hidden": "true" }, "›"),
        ),
      );
    }
    const { item } = row;
    const main = el(
      "button",
      {
        class: `${cls}${row.hidden ? " dim" : ""}`,
        part: "item",
        role: "option",
        title: [item.title || item.label, row.hidden ? t("Hidden from the Dock", "Dock에서 숨김") : ""].filter(Boolean).join("\n"),
        onclick: (e: Event) => {
          e.stopPropagation();
          const me = e as MouseEvent;
          this.activate(row, me.ctrlKey || me.metaKey);
        },
      },
      item.icon?.trim() ? document.createTextNode(`${firstGrapheme(item.icon)} `) : null,
      el(
        "span",
        { class: "t" },
        el("span", { class: "lab" }, row.path.length ? `${row.path.join(" › ")} › ` : "", marked(item.label, row.marks)),
        row.line ? el("span", { class: "line" }, marked(row.line.text, row.line.marks)) : null,
      ),
      row.hidden ? el("span", { class: "tag" }, t("Hidden", "숨김")) : null,
      row.showSet ? el("span", { class: "tag" }, row.set.name) : null,
    );
    const edit = this.deps.edit
      ? el("button", { class: "more", type: "button", title: t("Edit (Ctrl+click)", "편집 (Ctrl+클릭)"), "aria-label": t(`Edit ${item.label}`, `${item.label} 편집`), onclick: (e: Event) => (e.stopPropagation(), this.deps.edit!(row.set, item)) }, "✎")
      : null;
    return el("div", { class: "entry-row" }, main, edit);
  }
}

export const DOCK_SEARCH_CSS = `
.search-pop { width: min(360px, calc(100vw - 16px)); padding-top: 0; }
.search-pop > .search-box { position: sticky; top: 0; z-index: 1; margin: 0 -6px; padding: 6px 6px 4px; background: var(--d-panel-solid); }
.search-pop > .search-box > svg { left: 14px; }
.search-pop > .search-box > .search-clear { right: 9px; width: auto; }
.search-pop .search-list { display: flex; flex-direction: column; gap: 4px; }
.search-pop .row-main.active { border-color: var(--d-btn-border-hover); background: var(--d-hl-bg); }
.search-pop .row-main.dim { opacity: .6; }
.search-pop .row-main > .t { display: flex; flex-direction: column; }
.search-pop .row-main .lab { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.search-pop .row-main .line { font: 11px/1.3 var(--d-mono); color: var(--d-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.search-pop .row-main .tag { flex: none; max-width: 38%; margin-left: 6px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 11px; font-weight: 500; color: var(--d-muted); }
.search-pop .row-main .go { flex: none; margin-left: 6px; color: var(--d-muted); }
.search-pop .head { display: flex; align-items: center; gap: 6px; }
.search-pop .head > .back { width: auto; padding: 2px 8px; }
.search-pop .empty-note { padding: 8px 6px; color: var(--d-muted); }
`;
