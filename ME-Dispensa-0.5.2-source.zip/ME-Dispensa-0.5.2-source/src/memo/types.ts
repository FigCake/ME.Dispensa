// The saved shapes of memos and boards. Only types, so every memo module can import them
// (board.ts, board-frame.ts and model.ts would import each other otherwise).

import type { BoardLook } from "./board-themes";

/** Where a memo shows: one chat, or the chats these characters are in. No owner: every chat. */
export type MemoOwner = { chatId: string } | { characterIds: string[] };

export interface Memo {
  id: string;
  /** Shown in lists instead of the text, when set. */
  title?: string;
  text: string;
  /** Pinned: always listed in the 📝 bubble. */
  pinned?: boolean;
  createdAt: number;
  owner?: MemoOwner;
  /** The folder it is in (the notebook view of the 📋 tab); none: only under "All memos". */
  folder?: string;
}

export interface BoardImage {
  id: string;
  url: string;
}

/** Column, row, and how many of each it spans in the section layout. */
export interface BoardCell {
  c: number;
  r: number;
  w: number;
  h: number;
}

export interface BoardCard {
  memoId: string;
  x: number;
  y: number;
  /** Width in board pixels; the height follows the memo. */
  w: number;
  /** Degrees, -30 … 30. */
  rotate?: number;
  color?: string;
  z: number;
  cell?: BoardCell;
}

export interface BoardMagnet {
  id: string;
  image: BoardImage;
  x: number;
  y: number;
  /** Width in board pixels (the picture keeps its shape). */
  size: number;
  rotate?: number;
  z: number;
  cell?: BoardCell;
  /**
   * In the section layout: a sticker on top of the sections instead of filling one. x and w are
   * shares of the sections' width, y counts section rows from the top, so it stays over the same
   * sections whatever the screen.
   */
  sticker?: BoardSticker;
  /** A picture of a Gallery page: a tap opens the page where this browser has it. */
  page?: { archiveId: string; title: string };
}

export interface BoardSticker {
  x: number;
  y: number;
  w: number;
}

export interface Board {
  id: string;
  name: string;
  createdAt: number;
  background?: { image?: BoardImage };
  theme?: BoardLook;
  /** "frame": the section layout (board-frame.ts); free placement otherwise. */
  layout?: "frame";
  cols?: number;
  headCell?: BoardCell;
  /** false: cards show no number. */
  numbers?: false;
  cards: BoardCard[];
  magnets: BoardMagnet[];
}
