import type { Dialect } from "../stscript/host";
import { t } from "../shared/i18n";
import { newId } from "../util";
import { type StepQr, normalizeStepQr, stepsScript } from "./steps";

/** Auto-run triggers in SillyTavern's order. `st`: field in SillyTavern's QR files, `info`: in /qr-get's result, `arg`: /qr-create argument. */
export const AUTO_TRIGGERS = [
  { key: "startup", st: "executeOnStartup", info: "startup", arg: "startup" },
  { key: "user", st: "executeOnUser", info: "user", arg: "user" },
  { key: "ai", st: "executeOnAi", info: "bot", arg: "bot" },
  { key: "chatChange", st: "executeOnChatChange", info: "load", arg: "load" },
  { key: "newChat", st: "executeOnNewChat", info: "newChat", arg: "new" },
  { key: "groupDraft", st: "executeOnGroupMemberDraft", info: "group", arg: "group" },
  { key: "beforeGeneration", st: "executeBeforeGeneration", info: "generation", arg: "generation" },
] as const;

export type AutoTrigger = (typeof AUTO_TRIGGERS)[number]["key"];

export interface QrItem {
  id: string;
  label: string;
  /** Tooltip. */
  title?: string;
  /** STscript, or plain text to send. */
  script: string;
  dialect: Dialect;
  icon?: string;
  /** With an icon: false shows only the icon in menus (SillyTavern's showLabel). */
  showLabel?: boolean;
  /** Sets opened as a sub menu of this QR (right-click / long-press); chained items run this QR first. */
  contextList?: QrContextLink[];
  /** Hidden from the Dock (still runnable with /run or auto triggers). */
  hidden?: boolean;
  auto?: Partial<Record<AutoTrigger, boolean>>;
  /** Runs when a lorebook entry with this name (or id) comes into play (SillyTavern's automationId). */
  automationId?: string;
  /** While this QR runs, other QRs' auto-runs wait it out (SillyTavern's preventAutoExecute; unset = on). */
  preventAuto?: boolean;
  /** Commands the interpreter does not know (filled in on import/save). */
  unsupported?: string[];
  /** Why an imported QR still runs with SillyTavern numbering. */
  note?: string;
  /** A step QR: its steps and prompt; `script` is made from them (steps.ts). */
  steps?: StepQr;
}

/** A set shown as a QR's sub menu. */
interface QrContextLink {
  setId: string;
  /** Run the parent QR's script first, then the picked item (SillyTavern's "chain"). */
  chained?: boolean;
}

export interface QrSet {
  id: string;
  name: string;
  items: QrItem[];
  /** "folder": one chip that opens the items. "inline": items sit on the Dock. */
  display: "folder" | "inline";
  /** On in every chat (SillyTavern's global set list). Chat and character sets live in QrState. */
  enabled: boolean;
  color?: string;
  /** Use the color for the outline only (SillyTavern's onlyBorderColor). */
  colorBorderOnly?: boolean;
  /** The bubble's icon on the Dock (an emoji). */
  icon?: string;
  origin: "st" | "dispensa";
  /** One of Dispensa's own sets (found by this, whatever its name in either language). */
  builtin?: "visz" | "dock";
  /** SillyTavern set options for plain-text items. */
  disableSend?: boolean;
  placeBeforeInput?: boolean;
  injectInput?: boolean;
}

/** One bubble of the Dock: a set (a folder, or its QRs side by side) or one QR. */
export type DockEntry = { kind: "set"; setId: string; layout?: DockLayout } | { kind: "qr"; setId: string; itemId: string };

/** A set on the Dock: one folder bubble, or its QRs as bubbles on a line of their own. */
export type DockLayout = "folder" | "row";

export interface QrState {
  version: 1;
  sets: QrSet[];
  dockVisible: boolean;
  /** What the Dock shows, in order, in every chat. */
  dock: DockEntry[];
  /** Sets turned on for one chat (chat id → set ids). */
  chatSets: Record<string, string[]>;
  /** Sets turned on for one character, in every chat with them (character id → set ids). */
  charSets: Record<string, string[]>;
  /** The 🔍 bubble (unset: shown). */
  dockSearch?: boolean;
  /** More bubbles than fit: wrap (unset), scroll sideways or up and down. */
  dockFlow?: DockFlow;
  /** Bubbles (x, 8–16) or lines (y, 1–4) in view; unset: the default. */
  dockSpan?: number;
}

export type DockFlow = "wrap" | "x" | "y";

/** Span range and default per scrolling flow. */
export const DOCK_SPAN = { x: { min: 8, max: 16, default: 16 }, y: { min: 1, max: 4, default: 2 } } as const;

/** dockVisible: the switch by the input box; on, the Dock comes up on hover or touch. */
export const emptyState = (): QrState => ({ version: 1, sets: [], dockVisible: false, dock: [], chatSets: {}, charSets: {} });

export function newSet(name: string, origin: QrSet["origin"] = "dispensa"): QrSet {
  return { id: newId("set"), name, items: [], display: "folder", enabled: true, origin };
}

export function newItem(label: string, script: string, dialect: Dialect = "marinara"): QrItem {
  return { id: newId("qr"), label, script, dialect };
}

export function normalizeState(raw: unknown): QrState {
  const base = emptyState();
  if (!raw || typeof raw !== "object") return base;
  const r = raw as Partial<QrState>;
  return {
    version: 1,
    dockVisible: r.dockVisible === true,
    dock: Array.isArray(r.dock) ? dockEntries(r.dock) : [],
    chatSets: idLists(r.chatSets),
    charSets: idLists(r.charSets),
    ...dockOptions(r),
    sets: Array.isArray(r.sets)
      ? r.sets.map((s) => ({
          ...newSet(String(s?.name ?? t("Set", "세트"))),
          ...s,
          items: Array.isArray(s?.items) ? s.items.map((i) => withSteps({ ...newItem(String(i?.label ?? "QR"), String(i?.script ?? "")), ...i })) : [],
        }))
      : [],
  };
}

/** Normalizes a step QR's steps and rebuilds its script from them, so what runs follows the steps. */
export function withSteps(item: QrItem): QrItem {
  if (item.steps === undefined) return item;
  const steps = normalizeStepQr(item.steps);
  if (!steps) {
    delete item.steps;
    return item;
  }
  return { ...item, steps, script: stepsScript(steps), dialect: "marinara" };
}

/** Keeps valid values; a span out of range is clamped. */
function dockOptions(r: Partial<QrState>): Pick<QrState, "dockSearch" | "dockFlow" | "dockSpan"> {
  const out: Pick<QrState, "dockSearch" | "dockFlow" | "dockSpan"> = {};
  if (typeof r.dockSearch === "boolean") out.dockSearch = r.dockSearch;
  const flow = r.dockFlow === "x" || r.dockFlow === "y" ? r.dockFlow : undefined;
  if (flow) out.dockFlow = flow;
  if (flow && typeof r.dockSpan === "number" && Number.isFinite(r.dockSpan)) {
    const { min, max } = DOCK_SPAN[flow];
    out.dockSpan = Math.max(min, Math.min(max, Math.round(r.dockSpan)));
  }
  return out;
}

function dockEntries(raw: unknown[]): DockEntry[] {
  return raw.flatMap((e): DockEntry[] => {
    const x = e as Partial<{ kind: string; setId: unknown; itemId: unknown }>;
    if (typeof x?.setId !== "string") return [];
    if (x.kind === "set") return [{ kind: "set", setId: x.setId, ...((x as { layout?: unknown }).layout === "row" || (x as { layout?: unknown }).layout === "folder" ? { layout: (x as { layout: DockLayout }).layout } : {}) }];
    if (x.kind === "qr" && typeof x.itemId === "string") return [{ kind: "qr", setId: x.setId, itemId: x.itemId }];
    return [];
  });
}

function idLists(raw: unknown): Record<string, string[]> {
  const out: Record<string, string[]> = {};
  if (!raw || typeof raw !== "object") return out;
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    const ids = Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
    if (ids.length) out[k] = [...new Set(ids)];
  }
  return out;
}

/** One of Dispensa's own sets, by its mark. */
export function builtinSet(state: QrState, kind: NonNullable<QrSet["builtin"]>): QrSet | undefined {
  return state.sets.find((s) => s.builtin === kind);
}

/** Find a QR for /run: "Set.Label" first as a label, then set + label. */
export function findItem(state: QrState, name: string): { set: QrSet; item: QrItem } | undefined {
  for (const set of state.sets) {
    const item = set.items.find((i) => i.label === name);
    if (item) return { set, item };
  }
  const dot = name.indexOf(".");
  if (dot > 0) {
    const setName = name.slice(0, dot);
    const label = name.slice(dot + 1);
    const set = state.sets.find((s) => s.name === setName);
    const item = set?.items.find((i) => i.label === label);
    if (set && item) return { set, item };
  }
  return undefined;
}
