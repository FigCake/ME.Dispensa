// Search over sets and QRs. Case and width are folded; a consonant alone matches a Hangul
// initial in names (ㅂㅈ → 비주얼라이저).

import { type MenuGroup, contextMenu } from "./context";
import type { QrItem, QrSet, QrState } from "./model";

/** Start and end in the original text. */
export type Range = [start: number, end: number];

export type HitField = "name" | "title" | "icon" | "lore" | "path" | "body";

/** Text folded for matching, with where each folded character came from. */
interface Folded {
  raw: string;
  norm: string;
  /** Raw start and end per folded character; null when one to one. */
  from: number[] | null;
  to: number[] | null;
  /** Hangul initials (names only). */
  cho?: string;
}

interface IndexedSet {
  set: QrSet;
  name: Folded;
}

interface IndexedItem {
  set: QrSet;
  item: QrItem;
  run: QrItem;
  path: string[];
  via: string[];
  name: Folded;
  title?: Folded;
  icon?: Folded;
  lore?: Folded;
  parents?: Folded;
  /** Folded script (plain QRs only). */
  body?: string;
}

export interface SearchIndex {
  sets: IndexedSet[];
  /** Library order; sub menu entries follow their QR. */
  items: IndexedItem[];
}

export interface SetHit {
  set: QrSet;
  score: number;
  /** In the set's name. */
  marks: Range[];
}

export interface ItemHit {
  set: QrSet;
  item: QrItem;
  /** What a press runs (a sub menu entry: with its chained script). */
  run: QrItem;
  /** A sub menu entry's parent QRs; empty otherwise. */
  path: string[];
  /** Their ids, top first. */
  via: string[];
  /** Hidden from the Dock (never a sub menu entry). */
  hidden: boolean;
  score: number;
  fields: HitField[];
  marks: Partial<Record<Exclude<HitField, "body">, Range[]>>;
  /** The matched script line, shortened, with marks. */
  line?: { text: string; marks: Range[] };
}

export interface SearchResult {
  sets: SetHit[];
  items: ItemHit[];
}

export interface SearchOptions {
  /** Look in scripts too. */
  body?: boolean;
  /** Sets and QRs together, sets first. */
  limit?: number;
  /** Include sub menu entries ("Parent › Entry"). */
  menus?: boolean;
}

// ── folding ──

const CHO = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ";
/** Runs that fold one to one (ASCII, Hangul syllables). */
const PLAIN_RUN = /[\t\n\r\x20-\x7F\uAC00-\uD7A3]+(?![\p{M}\u1160-\u11FF\uD7B0-\uD7FF])/gu;
/** A character with its combining marks and jamo. */
const CLUSTER = /.[\p{M}\u1160-\u11FF\uD7B0-\uD7FF]*/gsu;
const COMPAT_JAMO = /^[\u3131-\u318E]$/;

const isConsonant = (c: string) => c >= "\u3131" && c <= "\u314E";

function foldCluster(c: string): string {
  // NFKC would turn ㅂ into a conjoining jamo
  if (COMPAT_JAMO.test(c)) return c;
  return c
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[\u1100-\u1112]/g, (j) => CHO[j.charCodeAt(0) - 0x1100]);
}

/** Folds `raw`; with `track`, also keeps where each folded character came from. */
function foldText(raw: string, track: boolean): Folded {
  const parts: string[] = [];
  let length = 0;
  let from: number[] | null = null;
  let to: number[] | null = null;
  const push = (folded: string, at: number, size: number) => {
    if (track && !from && folded.length !== size) {
      // from the first length change on, keep positions one by one
      from = Array.from({ length }, (_, i) => i);
      to = from.map((i) => i + 1);
    }
    if (from && to) {
      for (let i = 0; i < folded.length; i++) {
        // a changed length maps each folded character to the whole cluster
        const same = folded.length === size;
        from.push(same ? at + i : at);
        to.push(same ? at + i + 1 : at + size);
      }
    }
    parts.push(folded);
    length += folded.length;
  };
  const other = (start: number, end: number) => {
    if (start >= end) return;
    for (const m of raw.slice(start, end).matchAll(CLUSTER)) push(foldCluster(m[0]), start + m.index, m[0].length);
  };
  let last = 0;
  for (const m of raw.matchAll(PLAIN_RUN)) {
    other(last, m.index);
    push(m[0].toLowerCase(), m.index, m[0].length);
    last = m.index + m[0].length;
  }
  other(last, raw.length);
  return { raw, norm: parts.join(""), from, to };
}

/** Hangul initial per character (others unchanged). */
function initials(norm: string): string {
  let out = "";
  for (let i = 0; i < norm.length; i++) {
    const code = norm.charCodeAt(i);
    out += code >= 0xac00 && code <= 0xd7a3 ? CHO[Math.floor((code - 0xac00) / 588)] : norm[i];
  }
  return out;
}

/** A whole script at once (fast); only lines are needed, not positions. */
function foldScript(raw: string): string {
  return raw
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[\u1100-\u1112]/g, (j) => CHO[j.charCodeAt(0) - 0x1100]);
}

function foldName(raw: string): Folded {
  const f = foldText(raw, true);
  f.cho = initials(f.norm);
  return f;
}

const foldOptional = (raw: string | undefined): Folded | undefined => (raw?.trim() ? foldText(raw, true) : undefined);

/** The folded range [s, e) in the original text. */
function rawRange(f: Folded, s: number, e: number): Range {
  return f.from && f.to ? [f.from[s], f.to[e - 1]] : [s, e];
}

function merge(ranges: Range[]): Range[] {
  const sorted = [...ranges].sort((a, b) => a[0] - b[0]);
  const out: Range[] = [];
  for (const r of sorted) {
    const last = out[out.length - 1];
    if (last && r[0] <= last[1]) last[1] = Math.max(last[1], r[1]);
    else out.push([r[0], r[1]]);
  }
  return out;
}

// ── the index ──

/** Cap on sub menu entries (nested menus multiply). */
const MAX_MENU_ENTRIES = 5000;

/** `menus: false` skips sub menu entries. */
export function buildIndex(state: QrState, options: { menus?: boolean } = {}): SearchIndex {
  const sets: IndexedSet[] = [];
  const items: IndexedItem[] = [];
  let menuEntries = 0;
  const addMenu = (groups: MenuGroup[], path: string[], via: string[]) => {
    for (const g of groups) {
      for (const entry of g.entries) {
        if (menuEntries++ >= MAX_MENU_ENTRIES) return;
        items.push({ set: entry.set, item: entry.item, run: entry.run, path, via, name: foldName(entry.item.label), parents: foldText(path.join(" › "), true) });
        if (entry.children.length) addMenu(entry.children, [...path, entry.item.label], [...via, entry.item.id]);
      }
    }
  };
  for (const set of state.sets) {
    sets.push({ set, name: foldName(set.name) });
    for (const item of set.items) {
      items.push({
        set,
        item,
        run: item,
        path: [],
        via: [],
        name: foldName(item.label),
        title: foldOptional(item.title),
        icon: foldOptional(item.icon),
        lore: foldOptional(item.automationId),
        body: item.script ? foldScript(item.script) : undefined,
      });
      if ((options.menus ?? true) && item.contextList?.length) addMenu(contextMenu(state, set, item), [item.label], [item.id]);
    }
  }
  return { sets, items };
}

/** Rebuilt when the state object changes or after `invalidate()`. */
export function indexCache(options: { menus?: boolean } = {}): { get(state: QrState): SearchIndex; invalidate(): void } {
  let state: QrState | null = null;
  let index: SearchIndex | null = null;
  return {
    get(now) {
      if (now !== state || !index) {
        state = now;
        index = buildIndex(now, options);
      }
      return index;
    },
    invalidate() {
      index = null;
    },
  };
}

// ── matching ──

interface Term {
  text: string;
  /** Has a consonant typed alone. */
  cho: boolean;
}

/** How well a name matched, best first. */
const SCORE = { exact: 100, prefix: 80, word: 60, contains: 40, initials: 20, other: 10, body: 5 } as const;

function parseQuery(query: string): { terms: Term[]; whole: string } {
  const texts = foldText(query, false).norm.split(/\s+/).filter(Boolean);
  return { terms: texts.map((text) => ({ text, cho: [...text].some(isConsonant) })), whole: texts.join(" ") };
}

const WORD = /[\p{L}\p{N}]/u;

/** A term's best place in a name: start, word start, anywhere, initials. */
function inName(f: Folded, term: Term): { score: number; at: number } | null {
  let first = -1;
  for (let at = f.norm.indexOf(term.text); at >= 0; at = f.norm.indexOf(term.text, at + 1)) {
    if (at === 0) return { score: SCORE.prefix, at };
    if (!WORD.test(f.norm[at - 1])) return { score: SCORE.word, at };
    if (first < 0) first = at;
  }
  if (first >= 0) return { score: SCORE.contains, at: first };
  if (!term.cho || !f.cho) return null;
  const n = term.text.length;
  outer: for (let p = 0; p + n <= f.norm.length; p++) {
    for (let i = 0; i < n; i++) {
      const q = term.text[i];
      if (isConsonant(q) ? f.cho[p + i] !== q : f.norm[p + i] !== q) continue outer;
    }
    return { score: SCORE.initials, at: p };
  }
  return null;
}

const isExact = (f: Folded, whole: string) => f.norm.trim().split(/\s+/).join(" ") === whole;

function scoreSet(x: IndexedSet, terms: Term[], whole: string): SetHit | null {
  if (isExact(x.name, whole)) return { set: x.set, score: SCORE.exact, marks: [[0, x.name.raw.length]] };
  let score: number = SCORE.exact;
  const marks: Range[] = [];
  for (const term of terms) {
    const m = inName(x.name, term);
    if (!m) return null;
    score = Math.min(score, m.score);
    marks.push(rawRange(x.name, m.at, m.at + term.text.length));
  }
  return { set: x.set, score, marks: merge(marks) };
}

function scoreItem(x: IndexedItem, terms: Term[], whole: string, body: boolean): ItemHit | null {
  const fields = new Set<HitField>();
  const marks: ItemHit["marks"] = {};
  const mark = (field: Exclude<HitField, "body">, f: Folded, at: number, term: Term) => {
    fields.add(field);
    (marks[field] ??= []).push(rawRange(f, at, at + term.text.length));
  };
  const exact = isExact(x.name, whole);
  if (exact) {
    fields.add("name");
    marks.name = [[0, x.name.raw.length]];
  }
  let score: number = SCORE.exact;
  for (const term of terms) {
    let best = 0;
    const m = exact ? null : inName(x.name, term);
    if (m) {
      best = m.score;
      mark("name", x.name, m.at, term);
    }
    if (exact) best = SCORE.exact;
    for (const field of ["title", "icon", "lore"] as const) {
      const f = x[field];
      const at = f ? f.norm.indexOf(term.text) : -1;
      if (f && at >= 0) {
        best = Math.max(best, SCORE.other);
        mark(field, f, at, term);
      }
    }
    if (x.parents) {
      const at = x.parents.norm.indexOf(term.text);
      if (at >= 0) {
        best = Math.max(best, SCORE.other);
        mark("path", x.parents, at, term);
      }
    }
    if (body && x.body && x.body.includes(term.text)) {
      best = Math.max(best, SCORE.body);
      fields.add("body");
    }
    if (!best) return null;
    score = Math.min(score, best);
  }
  for (const k of Object.keys(marks) as (keyof typeof marks)[]) marks[k] = merge(marks[k]!);
  return { set: x.set, item: x.item, run: x.run, path: x.path, via: x.via, hidden: !!x.item.hidden && !x.path.length, score, fields: [...fields], marks };
}

/** Longer script lines are cut around the match. */
const LINE_MAX = 90;

/** The line of the first match, every term marked. */
function scriptLine(raw: string, folded: string, terms: Term[]): { text: string; marks: Range[] } {
  let at = -1;
  for (const term of terms) {
    const i = folded.indexOf(term.text);
    if (i >= 0 && (at < 0 || i < at)) at = i;
  }
  // folding keeps newlines, so line numbers match
  let lineNo = 0;
  for (let i = folded.indexOf("\n"); i >= 0 && i < at; i = folded.indexOf("\n", i + 1)) lineNo++;
  let start = 0;
  for (let n = 0; n < lineNo; n++) start = raw.indexOf("\n", start) + 1;
  const end = raw.indexOf("\n", start);
  let line = raw.slice(start, end < 0 ? raw.length : end).trim();
  if (line.length > LINE_MAX) {
    const f = foldText(line, true);
    let pos = 0;
    for (const term of terms) {
      const i = f.norm.indexOf(term.text);
      if (i >= 0) {
        pos = rawRange(f, i, i + term.text.length)[0];
        break;
      }
    }
    const from = Math.max(0, Math.min(pos - 30, line.length - LINE_MAX));
    line = `${from > 0 ? "…" : ""}${line.slice(from, from + LINE_MAX)}${from + LINE_MAX < line.length ? "…" : ""}`;
  }
  const f = foldText(line, true);
  const marks: Range[] = [];
  for (const term of terms) {
    for (let i = f.norm.indexOf(term.text); i >= 0; i = f.norm.indexOf(term.text, i + term.text.length)) marks.push(rawRange(f, i, i + term.text.length));
  }
  return { text: line, marks: merge(marks) };
}

/** Every word must match. Sets first, then QRs; by score, then Library order. */
export function search(index: SearchIndex, query: string, options: SearchOptions = {}): SearchResult {
  const { terms, whole } = parseQuery(query);
  if (!terms.length) return { sets: [], items: [] };
  const limit = options.limit ?? Infinity;
  const sets = index.sets.flatMap((x) => scoreSet(x, terms, whole) ?? []);
  const folded = new Map<ItemHit, string>();
  const items = index.items.flatMap((x) => {
    if (!(options.menus ?? true) && x.path.length) return [];
    const hit = scoreItem(x, terms, whole, !!options.body);
    if (hit && x.body && hit.fields.includes("body")) folded.set(hit, x.body);
    return hit ?? [];
  });
  // stable sort: ties keep Library order, a QR before its sub menu copies
  sets.sort((a, b) => b.score - a.score);
  items.sort((a, b) => b.score - a.score || (a.path.length ? 1 : 0) - (b.path.length ? 1 : 0));
  const shownSets = sets.slice(0, limit);
  const shownItems = items.slice(0, Math.max(0, limit - shownSets.length));
  // lines only for shown hits
  for (const hit of shownItems) {
    const body = folded.get(hit);
    if (body) hit.line = scriptLine(hit.item.script, body, terms);
  }
  return { sets: shownSets, items: shownItems };
}
