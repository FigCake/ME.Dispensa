// QRs run by hand, newest first. Kept in this browser, not in Marinara's storage,
// so a run doesn't re-save the Library.

import { type MenuGroup, contextMenu } from "./context";
import type { QrItem, QrSet, QrState } from "./model";

export interface RecentRun {
  setId: string;
  itemId: string;
  at: number;
  /** A sub menu run: the QR ids from the top QR down to this one's parent. */
  via?: string[];
}

/** A recent run as shown: `run` is what a press runs (a sub menu entry: with its chained script). */
export interface ShownRun {
  set: QrSet;
  item: QrItem;
  run: QrItem;
  /** Parent QRs' names (a sub menu run); empty otherwise. */
  path: string[];
  via?: string[];
  at: number;
}

export interface RecentStorage {
  read(): string | null;
  write(text: string): void;
}

export const RECENT_KEY = "dispensa:qr-recent";
export const RECENT_MAX = 20;

/** Anything broken reads as empty. */
export function parseRecent(text: string | null): RecentRun[] {
  if (!text) return [];
  try {
    const raw = JSON.parse(text) as unknown;
    if (!Array.isArray(raw)) return [];
    return raw
      .filter((r): r is RecentRun => !!r && typeof r === "object" && typeof r.setId === "string" && typeof r.itemId === "string" && typeof r.at === "number" && Number.isFinite(r.at))
      .map(({ setId, itemId, at, via }) => ({ setId, itemId, at, ...(validVia(via) ? { via: [...via] } : {}) }))
      .slice(0, RECENT_MAX);
  } catch {
    return [];
  }
}

/** An older record has no `via`; a broken one reads as a plain run. */
const validVia = (via: unknown): via is string[] => Array.isArray(via) && via.length > 0 && via.every((id) => typeof id === "string");

/** The same QR through another menu path is another run. */
const sameRun = (a: RecentRun, b: RecentRun) => a.itemId === b.itemId && (a.via ?? []).join("\u0000") === (b.via ?? []).join("\u0000");

/** A QR run again moves to the front. */
export function addRecent(list: RecentRun[], run: RecentRun): RecentRun[] {
  return [run, ...list.filter((r) => !sameRun(r, run))].slice(0, RECENT_MAX);
}

const findItem = (state: QrState, id: string) => {
  for (const set of state.sets) {
    const item = set.items.find((i) => i.id === id);
    if (item) return { set, item };
  }
  return undefined;
};

/** Follows `via` through the sub menus again; undefined when the path is broken. */
function throughMenus(state: QrState, via: string[], itemId: string): Omit<ShownRun, "at" | "via"> | undefined {
  const top = findItem(state, via[0]);
  if (!top) return undefined;
  const path = [top.item.label];
  let groups: MenuGroup[] = contextMenu(state, top.set, top.item);
  // down through the parents, then the QR itself
  for (const id of [...via.slice(1), itemId]) {
    const entry = groups.flatMap((g) => g.entries).find((e) => e.item.id === id);
    if (!entry) return undefined;
    if (path.length === via.length) return { set: entry.set, item: entry.item, run: entry.run, path };
    path.push(entry.item.label);
    groups = entry.children;
  }
  return undefined;
}

/** Skips QRs that are gone and sub menu runs whose path is broken; a moved QR is found by id. */
export function recentItems(state: QrState, list: RecentRun[], limit = RECENT_MAX): ShownRun[] {
  const out: ShownRun[] = [];
  for (const r of list) {
    if (out.length >= limit) break;
    if (r.via) {
      const hit = throughMenus(state, r.via, r.itemId);
      if (hit) out.push({ ...hit, via: r.via, at: r.at });
      continue;
    }
    const hit = findItem(state, r.itemId);
    if (hit) out.push({ ...hit, run: hit.item, path: [], at: r.at });
  }
  return out;
}

export class RecentRuns {
  constructor(
    private readonly storage: RecentStorage,
    private readonly now: () => number = Date.now,
  ) {}

  list(): RecentRun[] {
    try {
      return parseRecent(this.storage.read());
    } catch {
      return [];
    }
  }

  /** `via`: a sub menu run's parent QR ids, top first. */
  record(set: QrSet, item: QrItem, via?: string[]): void {
    try {
      this.storage.write(JSON.stringify(addRecent(this.list(), { setId: set.id, itemId: item.id, at: this.now(), ...(via?.length ? { via: [...via] } : {}) })));
    } catch {
      // blocked or full: not worth an error
    }
  }

  shown(state: QrState, limit?: number): ShownRun[] {
    return recentItems(state, this.list(), limit);
  }
}

/** localStorage, or nothing when blocked. */
export function localRecentStorage(key = RECENT_KEY): RecentStorage {
  return {
    read: () => {
      try {
        return globalThis.localStorage?.getItem(key) ?? null;
      } catch {
        return null;
      }
    },
    write: (text) => {
      try {
        globalThis.localStorage?.setItem(key, text);
      } catch {
        // blocked or full
      }
    },
  };
}
