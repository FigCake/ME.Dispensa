// Lets scripts manage Quick Replies and the Dock (the /qr-* commands).

import type { Dialect, QrControl, QrInfo, QrRef, QrSetOptions, ScriptSource } from "../stscript/host";
import { emojiForIcon } from "./icons";
import { AUTO_TRIGGERS, type QrItem, type QrSet, type QrState, findItem, newItem, newSet } from "./model";
import type { QrRunner } from "./runner";
import { addToDock, pruneDock, removeFromDock, setLayout } from "./dock";
import { type ChatScope, NO_CHAT, activeSets, forgetSet, isOnForChat, setForChat } from "./scopes";
import type { QrStore } from "./store";
import { t } from "../shared/i18n";

export function createQrControl(store: QrStore, runner: () => QrRunner, scope: () => ChatScope = () => NO_CHAT): QrControl & { dispose(): void } {
  const timers = new Set<ReturnType<typeof setTimeout>>();
  const findSet = (st: QrState, name: string) => st.sets.find((s) => s.name === name);
  const findIn = (st: QrState, ref: QrRef): { set: QrSet; item: QrItem } | undefined => {
    const set = findSet(st, ref.set);
    if (!set) return undefined;
    const item = ref.id !== undefined ? set.items[ref.id - 1] : set.items.find((i) => i.label === ref.label);
    return item ? { set, item } : undefined;
  };
  const setName = (id: string) => store.value.sets.find((s) => s.id === id)?.name;
  const apply = (item: QrItem, changes: Partial<QrInfo>) => {
    if (changes.title !== undefined) item.title = changes.title || undefined;
    if (changes.message !== undefined) {
      item.script = changes.message;
      // a script written over a step QR makes it a plain script QR (the steps would make the old one again)
      delete item.steps;
    }
    if (changes.hidden !== undefined) item.hidden = changes.hidden;
    if (changes.icon !== undefined) {
      const icon = changes.icon.trim();
      item.icon = icon.startsWith("fa") ? emojiForIcon(icon) : icon || undefined;
    }
    if (changes.showLabel !== undefined) {
      if (changes.showLabel) delete item.showLabel;
      else item.showLabel = false;
    }
    const auto = { ...item.auto };
    for (const { key, info } of AUTO_TRIGGERS) {
      const v = changes[info];
      if (v === undefined) continue;
      if (v) auto[key] = true;
      else delete auto[key];
    }
    item.auto = Object.keys(auto).length ? auto : undefined;
  };
  const setOptions = (set: QrSet, o: QrSetOptions) => {
    if (o.nosend !== undefined) set.disableSend = o.nosend;
    if (o.before !== undefined) set.placeBeforeInput = o.before;
    if (o.inject !== undefined) set.injectInput = o.inject;
    if (o.color !== undefined) {
      if (o.color && o.color !== "transparent" && o.color !== "rgba(0, 0, 0, 0)") set.color = o.color;
      else delete set.color;
    }
    if (o.onlyBorder !== undefined) {
      if (o.onlyBorder) set.colorBorderOnly = true;
      else delete set.colorBorderOnly;
    }
  };
  const withItem = (ref: QrRef, fn: (item: QrItem, st: QrState) => void) => {
    let found = false;
    store.update((st) => {
      const hit = findIn(st, ref);
      if (!hit) return;
      found = true;
      fn(hit.item, st);
    });
    if (!found) throw new Error(ref.id !== undefined ? t(`No QR #${ref.id} in set "${ref.set}"`, `"${ref.set}" 세트에 QR #${ref.id}가 없어요`) : t(`No QR "${ref.label}" in set "${ref.set}"`, `"${ref.set}" 세트에 "${ref.label}" QR이 없어요`));
  };

  return {
    setNames: (where = "all") => {
      const st = store.value;
      if (where === "global") return st.sets.filter((s) => s.enabled).map((s) => s.name);
      if (where === "chat") {
        const chat = scope().chatId;
        return chat ? st.sets.filter((s) => isOnForChat(st, s.id, chat)).map((s) => s.name) : [];
      }
      return st.sets.map((s) => s.name);
    },
    labels: (set) => findSet(store.value, set)?.items.map((i) => i.label) ?? [],
    get: (ref) => {
      const hit = findIn(store.value, ref);
      if (!hit) return undefined;
      const { set, item: i } = hit;
      return {
        id: set.items.indexOf(i) + 1,
        icon: i.icon ?? "",
        showLabel: i.showLabel !== false,
        label: i.label,
        title: i.title ?? "",
        message: i.script,
        contextList: (i.contextList ?? []).map((l) => ({ set: setName(l.setId), isChained: !!l.chained })).filter((l) => l.set),
        preventAutoExecute: i.preventAuto !== false,
        isHidden: !!i.hidden,
        automationId: i.automationId ?? "",
        ...Object.fromEntries(AUTO_TRIGGERS.map(({ key, st }) => [st, !!i.auto?.[key]])),
        // Dispensa's own keys
        set: set.name,
        hidden: !!i.hidden,
        ...Object.fromEntries(AUTO_TRIGGERS.map(({ key, info }) => [info, !!i.auto?.[key]])),
      };
    },
    create: (info, dialect: Dialect) =>
      store.update((st) => {
        let set = findSet(st, info.set);
        if (!set) {
          set = newSet(info.set);
          st.sets.push(set);
        }
        const item = newItem(info.label, info.message ?? "", dialect);
        if (dialect === "st") item.note = t("Made with /qr-create by a QR counting from #0.", "0번부터 세는 QR이 /qr-create로 만든 QR이에요.");
        apply(item, info);
        set.items.push(item);
      }),
    update: (ref, changes) => {
      try {
        withItem(ref, (item) => {
          apply(item, changes);
          if (changes.newLabel) item.label = changes.newLabel;
        });
        return true;
      } catch {
        return false;
      }
    },
    remove: (ref) => {
      let found = false;
      store.update((st) => {
        const hit = findIn(st, ref);
        if (!hit) return;
        hit.set.items = hit.set.items.filter((i) => i !== hit.item);
        pruneDock(st);
        found = true;
      });
      return found;
    },
    createSet: (name, options) =>
      store.update((st) => {
        // SillyTavern: creating overrides an existing preset
        for (const old of st.sets.filter((s) => s.name === name)) forgetSet(st, old.id);
        st.sets = st.sets.filter((s) => s.name !== name);
        pruneDock(st);
        const set = newSet(name);
        setOptions(set, options);
        st.sets.push(set);
      }),
    updateSet: (name, options) => {
      let found = false;
      store.update((st) => {
        const set = findSet(st, name);
        if (!set) return;
        found = true;
        setOptions(set, options);
      });
      return found;
    },
    removeSet: (name) => {
      let found = false;
      store.update((st) => {
        for (const old of st.sets.filter((s) => s.name === name)) forgetSet(st, old.id);
        const before = st.sets.length;
        st.sets = st.sets.filter((s) => s.name !== name);
        pruneDock(st);
        found = st.sets.length !== before;
      });
      return found;
    },
    setEnabled: (name, state) => {
      let result = false;
      store.update((st) => {
        const set = findSet(st, name);
        if (!set) return;
        set.enabled = state ?? !set.enabled;
        result = set.enabled;
        // SillyTavern shows a global set's buttons: on and off the Dock with it
        if (result) addToDock(st, { kind: "set", setId: set.id });
        else removeFromDock(st, { kind: "set", setId: set.id });
      });
      return result;
    },
    setForChat: (name, state) => {
      const chat = scope().chatId;
      if (!chat) throw new Error(t("No chat is open", "열려 있는 채팅이 없어요"));
      let result = false;
      store.update((st) => {
        const set = findSet(st, name);
        if (!set) throw new Error(t(`No QR set "${name}"`, `"${name}" QR 세트가 없어요`));
        result = state ?? !isOnForChat(st, set.id, chat);
        setForChat(st, chat, set.id, result);
      });
      return result;
    },
    setDisplay: (name, display) => {
      let found = false;
      store.update((st) => {
        const set = findSet(st, name);
        if (!set) return;
        found = true;
        set.display = display;
        setLayout(st, set.id, display === "inline" ? "row" : "folder");
      });
      return found;
    },
    contextAdd: (ref, name, chained) =>
      withItem(ref, (item, st) => {
        const target = findSet(st, name);
        if (!target) throw new Error(t(`No QR set "${name}"`, `"${name}" QR 세트가 없어요`));
        const links = (item.contextList ?? []).filter((l) => l.setId !== target.id);
        links.push(chained ? { setId: target.id, chained: true } : { setId: target.id });
        item.contextList = links;
      }),
    contextDel: (ref, name) =>
      withItem(ref, (item, st) => {
        const ids = st.sets.filter((s) => s.name === name).map((s) => s.id);
        item.contextList = (item.contextList ?? []).filter((l) => !ids.includes(l.setId));
        if (!item.contextList.length) delete item.contextList;
      }),
    contextClear: (ref) => withItem(ref, (item) => delete item.contextList),
    dockVisible: (state) => {
      let result = true;
      store.update((st) => {
        st.dockVisible = state ?? !st.dockVisible;
        result = st.dockVisible;
      });
      return result;
    },
    // SillyTavern's /qr counts the QRs of the sets on here (with or without buttons)
    visible: () => activeSets(store.value, scope()).flatMap((s) => s.items.filter((i) => !i.hidden).map((i) => ({ set: s.name, label: i.label }))),
    runLater: (name, delayMs) => {
      const timer = setTimeout(() => {
        timers.delete(timer);
        const found = findItem(store.value, name);
        if (found) void runner().run(found.set, found.item, { auto: true });
      }, delayMs);
      timers.add(timer);
    },
    run: async (name, signal) => {
      const found = findItem(store.value, name);
      if (!found) throw new Error(t(`No Quick Reply named "${name}"`, `"${name}"(이)라는 QR이 없어요`));
      // Called from inside a running script: run inline through /run semantics instead of the runner's busy lock.
      await runner().runNested(found.set, found.item, signal);
    },
    source: (name): ScriptSource | undefined => {
      const found = findItem(store.value, name);
      return found ? { script: found.item.script, dialect: found.item.dialect, label: found.item.label, setName: found.set.name } : undefined;
    },
    dispose: () => {
      for (const t of timers) clearTimeout(t);
      timers.clear();
    },
  };
}
