// Bytes as Marinara counts extension storage: the whole stored object as JSON, null keys included.

const encoder = new TextEncoder();

function utf8Bytes(text: string): number {
  return encoder.encode(text).length;
}

/** Bytes of one `"key":value` in the stored object's JSON. */
export function entryBytes(key: string, value: unknown): number {
  return utf8Bytes(JSON.stringify(key)) + 1 + utf8Bytes(JSON.stringify(value ?? null));
}

/** The object's JSON bytes from its entries': adds the braces and commas. */
export function objectBytes(entries: Iterable<number>): number {
  let sum = 0;
  let n = 0;
  for (const b of entries) {
    sum += b;
    n++;
  }
  return 2 + sum + Math.max(0, n - 1);
}

/** Each key's entry bytes in a stored object. */
export function entriesOf(stored: Record<string, unknown>): Map<string, number> {
  return new Map(Object.entries(stored).map(([k, v]) => [k, entryBytes(k, v)]));
}
