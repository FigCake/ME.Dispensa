// visz data: presets and settings (in Marinara storage); saved results are in archive.ts.

import type { PresetChunk, ViszModeSetting, ViszPreset } from "./core";
import { DEFAULT_WRAPPERS, type Wrapper } from "./defaults";
import { SUPERVIZ } from "./superviz";
import { t } from "../shared/i18n";
import { newId } from "../util";

/** How OOC is sent. guided: Marinara /guided (no visible message, the reply is the character's turn). */
export type OocMode = "guided" | "hidden" | "user" | "input";
/** Where a page goes: the viewer above the Dock, the chat as the character's message, or only the Gallery. */
export type ViszOutput = "viewer" | "chat" | "gallery";
export type GalleryCollect = "chat" | "gallery" | "all";
export type ViszAction = "ooc" | "viz";

/** Labels in the screen language (getters: read when shown). */
export const OOC_MODES: Record<OocMode, string> = {
  get hidden() {
    return t("Get the result (as a character message)", "결과물 받기 (캐릭터 메시지로)");
  },
  get guided() {
    return t("Steer the next reply", "전개에 반영하기 (다음 답에)");
  },
  get user() {
    return t("Send as me", "직접 보내기 (내 메시지로)");
  },
  get input() {
    return t("Put in the input (edit, then send)", "입력창에 넣기 (고친 뒤 전송)");
  },
};

export const VISZ_OUTPUTS: Record<ViszOutput, string> = {
  get viewer() {
    return t("Viewer", "보기 창");
  },
  get chat() {
    return t("Current chat", "현재 채팅");
  },
  get gallery() {
    return t("Gallery", "갤러리");
  },
};

export interface ViszSettings {
  language: string;
  viszMode: ViszModeSetting;
  viszOutput: ViszOutput;
  /** What goes to the Gallery by itself: results posted to the open chat (by the visualizer or any QR, but /guided), QRs run from the Gallery, or both. */
  collect: GalleryCollect;
  /** Only results with an HTML page in them are kept. */
  htmlOnly: boolean;
  oocMode: OocMode;
  wrapperId: string;
  /** "" = the chat's own connection. */
  connectionId: string;
  /** QRs run from the Gallery use this one ("" = the visualizer's). */
  galleryConnectionId: string;
  /** The prompt preset for Gallery runs and the visualizer ("" = the chat's own). */
  galleryPresetId: string;
  /** Pages and OOC results go with the chat's RP prompt preset (off: without it, its lorebooks still in). */
  sendPreset: boolean;
  showButton: boolean;
  dockIcon: string;
  /** Let pages load outside resources (fonts, images, html2canvas). */
  allowExternal: boolean;
  maxFrameHeight: number;
}

export interface ViszState {
  version: 1;
  settings: ViszSettings;
  wrappers: Wrapper[];
  /** Chunk edits on top of the built-in Superviz (by chunk id), plus extra chunks. */
  preset: ViszPreset;
}

const DEFAULT_SETTINGS: ViszSettings = {
  language: "English",
  // Marinara's security policy stops scripts in pages: full only when Fornello runs them
  viszMode: "auto",
  viszOutput: "viewer",
  collect: "all",
  htmlOnly: true,
  // like the user's SillyTavern QRs: /gen with the request, then /sendas the result as the character
  oocMode: "hidden",
  wrapperId: DEFAULT_WRAPPERS[0].id,
  connectionId: "",
  galleryConnectionId: "",
  galleryPresetId: "",
  sendPreset: true,
  showButton: true,
  dockIcon: "🍰",
  allowExternal: true,
  maxFrameHeight: 1600,
};

export function defaultPreset(): ViszPreset {
  return { ...structuredClone(SUPERVIZ), known: SUPERVIZ.chunks.map((c) => c.id) };
}

export function defaultViszState(): ViszState {
  return {
    version: 1,
    settings: { ...DEFAULT_SETTINGS },
    wrappers: structuredClone(DEFAULT_WRAPPERS),
    preset: defaultPreset(),
  };
}

const str = (v: unknown, fallback = "") => (typeof v === "string" ? v : fallback);
const pick = <T extends string>(v: unknown, allowed: readonly T[], fallback: T): T => (allowed.includes(v as T) ? (v as T) : fallback);

function normalizeChunk(raw: unknown): PresetChunk | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  return {
    id: str(r.id) || newId("chunk"),
    name: str(r.name) || t("Chunk", "조각"),
    mode: pick(r.mode, ["all", "full", "lite"] as const, "all"),
    enabled: r.enabled !== false,
    text: str(r.text),
    ...(r.needs === "fornello" ? { needs: "fornello" as const } : {}),
  };
}

/** Built-in chunks added since the preset was saved go in (before the chunk that follows them by default). */
function withNewBuiltins(chunks: PresetChunk[], known: string[] | null): { chunks: PresetChunk[]; known: string[] } {
  const builtins = defaultPreset().chunks;
  const seen = new Set(known ?? builtins.map((b) => b.id));
  const out = [...chunks];
  builtins.forEach((b, i) => {
    if (seen.has(b.id)) return;
    const next = builtins.slice(i + 1).find((x) => out.some((c) => c.id === x.id));
    const at = next ? out.findIndex((c) => c.id === next.id) : out.length;
    out.splice(at, 0, structuredClone(b));
  });
  return { chunks: out, known: builtins.map((b) => b.id) };
}

export function normalizeViszState(raw: unknown): ViszState {
  const base = defaultViszState();
  if (!raw || typeof raw !== "object") return base;
  const r = raw as Record<string, unknown>;
  const wrappers = Array.isArray(r.wrappers) ? normalizeWrappers(r.wrappers) : base.wrappers;
  return {
    version: 1,
    settings: normalizeSettings(r.settings && typeof r.settings === "object" ? (r.settings as Record<string, unknown>) : {}),
    wrappers: wrappers.length ? wrappers : base.wrappers,
    preset: r.preset && typeof r.preset === "object" ? normalizePreset(r.preset as Record<string, unknown>, base.preset) : base.preset,
  };
}

function normalizeSettings(s: Record<string, unknown>): ViszSettings {
  return {
    language: str(s.language) || DEFAULT_SETTINGS.language,
    // auto: full pages with Fornello, light without; "lite" (the "Full pages" switch off) stays light
    viszMode: s.viszMode === "lite" ? "lite" : "auto",
    viszOutput: pick(s.viszOutput, ["viewer", "chat", "gallery"] as const, DEFAULT_SETTINGS.viszOutput),
    // saved before there was a choice: "chat pages to the Gallery" off kept only what the Gallery itself made
    collect: pick(s.collect, ["chat", "gallery", "all"] as const, s.autoArchive === false ? "gallery" : DEFAULT_SETTINGS.collect),
    htmlOnly: typeof s.htmlOnly === "boolean" ? s.htmlOnly : DEFAULT_SETTINGS.htmlOnly,
    oocMode: pick(s.oocMode, Object.keys(OOC_MODES) as OocMode[], DEFAULT_SETTINGS.oocMode),
    wrapperId: str(s.wrapperId) || DEFAULT_SETTINGS.wrapperId,
    connectionId: str(s.connectionId),
    galleryConnectionId: str(s.galleryConnectionId),
    galleryPresetId: str(s.galleryPresetId),
    sendPreset: typeof s.sendPreset === "boolean" ? s.sendPreset : DEFAULT_SETTINGS.sendPreset,
    showButton: typeof s.showButton === "boolean" ? s.showButton : DEFAULT_SETTINGS.showButton,
    dockIcon: str(s.dockIcon).trim() || DEFAULT_SETTINGS.dockIcon,
    allowExternal: typeof s.allowExternal === "boolean" ? s.allowExternal : DEFAULT_SETTINGS.allowExternal,
    maxFrameHeight: Number(s.maxFrameHeight) >= 200 ? Number(s.maxFrameHeight) : DEFAULT_SETTINGS.maxFrameHeight,
  };
}

function normalizeWrappers(raw: unknown[]): Wrapper[] {
  return raw
    .filter((w): w is Record<string, unknown> => !!w && typeof w === "object")
    .map((w) => ({ id: str(w.id) || newId("wrap"), name: str(w.name) || t("Wrapper", "틀"), template: str(w.template) || "{{내용}}" }));
}

function normalizePreset(p: Record<string, unknown>, base: ViszPreset): ViszPreset {
  const stored = Array.isArray(p.chunks) ? p.chunks.map(normalizeChunk).filter((c): c is PresetChunk => !!c) : null;
  const known = Array.isArray(p.known) ? p.known.map(String) : null;
  const { chunks, known: offered } = stored ? withNewBuiltins(stored, known) : { chunks: base.chunks, known: base.known ?? [] };
  return { id: str(p.id) || base.id, name: str(p.name) || base.name, wrap: p.wrap !== false, chunks, known: offered };
}

export function viszOptions(state: ViszState) {
  const s = state.settings;
  return {
    oocMode: s.oocMode,
    viszOutput: s.viszOutput,
    wrapper: state.wrappers.find((w) => w.id === s.wrapperId) ?? state.wrappers[0] ?? DEFAULT_WRAPPERS[0],
    connectionId: s.connectionId,
  };
}
