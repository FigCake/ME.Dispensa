// The OOC templates.

import { t } from "../shared/i18n";

/** A template the OOC request is put in (`{{내용}}` is the request). */
export interface Wrapper {
  id: string;
  name: string;
  template: string;
}

// Only the request between <System> tags, nothing added: a request that wants a language says so itself.
const DEFAULT_OOC_TEMPLATE = "<System>\n{{내용}}\n</System>";

export const CONTINUE_TEMPLATE = "<System>\nThe HTML you wrote earlier was cut off before it was finished. This is everything written so far:\n```html\n{{앞부분}}\n```\nContinue the code from EXACTLY where it stops. Output ONLY the remaining code: do not repeat anything already written, do not restart the document, do not explain, and do not wrap it in a Markdown code block. Close every open tag and end with </html>.\n</System>";

// Names are getters, copied in the screen language when the wrappers are made.
export const DEFAULT_WRAPPERS: Wrapper[] = [
  {
    id: "system",
    get name() {
      return t("<System> block", "<System> 블록");
    },
    template: DEFAULT_OOC_TEMPLATE,
  },
  { id: "ooc-star", name: "*{OOC: …}*", template: "*{OOC: {{내용}}}*" },
  {
    id: "raw",
    get name() {
      return t("No wrapper", "틀 없음");
    },
    template: "{{내용}}",
  },
];
