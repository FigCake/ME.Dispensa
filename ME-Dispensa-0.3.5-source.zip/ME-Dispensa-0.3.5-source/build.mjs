// Builds Dispensa for Marinara Engine:
//
//   dist/manifest.json                Marinara personal-extension manifest (v1)
//   dist/extension.js                 the whole extension, one readable file (esbuild, no minify)
//   dist/README-ko.txt                the Korean README, for people who open the zip
//   dist/THIRD_PARTY_NOTICES.txt      licenses of bundled third-party code (html-to-image, MIT)
//   dist/SHA256SUMS.txt               file hashes + the content hash Marinara will show
//   dist/ME-Dispensa-<version>.zip    what you import in Settings → Addons → External Extensions
//   dist/ME-Dispensa-<version>-source.zip   the Corresponding Source (AGPL-3.0 §6): what it takes to rebuild extension.js
//   dist/public/                      exactly what the public repository (FigCake/ME.Dispensa) carries
//
// Deterministic: same sources → same bytes (fixed zip timestamps, store-only
// entries, sorted names, no source maps).

import { build } from 'esbuild';
import { createHash } from 'node:crypto';
import { mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { join, relative } from 'node:path';

const CRC_TABLE = new Uint32Array(256).map((_, n) => {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    return c >>> 0;
});

const root = new URL('.', import.meta.url).pathname;
const at = (...parts) => join(root, ...parts);
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');

const pkg = JSON.parse(await readFile(at('package.json'), 'utf8'));
const version = pkg.version;
const name = 'Dispensa';
const description =
    'Quick replies on a Dock above the chat input: runs SillyTavern Quick Reply sets (STscript) in Marinara, with step QRs, '
    + 'auto-run, a visualizer that makes HTML pages and a memo pad, plus commands for Marinara\'s tracker, lorebooks, characters '
    + 'and connections. Calls the AI only when a QR or page asks; Dispensa itself talks to no outside server. '
    + '채팅 입력창 위 Dock에서 쓰는 퀵 리플라이: 실리태번 QR(STscript)을 마리나라에서 실행하고, 단계 QR·자동 실행·HTML 페이지를 만드는 '
    + '비주얼라이저·메모장, 마리나라 트래커·로어북·캐릭터·연결 명령을 더합니다. AI 호출은 QR이나 페이지가 요청할 때만, 외부 서버와는 통신하지 않습니다.';

await rm(at('dist'), { recursive: true, force: true });
await mkdir(at('dist'), { recursive: true });

// 1. Bundle. Marinara runs this as the body of `async (marinara) => { … }`, so:
//    IIFE, no imports/exports, `marinara` left as a free identifier.
const banner = `/*! ${name} ${version} — quick replies on a Dock for Marinara Engine 2.5.x (External Extension).
 * Runs SillyTavern Quick Replies (STscript) in Marinara.
 * Copyright (C) 2026 FigCake. Derived from SillyTavern and Marinara Engine (both AGPL-3.0); includes html-to-image (MIT) and Lucide icons (ISC).
 * License: AGPL-3.0, except the prompt texts of 슈퍼비즈, 수퍼라비 and the example QRs: CC BY-NC-SA 4.0, see LICENSE-SUPERVIZ.txt.
 * Source: https://github.com/FigCake/ME.Dispensa (ME-Dispensa-${version}-source.zip) */`;
// Bundled third-party code (MIT, and Lucide's icon paths: ISC): its notices travel inside extension.js and next to it.
const notices = (await Promise.all(['html-to-image'].map(async dep => {
    const meta = JSON.parse(await readFile(at('node_modules', dep, 'package.json'), 'utf8'));
    const license = (await readFile(at('node_modules', dep, 'LICENSE'), 'utf8')).trim();
    return `${dep} ${meta.version} (${meta.license})\n\n${license}`;
}))).concat([`Lucide icons (ISC; some icons from Feather, MIT), drawn as SVG paths\n\n${(await readFile(at('third-party', 'lucide-LICENSE.txt'), 'utf8')).trim()}`]).join('\n\n-----\n\n');
const footer = `/*! Third-party notices (bundled code):\n\n${notices.replace(/\*\//g, '* /')}\n*/`;
await build({
    entryPoints: [at('src/entry.ts')],
    outfile: at('dist/extension.js'),
    bundle: true,
    format: 'iife',
    platform: 'browser',
    target: 'es2022',
    minify: false,
    sourcemap: false,
    legalComments: 'inline',
    logLevel: 'warning',
    charset: 'utf8',
    banner: { js: banner },
    footer: { js: footer },
});
const js = await readFile(at('dist/extension.js'));
const jsText = js.toString('utf8');
if (/^\s*(import|export)\s/m.test(jsText)) throw new Error('bundle must not contain import/export statements');

// 2. Manifest (packages/shared/src/schemas/personal-extension.schema.ts limits: name ≤ 200, version ≤ 64, description ≤ 2000)
const manifest = {
    kind: 'marinara.personal-extension',
    version: 1,
    config: {
        name,
        version,
        description,
        runtime: 'client',
        capabilities: ['full_page_access'],
        jsPath: 'extension.js',
    },
};
if (description.length > 2000) throw new Error('description exceeds 2000 characters');
const manifestText = `${JSON.stringify(manifest, null, 2)}\n`;
await writeFile(at('dist/manifest.json'), manifestText);

// 3. README for the zip
const readmeKo = await readFile(at('README-ko.md'), 'utf8');
await writeFile(at('dist/README-ko.txt'), readmeKo);
await writeFile(at('dist/THIRD_PARTY_NOTICES.txt'), `${notices}\n`);

// 4. Source archive: the code and everything the build reads (sorted, fixed timestamps).
//    Tests, e2e and CI stay in the development repository.
const SOURCE_FILES = ['build.mjs', 'package.json', 'package-lock.json', 'tsconfig.json', 'README.md', 'README-ko.md', 'third-party/lucide-LICENSE.txt', 'LICENSE', 'LICENSE-SUPERVIZ.txt'];
const SOURCE_DIRS = ['src', 'scripts'];
const listFiles = async dir => {
    const out = [];
    for (const entry of await readdir(at(dir), { withFileTypes: true })) {
        const path = join(dir, entry.name);
        if (entry.isDirectory()) out.push(...(await listFiles(path)));
        else if (!entry.name.startsWith('.')) out.push(path);
    }
    return out;
};
const sourcePaths = [...SOURCE_FILES];
for (const dir of SOURCE_DIRS) sourcePaths.push(...(await listFiles(dir)));
const sourceZipName = `ME-Dispensa-${version}-source.zip`;
const sourceZip = createZip(
    (await Promise.all(sourcePaths.map(async f => ({ name: `ME-Dispensa-${version}-source/${relative(root, at(f)).split('\\').join('/')}`, data: await readFile(at(f)) }))))
        .sort((a, b) => (a.name < b.name ? -1 : 1)),
);
await writeFile(at('dist', sourceZipName), sourceZip);

// 5. Hashes: per file, and the content hash Marinara computes for this exact package
//    (personal-extension-hash.ts: sha256 of JSON.stringify([runtime, css, js, serverJs, capabilities]))
const contentHash = `sha256:${sha256(JSON.stringify(['client', '', jsText, '', ['full_page_access']]))}`;
const sums = [
    `${sha256(js)}  extension.js`,
    `${sha256(Buffer.from(manifestText))}  manifest.json`,
    `${sha256(Buffer.from(readmeKo))}  README-ko.txt`,
    `${sha256(sourceZip)}  ${sourceZipName}`,
    '',
    `Marinara content hash (shown in "Review and Run"): ${contentHash}`,
    '',
].join('\n');
await writeFile(at('dist/SHA256SUMS.txt'), sums);

// 6. Zip
const entries = [
    { name: 'manifest.json', data: Buffer.from(manifestText) },
    { name: 'extension.js', data: js },
    { name: 'README-ko.txt', data: Buffer.from(readmeKo) },
    { name: 'SHA256SUMS.txt', data: Buffer.from(sums) },
    { name: 'THIRD_PARTY_NOTICES.txt', data: Buffer.from(`${notices}\n`) },
    { name: 'LICENSE-SUPERVIZ.txt', data: await readFile(at('LICENSE-SUPERVIZ.txt')) },
].sort((a, b) => (a.name < b.name ? -1 : 1));
const zipName = `ME-Dispensa-${version}.zip`;
const zip = createZip(entries);
await writeFile(at('dist', zipName), zip);

// 7. The public set: what FigCake/ME.Dispensa publishes (the build, plus the source archive).
//    The READMEs lose their Development section; everything else is identical.
const stripDevelopment = text => text.replace(/\n## (Development|개발)\n[\s\S]*?(?=\n## |$)/, '\n').trimEnd() + '\n';
await mkdir(at('dist/public'), { recursive: true });
// its checksums list only what it carries (README-ko.txt lives in the zip)
await writeFile(at('dist/public/SHA256SUMS.txt'), sums.split('\n').filter(line => !/ {2}README-ko\.txt$/.test(line)).join('\n'));
for (const file of ['manifest.json', 'extension.js', 'THIRD_PARTY_NOTICES.txt', zipName, sourceZipName]) {
    await writeFile(at('dist/public', file), await readFile(at('dist', file)));
}
await writeFile(at('dist/public/README.md'), stripDevelopment(await readFile(at('README.md'), 'utf8')));
await writeFile(at('dist/public/README-ko.md'), stripDevelopment(readmeKo));
await writeFile(at('dist/public/LICENSE'), await readFile(at('LICENSE')));
await writeFile(at('dist/public/LICENSE-SUPERVIZ.txt'), await readFile(at('LICENSE-SUPERVIZ.txt')));

console.log(`${name} ${version}`);
console.log(`  dist/extension.js   ${js.byteLength} bytes  sha256 ${sha256(js)}`);
console.log(`  dist/${zipName}  ${zip.byteLength} bytes  sha256 ${sha256(zip)}`);
console.log(`  Marinara content hash: ${contentHash}`);

// ── deterministic store-only zip writer (fixed timestamp, no directory entries) ──
function createZip(files) {
    const DOS_DATE = ((2000 - 1980) << 9) | (1 << 5) | 1; // 2000-01-01
    const locals = [], centrals = [];
    let offset = 0;
    for (const { name, data } of files) {
        const nameBytes = Buffer.from(name, 'utf8');
        const checksum = crc32(data);
        const local = Buffer.alloc(30);
        local.writeUInt32LE(0x04034b50, 0);
        local.writeUInt16LE(20, 4);
        local.writeUInt16LE(0x0800, 6);
        local.writeUInt16LE(0, 8);
        local.writeUInt16LE(0, 10);
        local.writeUInt16LE(DOS_DATE, 12);
        local.writeUInt32LE(checksum, 14);
        local.writeUInt32LE(data.length, 18);
        local.writeUInt32LE(data.length, 22);
        local.writeUInt16LE(nameBytes.length, 26);
        local.writeUInt16LE(0, 28);
        locals.push(local, nameBytes, data);

        const central = Buffer.alloc(46);
        central.writeUInt32LE(0x02014b50, 0);
        central.writeUInt16LE((3 << 8) | 20, 4);
        central.writeUInt16LE(20, 6);
        central.writeUInt16LE(0x0800, 8);
        central.writeUInt16LE(0, 10);
        central.writeUInt16LE(0, 12);
        central.writeUInt16LE(DOS_DATE, 14);
        central.writeUInt32LE(checksum, 16);
        central.writeUInt32LE(data.length, 20);
        central.writeUInt32LE(data.length, 24);
        central.writeUInt16LE(nameBytes.length, 28);
        central.writeUInt16LE(0, 30);
        central.writeUInt16LE(0, 32);
        central.writeUInt16LE(0, 34);
        central.writeUInt16LE(0, 36);
        central.writeUInt32LE(0o644 << 16, 38);
        central.writeUInt32LE(offset, 42);
        centrals.push(central, nameBytes);
        offset += local.length + nameBytes.length + data.length;
    }
    const centralSize = centrals.reduce((n, b) => n + b.length, 0);
    const end = Buffer.alloc(22);
    end.writeUInt32LE(0x06054b50, 0);
    end.writeUInt16LE(files.length, 8);
    end.writeUInt16LE(files.length, 10);
    end.writeUInt32LE(centralSize, 12);
    end.writeUInt32LE(offset, 16);
    return Buffer.concat([...locals, ...centrals, end]);
}

function crc32(bytes) {
    let crc = 0xffffffff;
    for (const b of bytes) crc = CRC_TABLE[(crc ^ b) & 0xff] ^ (crc >>> 8);
    return (crc ^ 0xffffffff) >>> 0;
}
