// Dispensa entry point (runs inside Marinara as a full-page extension):
// loads the saved data, then builds the parts and wires them together.
// Each part lives in its own module; this file only connects them.

import { startAutoRun } from "./auto-run";
import { publishBridge } from "./bridge";
import { DISPENSA_DOCK, type DockGroup } from "./shared/dispensa-bridge";
import { ChatScopeWatch } from "./host/chat-scope";
import { getMarinara } from "./shared/marinara-global";
import { MarinaraHost } from "./host/marinara-host";
import { createViszHost } from "./host/visz-host";
import { onLangChange, t } from "./shared/i18n";
import { memosFrom, newMemo } from "./memo/model";
import { MemoStore } from "./memo/store";
import { createQrControl } from "./qr/control";
import { dockSlice } from "./qr/dock";
import { type QrItem, type QrSet, builtinSet } from "./qr/model";
import { QrRunner } from "./qr/runner";
import { QrStore } from "./qr/store";
import { createRegistry } from "./stscript";
import type { HostUI } from "./stscript/host";
import { addViewButtons } from "./ui/chat-blocks";
import { ComposerToggle } from "./ui/composer-toggle";
import { Dialogs } from "./ui/dialogs";
import { Dock } from "./ui/dock";
import { keepDockPlaced } from "./ui/dock-placement";
import { QrManager } from "./ui/manager";
import { MemoCapture } from "./ui/memo-capture";
import { MemoPanel } from "./ui/memo-panel";
import { pickMemos } from "./ui/memo-pick";
import { ThemeSync } from "./shared/theme";
import { MENU_ICONS, addMenuSource, keepTopMenu } from "./shared/top-menu";
import { ViewerPanel } from "./ui/viewer";
import { ViszPanel } from "./ui/visz-panel";
import { createArchive } from "./visz/archive";
import { extractHtmlBlocks } from "./visz/core";
import { ViszService } from "./visz/service";
import { ViszStore } from "./visz/store";

/** Loads a store; on failure says so (the store then never writes, so nothing saved is lost). */
async function load(store: { load(): Promise<void> }, ui: HostUI, message: string, what: string): Promise<void> {
  try {
    await store.load();
  } catch (e) {
    ui.toast(message, "error");
    getMarinara().log.error(`${what} load failed`, e);
  }
}

export async function start(): Promise<() => void> {
  const marinara = getMarinara();
  // a Dock left by an earlier start
  document.getElementById("dispensa-dock")?.remove();

  const theme = new ThemeSync("dispensa-theme");
  theme.start();
  const dialogs = new Dialogs();
  const host = new MarinaraHost(dialogs);
  const registry = createRegistry();

  // ── saved data ──
  const store = new QrStore();
  const viszStore = new ViszStore();
  const memoStore = new MemoStore();
  await load(store, host.ui, t("Dispensa: couldn't load the saved QRs. Changes on this screen won't be saved.", "Dispensa: 저장된 QR을 불러오지 못했어요. 이번 화면에서는 변경 내용이 저장되지 않아요."), "QR");
  await load(viszStore, host.ui, t("Dispensa: couldn't load the Visualizer settings. Changes on this screen won't be saved.", "Dispensa: 비주얼라이저 설정을 불러오지 못했어요. 이번 화면에서는 변경 내용이 저장되지 않아요."), "visz");
  await load(memoStore, host.ui, t("Dispensa: couldn't load the Memo pad. Memos on this screen won't be saved.", "Dispensa: 메모장을 불러오지 못했어요. 이번 화면에서는 메모가 저장되지 않아요."), "memo");

  // ── running QRs ──
  const scope = new ChatScopeWatch();
  const runner = new QrRunner(host, registry, () => store.value, {
    onStart: (item) => dock.setRunning(item),
    onEnd: () => dock.setRunning(null),
  });
  const qrControl = createQrControl(store, () => runner, () => scope.current);
  host.qr = qrControl;
  const run = (set: QrSet, item: QrItem) => void runner.run(set, item);

  // ── visz and the memo pad ──
  let viewer: ViewerPanel | null = null;
  const viszHost = createViszHost(host, dialogs);
  const chooseMemos = (query?: string) => pickMemos(host.ui, memoStore, undefined, query);
  viszHost.pickMemos = () => chooseMemos();
  const visz = new ViszService(viszHost, () => viszStore.value, createArchive(), () => viewer);
  const sendOoc = (text: string) => visz.run("ooc", text);
  const addMemos = (text: string) => {
    const memos = memosFrom(text);
    memoStore.update((m) => m.memos.push(...memos));
    return memos.length;
  };
  host.memo = { pick: chooseMemos, add: addMemos, list: () => memoStore.value.memos.map((m) => m.text) };
  host.visz = { run: (text, options) => visz.runText(text, options) };

  // ── the Dispensa window, and the bridge that opens it for other extensions ──
  const manager = new QrManager({
    store,
    registry,
    ui: host.ui,
    run,
    runInEditor: (set, item, options) => runner.runInEditor(set, item, options),
    memo: { store: memoStore, sendOoc: (text) => sendOoc(text), putInInput: (text) => viszHost.putInInput(text), makePage: (text) => visz.run("viz", text) },
    characterName: (id) => host.characterName(id),
    connections: () => host.marinara.connections(),
    viszStore,
  });
  // other extensions' buttons for the Dock (Fornello's scripts): kept until the Dock is built
  const dockGroups = new Map<string, DockGroup>();
  let dockBuilt: Dock | null = null;
  const setDockGroup = (id: string, group: DockGroup | null) => {
    if (group) dockGroups.set(id, group);
    else dockGroups.delete(id);
    dockBuilt?.setGroups(dockGroups);
  };
  const unpublish = publishBridge(host, registry, () => manager.open(), setDockGroup, () => store.value.dockVisible);
  // Dispensa's entry in the top-bar menu (Polyglot's, or the one this or Fornello puts up)
  const removeMenu = addMenuSource({ id: "dispensa", name: "Dispensa", order: 10, items: () => [{ icon: MENU_ICONS.star, label: t("Dispensa settings", "Dispensa 설정"), run: () => manager.open() }] });
  const stopTopMenu = keepTopMenu();

  // ── the Dock, its menus and the viewer ──
  viewer = new ViewerPanel({ service: visz, store: viszStore, ui: host.ui, onChange: () => placement.schedule() });
  const viszPanel = new ViszPanel({
    store: viszStore,
    service: visz,
    qrStore: store,
    viewer: () => viewer,
    ui: host.ui,
    close: () => dock.closeMenus(),
    openSettings: () => {
      dock.closeMenus();
      manager.open("visz");
    },
    pickMemos: () => chooseMemos(),
    addMemo: (text) => memoStore.update((m) => m.memos.push(newMemo(text))),
    run: (set, item) => run(set, item),
  });
  const memoPanel = new MemoPanel({
    store: memoStore,
    ui: host.ui,
    sendOoc,
    putInInput: (text) => viszHost.putInInput(text),
    close: () => dock.closeMenus(),
    openSettings: () => {
      dock.closeMenus();
      manager.open("memo");
    },
  });
  const capture = new MemoCapture((text) => {
    const n = addMemos(text);
    host.ui.toast(n > 1 ? t(`Added ${n} memos to the Memo pad.`, `메모 ${n}개를 메모장에 넣었어요.`) : t("Added to the Memo pad.", "메모장에 넣었어요."), "success", { title: "📝" });
  });
  const dock = new Dock({
    run,
    stop: () => runner.stop(),
    openManager: () => manager.open("qr"),
    edit: (set, item) => manager.openItem(set.id, item.id),
    visz: { panel: viszPanel },
    memo: { panel: memoPanel },
  });
  dockBuilt = dock;
  dock.setGroups(dockGroups);
  // The switch next to the input box: on = a thin ⋯ handle above the input; pointing at it or touching it brings the Dock up
  const toggle = new ComposerToggle(() => store.update((s) => (s.dockVisible = !s.dockVisible)));
  const viewChatPage = async (messageId: string, index: number) => {
    host.chat.markStale();
    const message = (await host.chat.messages()).find((m) => m.id === messageId);
    // same order as the html code blocks on screen
    const fenced = message ? extractHtmlBlocks(message.content).filter((b) => /^html?$/i.test(b.lang) && message.content.startsWith("```", b.start)) : [];
    const block = fenced[index];
    if (!block) {
      host.ui.toast(t("No HTML found in this message.", "이 메시지에서 HTML을 찾지 못했어요."), "warning", { title: "🌟" });
      return;
    }
    viewer?.show({ title: block.title || t("HTML in chat", "채팅 속 HTML"), kind: "viz", text: "```html\n" + block.code + "\n```" });
  };

  // ── keeping the screen in step with the data ──
  // Each part redraws only for the slice of data it shows (typing a script
  // or a memo redraws neither the Dock nor its menus).
  const syncVisz = () => dock.setVisz({ show: viszStore.value.settings.showButton, icon: viszStore.value.settings.dockIcon, busy: visz.busy });
  const syncMemo = () => dock.setMemo({ show: memoStore.value.showButton, icon: memoStore.value.dockIcon });
  const syncCapture = () => capture.setEnabled(memoStore.value.capture !== false);
  dock.setState(store.value);
  syncVisz();
  toggle.setArmed(store.value.dockVisible);
  syncMemo();
  syncCapture();
  memoPanel.render();
  const unsubscribers = [
    store.select(dockSlice, (s) => dock.setState(s)),
    store.select((s) => s.dockVisible, (s) => {
      toggle.setArmed(s.dockVisible);
      // Fornello moves its buttons between the Dock and the top-bar menu
      window.dispatchEvent(new Event(DISPENSA_DOCK));
    }),
    // the Visualizer set's QRs are the visz menu's items
    store.select((s) => builtinSet(s, "visz")?.items.map((i) => [i.id, i.label, i.icon, i.title]) ?? null, () => viszPanel.render()),
    viszStore.select((s) => [s.settings.showButton, s.settings.dockIcon], syncVisz),
    visz.onBusy(syncVisz),
    memoStore.select((s) => [s.showButton, s.dockIcon], syncMemo),
    memoStore.select((s) => s.capture !== false, syncCapture),
    memoStore.select((s) => s.memos, () => memoPanel.render()),
    // the screen language changed: everything open draws again
    onLangChange(() => {
      dock.render();
      toggle.setArmed(store.value.dockVisible);
      viszPanel.render();
      memoPanel.render();
      manager.refresh();
    }),
  ];

  const placement = keepDockPlaced({
    dock: dock.element,
    toggle,
    viewer: () => viewer,
    afterPlace: () => {
      theme.noticeComposer();
      addViewButtons((messageId, index) => void viewChatPage(messageId, index));
    },
  });

  const stopAutoRun = startAutoRun({
    state: () => store.value,
    scope,
    chat: host.chat,
    run: (set, item) => runner.run(set, item, { auto: true }),
    onScope: (now) => manager.setScope(now),
  });

  const cleanup = () => {
    unpublish();
    stopTopMenu();
    removeMenu();
    placement.dispose();
    stopAutoRun();
    for (const off of unsubscribers) off();
    capture.dispose();
    void memoStore.saveNow().catch(() => undefined);
    viewer?.dispose();
    theme.stop();
    void viszStore.saveNow().catch(() => undefined);
    runner.stop();
    qrControl.dispose();
    manager.close();
    dock.dispose();
    toggle.dispose();
    void host.flush().finally(() => host.dispose());
  };
  marinara.onCleanup(cleanup);
  marinara.log.info("Dispensa ready");
  return cleanup;
}
