// The Visualizer set: ordinary QRs that make pages with /visz.

import { t } from "../shared/i18n";
import { type QrSet, newItem, newSet } from "../qr/model";

/** The Visualizer set: its name in the screen language when it is made, and its icon. */
const VISZ_SET = { name: () => t("Visualizer", "비주얼라이저"), icon: "🌟" };

const LAST_MESSAGE_SCRIPT = "/visz prompt=last {{lastMessage}}";
const WIKI_EN = "Recreate the screen of a wiki page about {{char}}, made by {{char}}'s fans. Put {{char}}'s basic profile, team or agency, catchphrase, nicknames and the like in a table, and fill the page with a table of contents: Before debut, After debut, Portfolio, Biography, Other career, Interviews and quotes, Public reception, Incidents, Trivia. Add footnotes with extra details and strikethroughs to show the fans' point of view richly. Style it as fans would decorate a wiki, with {{char}}'s signature color and the signature color of {{char}}'s team (or, without one, {{char}}'s own).";
const WIKI_KO = "{{char}}의 팬들이 꾸민 {{char}}의 위키 페이지 화면을 구현한다. {{char}}에 대한 기본 신상 정보, 소속팀이나 소속사, 캐치프레이즈, 별명 등을 테이블에 담고 목차로 데뷔 전, 데뷔 후, 포트폴리오, 바이오그래피, 기타 경력, 인터뷰 및 어록, 대중 평가, 사건 사고, 여담을 넣어 내용을 채운다. 부가적인 내용들이 담긴 각주나 취소선들을 넣어 팬들의 시각을 풍부하게 묘사한다. {{char}}의 상징색과 {{char}}의 소속팀(없으면 {{char}} 개인의) 상징색을 활용하여 팬들이 꾸밀 법한 위키 스타일로 구현한다.";

/** The Visualizer set's QRs, in the screen language. */
const VISZ_QRS = (): { label: string; icon: string; title: string; script: string }[] => [
  { label: t("Last message", "마지막 메시지"), icon: "🎬", title: t("A new scene made from the last message", "마지막 메시지로 새 장면 만들기"), script: LAST_MESSAGE_SCRIPT },
  { label: t("Fandom wiki", "팬덤 위키"), icon: "📖", title: t("{{char}}'s wiki page, as the fans made it", "팬들이 꾸민 {{char}}의 위키 페이지"), script: `/visz ${t(WIKI_EN, WIKI_KO)}` },
];

/** The Visualizer set with its QRs (off everywhere: they show in the visz menu). */
export function viszSet(): QrSet {
  const items = VISZ_QRS().map((v) => ({ ...newItem(v.label, v.script), icon: v.icon, title: v.title }));
  return { ...newSet(VISZ_SET.name()), icon: VISZ_SET.icon, enabled: false, builtin: "visz", items };
}
