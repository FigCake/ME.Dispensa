// visz settings, wrappers and preset in Marinara's storage (key "visz").

import { PersistedStore } from "../host/persisted-store";
import { type ViszState, normalizeViszState } from "./model";

export class ViszStore extends PersistedStore<ViszState> {
  constructor() {
    super({ key: "visz", normalize: normalizeViszState, label: "visz" });
  }
}
