// The memo pad: lines of text kept for later (OOC notes, ideas for a page).
// They are not QRs: no scripts, no sets; they are found, sent as OOC, put in
// the input or the visz request, or turned into a QR.

import { extractOocNotes } from "../qr/import";
import { newId, oneLine } from "../util";

export interface Memo {
  id: string;
  /** Shown in lists instead of the text, when set. */
  title?: string;
  text: string;
  /** Kept at the top. */
  pinned?: boolean;
  createdAt: number;
}

export interface MemoState {
  version: 1;
  memos: Memo[];
  /** The memo pad's bubble on the Dock. */
  showButton: boolean;
  dockIcon: string;
  /** The "Memo" button under selected chat text (on unless turned off). */
  capture?: boolean;
}

export const emptyMemos = (): MemoState => ({ version: 1, memos: [], showButton: true, dockIcon: "📝" });

export function newMemo(text: string, at = Date.now()): Memo {
  return { id: newId("memo"), text: text.trim(), createdAt: at };
}

export function normalizeMemos(raw: unknown): MemoState {
  const base = emptyMemos();
  if (!raw || typeof raw !== "object") return base;
  const r = raw as Partial<MemoState>;
  const icon = r.dockIcon;
  return {
    version: 1,
    memos: Array.isArray(r.memos)
      ? r.memos
          .filter((m) => m && typeof m.text === "string")
          .map((m) => ({
            id: typeof m.id === "string" ? m.id : newId("memo"),
            ...(typeof m.title === "string" && m.title.trim() ? { title: m.title.trim() } : {}),
            text: m.text,
            createdAt: Number(m.createdAt) || 0,
            ...(m.pinned ? { pinned: true } : {}),
          }))
      : [],
    showButton: r.showButton !== false,
    dockIcon: typeof icon === "string" && icon.trim() ? icon.trim() : base.dockIcon,
    ...(r.capture === false ? { capture: false } : {}),
  };
}

/** Memos made from text: OOC wrappers come off, several wrapped notes become several memos. */
export function memosFrom(text: string, at = Date.now()): Memo[] {
  return extractOocNotes(text)
    .map((t) => t.trim())
    .filter(Boolean)
    .map((t, i) => newMemo(t, at + i));
}

/** What a list shows for a memo: its title, or the start of its text. */
export function memoLabel(m: Memo, max?: number): string {
  return m.title?.trim() || oneLine(m.text, max);
}

const fold = (s: string) => s.normalize("NFC").toLowerCase();

/** Pinned first, then newest; `query` keeps those with every word in them. */
export function shownMemos(memos: Memo[], query = ""): Memo[] {
  const words = fold(query).split(/\s+/).filter(Boolean);
  return memos
    .filter((m) => words.every((w) => fold(`${m.title ?? ""} ${m.text}`).includes(w)))
    .sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned) || b.createdAt - a.createdAt);
}

