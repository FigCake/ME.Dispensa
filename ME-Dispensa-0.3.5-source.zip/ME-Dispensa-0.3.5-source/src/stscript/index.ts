import { chatCommands } from "./commands/chat";
import { coreCommands } from "./commands/core";
import { textCommands } from "./commands/text";
import { uiCommands } from "./commands/ui";
import { qrCommands } from "./commands/qr";
import { marinaraCommands } from "./commands/marinara";
import { viszCommands } from "./commands/visz";
import { memoCommands } from "./commands/memo";
import { CommandRegistry } from "./registry";

export function createRegistry(): CommandRegistry {
  return new CommandRegistry().register(...coreCommands, ...chatCommands, ...textCommands, ...uiCommands, ...qrCommands, ...marinaraCommands, ...viszCommands, ...memoCommands);
}

export { addExternalCommand } from "./external";
export { Runtime } from "./interpreter";
export { parse } from "./parser";
