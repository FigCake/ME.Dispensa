// Commands other Marinara extensions add to Dispensa's scripts, through
// window.__dispensa.registerCommand (bridge.ts): Polyglot's /pg-translate and the
// rest. A name Dispensa already has stays Dispensa's; an alias that is taken is
// left out.

import { asText } from "./interpreter";
import type { CommandDef, CommandRegistry } from "./registry";
import type { ExternalCommand } from "../shared/dispensa-bridge";

export type { ExternalCommand };

/** Adds another extension's command; returns what takes it out again. */
export function addExternalCommand(registry: CommandRegistry, def: ExternalCommand): () => void {
  const taken = (name: string) => {
    const there = registry.get(name);
    return !!there && there.origin !== "extension";
  };
  if (!def?.name || typeof def.run !== "function") throw new Error("A command needs a name and run()");
  if (taken(def.name)) throw new Error(`/${def.name} is one of Dispensa's own commands`);
  const command: CommandDef = {
    name: def.name,
    aliases: (def.aliases ?? []).filter((alias) => !taken(alias)),
    help: String(def.help ?? ""),
    origin: "extension",
    from: String(def.from ?? ""),
    run: async (c) => {
      const named = Object.fromEntries(Object.entries(c.named).map(([key, value]) => [key, asText(value)]));
      const result = await def.run({ text: asText(c.unnamed), named });
      return result === undefined || result === null ? "" : String(result);
    },
  };
  registry.register(command);
  return () => registry.unregister(command);
}
