// Commands that talk to the user or the chat. They go through the Host, so
// the same definitions work against Marinara and against the test fake.

import type { CommandCall } from "../interpreter";
import { asText } from "../interpreter";
import { isFalse, isTrue } from "../parser";
import type { CommandDef } from "../registry";
import { ScriptError } from "../scope";
import type { Severity } from "../host";
import { t } from "../../shared/i18n";

const text = (c: CommandCall) => asText(c.unnamed);
const str = (c: CommandCall, key: string): string | undefined => {
  const v = c.named[key];
  return v === undefined ? undefined : asText(v);
};
const flag = (c: CommandCall, key: string, fallback = false): boolean => {
  const v = str(c, key);
  if (v === undefined || v === "") return fallback;
  return isTrue(v) || (!isFalse(v) && fallback);
};

function parseJsonList(c: CommandCall, raw: string | undefined): string[] | undefined {
  if (raw === undefined) return undefined;
  const source = c.rt.host.local.has(raw) ? c.rt.host.local.get(raw)! : c.rt.host.global.has(raw) ? c.rt.host.global.get(raw)! : raw;
  try {
    const parsed = JSON.parse(source);
    if (Array.isArray(parsed)) return parsed.map((x) => String(x));
  } catch {
    // not JSON
  }
  return undefined;
}

/** "5", "3-8" or "2,5,9-12" in the script's own numbering → Marinara numbers. */
function parseRange(c: CommandCall, raw: string): number[] {
  const out: number[] = [];
  for (const piece of raw.split(",").map((s) => s.trim()).filter(Boolean)) {
    const m = /^(-?\d+)\s*(?:-\s*(-?\d+))?$/.exec(piece);
    if (!m) throw new ScriptError(`Invalid message range "${piece}"`);
    const a = Number(m[1]);
    const b = m[2] !== undefined ? Number(m[2]) : a;
    for (let i = Math.min(a, b); i <= Math.max(a, b); i++) out.push(c.rt.toMarinaraNumber(i));
  }
  return out.filter((n) => n >= 1);
}

/** ST /send, /sendas, /sys take at= in the script's numbering; Marinara wants 1-based. */
function atArg(c: CommandCall): number | undefined {
  const raw = str(c, "at");
  if (raw === undefined || raw === "") return undefined;
  const n = Number(raw);
  if (Number.isNaN(n)) return undefined;
  return c.rt.toMarinaraNumber(n);
}

async function native(c: CommandCall, command: string, args: string): Promise<string> {
  await c.rt.host.chat.requireChat();
  await c.rt.host.chat.runNativeCommand(`/${command}${args ? ` ${args}` : ""}`);
  return "";
}

/** Marinara's own slash commands, forwarded through the chat input. */
function passThrough(name: string, aliases: string[], help: string): CommandDef {
  return {
    name,
    aliases,
    help,
    rawQuotes: true,
    origin: "marinara",
    run: (c) => native(c, name, text(c)),
  };
}

export const chatCommands: CommandDef[] = [
  // ── talking to the user ──
  {
    name: "echo",
    rawQuotes: true,
    help: "Show a toast: /echo [severity=info|success|warning|error] [title=] text",
    origin: "st",
    run: (c) => {
      const message = text(c);
      const severity = (str(c, "severity") ?? "info") as Severity;
      c.rt.host.ui.toast(message, ["info", "success", "warning", "error"].includes(severity) ? severity : "info", { title: str(c, "title") });
      return message;
    },
  },
  {
    name: "popup",
    help: "Show a blocking popup (simple HTML allowed).",
    origin: "st",
    run: async (c) => {
      const ok = await c.rt.host.ui.popup(text(c), {
        large: flag(c, "large"),
        wide: flag(c, "wide"),
        okButton: str(c, "okButton"),
        cancelButton: str(c, "cancelButton"),
      });
      return ok ? text(c) : "";
    },
  },
  {
    name: "input",
    help: "Ask for text: /input [default=] [placeholder=] [rows=] prompt",
    origin: "st",
    run: async (c) => {
      const answer = await c.rt.host.ui.input(text(c), {
        defaultValue: str(c, "default"),
        placeholder: str(c, "placeholder"),
        rows: Number(str(c, "rows") ?? "1") || 1,
        large: flag(c, "large"),
        wide: flag(c, "wide"),
        okButton: str(c, "okButton"),
        cancelButton: str(c, "cancelButton"),
        multiline: flag(c, "multiline"),
      });
      return answer ?? "";
    },
  },
  {
    name: "buttons",
    help: 'Ask with buttons: /buttons labels=["a","b"] text → clicked label, "" when cancelled',
    origin: "st",
    run: async (c) => {
      const labels = parseJsonList(c, str(c, "labels"));
      if (!labels || labels.length === 0) throw new ScriptError('/buttons needs labels=["a","b"]');
      return c.rt.host.ui.buttons(text(c), labels, { multiple: flag(c, "multiple") });
    },
  },
  {
    name: "setinput",
    help: "Replace the chat input text.",
    origin: "st",
    run: (c) => {
      c.rt.host.ui.setInput(text(c));
      return text(c);
    },
  },
  { name: "beep", aliases: ["ding"], help: "Play a notification sound.", origin: "st", run: (c) => (c.rt.host.ui.beep(), "") },
  { name: "loader-show", help: "Show a loading overlay.", origin: "st", run: (c) => (c.rt.host.ui.loader("show", text(c)), "") },
  { name: "loader-hide", aliases: ["loader-stop"], help: "Hide the loading overlay.", origin: "st", run: (c) => (c.rt.host.ui.loader("hide"), "") },
  {
    name: "loader-wrap",
    help: "Show a loader while running a closure.",
    origin: "st",
    run: async (c) => {
      c.rt.host.ui.loader("show", str(c, "text") ?? "");
      try {
        return (await c.rt.runBody(Array.isArray(c.unnamed) ? c.unnamed[0] ?? "" : c.unnamed, c, true)).pipe;
      } finally {
        c.rt.host.ui.loader("hide");
      }
    },
  },

  // ── generation ──
  {
    name: "gen",
    help: "Generate with the chat's context (nothing is posted). Result goes to the pipe.",
    origin: "st",
    run: async (c) => {
      await c.rt.host.chat.requireChat();
      const lock = flag(c, "lock");
      if (lock) c.rt.host.ui.loader("show", "");
      try {
        return await c.rt.host.chat.generate({
          mode: "chat",
          prompt: text(c),
          lock,
          stop: parseJsonList(c, str(c, "stop")),
          characterName: str(c, "name"),
        });
      } finally {
        if (lock) c.rt.host.ui.loader("hide");
      }
    },
  },
  {
    name: "genraw",
    help: "Generate from the prompt alone (no character or chat). Result goes to the pipe.",
    origin: "st",
    run: async (c) => {
      const lock = flag(c, "lock");
      if (lock) c.rt.host.ui.loader("show", "");
      try {
        return await c.rt.host.chat.generate({
          mode: "raw",
          prompt: text(c),
          lock,
          stop: parseJsonList(c, str(c, "stop")),
          as: str(c, "as") === "char" ? "char" : "system",
        });
      } finally {
        if (lock) c.rt.host.ui.loader("hide");
      }
    },
  },
  {
    name: "ask",
    help: "Generate as another character: /ask name=Alice prompt",
    origin: "st",
    run: async (c) => {
      const name = str(c, "name");
      if (!name) throw new ScriptError("/ask needs name=");
      return c.rt.host.chat.generate({ mode: "chat", prompt: text(c), characterName: name });
    },
  },
  {
    name: "trigger",
    help: "Start a normal reply (optionally for one group member).",
    origin: "st",
    run: async (c) => {
      await c.rt.host.chat.trigger(text(c).trim() || undefined);
      return "";
    },
  },
  { name: "continue", aliases: ["cont"], help: "Continue the last reply.", origin: "st", run: async (c) => (await c.rt.host.chat.continueLast(), "") },
  { name: "regenerate", aliases: ["swipe"], help: "Regenerate the last reply.", origin: "st", run: async (c) => (await c.rt.host.chat.regenerate(), "") },
  { name: "addswipe", help: "Add a swipe to the last character message.", origin: "st", run: async (c) => (await c.rt.host.chat.addSwipe(text(c)), "") },

  // ── posting ──
  {
    name: "sendas",
    rawQuotes: true,
    unlisted: true,
    help: "Post a message as a character: /sendas name={{char}} text",
    origin: "st",
    run: async (c) => {
      const name = str(c, "name");
      if (!name) throw new ScriptError("/sendas needs name=");
      await c.rt.host.chat.send({ role: "assistant", name, text: text(c), at: atArg(c) });
      return "";
    },
  },
  {
    name: "send",
    rawQuotes: true,
    help: "Post a message as you (no reply is generated).",
    origin: "st",
    run: async (c) => {
      await c.rt.host.chat.send({ role: "user", text: text(c), at: atArg(c) });
      return "";
    },
  },
  {
    name: "sys",
    aliases: ["system"],
    rawQuotes: true,
    help: "Post a narrator/system message.",
    origin: "st",
    run: async (c) => {
      await c.rt.host.chat.send({ role: "system", text: text(c), at: atArg(c) });
      return "";
    },
  },
  {
    name: "comment",
    rawQuotes: true,
    help: "Post a note shown in the chat but hidden from the AI.",
    origin: "st",
    run: async (c) => {
      await c.rt.host.chat.send({ role: "system", text: text(c), at: atArg(c), hidden: true });
      return "";
    },
  },

  // ── reading and editing the chat ──
  {
    name: "messages",
    aliases: ["message"],
    help: "Get messages by number or range: /messages names=on|off 3-5",
    origin: "st",
    run: async (c) => {
      const all = await c.rt.host.chat.messages();
      const raw = text(c).trim();
      const wanted = raw ? new Set(parseRange(c, raw)) : null;
      const names = !isFalse(str(c, "names") ?? "on");
      const includeHidden = flag(c, "hidden");
      const role = str(c, "role");
      const picked = all.filter(
        (m) =>
          (!wanted || wanted.has(m.number)) &&
          (includeHidden || !m.hidden) &&
          (!role || (role === "char" ? m.role === "assistant" : role === "user" ? m.role === "user" : m.role === "system" || m.role === "narrator")),
      );
      return picked.map((m) => (names ? `${m.name}: ${m.content}` : m.content)).join("\n\n");
    },
  },
  {
    name: "hide",
    help: "Hide messages from the AI by number or range.",
    origin: "st",
    run: async (c) => String(await c.rt.host.chat.setHidden(parseRange(c, text(c)), true)),
  },
  {
    name: "unhide",
    help: "Show hidden messages to the AI again.",
    origin: "st",
    run: async (c) => String(await c.rt.host.chat.setHidden(parseRange(c, text(c)), false)),
  },
  {
    name: "cut",
    help: "Delete messages by number or range (asks first).",
    origin: "st",
    run: async (c) => {
      const numbers = parseRange(c, text(c));
      if (!numbers.length) return "";
      if (!(await c.rt.host.confirm(t(`Delete ${numbers.length} message(s)? (#${numbers.join(", #")})`, `메시지 ${numbers.length}개를 삭제할까요? (${numbers.join(", ")}번)`)))) return "";
      return String(await c.rt.host.chat.deleteMessages(numbers));
    },
  },
  {
    name: "del",
    help: "Delete the last N messages (asks first).",
    origin: "st",
    run: async (c) => {
      const count = Math.max(0, Number(text(c)) || 0);
      if (!count) return "";
      const all = await c.rt.host.chat.messages();
      const numbers = all.slice(-count).map((m) => m.number);
      if (!(await c.rt.host.confirm(t(`Delete the last ${numbers.length} message(s)?`, `마지막 메시지 ${numbers.length}개를 삭제할까요?`)))) return "";
      return String(await c.rt.host.chat.deleteMessages(numbers));
    },
  },

  // ── Marinara's own commands ──
  passThrough("guided", ["narrator", "narrate"], "Marinara: steer the next reply without posting a message."),
  {
    name: "nar",
    rawQuotes: true,
    unlisted: true,
    help: "Marinara: same as /guided. (In QRs counting from #0: same as /sys.)",
    origin: "marinara",
    run: async (c) => {
      if (c.rt.dialect === "st") {
        await c.rt.host.chat.send({ role: "system", text: text(c), at: atArg(c) });
        return "";
      }
      return native(c, "guided", text(c));
    },
  },
  passThrough("as", ["respond"], "Marinara: post as, or reply as, a character: /as name [message]"),
  passThrough("impersonate", ["imp"], "Marinara: write a reply as your persona."),
  passThrough("illustrate", ["ill"], "Marinara: generate an image for the chat."),
  passThrough("selfie", [], "Marinara: a character sends a selfie (Conversation)."),
  passThrough("video", [], "Marinara: a character sends a short video (Conversation)."),
  passThrough("emote", ["emotion", "sprite"], "Marinara: show or switch a sprite expression."),
  passThrough("roll", ["r", "dice"], "Marinara: roll dice and post the result."),
  passThrough("remind", ["reminder", "timer"], "Marinara: post a reminder after a delay."),
  passThrough("scene", ["rp"], "Marinara: start a Roleplay scene from a Conversation."),
  passThrough("status", [], "Marinara: set a character's presence status."),
  passThrough("impersonate_prompt", ["imp_prompt"], "Marinara: set this chat's impersonate prompt."),
  {
    name: "goto",
    aliases: ["jump", "scroll"],
    help: "Marinara: scroll to a message by number.",
    origin: "marinara",
    run: (c) => {
      const n = Number(text(c));
      return native(c, "goto", Number.isNaN(n) ? text(c) : String(c.rt.toMarinaraNumber(n)));
    },
  },
  {
    name: "randomchar",
    help: "Open a chat with a random character (optionally only characters with a tag). Returns the name.",
    origin: "dispensa",
    run: async (c) => {
      if (!c.rt.host.chat.openRandomCharacter) throw new ScriptError("/randomchar is not available here");
      return c.rt.host.chat.openRandomCharacter(text(c).trim() || undefined);
    },
  },
  {
    name: "random",
    aliases: ["event"],
    help: "Marinara: ask the AI for a surprise event. (In QRs counting from #0: /randomchar.)",
    origin: "marinara",
    run: async (c) => {
      // SillyTavern scripts mean "chat with a random character"
      if (c.rt.dialect === "st" && c.rt.host.chat.openRandomCharacter) return c.rt.host.chat.openRandomCharacter(text(c).trim() || undefined);
      return native(c, "random", text(c));
    },
  },
];
