// Language-level commands: flow control, variables, math and text helpers.
// None of these touch the chat.

import { AbortScript, type CommandCall, asText } from "../interpreter";
import { isFalse, isTrue } from "../parser";
import type { CommandDef } from "../registry";
import { ScriptError, type Val, isClosureValue } from "../scope";
import { type VarValue, type VariableStore, addVar, readVar, writeVar } from "../variables";
import { sleep } from "../../util";

const MAX_LOOPS = 100;

const text = (v: Val | Val[] | undefined) => asText(v);
const str = (call: CommandCall, key: string): string | undefined => {
  const v = call.named[key];
  return v === undefined ? undefined : asText(v);
};
const parts = (call: CommandCall): Val[] => (Array.isArray(call.unnamed) ? call.unnamed : call.unnamed === "" ? [] : [call.unnamed]);

// ── conditions ──────────────────────────────────────────────

function operand(call: CommandCall, raw: string | undefined): VarValue | undefined {
  if (raw === undefined) return undefined;
  if (raw === "") return "";
  const n = raw.trim().length ? Number(raw) : Number.NaN;
  if (!Number.isNaN(n)) return n;
  if (call.scope.has(raw)) {
    const v = call.scope.get(raw);
    return isClosureValue(v) ? "" : v;
  }
  const { local, global } = call.rt.host;
  if (local.has(raw)) return readVar(local, raw);
  if (global.has(raw)) return readVar(global, raw);
  return raw;
}

function evalRule(rule: string | undefined, a: VarValue | undefined, b: VarValue | undefined): boolean {
  if (a === undefined) throw new ScriptError("Left operand (left=) is missing");
  if (b === undefined) {
    if (rule !== undefined && rule !== "not") throw new ScriptError(`Rule "${rule}" needs a right operand (right=)`);
    const truthy = rule !== "not";
    if (isTrue(String(a))) return truthy;
    if (isFalse(String(a))) return !truthy;
    return a ? truthy : !truthy;
  }
  const r = rule ?? "eq";
  if (typeof a === "number" && typeof b === "number") {
    switch (r) {
      case "gt":
        return a > b;
      case "gte":
        return a >= b;
      case "lt":
        return a < b;
      case "lte":
        return a <= b;
      case "eq":
        return a === b;
      case "neq":
        return a !== b;
      case "in":
      case "nin":
        break;
      default:
        throw new ScriptError(`Unknown rule "${r}" for numbers (use gt, gte, lt, lte, eq, neq)`);
    }
  }
  const as = String(a).toLowerCase();
  const bs = String(b).toLowerCase();
  switch (r) {
    case "in":
      return as.includes(bs);
    case "nin":
      return !as.includes(bs);
    case "eq":
      return as === bs;
    case "neq":
      return as !== bs;
    default:
      throw new ScriptError(`Unknown rule "${r}" for text (use eq, neq, in, nin)`);
  }
}

function condition(call: CommandCall): boolean {
  const a = operand(call, str(call, "left") ?? str(call, "a") ?? str(call, "first") ?? str(call, "x"));
  const b = operand(call, str(call, "right") ?? str(call, "b") ?? str(call, "second") ?? str(call, "y"));
  return evalRule(str(call, "rule"), a, b);
}

function bodyOf(values: Val[]): Val | undefined {
  if (values.length === 0) return undefined;
  if (isClosureValue(values[0])) return values[0];
  return values.map((v) => asText(v)).join(" ");
}

// ── variable helpers ────────────────────────────────────────

function varName(call: CommandCall): string {
  const name = str(call, "key") ?? str(call, "name") ?? "";
  if (name) return name.trim();
  return text(call.unnamed).trim();
}

function setVar(store: VariableStore, call: CommandCall): string {
  const key = str(call, "key") ?? str(call, "name");
  if (!key) throw new ScriptError("Missing key= for the variable name");
  const value = text(call.unnamed);
  writeVar(store, key.trim(), value, str(call, "index"), str(call, "as"));
  return value;
}

function getVar(store: VariableStore, call: CommandCall): string {
  const name = varName(call);
  return String(readVar(store, name, str(call, "index")));
}

function addToVar(store: VariableStore, call: CommandCall): string {
  const key = str(call, "key") ?? str(call, "name");
  if (!key) throw new ScriptError("Missing key= for the variable name");
  return String(addVar(store, key.trim(), text(call.unnamed)));
}

// ── math ────────────────────────────────────────────────────

function num(call: CommandCall, v: Val): number {
  const raw = asText(v).trim();
  const n = Number(raw);
  if (raw !== "" && !Number.isNaN(n)) return n;
  const resolved = operand(call, raw);
  const m = Number(resolved);
  return Number.isNaN(m) ? 0 : m;
}

function mathArgs(call: CommandCall): number[] {
  return parts(call)
    .flatMap((v) => asText(v).split(/\s+/))
    .filter((s) => s !== "")
    .map((s) => num(call, s));
}

const safe = (n: number) => (Number.isFinite(n) ? n : 0);

function math(name: string, help: string, fn: (xs: number[]) => number, aliases?: string[]): CommandDef {
  return { name, aliases, help, split: true, origin: "st", run: (call) => String(safe(fn(mathArgs(call)))) };
}

// ── commands ────────────────────────────────────────────────

export const coreCommands: CommandDef[] = [
  { name: "pass", aliases: ["return"], help: "Put a value into the pipe.", origin: "st", run: (c) => c.unnamed as Val },
  {
    name: "let",
    split: true,
    splitCount: 1,
    help: "Declare a scoped variable: /let name value",
    origin: "st",
    run: (c) => {
      const key = str(c, "key");
      const list = parts(c);
      const name = key ?? asText(list[0] ?? "");
      const value = key ? (list.length === 1 ? list[0] : list.map((v) => asText(v)).join(" ")) : list[1] ?? "";
      if (!name) throw new ScriptError("/let needs a variable name");
      c.scope.let(name, value);
      return value;
    },
  },
  {
    name: "var",
    split: true,
    splitCount: 1,
    help: "Set or get a scoped variable: /var name [value]",
    origin: "st",
    run: (c) => {
      const key = str(c, "key");
      const list = parts(c);
      const name = key ?? asText(list[0] ?? "");
      const rest = key ? list : list.slice(1);
      const index = str(c, "index");
      if (rest.length === 0) return c.scope.get(name, index);
      const value = rest.length === 1 ? rest[0] : rest.map((v) => asText(v)).join(" ");
      return c.scope.set(name, value, index);
    },
  },
  {
    name: "if",
    split: true,
    help: "Run commands when a condition holds: /if left=a rule=eq right=b else={: ... :} {: ... :}",
    origin: "st",
    run: async (c) => {
      const body = bodyOf(parts(c));
      if (condition(c)) {
        if (body !== undefined) return (await c.rt.runBody(body, c, true)).pipe;
      } else {
        const otherwise = c.named.else;
        if (otherwise !== undefined && (isClosureValue(otherwise) || otherwise !== "")) {
          return (await c.rt.runBody(otherwise, c, true)).pipe;
        }
      }
      return "";
    },
  },
  {
    name: "while",
    split: true,
    help: "Repeat while a condition holds (max 100 unless guard=off).",
    origin: "st",
    run: async (c) => {
      const limit = isFalse(str(c, "guard") ?? "on") ? Number.MAX_SAFE_INTEGER : MAX_LOOPS;
      const body = bodyOf(parts(c));
      let last: Val = "";
      for (let i = 0; i < limit; i++) {
        if (!condition(c) || body === undefined) break;
        const r = await c.rt.runBody(body, c, false);
        last = r.pipe;
        if (r.isBreak) break;
      }
      return last;
    },
  },
  {
    name: "times",
    split: true,
    splitCount: 1,
    help: "Repeat N times; {{timesIndex}} counts from 0.",
    origin: "st",
    run: async (c) => {
      const list = parts(c);
      const repeats = Number(asText(list[0] ?? "0"));
      const body = bodyOf(list.slice(1));
      const limit = Math.min(Number.isNaN(repeats) ? 0 : repeats, isFalse(str(c, "guard") ?? "on") ? Number.MAX_SAFE_INTEGER : MAX_LOOPS);
      let last: Val = "";
      if (body === undefined) return last;
      for (let i = 0; i < limit; i++) {
        const r = await c.rt.runBody(body, c, false, { timesIndex: String(i) });
        last = r.pipe;
        if (r.isBreak) break;
      }
      return last;
    },
  },
  {
    name: "run",
    aliases: [":"],
    help: "Run a closure or a Quick Reply (Set.Label).",
    origin: "st",
    run: (c) => {
      const provided = Object.entries(c.named).map(([name, value]) => ({ name, value }));
      const target = Array.isArray(c.unnamed) ? c.unnamed[0] ?? "" : c.unnamed;
      return c.rt.runNamed(target, provided, c);
    },
  },
  {
    name: "breakpoint",
    help: "Stop here when the QR editor's debugger runs this script (does nothing otherwise).",
    origin: "st",
    run: (c) => c.scope.pipe,
  },
  {
    name: "abort",
    help: "Stop the script.",
    origin: "st",
    run: (c) => {
      throw new AbortScript(text(c.unnamed), isTrue(str(c, "quiet") ?? "on"));
    },
  },
  {
    name: "delay",
    aliases: ["wait", "sleep"],
    help: "Wait for N milliseconds.",
    origin: "st",
    run: async (c) => {
      const ms = Math.max(0, Math.min(Number(text(c.unnamed)) || 0, 600_000));
      await sleep(ms);
      return "";
    },
  },

  // chat (local) variables
  { name: "setvar", help: "Set a chat variable: /setvar key=name value", origin: "st", run: (c) => setVar(c.rt.host.local, c) },
  { name: "getvar", help: "Get a chat variable.", origin: "st", run: (c) => getVar(c.rt.host.local, c) },
  { name: "addvar", help: "Add to a chat variable (number add, text append, array push).", origin: "st", run: (c) => addToVar(c.rt.host.local, c) },
  { name: "incvar", help: "Add 1 to a chat variable.", origin: "st", run: (c) => String(addVar(c.rt.host.local, varName(c), 1)) },
  { name: "decvar", help: "Subtract 1 from a chat variable.", origin: "st", run: (c) => String(addVar(c.rt.host.local, varName(c), -1)) },
  {
    name: "flushvar",
    help: "Delete a chat variable.",
    origin: "st",
    run: (c) => {
      const name = varName(c);
      if (isClosureValue(c.unnamed)) throw new ScriptError("/flushvar needs a variable name");
      c.rt.host.local.delete(name);
      return "";
    },
  },
  // global variables
  { name: "setglobalvar", help: "Set a global variable.", origin: "st", run: (c) => setVar(c.rt.host.global, c) },
  { name: "getglobalvar", help: "Get a global variable.", origin: "st", run: (c) => getVar(c.rt.host.global, c) },
  { name: "addglobalvar", help: "Add to a global variable.", origin: "st", run: (c) => addToVar(c.rt.host.global, c) },
  { name: "incglobalvar", help: "Add 1 to a global variable.", origin: "st", run: (c) => String(addVar(c.rt.host.global, varName(c), 1)) },
  { name: "decglobalvar", help: "Subtract 1 from a global variable.", origin: "st", run: (c) => String(addVar(c.rt.host.global, varName(c), -1)) },
  {
    name: "flushglobalvar",
    help: "Delete a global variable.",
    origin: "st",
    run: (c) => {
      c.rt.host.global.delete(varName(c));
      return "";
    },
  },
  {
    name: "listvar",
    help: "List variables as JSON.",
    origin: "st",
    run: (c) => {
      const scope = (str(c, "scope") ?? "all").toLowerCase();
      const out: { key: string; value: string; scope: string }[] = [];
      if (scope !== "global") for (const [key, value] of c.rt.host.local.entries()) out.push({ key, value, scope: "local" });
      if (scope !== "local") for (const [key, value] of c.rt.host.global.entries()) out.push({ key, value, scope: "global" });
      return JSON.stringify(out);
    },
  },

  // math
  math("add", "Add numbers.", (xs) => xs.reduce((a, b) => a + b, 0)),
  math("mul", "Multiply numbers.", (xs) => xs.reduce((a, b) => a * b, 1)),
  math("max", "Largest number.", (xs) => (xs.length ? Math.max(...xs) : 0)),
  math("min", "Smallest number.", (xs) => (xs.length ? Math.min(...xs) : 0)),
  math("sub", "a - b.", ([a = 0, b = 0]) => a - b),
  math("div", "a / b (0 when dividing by 0).", ([a = 0, b = 0]) => (b === 0 ? 0 : a / b)),
  math("mod", "a mod b.", ([a = 0, b = 0]) => (b === 0 ? 0 : a % b)),
  math("pow", "a to the power b.", ([a = 0, b = 0]) => a ** b),
  math("sin", "Sine.", ([a = 0]) => Math.sin(a)),
  math("cos", "Cosine.", ([a = 0]) => Math.cos(a)),
  math("log", "Natural log.", ([a = 0]) => Math.log(a)),
  math("abs", "Absolute value.", ([a = 0]) => Math.abs(a)),
  math("sqrt", "Square root.", ([a = 0]) => Math.sqrt(a)),
  math("round", "Round to the nearest integer.", ([a = 0]) => Math.round(a)),
  {
    name: "rand",
    help: "Random number: /rand [to] or /rand from=a to=b round=round|ceil|floor",
    origin: "st",
    run: (c) => {
      const fromArg = str(c, "from");
      const toArg = str(c, "to") ?? (text(c.unnamed).trim() || undefined);
      const from = Number(fromArg ?? 0);
      const to = Number(toArg ?? 1);
      const lo = Math.min(from, to);
      const hi = Math.max(from, to);
      let n = lo + Math.random() * (hi - lo);
      const mode = str(c, "round");
      if (mode === "round") n = Math.round(n);
      else if (mode === "ceil") n = Math.ceil(n);
      else if (mode === "floor") n = Math.floor(n);
      return String(n);
    },
  },

  // text
  {
    name: "len",
    aliases: ["length"],
    help: "Length of text, or item count of a JSON array/object.",
    origin: "st",
    run: (c) => {
      const t = text(c.unnamed);
      try {
        const parsed = JSON.parse(t);
        if (Array.isArray(parsed)) return String(parsed.length);
        if (parsed && typeof parsed === "object") return String(Object.keys(parsed).length);
      } catch {
        // plain text
      }
      return String(t.length);
    },
  },
  {
    name: "trimstart",
    help: "Drop text before the first full sentence.",
    origin: "st",
    run: (c) => {
      const t = text(c.unnamed);
      const m = /[.!?…。！？]\s+/.exec(t);
      return m && /^[a-z]/.test(t) ? t.slice(m.index + m[0].length) : t;
    },
  },
  {
    name: "trimend",
    help: "Drop text after the last full sentence.",
    origin: "st",
    run: (c) => {
      const t = text(c.unnamed);
      const m = /[\s\S]*[.!?…。！？"”*)\]]/.exec(t);
      return m ? m[0] : t;
    },
  },
  {
    name: "fuzzy",
    help: "Pick the closest candidate from list=[...] for the input.",
    origin: "st",
    run: (c) => {
      const listRaw = str(c, "list") ?? "[]";
      let list: string[];
      try {
        list = JSON.parse(c.rt.host.local.has(listRaw) ? String(c.rt.host.local.get(listRaw)) : listRaw);
      } catch {
        list = [];
      }
      const input = text(c.unnamed).toLowerCase();
      let best = "";
      let bestScore = -1;
      for (const item of list) {
        const score = similarity(String(item).toLowerCase(), input);
        if (score > bestScore) {
          best = String(item);
          bestScore = score;
        }
      }
      return best;
    },
  },
  {
    name: "parser-flag",
    help: "Parser flags are handled while parsing.",
    origin: "st",
    run: () => "",
  },
];

function similarity(a: string, b: string): number {
  if (a === b) return 1;
  if (a.includes(b) || b.includes(a)) return 0.9;
  const grams = (s: string) => new Set(Array.from({ length: Math.max(0, s.length - 1) }, (_, i) => s.slice(i, i + 2)));
  const ga = grams(a);
  const gb = grams(b);
  let common = 0;
  for (const g of ga) if (gb.has(g)) common++;
  return (2 * common) / (ga.size + gb.size || 1);
}
