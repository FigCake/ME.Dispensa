import type { CommandSpec } from "./ast";
import type { CommandCall } from "./interpreter";

export interface CommandDef extends CommandSpec {
  name: string;
  aliases?: string[];
  /** One-line description shown in the editor's command list. */
  help: string;
  /** Present in SillyTavern ("st"), Dispensa-only ("dispensa"), Marinara pass-through ("marinara") or added by another extension ("extension"). */
  origin?: "st" | "dispensa" | "marinara" | "extension";
  /** The extension that added it (origin "extension"), shown on it in the editor. */
  from?: string;
  /** Left out of the editor's list: a Dispensa or Marinara command does the same job. It still runs. */
  unlisted?: boolean;
  run(call: CommandCall): Promise<unknown> | unknown;
}

export class CommandRegistry {
  private readonly map = new Map<string, CommandDef>();

  register(...defs: CommandDef[]): this {
    for (const def of defs) {
      this.map.set(def.name, def);
      for (const alias of def.aliases ?? []) this.map.set(alias, def);
    }
    return this;
  }

  /** Takes a command out, under its name and aliases (another extension's, when it stops). */
  unregister(def: CommandDef): void {
    for (const name of [def.name, ...(def.aliases ?? [])]) if (this.map.get(name) === def) this.map.delete(name);
  }

  get(name: string): CommandDef | undefined {
    return this.map.get(name);
  }

  has(name: string): boolean {
    return this.map.has(name);
  }

  /** The commands the editor lists (unlisted ones still run). */
  list(): CommandDef[] {
    return [...new Set(this.map.values())].filter((d) => !d.unlisted).sort((a, b) => a.name.localeCompare(b.name));
  }
}
