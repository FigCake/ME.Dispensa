// Same file in Dispensa and Fornello (src/shared/): after a change, run
// `npm run shared -- sync <path to the other repository>`.

// Reading and writing Marinara's tracker state (the Tracker Panel) by path.
//
// Paths:
//   date | time | location | weather | temperature
//   world.<field>                  world custom field
//   custom.<field>                 Custom Tracker field (playerStats.customTrackerFields)
//   persona.<stat>                 persona stat bar value (persona.<stat>.max for the maximum)
//   char.<name>.<mood|appearance|outfit|thoughts|emoji|action>
//   char.<name>.<stat>             character stat bar value (.max for the maximum)
//   char.<name>.<field>            character custom field (when no stat has that name)
//   status                         player status text
//   inventory | quests | events | characters   (JSON, read only)

interface Stat {
  name: string;
  value: number;
  max: number;
  color: string;
}

export interface TrackerState {
  messageId?: string;
  swipeIndex?: number;
  date?: string | null;
  time?: string | null;
  location?: string | null;
  weather?: string | null;
  temperature?: string | null;
  worldCustomFields?: { name: string; value: string; icon?: string | null }[];
  presentCharacters?: {
    characterId?: string;
    name: string;
    emoji?: string;
    mood?: string;
    action?: string;
    appearance?: string | null;
    outfit?: string | null;
    thoughts?: string | null;
    customFields?: Record<string, string>;
    stats?: Stat[];
  }[];
  recentEvents?: string[];
  playerStats?: {
    stats?: Stat[];
    attributes?: unknown;
    skills?: Record<string, number>;
    inventory?: unknown[];
    activeQuests?: unknown[];
    status?: string;
    /** `instruction`: what the tracker AI writes in it (not Marinara's own: it keeps and shows the field as it is). */
    customTrackerFields?: { name: string; value: string; locked?: boolean; instruction?: string }[];
    [key: string]: unknown;
  } | null;
  personaStats?: Stat[] | null;
  [key: string]: unknown;
}

export class TrackerPathError extends Error {}

const SCALARS = new Set(["date", "time", "location", "weather", "temperature"]);
const CHAR_TEXT = new Set(["mood", "appearance", "outfit", "thoughts", "emoji", "action"]);
const DEFAULT_COLOR = "#ec4b97";

function split(path: string): string[] {
  const parts = path.split(".").map((p) => p.trim());
  if (parts.some((p) => p === "")) throw new TrackerPathError(`Invalid tracker path "${path}"`);
  return parts;
}

const sameName = (a: string, b: string) => a.trim().toLowerCase() === b.trim().toLowerCase();
const json = (v: unknown) => JSON.stringify(v ?? null);

/** The value at a path as text ("" when missing). */
export function getTrackerValue(state: TrackerState | null, path: string): string {
  if (!path.trim()) return json(state);
  if (!state) return "";
  const [head, ...rest] = split(path);
  const key = head.toLowerCase();
  if (SCALARS.has(key) && rest.length === 0) return String(state[key] ?? "");
  switch (key) {
    case "world":
      return state.worldCustomFields?.find((f) => sameName(f.name, rest.join(".")))?.value ?? "";
    case "custom":
      return state.playerStats?.customTrackerFields?.find((f) => sameName(f.name, rest.join(".")))?.value ?? "";
    case "status":
      return String(state.playerStats?.status ?? "");
    case "persona": {
      const [stat, sub] = rest;
      const s = state.personaStats?.find((x) => sameName(x.name, stat ?? ""));
      return s ? String(sub === "max" ? s.max : s.value) : "";
    }
    case "char": {
      const [name, field, sub] = rest;
      const c = state.presentCharacters?.find((x) => sameName(x.name, name ?? ""));
      if (!c) return "";
      if (!field) return json(c);
      if (CHAR_TEXT.has(field.toLowerCase())) return String((c as Record<string, unknown>)[field.toLowerCase()] ?? "");
      const stat = c.stats?.find((x) => sameName(x.name, field));
      if (stat) return String(sub === "max" ? stat.max : stat.value);
      const custom = Object.entries(c.customFields ?? {}).find(([k]) => sameName(k, field));
      return custom ? custom[1] : "";
    }
    case "inventory":
      return json(state.playerStats?.inventory ?? []);
    case "quests":
      return json(state.playerStats?.activeQuests ?? []);
    case "events":
      return json(state.recentEvents ?? []);
    case "characters":
      return json((state.presentCharacters ?? []).map((c) => c.name));
    default:
      throw new TrackerPathError(`Unknown tracker path "${path}"`);
  }
}

export interface SetOptions {
  max?: number;
  color?: string;
  /** Character stat instead of custom field when the name is new. */
  asStat?: boolean;
}

/**
 * Change one value. Returns the names of the top-level fields to send back
 * (Marinara replaces each sent field wholesale, so callers send the whole field).
 */
export function setTrackerValue(state: TrackerState, path: string, value: string, opts: SetOptions = {}): string[] {
  const [head, ...rest] = split(path);
  const key = head.toLowerCase();
  if (SCALARS.has(key) && rest.length === 0) {
    state[key] = value;
    return [key];
  }
  const ensurePlayer = () => (state.playerStats ??= { stats: [], attributes: null, skills: {}, inventory: [], activeQuests: [], status: "" });
  switch (key) {
    case "world": {
      const name = rest.join(".");
      const list = (state.worldCustomFields ??= []);
      const f = list.find((x) => sameName(x.name, name));
      if (f) f.value = value;
      else list.push({ name, value });
      return ["worldCustomFields"];
    }
    case "custom": {
      const name = rest.join(".");
      const list = (ensurePlayer().customTrackerFields ??= []);
      const f = list.find((x) => sameName(x.name, name));
      if (f) f.value = value;
      else list.push({ name, value });
      return ["playerStats"];
    }
    case "status":
      ensurePlayer().status = value;
      return ["playerStats"];
    case "persona": {
      const [statName, sub] = rest;
      if (!statName) throw new TrackerPathError("persona.<stat> needs a stat name");
      const list = (state.personaStats ??= []);
      upsertStat(list, statName, sub, value, opts);
      return ["personaStats"];
    }
    case "char": {
      const [name, field, sub] = rest;
      if (!name || !field) throw new TrackerPathError("char.<name>.<field> needs a character name and a field");
      const list = (state.presentCharacters ??= []);
      let c = list.find((x) => sameName(x.name, name));
      if (!c) {
        c = { name, emoji: "", mood: "", appearance: null, outfit: null, thoughts: null, customFields: {}, stats: [] };
        list.push(c);
      }
      const lower = field.toLowerCase();
      if (CHAR_TEXT.has(lower)) {
        (c as Record<string, unknown>)[lower] = value;
      } else if (c.stats?.some((x) => sameName(x.name, field)) || opts.asStat || sub === "max" || opts.max !== undefined) {
        upsertStat((c.stats ??= []), field, sub, value, opts);
      } else {
        const fields = (c.customFields ??= {});
        const existing = Object.keys(fields).find((k) => sameName(k, field));
        fields[existing ?? field] = value;
      }
      return ["presentCharacters"];
    }
    default:
      throw new TrackerPathError(`Can't change tracker path "${path}"`);
  }
}

function upsertStat(list: Stat[], name: string, sub: string | undefined, value: string, opts: SetOptions): void {
  const n = Number(value);
  if (Number.isNaN(n)) throw new TrackerPathError(`Stat "${name}" needs a number, got "${value}"`);
  let s = list.find((x) => sameName(x.name, name));
  if (!s) {
    s = { name, value: 0, max: opts.max ?? 100, color: opts.color ?? DEFAULT_COLOR };
    list.push(s);
  }
  if (sub === "max") s.max = n;
  else s.value = n;
  if (opts.max !== undefined) s.max = opts.max;
  if (opts.color) s.color = opts.color;
}
