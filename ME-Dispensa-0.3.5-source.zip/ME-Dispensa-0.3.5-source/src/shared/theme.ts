// Same file in Dispensa and Fornello (src/shared/): after a change, run
// `npm run shared -- sync <path to the other repository>`.

// Follows Marinara's theme. Two sources:
//  1. Marinara's chat chrome tokens (--marinara-chat-chrome-*): the values
//     themes are meant to override ("Custom themes can override
//     --marinara-chat-chrome-* without touching component code").
//  2. The live look of Marinara's own composer and body text, mirrored into
//     --dsp-shell-* / --dsp-font, so themes that restyle elements directly
//     (not only tokens) still match.
// Shadow roots inherit custom properties, so every surface of both extensions
// reads these (Fornello uses the tokens; ThemeSync is Dispensa's).

/** Token aliases every shadow root of both extensions starts with. */
export const THEME_TOKENS = `
:host {
  --d-font: var(--dsp-font, inherit);
  --d-mono: var(--font-mono, ui-monospace, SFMono-Regular, Menlo, monospace);
  --d-text: var(--marinara-chat-chrome-panel-text, var(--foreground, #e5e5e5));
  --d-title: var(--marinara-chat-chrome-panel-title, var(--d-text));
  --d-muted: var(--marinara-chat-chrome-panel-muted, var(--muted-foreground, #a1a1aa));
  --d-line: var(--marinara-chat-chrome-panel-border, var(--border, #333));
  --d-divider: var(--marinara-chat-chrome-panel-divider, var(--d-line));
  --d-panel: var(--marinara-chat-chrome-panel-bg, var(--popover, #141414));
  --d-panel-solid: linear-gradient(var(--d-panel), var(--d-panel)), var(--background, #111);
  --d-btn-bg: var(--marinara-chat-chrome-button-bg, var(--secondary, #222));
  --d-btn-border: var(--marinara-chat-chrome-button-border, var(--d-line));
  --d-btn-text: var(--marinara-chat-chrome-button-text, var(--d-text));
  --d-btn-bg-hover: var(--marinara-chat-chrome-button-bg-hover, var(--accent, #2a1a3e));
  --d-btn-border-hover: var(--marinara-chat-chrome-button-border-hover, var(--d-accent));
  --d-btn-text-hover: var(--marinara-chat-chrome-button-text-hover, var(--d-text));
  --d-btn-bg-active: var(--marinara-chat-chrome-button-bg-active, var(--d-btn-bg-hover));
  --d-btn-border-active: var(--marinara-chat-chrome-button-border-active, var(--d-accent));
  --d-btn-text-active: var(--marinara-chat-chrome-button-text-active, var(--d-accent));
  --d-hl-bg: var(--marinara-chat-chrome-highlight-bg, var(--accent, #2a1a3e));
  --d-hl-text: var(--marinara-chat-chrome-highlight-text, var(--d-accent));
  --d-field: var(--marinara-chat-chrome-input-bg, var(--input, #141414));
  --d-field-border: var(--marinara-chat-chrome-input-border, var(--d-line));
  --d-field-focus: var(--marinara-chat-chrome-input-border-focus, var(--d-accent));
  --d-ring: var(--marinara-chat-chrome-focus-ring, var(--ring, var(--d-accent)));
  --d-accent: var(--marinara-chat-chrome-accent, var(--primary, #ec4b97));
  --d-accent-fill: var(--marinara-chat-chrome-accent-gradient, var(--d-accent));
  --d-accent-text: var(--primary-foreground, #fff);
  --d-danger: var(--destructive, #e5484d);
  --d-radius: var(--radius, 0.75rem);
  --d-radius-sm: calc(var(--d-radius) - 0.25rem);
  --d-shadow: 0 10px 30px rgb(0 0 0 / 0.28);
  --d-shell-bg: var(--dsp-shell-bg, var(--marinara-chat-chrome-input-bg, var(--d-panel)));
  --d-shell-border: var(--dsp-shell-border, 1px solid var(--d-field-border));
  --d-shell-radius: var(--dsp-shell-radius, var(--d-radius));
  --d-shell-shadow: var(--dsp-shell-shadow, none);
  --d-shell-blur: var(--dsp-shell-blur, none);
}
`;

/** Buttons and fields in the style of Marinara's .mari-chrome-control / .mari-chrome-field. */
export const CONTROLS = `
button { font: inherit; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; white-space: nowrap;
  border: 1px solid var(--d-btn-border); background: var(--d-btn-bg); color: var(--d-btn-text); font-weight: 600;
  border-radius: var(--d-radius-sm); padding: 5px 10px;
  transition: background-color 150ms ease, border-color 150ms ease, color 150ms ease, box-shadow 150ms ease, transform 120ms ease; }
button:hover { border-color: var(--d-btn-border-hover); background: var(--d-btn-bg-hover); color: var(--d-btn-text-hover); }
button:focus-visible { outline: none; box-shadow: 0 0 0 2px var(--d-ring); }
button:active { transform: scale(0.98); }
button:disabled { cursor: not-allowed; opacity: .45; transform: none; }
button.ghost { background: transparent; border-color: transparent; color: var(--d-muted); font-weight: 500; }
button.ghost:hover { background: var(--d-hl-bg); color: var(--d-hl-text); border-color: transparent; }
button.sel, button.on, button[aria-pressed="true"] { border-color: var(--d-btn-border-active); background: var(--d-btn-bg-active); color: var(--d-btn-text-active); }
button.primary { background: var(--d-accent-fill); color: var(--d-accent-text); border-color: transparent; font-weight: 700; }
button.primary:hover { filter: brightness(1.06); color: var(--d-accent-text); }
button.danger:hover { border-color: var(--d-danger); color: var(--d-danger); background: color-mix(in srgb, var(--d-danger) 10%, transparent); }
input:not([type=checkbox]):not([type=radio]), textarea, select { font: inherit; color: var(--d-text); background: var(--d-field);
  border: 1px solid var(--d-field-border); border-radius: var(--d-radius-sm); padding: 6px 9px; outline: none; }
input:not([type=checkbox]):not([type=radio]):focus, textarea:focus, select:focus { border-color: var(--d-field-focus); box-shadow: 0 0 0 2px var(--d-ring); }
input::placeholder, textarea::placeholder { color: var(--d-muted); }
input[type=checkbox], input[type=radio] { accent-color: var(--d-accent); }
::-webkit-scrollbar { width: 8px; height: 8px; }
::-webkit-scrollbar-thumb { background: var(--marinara-chat-chrome-panel-scrollbar, var(--d-line)); border-radius: 8px; }
`;

/** Round icon buttons in a corner, shown while the pointer is over `.wrap` (always on touch screens; `.keep` ones always). */
export const HOVER_TOOLS = `
.tools { position: absolute; top: 4px; right: 4px; z-index: 5; display: flex; gap: 4px; }
.tools > * { opacity: 0; transition: opacity .15s ease; }
.wrap:hover .tools > *, .wrap:focus-within .tools > *, .tools > .keep { opacity: 1; }
/* touch screens: no hover, so the buttons sit in a row above the page instead of on it */
@media (hover: none) { .tools { position: static; justify-content: flex-end; margin: 0 0 4px; } .tools > * { opacity: 1; } }
.tools button { font: 12px/1 var(--d-font); color: var(--d-btn-text); background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: 999px; cursor: pointer;
  width: 26px; height: 26px; padding: 0; display: grid; place-items: center; box-shadow: var(--d-shadow, 0 2px 8px rgb(0 0 0 / .25)); }
.tools button:hover { border-color: var(--d-btn-border-hover); color: var(--d-btn-text-hover); }
.tools button:disabled { opacity: .5; cursor: progress; }
`;

/** What ThemeSync mirrors. */
type ShellProp = "--dsp-shell-bg" | "--dsp-shell-border" | "--dsp-shell-radius" | "--dsp-shell-shadow" | "--dsp-shell-blur" | "--dsp-font";

/** Mirrors the composer's look and the body font into a <style> in <head>. */
export class ThemeSync {
  private readonly style = document.createElement("style");
  private observer: MutationObserver | null = null;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private last = "";
  private composer: Element | null = null;

  /** `id`: the <style> element's id in <head>. */
  constructor(private readonly id: string) {}

  start(): void {
    this.style.id = this.id;
    document.head.append(this.style);
    // Theme switches: attributes and inline style on <html>, theme CSS in <head>
    this.observer = new MutationObserver((records) => {
      if (records.some((r) => r.target === this.style || (r.type === "childList" && [...r.addedNodes].every((n) => n === this.style)))) return;
      this.schedule();
    });
    this.observer.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme", "class", "style"] });
    this.observer.observe(document.head, { childList: true, subtree: true, characterData: true });
    this.refresh();
  }

  stop(): void {
    this.observer?.disconnect();
    if (this.timer) clearTimeout(this.timer);
    this.style.remove();
  }

  /** Call when the composer may have been replaced (React re-render, chat switch). */
  noticeComposer(): void {
    const composer = document.querySelector(".mari-chat-input-box");
    if (composer !== this.composer) {
      this.composer = composer;
      this.schedule();
    }
  }

  private schedule(): void {
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => this.refresh(), 120);
  }

  refresh(): void {
    const values: Partial<Record<ShellProp, string>> = {};
    values["--dsp-font"] = getComputedStyle(document.body).fontFamily;
    const box = document.querySelector(".mari-chat-input-box");
    if (box) {
      const cs = getComputedStyle(box);
      const image = cs.backgroundImage && cs.backgroundImage !== "none" ? `${cs.backgroundImage}, ` : "";
      values["--dsp-shell-bg"] = `${image}linear-gradient(${cs.backgroundColor}, ${cs.backgroundColor})`;
      values["--dsp-shell-border"] = `${cs.borderTopWidth} ${cs.borderTopStyle} ${cs.borderTopColor}`;
      values["--dsp-shell-radius"] = cs.borderTopLeftRadius;
      values["--dsp-shell-shadow"] = cs.boxShadow;
      values["--dsp-shell-blur"] = cs.backdropFilter || "none";
    }
    const css = `:root {\n${Object.entries(values)
      .filter(([, v]) => v)
      .map(([k, v]) => `  ${k}: ${v};`)
      .join("\n")}\n}`;
    if (css !== this.last) {
      this.last = css;
      this.style.textContent = css;
    }
  }
}
