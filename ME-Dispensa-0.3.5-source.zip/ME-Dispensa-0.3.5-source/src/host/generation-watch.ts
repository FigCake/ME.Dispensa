// Watches Marinara's own requests (it has no "generation is starting" event):
// POST /api/generate is held until the "before the AI writes" QRs are done,
// its event stream is read alongside Marinara (my message saved, a group
// member's turn, the reply saved), and POST /api/chats tells a new chat.

export interface GenerateEvent {
  type: string;
  data?: unknown;
}

export interface GenerationHooks {
  /** Before the request goes out (awaited, within a time limit). */
  beforeGeneration(body: Record<string, unknown>): Promise<void>;
  /** Each event of the reply stream. */
  onEvent(event: GenerateEvent, body: Record<string, unknown>): void;
  /** A chat was created. */
  onChatCreated(chat: { id: string }): void;
}

/** How long a generation waits for the "before" QRs. */
const BEFORE_LIMIT_MS = 60_000;

export function watchGeneration(hooks: GenerationHooks, limitMs = BEFORE_LIMIT_MS): () => void {
  const original = window.fetch;
  let active = true;
  const wrapped: typeof window.fetch = async function (this: unknown, input: RequestInfo | URL, init?: RequestInit) {
    if (!active) return original.call(this ?? window, input, init);
    const req = describe(input, init);
    if (req.method === "POST" && /\/api\/generate$/.test(req.path)) {
      const body = parseBody(init?.body);
      await withLimit(hooks.beforeGeneration(body), limitMs);
      const res = await original.call(this ?? window, input, init);
      return tapStream(res, (event) => hooks.onEvent(event, body));
    }
    const res = await original.call(this ?? window, input, init);
    if (req.method === "POST" && /\/api\/chats$/.test(req.path) && res.ok) {
      res
        .clone()
        .json()
        .then((chat: unknown) => {
          const id = (chat as { id?: unknown } | null)?.id;
          if (typeof id === "string") hooks.onChatCreated({ id });
        })
        .catch(() => undefined);
    }
    return res;
  };
  window.fetch = wrapped;
  return () => {
    active = false;
    // another wrapper may sit on top of ours; then ours stays as a pass-through
    if (window.fetch === wrapped) window.fetch = original;
  };
}

function describe(input: RequestInfo | URL, init?: RequestInit): { method: string; path: string } {
  const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
  const method = (init?.method ?? (typeof input === "object" && "method" in input ? input.method : "GET")).toUpperCase();
  let path = url;
  try {
    path = new URL(url, location.href).pathname;
  } catch {
    // keep the raw url
  }
  return { method, path: path.replace(/\/+$/, "") };
}

function parseBody(body: unknown): Record<string, unknown> {
  if (typeof body !== "string") return {};
  try {
    const parsed = JSON.parse(body);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

async function withLimit(work: Promise<void>, ms: number): Promise<void> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    await Promise.race([work.catch((e) => console.warn("[Dispensa] before-generation", e)), new Promise<void>((r) => (timer = setTimeout(r, ms)))]);
  } finally {
    clearTimeout(timer);
  }
}

/** Hands Marinara the same stream while a copy is read here. */
function tapStream(res: Response, onEvent: (event: GenerateEvent) => void): Response {
  if (!res.ok || !res.body || !/event-stream/.test(res.headers.get("content-type") ?? "")) return res;
  const [mine, theirs] = res.body.tee();
  void readEvents(mine, onEvent);
  return new Response(theirs, { status: res.status, statusText: res.statusText, headers: res.headers });
}

export async function readEvents(stream: ReadableStream<Uint8Array>, onEvent: (event: GenerateEvent) => void): Promise<void> {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  const flush = (chunk: string) => {
    for (const line of chunk.split("\n")) {
      if (!line.startsWith("data:")) continue;
      try {
        const event = JSON.parse(line.slice(5).trim());
        if (event && typeof event.type === "string") onEvent(event);
      } catch {
        // not JSON
      }
    }
  };
  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let cut: number;
      while ((cut = buffer.indexOf("\n\n")) >= 0) {
        flush(buffer.slice(0, cut));
        buffer = buffer.slice(cut + 2);
      }
    }
    if (buffer.trim()) flush(buffer);
  } catch {
    // the generation was stopped
  } finally {
    onEvent({ type: "dispensa:end" });
  }
}

/** Lorebook entries that came into play, from a saved message's extra. */
export function activatedEntries(message: unknown): { id?: unknown; name?: unknown }[] {
  const raw = (message as { extra?: unknown } | null)?.extra;
  let extra: unknown = raw;
  if (typeof raw === "string") {
    try {
      extra = JSON.parse(raw);
    } catch {
      return [];
    }
  }
  const scan = (extra as { lorebookScan?: { activatedEntries?: unknown } } | null)?.lorebookScan;
  return Array.isArray(scan?.activatedEntries) ? scan.activatedEntries : [];
}
