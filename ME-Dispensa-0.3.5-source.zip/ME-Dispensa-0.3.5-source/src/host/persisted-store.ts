// A piece of state kept under one key of Dispensa's Marinara extension
// storage (so it follows the user to other devices). The QR Library, the
// visz settings and the memo pad are each one of these.
//
// Changes go through update(): it changes the state in place, tells the
// listeners, and saves a moment later (typing does not write on every key).
// A store that failed to load never saves, so a read error can't wipe data.

import { getMarinara } from "../shared/marinara-global";

export interface StoreSpec<T> {
  /** The storage key. */
  key: string;
  /** Saved data → a complete state (missing or broken parts get defaults); normalize(undefined) is the empty state. */
  normalize(raw: unknown): T;
  /** A fresh install's state (nothing saved under `key` yet), saved right away. Default: the empty state. */
  initial?(): T;
  /** For log messages. */
  label: string;
}

/** Marinara allows 1,000,000 bytes of extension storage in total. */
export const STORAGE_LIMIT = 1_000_000;
/** Past this, Dispensa warns that storage is almost full. */
export const STORAGE_SOFT_LIMIT = 900_000;
/** Past this, the Dispensa window shows how full storage is. */
export const STORAGE_SHOW_FROM = 700_000;

/** How long after the last change a save happens. */
const SAVE_DELAY_MS = 400;

export class PersistedStore<T> {
  private state: T;
  private readonly listeners = new Set<(s: T) => void>();
  private saveTimer: ReturnType<typeof setTimeout> | null = null;
  private loadedOk = false;

  constructor(private readonly spec: StoreSpec<T>) {
    this.state = spec.normalize(undefined);
  }

  /** Loaded from storage (writes are safe). */
  get ready(): boolean {
    return this.loadedOk;
  }

  get value(): T {
    return this.state;
  }

  async load(): Promise<void> {
    try {
      const stored = await getMarinara().storage.get();
      const raw = stored[this.spec.key];
      const fresh = raw == null && !!this.spec.initial;
      this.state = fresh ? this.spec.initial!() : this.spec.normalize(raw);
      this.loadedOk = true;
      if (fresh) this.scheduleSave();
    } catch (e) {
      // Never overwrite storage we could not read.
      this.loadedOk = false;
      throw e;
    }
    this.emit();
  }

  subscribe(fn: (s: T) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  /**
   * Like subscribe, but `fn` runs only when the slice `pick` returns has
   * changed (compared as JSON; a string is compared as it is), so a view
   * redraws only for what it shows.
   */
  select(pick: (s: T) => unknown, fn: (s: T) => void): () => void {
    const key = (s: T) => {
      const v = pick(s);
      return typeof v === "string" ? v : JSON.stringify(v);
    };
    let last = key(this.state);
    return this.subscribe((s) => {
      const next = key(s);
      if (next === last) return;
      last = next;
      fn(s);
    });
  }

  update(mutate: (s: T) => void): void {
    mutate(this.state);
    this.emit();
    this.scheduleSave();
  }

  /** Size of the saved data in bytes, to warn before Marinara's limit. */
  size(): number {
    return new TextEncoder().encode(JSON.stringify(this.state)).length;
  }

  async saveNow(): Promise<void> {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = null;
    if (!this.loadedOk) return;
    await getMarinara().storage.patch({ [this.spec.key]: this.state });
  }

  private scheduleSave(): void {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => {
      void this.saveNow().catch((e) => console.error(`[Dispensa] ${this.spec.label} save failed`, e));
    }, SAVE_DELAY_MS);
  }

  private emit(): void {
    for (const fn of this.listeners) fn(this.state);
  }
}

/** Bytes all of Dispensa's stores take together (they share Marinara's one limit). */
export function storageUsed(stores: ({ size(): number } | undefined)[]): number {
  return stores.reduce((sum, s) => sum + (s?.size() ?? 0), 0);
}
