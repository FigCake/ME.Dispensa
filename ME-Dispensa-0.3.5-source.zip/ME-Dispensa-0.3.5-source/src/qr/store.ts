// The QR Library (sets, the Dock, where sets are on) in Marinara's storage (key "qr").

import { PersistedStore } from "../host/persisted-store";
import { viszSet } from "../visz/set";
import { exampleSet } from "./examples";
import { type QrState, emptyState, normalizeState } from "./model";

/** A fresh install: the Visualizer set and the Example QRs set (both off), an empty Dock. */
export function firstRunState(): QrState {
  return { ...emptyState(), sets: [viszSet(), exampleSet()] };
}

export class QrStore extends PersistedStore<QrState> {
  constructor() {
    super({ key: "qr", normalize: normalizeState, initial: firstRunState, label: "QR" });
  }
}
