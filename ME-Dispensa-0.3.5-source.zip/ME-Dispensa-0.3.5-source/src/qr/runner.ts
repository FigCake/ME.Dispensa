// Runs a Quick Reply: STscript through the interpreter, plain text through
// the chat input (honoring SillyTavern's set options).

import { submitThroughComposer } from "../shared/composer";
import { type Debugger, Runtime, asText } from "../stscript/interpreter";
import type { Host } from "../stscript/host";
import type { CommandRegistry } from "../stscript/registry";
import { Scope, ScriptError } from "../stscript/scope";
import { type QrItem, type QrSet, type QrState, findItem } from "./model";
import { t } from "../shared/i18n";

export interface RunnerEvents {
  onStart?(item: QrItem): void;
  onEnd?(item: QrItem): void;
}

export interface RunOptions {
  /** Started by a trigger: never blocked by a running QR, never shown on the Dock. */
  auto?: boolean;
}

export class QrRunner {
  private controller: AbortController | null = null;
  private current: QrItem | null = null;
  /** Auto-runs under way (they run alongside a QR started by hand). */
  private readonly autoRuns = new Set<AbortController>();

  constructor(
    private readonly host: Host,
    private readonly registry: CommandRegistry,
    private readonly state: () => QrState,
    private readonly events: RunnerEvents = {},
  ) {}

  /** /run and /: look QRs up by name. */
  private readonly findScript = (name: string) => {
    const found = findItem(this.state(), name);
    return found ? sourceOf(found.set, found.item) : undefined;
  };

  get busy(): boolean {
    return this.controller !== null;
  }

  get running(): QrItem | null {
    return this.current;
  }

  /** Stops the QR started by hand and every auto-run. */
  stop(): void {
    this.controller?.abort();
    for (const c of this.autoRuns) c.abort();
  }

  async run(set: QrSet, item: QrItem, options: RunOptions = {}): Promise<void> {
    if (options.auto) {
      const controller = new AbortController();
      this.autoRuns.add(controller);
      try {
        await this.execute(set, item, controller, true);
      } finally {
        this.autoRuns.delete(controller);
      }
      return;
    }
    if (this.controller) {
      this.host.ui.toast(t("Another QR is running. Try again when it's done.", "다른 QR이 실행 중이에요. 끝난 뒤 다시 눌러 주세요."), "warning");
      return;
    }
    const controller = new AbortController();
    this.controller = controller;
    this.current = item;
    this.events.onStart?.(item);
    try {
      await this.execute(set, item, controller, false);
    } finally {
      this.controller = null;
      this.current = null;
      this.events.onEnd?.(item);
    }
  }

  private async execute(set: QrSet, item: QrItem, controller: AbortController, auto: boolean): Promise<void> {
    try {
      const script = item.script;
      if (script.trimStart().startsWith("/")) {
        const rt = new Runtime({
          host: this.host,
          registry: this.registry,
          dialect: item.dialect,
          signal: controller.signal,
          findScript: this.findScript,
          source: { label: `${set.name}.${item.label}`, text: script },
        });
        const result = await rt.runScript(script);
        if (result.aborted && result.abortReason && result.abortReason !== "Stopped by user") {
          this.host.ui.toast(result.abortReason, "info");
        }
      } else {
        await this.sendPlain(set, script, item, auto);
      }
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      this.host.ui.toast(message, "error", { title: t(`QR "${item.label}" failed`, `QR "${item.label}" 실행 실패`) });
      if (!(e instanceof ScriptError)) console.error("[Dispensa]", e);
    }
  }

  /**
   * Run from the QR editor: the result comes back (the pipe, or the error
   * thrown), optionally stopping in the debugger.
   */
  async runInEditor(set: QrSet, item: QrItem, options: { signal: AbortSignal; debug?: Debugger }): Promise<{ pipe: string; aborted?: string }> {
    if (!item.script.trimStart().startsWith("/")) {
      await this.sendPlain(set, item.script, item);
      return { pipe: "" };
    }
    const rt = new Runtime({
      host: this.host,
      registry: this.registry,
      dialect: item.dialect,
      signal: options.signal,
      debug: options.debug,
      findScript: this.findScript,
      source: { label: `${set.name}.${item.label}`, text: item.script },
    });
    const result = await rt.runScript(item.script);
    return { pipe: asText(result.pipe), aborted: result.aborted ? result.abortReason || t("Stopped", "중단됨") : undefined };
  }

  /** Run a QR from inside another running QR (/qr). Shares the stop button. */
  async runNested(set: QrSet, item: QrItem): Promise<void> {
    if (!item.script.trimStart().startsWith("/")) {
      await this.sendPlain(set, item.script, item);
      return;
    }
    const rt = new Runtime({
      host: this.host,
      registry: this.registry,
      dialect: item.dialect,
      signal: this.controller?.signal,
      findScript: this.findScript,
    });
    await rt.runScript(item.script);
  }

  /** SillyTavern: a QR without a leading "/" is text for the chat input (an auto-run sends it as is). */
  private async sendPlain(set: QrSet, text: string, item: QrItem, auto = false): Promise<void> {
    const rt = new Runtime({ host: this.host, registry: this.registry, dialect: item.dialect });
    await this.host.beginRun?.();
    const resolved = String(await rt.substitute(text, new Scope()));
    const current = auto ? "" : this.host.ui.getInput();
    const line = set.injectInput && current ? (set.placeBeforeInput ? `${resolved} ${current}` : `${current} ${resolved}`) : resolved;
    if (set.disableSend) {
      this.host.ui.setInput(line);
      return;
    }
    if (set.injectInput && current) this.host.ui.setInput("");
    await submitThroughComposer(line);
  }
}

/** What /run executes for a QR. */
function sourceOf(set: QrSet, item: QrItem) {
  return { script: item.script, dialect: item.dialect, label: item.label, setName: set.name };
}
