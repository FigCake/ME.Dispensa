// Step QRs: a QR made of steps (choices and text boxes) and one prompt, kept
// as data so the editor can show them as cards again. Running or exporting
// one uses the STscript made from it (stepsScript), so the interpreter, the
// debugger and SillyTavern files work as for any QR.

import { t } from "../shared/i18n";
import { escapeScriptText } from "./script-text";

interface StepOption {
  label: string;
  /** With the step's `perOption`: what is sent when this one is picked. */
  prompt?: string;
}

export interface QrStep {
  /** The variable the answer is kept in; `{{name}}` in the prompt. */
  name: string;
  kind: "choice" | "input";
  question: string;
  options: StepOption[];
  /** A "type it" choice: its label, and the question its text box asks. */
  custom?: { label: string; question: string };
  /** Each option sends its own prompt (`{{name:prompt}}` in the prompt). */
  perOption?: boolean;
}

export type StepFrame = "system" | "ooc" | "none";
/** result: /gen, then posted as `as`; user: sent as my message, then a reply; input: put in the chat input. */
export type StepSend = "result" | "user" | "input";

export interface StepQr {
  steps: QrStep[];
  prompt: string;
  frame: StepFrame;
  send: StepSend;
  /** Who the result is posted as (send "result"): {{char}}, a step's {{name}}, or any name. */
  as: string;
  /** Shown when a step is cancelled / when it finishes. */
  cancelText?: string;
  doneText?: string;
  /** false: every variable stays after the QR. */
  clean?: false;
  /** Steps whose variables stay after the QR (for other QRs); the rest are deleted. */
  keep?: string[];
}

/** Letters (any script), digits and _, not starting with a digit. */
export const STEP_NAME = /^[\p{L}_][\p{L}\p{N}_]*$/u;

export function newStepQr(): StepQr {
  return { steps: [], prompt: "", frame: "system", send: "result", as: "{{char}}" };
}

const str = (v: unknown) => (typeof v === "string" ? v : "");

/** A step QR as saved (unknown parts left out). Half-written steps and options stay, so editing never loses them. */
export function normalizeStepQr(raw: unknown): StepQr | undefined {
  if (!raw || typeof raw !== "object") return undefined;
  const r = raw as Record<string, unknown>;
  const steps = (Array.isArray(r.steps) ? r.steps : []).flatMap((s): QrStep[] => {
    if (!s || typeof s !== "object") return [];
    const x = s as Record<string, unknown>;
    const name = str(x.name).trim();
    const options = (Array.isArray(x.options) ? x.options : []).map((o) => (typeof o === "string" ? { label: o } : { label: str((o as StepOption)?.label), ...(str((o as StepOption)?.prompt) ? { prompt: str((o as StepOption).prompt) } : {}) }));
    const c = x.custom as { label?: unknown; question?: unknown } | undefined;
    return [
      {
        name,
        kind: x.kind === "input" ? "input" : "choice",
        question: str(x.question),
        options,
        ...(c && typeof c === "object" ? { custom: { label: str(c.label), question: str(c.question) } } : {}),
        ...(x.perOption === true ? { perOption: true } : {}),
      },
    ];
  });
  return {
    steps,
    prompt: str(r.prompt),
    frame: r.frame === "ooc" || r.frame === "none" ? r.frame : "system",
    send: r.send === "user" || r.send === "input" ? r.send : "result",
    as: str(r.as) || "{{char}}",
    ...(str(r.cancelText) ? { cancelText: str(r.cancelText) } : {}),
    ...(str(r.doneText) ? { doneText: str(r.doneText) } : {}),
    ...(r.clean === false ? { clean: false as const } : {}),
    ...(Array.isArray(r.keep) ? { keep: r.keep.filter((k): k is string => typeof k === "string") } : {}),
  };
}

/** What is wrong with it, for the editor (empty: it can run). */
export function stepProblems(q: StepQr): string[] {
  const out: string[] = [];
  const names = new Set<string>();
  for (const s of q.steps) {
    if (!STEP_NAME.test(s.name)) out.push(`name:${s.name}`);
    else if (names.has(s.name)) out.push(`duplicate:${s.name}`);
    names.add(s.name);
    if (s.kind === "choice" && !s.options.some((o) => o.label.trim()) && !s.custom?.label.trim()) out.push(`options:${s.name}`);
  }
  if (q.steps.filter((s) => s.kind === "choice" && s.perOption).length > 1) out.push("perOption");
  if (!q.prompt.trim() && !q.steps.some((s) => s.kind === "choice" && s.perOption)) out.push("prompt");
  return out;
}

const quote = (text: string) => JSON.stringify(text);
const get = (name: string) => `{{getvar::${name}}}`;

/** The prompt with `{{name}}` turned into the step's variable, and `{{name:prompt}}` into `optionPrompt`. */
function fill(text: string, names: Set<string>, branch?: { name: string; prompt: string }): string {
  return text.replace(/\{\{([\p{L}\p{N}_]+)(:prompt)?\}\}/gu, (whole, name: string, wantsPrompt?: string) => {
    if (!names.has(name)) return whole;
    if (wantsPrompt) return branch && branch.name === name ? branch.prompt : whole;
    return get(name);
  });
}

function framed(text: string, frame: StepFrame): string {
  if (frame === "system") return `<System>\n${text}\n</System>`;
  if (frame === "ooc") return `*{OOC: ${text}}*`;
  return text;
}

/** The STscript a step QR runs as (while it has problems, a warning that says so). */
export function stepsScript(q: StepQr): string {
  if (stepProblems(q).length) return `/echo severity=warning ${escapeScriptText(t("This step QR isn't finished: see its editor.", "아직 덜 만든 단계 QR이에요. 편집 창을 확인해 주세요."))}`;
  const names = new Set(q.steps.map((s) => s.name));
  // every variable made so far: what a cancel (or the end) deletes
  const made: string[] = [];
  const keep = new Set(q.keep ?? []);
  const lines: string[] = [];
  const flush = (list: string[]) => (q.clean === false ? [] : list).filter((n) => !keep.has(n)).map((n) => `/flushvar ${n}`);
  const cancel = () => [...(q.cancelText?.trim() ? [`/echo ${escapeScriptText(q.cancelText.trim())}`] : []), ...flush(made), "/abort"].join(" | ");
  for (const s of q.steps) {
    made.push(s.name);
    const ifEmpty = () => `/if left=${get(s.name)} right="" rule=eq {: ${cancel()} :} |`;
    if (s.kind === "input") {
      lines.push(`/input ${escapeScriptText(fill(s.question || s.name, names))} |`, `/setvar key=${s.name} {{pipe}} |`, ifEmpty());
      continue;
    }
    const options = s.options.filter((o) => o.label.trim());
    const custom = s.custom?.label.trim() ? s.custom : undefined;
    const labels = [...options.map((o) => o.label), ...(custom ? [custom.label] : [])];
    lines.push(`/buttons labels=${JSON.stringify(labels)} ${escapeScriptText(fill(s.question || s.name, names))} |`, `/setvar key=${s.name} {{pipe}} |`, ifEmpty());
    if (custom) {
      // the typed text takes the label's place; _typed remembers it was typed (for its own prompt)
      const typed = `${s.name}_typed`;
      if (s.perOption) made.push(typed);
      lines.push(
        `/if left=${get(s.name)} right=${quote(custom.label)} rule=eq {: /input ${escapeScriptText(fill(custom.question || custom.label, names))} | /setvar key=${s.name} {{pipe}}${s.perOption ? ` | /setvar key=${typed} 1` : ""} :} |`,
        ifEmpty(),
      );
    }
  }
  const send = (prompt: string) => {
    const text = escapeScriptText(framed(prompt, q.frame));
    if (q.send === "input") return `/setinput ${text}`;
    if (q.send === "user") return `/send ${text} | /trigger`;
    const as = fill(q.as.trim() || "{{char}}", names);
    return `/gen lock=on ${text} | /sendas name=${quote(as)}`;
  };
  const branch = q.steps.find((s) => s.kind === "choice" && s.perOption);
  if (branch) {
    const template = q.prompt.trim() ? q.prompt : `{{${branch.name}:prompt}}`;
    for (const o of branch.options.filter((o) => o.label.trim())) {
      lines.push(`/if left=${get(branch.name)} right=${quote(o.label)} rule=eq {: ${send(fill(template, names, { name: branch.name, prompt: fill(o.prompt ?? "", names) }))} :} |`);
    }
    if (branch.custom?.label.trim()) lines.push(`/if left=${get(`${branch.name}_typed`)} right="1" rule=eq {: ${send(fill(template, names, { name: branch.name, prompt: get(branch.name) }))} :} |`);
  } else {
    lines.push(`${send(fill(q.prompt, names))} |`);
  }
  if (q.doneText?.trim()) lines.push(`/echo ${escapeScriptText(q.doneText.trim())} |`);
  lines.push(...flush(made).map((l) => `${l} |`));
  // the last line ends the script, not a pipe
  lines[lines.length - 1] = lines[lines.length - 1].replace(/ \|$/, "");
  return lines.join("\n");
}
