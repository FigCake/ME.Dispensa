// Text put into a generated STscript line (a step QR's prompt, a QR made from
// a memo): escaped so it stays one plain argument.

/** `|`, `\`, `{:` and `:}` escaped: the text neither ends the command, escapes what follows, nor opens or closes a closure. */
export function escapeScriptText(text: string): string {
  return text.replace(/[|\\]/g, (c) => `\\${c}`).replace(/\{:/g, "\\{:").replace(/:\}/g, "\\:}");
}
