// Under the QR editor: run the script and see what came out, or step
// through it (stop at a line, one command at a time, into and out of
// closures and other QRs) with its variables and call stack.

import { DebugSession, type StepMode, lineOf } from "../qr/debug";
import type { DebugStop, Debugger } from "../stscript/interpreter";
import { isClosureValue, type Val } from "../stscript/scope";
import { el, icon } from "./dom";
import { helpTip } from "../shared/form";
import type { ScriptEditor } from "./script-editor";
import { t } from "../shared/i18n";

export const RUN_PANEL_CSS = `
.runbar { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }
.runbar .hint { color: var(--d-muted); font-size: 12px; }
.runbar .stop-run { border-color: var(--d-danger); color: var(--d-danger); }
.out { margin-top: 2px; border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); background: var(--d-field); font-size: 12.5px; overflow: hidden; }
.out > .out-h { display: flex; align-items: center; gap: 8px; padding: 5px 10px; border-bottom: 1px solid var(--d-divider); color: var(--d-muted); font-size: 12px; }
.out > .out-h .grow { flex: 1; }
.out pre { margin: 0; padding: 8px 10px; max-height: 220px; overflow: auto; white-space: pre-wrap; overflow-wrap: anywhere; font: 12.5px/1.5 var(--d-mono); color: var(--d-text); }
.out.error pre { color: var(--d-danger); }
.dbg { display: grid; grid-template-columns: 1fr 1fr; gap: 0; }
.dbg > div { min-width: 0; padding: 6px 10px; }
.dbg > div + div { border-left: 1px solid var(--d-divider); }
.dbg h4 { margin: 0 0 4px; font-size: 11.5px; font-weight: 700; color: var(--d-muted); }
.dbg .var { display: flex; gap: 8px; font: 12px/1.5 var(--d-mono); }
.dbg .var b { color: #c792ea; font-weight: 600; white-space: nowrap; }
.dbg .var span { color: var(--d-text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dbg .frame { font: 12px/1.5 var(--d-mono); color: var(--d-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.dbg .frame.top { color: var(--d-text); font-weight: 600; }
.dbg .lvl { margin-top: 4px; font-size: 11px; color: var(--d-muted); }
.at { padding: 6px 10px; border-bottom: 1px solid var(--d-divider); font: 12.5px/1.5 var(--d-mono); white-space: pre-wrap; overflow-wrap: anywhere; }
@media (max-width: 560px) { .dbg { grid-template-columns: 1fr; } .dbg > div + div { border-left: 0; border-top: 1px solid var(--d-divider); } }
`;

const RUN_HELP = (): string =>
  t(
    "▶ Run (Ctrl+Enter): result below\n🐞 Step: stops at the start, at marked lines and at /breakpoint",
    "▶ 실행 (Ctrl+Enter): 결과는 아래에\n🐞 한 줄씩: 처음·표시한 줄·/breakpoint에서 멈춤",
  );

interface Deps {
  run(signal: AbortSignal, debug?: Debugger): Promise<{ pipe: string; aborted?: string }>;
  editor(): ScriptEditor | null;
  breakpoints(): Set<number>;
  changed(): void;
}

export class RunPanel {
  private controller: AbortController | null = null;
  private session: DebugSession | null = null;
  private stop_: DebugStop | null = null;
  private result: { text: string; kind: "ok" | "error" | "stopped"; ms: number } | null = null;
  private started = 0;

  constructor(private readonly deps: Deps) {}

  get running(): boolean {
    return this.controller !== null;
  }

  /** Ctrl+Enter, the run button, the debug button. */
  async start(debug = false): Promise<void> {
    if (this.controller) return;
    const controller = new AbortController();
    this.controller = controller;
    this.result = null;
    this.started = performance.now();
    this.session = debug
      ? new DebugSession({
          text: () => this.deps.editor()?.value ?? "",
          breakpoints: () => this.deps.breakpoints(),
          startPaused: true,
          onPause: (stop) => {
            this.stop_ = stop;
            this.markEditor();
            this.deps.changed();
          },
        })
      : this.deps.breakpoints().size
        ? // marked lines stop a plain run too
          new DebugSession({
            text: () => this.deps.editor()?.value ?? "",
            breakpoints: () => this.deps.breakpoints(),
            onPause: (stop) => {
              this.stop_ = stop;
              this.markEditor();
              this.deps.changed();
            },
          })
        : null;
    this.deps.changed();
    try {
      const res = await this.deps.run(controller.signal, this.session ?? undefined);
      const ms = performance.now() - this.started;
      this.result = res.aborted ? { text: res.aborted === "Stopped by user" ? t("Stopped.", "중지했어요.") : res.aborted, kind: "stopped", ms } : { text: res.pipe, kind: "ok", ms };
    } catch (e) {
      this.result = { text: e instanceof Error ? e.message : String(e), kind: "error", ms: performance.now() - this.started };
    } finally {
      this.controller = null;
      this.session = null;
      this.stop_ = null;
      this.markEditor();
      this.deps.changed();
    }
  }

  stop(): void {
    this.controller?.abort();
    this.session?.release();
  }

  private step(mode: StepMode): void {
    this.session?.step(mode);
  }

  private markEditor(): void {
    const editor = this.deps.editor();
    if (!editor) return;
    const s = this.stop_;
    editor.setMark(s && s.source && s.source.text === editor.value ? { start: s.node.start, end: s.node.end } : null);
  }

  render(): HTMLElement {
    const paused = this.stop_;
    const bar = el("div", { class: "runbar" });
    if (!this.controller) {
      bar.append(
        el("button", { type: "button", title: t("Run (Ctrl+Enter)", "실행 (Ctrl+Enter)"), onclick: () => void this.start(false) }, icon("play"), t("Run", "실행")),
        el("button", { type: "button", title: t("Run one command at a time", "한 명령씩 실행"), onclick: () => void this.start(true) }, icon("bug"), t("Step", "한 줄씩")),
        helpTip(RUN_HELP(), t("Run and debug", "실행과 디버그")),
      );
    } else if (paused) {
      bar.append(
        el("button", { type: "button", title: t("Run to the next stop", "다음 멈출 곳까지 실행"), onclick: () => this.step("continue") }, icon("play"), t("Continue", "계속")),
        el("button", { type: "button", title: t("Next command at this level", "이 단계의 다음 명령"), onclick: () => this.step("over") }, icon("step-over"), t("Next", "다음")),
        el("button", { type: "button", title: t("Into a closure or /run", "클로저·/run 속으로"), onclick: () => this.step("into") }, icon("step-into"), t("Into", "안으로")),
        el("button", { type: "button", title: t("Finish this level", "이 단계 끝까지"), onclick: () => this.step("out") }, icon("step-out"), t("Out", "밖으로")),
        el("button", { type: "button", class: "stop-run", title: t("Stop", "중지"), onclick: () => this.stop() }, icon("square"), t("Stop", "중지")),
      );
    } else {
      bar.append(el("button", { type: "button", class: "stop-run", onclick: () => this.stop() }, icon("square"), t("Stop", "중지")), el("span", { class: "hint" }, t("Running…", "실행 중…")));
    }
    const box = el("div", { class: "run" }, bar);
    if (paused) box.append(this.pausedView(paused));
    else if (this.result) {
      const r = this.result;
      const head = r.kind === "error" ? t("Error", "오류") : r.kind === "stopped" ? t("Stopped", "멈춤") : t("Result", "결과");
      box.append(
        el(
          "div",
          { class: `out${r.kind === "error" ? " error" : ""}` },
          el("div", { class: "out-h" }, el("strong", {}, head), el("span", { class: "grow" }), `${Math.round(r.ms)}ms`, el("button", { type: "button", class: "icon", title: t("Close", "닫기"), "aria-label": t("Close result", "결과 닫기"), onclick: () => ((this.result = null), this.deps.changed()) }, icon("x"))),
          el("pre", {}, clip(r.text) || (r.kind === "ok" ? t("(empty)", "(빈 값)") : "")),
        ),
      );
    }
    return box;
  }

  private pausedView(stop: DebugStop): HTMLElement {
    const text = stop.source?.text ?? "";
    const where = stop.source ? t(`${stop.source.label} · line ${lineOf(text, stop.node.start) + 1}`, `${stop.source.label} · ${lineOf(text, stop.node.start) + 1}번째 줄`) : t("(command in quotes)", "(따옴표 안 명령)");
    const vars = el("div", {}, el("h4", {}, t("Variables", "변수")));
    const frames = [...stop.stack].reverse();
    frames.forEach((f, i) => {
      const own = f.scope.ownVars();
      if (i > 0 && !own.length) return;
      if (i > 0) vars.append(el("div", { class: "lvl" }, `↑ ${f.label}`));
      if (i === 0) vars.append(el("div", { class: "var" }, el("b", {}, "{{pipe}}"), el("span", { title: show(f.scope.pipe) }, show(f.scope.pipe) || t("(empty)", "(빈 값)"))));
      for (const [k, v] of own) vars.append(el("div", { class: "var" }, el("b", {}, k), el("span", { title: show(v) }, show(v) || t("(empty)", "(빈 값)"))));
    });
    const named = Object.entries(stop.named);
    const args = named.length || (Array.isArray(stop.unnamed) ? stop.unnamed.length : stop.unnamed !== "")
      ? el("div", { class: "lvl" }, `${t("Arguments", "넘길 값")}: ${[...named.map(([k, v]) => `${k}=${show(v)}`), ...(Array.isArray(stop.unnamed) ? stop.unnamed : [stop.unnamed]).map(show)].filter(Boolean).join(" ")}`)
      : null;
    const calls = el(
      "div",
      {},
      el("h4", {}, t("Call stack", "호출 순서")),
      ...frames.map((f, i) => el("div", { class: `frame${i === 0 ? " top" : ""}` }, `${f.node ? `/${f.node.name}` : "…"}  ${f.label}`)),
    );
    return el(
      "div",
      { class: "out" },
      el("div", { class: "out-h" }, el("strong", {}, t("Stopped", "멈춤")), el("span", { class: "grow" }, where)),
      el("div", { class: "at" }, text ? text.slice(stop.node.start, stop.node.end).trim() : `/${stop.node.name}`),
      args ? el("div", { class: "at" }, args) : null,
      el("div", { class: "dbg" }, vars, calls),
    );
  }
}

function show(v: Val | Val[]): string {
  if (Array.isArray(v)) return v.map(show).join(" ");
  return isClosureValue(v) ? t("{: closure :}", "{: 닫힘 :}") : v;
}

function clip(s: string): string {
  return s.length > 6000 ? t(`${s.slice(0, 6000)}\n… (${s.length - 6000} more characters)`, `${s.slice(0, 6000)}\n… (${s.length - 6000}자 더)`) : s;
}
