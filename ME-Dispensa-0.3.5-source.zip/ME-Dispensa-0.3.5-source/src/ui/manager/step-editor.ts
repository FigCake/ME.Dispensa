// A step QR's editor: its steps as cards (choices or a text box), the prompt
// that uses their answers, how the result is sent, and what happens on a
// cancel. Every change makes the QR's script again from the steps.

import { t } from "../../shared/i18n";
import type { QrItem, QrSet } from "../../qr/model";
import { type QrStep, type StepFrame, type StepQr, type StepSend, STEP_NAME, stepProblems, stepsScript } from "../../qr/steps";
import { el, icon } from "../dom";
import { helpTip, setting, toggle } from "../../shared/form";
import type { ManagerContext } from "./context";

const FRAMES = (): { value: StepFrame; label: string }[] => [
  { value: "system", label: "<System> … </System>" },
  { value: "ooc", label: "*{OOC: … }*" },
  { value: "none", label: t("No frame", "틀 없음") },
];

const SENDS = (): { value: StepSend; label: string }[] => [
  {
    value: "result",
    label: t("Get a character reply", "캐릭터 답변으로 받기"),
  },
  {
    value: "user",
    label: t("Send as my message, then a reply", "내 메시지로 보내고 답 받기"),
  },
  { value: "input", label: t("Put it in the chat input", "입력창에 넣기") },
];

/** The editor's words for stepProblems' codes. */
function problemText(code: string): string {
  const [kind, name] = code.split(/:(.*)/s);
  if (kind === "name")
    return name
      ? t(`"${name}": a name is letters, digits and _ (not starting with a digit), no spaces`, `"${name}": 이름은 글자·숫자·_만 (숫자로 시작 X, 띄어쓰기 X)`)
      : t("A step has no name", "이름 없는 단계가 있어요");
  if (kind === "duplicate") return t(`Two steps are called "${name}"`, `"${name}" 이름의 단계가 둘이에요`);
  if (kind === "options") return t(`"${name}" has no options`, `"${name}"에 선택지가 없어요`);
  if (kind === "perOption") return t("Only one step can have a prompt per option", "선택지별 프롬프트는 한 단계만 쓸 수 있어요");
  return t("Write the prompt", "프롬프트를 적어 주세요");
}

/** A name not used by another step yet: step1, step2, … */
function freeName(q: StepQr): string {
  const base = t("step", "단계");
  let n = q.steps.length + 1;
  while (q.steps.some((s) => s.name === `${base}${n}`)) n++;
  return `${base}${n}`;
}

export function stepEditor(ctx: ManagerContext, set: QrSet, item: QrItem): HTMLElement {
  const q = item.steps!;
  // a change to the steps also makes the script the QR runs again
  const edit = (fn: (q: StepQr) => void) =>
    ctx.mutateItem(set, item, (i) => {
      if (!i.steps) return;
      fn(i.steps);
      i.script = stepsScript(i.steps);
    });
  const problems = stepProblems(q);
  return el(
    "div",
    { class: "steps" },
    el(
      "div",
      { class: "field-h" },
      t("Steps", "단계"),
      helpTip(
        t(
          "Asked in order; {{name}} puts a step's answer in the prompt\n· Choice: buttons · Text box: typed answer\n· Cancel at any step stops the QR",
          "차례로 물어봄. {{이름}} 자리에 그 단계의 답이 들어감\n· 선택지: 버튼 · 입력: 직접 적기\n· 어느 단계든 취소하면 QR이 멈춤",
        ),
        t("Steps", "단계"),
      ),
    ),
    ...q.steps.map((s, n) => stepCard(q, s, n, edit)),
    el(
      "div",
      { class: "row" },
      el(
        "button",
        {
          onclick: () =>
            edit((x) =>
              x.steps.push({
                name: freeName(x),
                kind: "choice",
                question: "",
                options: [{ label: "" }, { label: "" }],
              }),
            ),
        },
        icon("plus"),
        t("Choice step", "선택지 단계"),
      ),
      el(
        "button",
        {
          onclick: () =>
            edit((x) =>
              x.steps.push({
                name: freeName(x),
                kind: "input",
                question: "",
                options: [],
              }),
            ),
        },
        icon("plus"),
        t("Text box step", "입력 단계"),
      ),
    ),
    finish(ctx, q, edit),
    problems.length ? el("ul", { class: "warn step-problems" }, ...problems.map((p) => el("li", {}, problemText(p)))) : null,
    ctx.fold(
      `steps-script-${item.id}`,
      t("Script made from the steps", "단계로 만든 스크립트"),
      0,
      t("What runs (read only)", "실제로 실행되는 스크립트 (읽기 전용)"),
      el("pre", { class: "step-script" }, item.script),
    ),
    el(
      "div",
      { class: "row" },
      el(
        "button",
        {
          title: t("Keep the script, drop the cards", "스크립트만 남기고 카드는 없앰"),
          onclick: async () => {
            const ok = await ctx.deps.ui.popup(t("Turn this into a plain QR? The cards can't come back.", "일반 QR로 바꿀까요? 카드는 되돌릴 수 없어요."), {
              okButton: t("Turn into a script", "스크립트로 바꾸기"),
              cancelButton: t("Cancel", "취소"),
            });
            if (ok) ctx.mutateItem(set, item, (i) => delete i.steps);
          },
        },
        t("Turn into a script", "스크립트로 바꾸기"),
      ),
    ),
  );
}

function stepCard(q: StepQr, s: QrStep, n: number, edit: (fn: (q: StepQr) => void) => void): HTMLElement {
  const step = (fn: (s: QrStep) => void) => edit((x) => x.steps[n] && fn(x.steps[n]));
  const move = (by: number) =>
    edit((x) => {
      const [moved] = x.steps.splice(n, 1);
      x.steps.splice(n + by, 0, moved);
    });
  const key = `step-${n}`;
  const badName = !STEP_NAME.test(s.name) || q.steps.some((o, m) => m !== n && o.name === s.name);
  return el(
    "div",
    { class: "step-card" },
    el(
      "div",
      { class: "row" },
      el("span", { class: "step-no" }, String(n + 1)),
      el(
        "label",
        { class: "grow" },
        t("Name (where the answer is kept)", "이름 (답이 저장되는 곳)"),
        el("input", {
          type: "text",
          value: s.name,
          class: badName ? "bad" : "",
          "data-key": `${key}-name`,
          oninput: (e: Event) => {
            const name = (e.target as HTMLInputElement).value.trim();
            // the prompt and the keep list follow a renamed step (unless another step has either name)
            edit((x) => {
              const old = x.steps[n]?.name;
              if (old === undefined || old === name) return;
              x.steps[n].name = name;
              if (!old || !name || x.steps.some((o, m) => m !== n && (o.name === old || o.name === name))) return;
              x.prompt = x.prompt.replaceAll(`{{${old}}}`, `{{${name}}}`).replaceAll(`{{${old}:prompt}}`, `{{${name}:prompt}}`);
              if (x.keep) x.keep = x.keep.map((k) => (k === old ? name : k));
            });
          },
        }),
      ),
      el(
        "label",
        {},
        t("Kind", "종류"),
        el(
          "select",
          {
            "data-key": `${key}-kind`,
            onchange: (e: Event) => step((x) => (x.kind = (e.target as HTMLSelectElement).value === "input" ? "input" : "choice")),
          },
          el("option", { value: "choice", selected: s.kind === "choice" }, t("Choice", "선택지")),
          el("option", { value: "input", selected: s.kind === "input" }, t("Text box", "입력")),
        ),
      ),
      el(
        "button",
        {
          class: "icon",
          title: t("Move up", "위로"),
          "aria-label": t("Move up", "위로"),
          disabled: n === 0,
          onclick: () => move(-1),
        },
        icon("arrow-up"),
      ),
      el(
        "button",
        {
          class: "icon",
          title: t("Move down", "아래로"),
          "aria-label": t("Move down", "아래로"),
          disabled: n === q.steps.length - 1,
          onclick: () => move(1),
        },
        icon("arrow-down"),
      ),
      el(
        "button",
        {
          class: "icon",
          title: t("Delete step", "단계 삭제"),
          "aria-label": t("Delete step", "단계 삭제"),
          onclick: () => edit((x) => x.steps.splice(n, 1)),
        },
        icon("trash"),
      ),
    ),
    el(
      "label",
      {},
      t("Question", "질문"),
      el("input", {
        type: "text",
        value: s.question,
        placeholder: s.kind === "choice" ? t("Who cooks?", "누가 요리하나요?") : t("What should they cook?", "무엇을 만들까요?"),
        "data-key": `${key}-question`,
        oninput: (e: Event) => step((x) => (x.question = (e.target as HTMLInputElement).value)),
      }),
    ),
    s.kind === "choice" ? choicePart(s, key, step) : null,
  );
}

function choicePart(s: QrStep, key: string, step: (fn: (s: QrStep) => void) => void): HTMLElement {
  return el(
    "div",
    { class: "step-options" },
    ...s.options.map((o, m) =>
      el(
        "div",
        { class: "step-option" },
        el(
          "div",
          { class: "row" },
          el("input", {
            type: "text",
            class: "grow",
            value: o.label,
            placeholder: t(`Option ${m + 1}`, `선택지 ${m + 1}`),
            "aria-label": t(`Option ${m + 1}`, `선택지 ${m + 1}`),
            "data-key": `${key}-opt-${m}`,
            oninput: (e: Event) => step((x) => x.options[m] && (x.options[m].label = (e.target as HTMLInputElement).value)),
          }),
          el(
            "button",
            {
              class: "icon",
              title: t("Remove option", "선택지 빼기"),
              "aria-label": t("Remove option", "선택지 빼기"),
              onclick: () => step((x) => x.options.splice(m, 1)),
            },
            icon("x"),
          ),
        ),
        s.perOption
          ? el(
              "textarea",
              {
                class: "step-text",
                placeholder: t("What is sent when this one is picked", "이걸 고르면 보낼 내용"),
                "aria-label": t(`Prompt for option ${m + 1}`, `선택지 ${m + 1}의 프롬프트`),
                "data-key": `${key}-opt-${m}-prompt`,
                oninput: (e: Event) =>
                  step((x) => {
                    const v = (e.target as HTMLTextAreaElement).value;
                    if (!x.options[m]) return;
                    if (v) x.options[m].prompt = v;
                    else delete x.options[m].prompt;
                  }),
              },
              o.prompt ?? "",
            )
          : null,
      ),
    ),
    el("div", { class: "row" }, el("button", { onclick: () => step((x) => x.options.push({ label: "" })) }, icon("plus"), t("Option", "선택지"))),
    setting(
      t("'Type it' option", "직접 입력 선택지"),
      toggle(!!s.custom, (v) => step((x) => (v ? (x.custom = { label: t("Type it", "직접 입력"), question: "" }) : delete x.custom)), t("'Type it' option", "직접 입력 선택지"), `${key}-custom`),
      t("A button for typing the answer", "답을 직접 적는 버튼"),
    ),
    s.custom
      ? el(
          "div",
          { class: "row" },
          el(
            "label",
            { class: "grow" },
            t("Button", "버튼"),
            el("input", {
              type: "text",
              value: s.custom.label,
              "data-key": `${key}-custom-label`,
              oninput: (e: Event) => step((x) => x.custom && (x.custom.label = (e.target as HTMLInputElement).value)),
            }),
          ),
          el(
            "label",
            { class: "grow" },
            t("Its question", "글상자 질문"),
            el("input", {
              type: "text",
              value: s.custom.question,
              "data-key": `${key}-custom-question`,
              oninput: (e: Event) => step((x) => x.custom && (x.custom.question = (e.target as HTMLInputElement).value)),
            }),
          ),
        )
      : null,
    setting(
      t("A prompt for each option", "선택지마다 다른 프롬프트"),
      toggle(!!s.perOption, (v) => step((x) => (v ? (x.perOption = true) : delete x.perOption)), t("A prompt for each option", "선택지마다 다른 프롬프트"), `${key}-per-option`),
      t(
        `Each option sends its own text, at {{${s.name}:prompt}}`,
        `선택지마다 보낼 글이 따로. {{${s.name}:prompt}} 자리에 들어감`,
      ),
    ),
  );
}

/** The prompt, how it is sent, and what a cancel or the end says and deletes. */
function finish(ctx: ManagerContext, q: StepQr, edit: (fn: (q: StepQr) => void) => void): HTMLElement {
  const insert = (text: string) => {
    const ta = ctx.root?.querySelector<HTMLTextAreaElement>('textarea[data-key="steps-prompt"]');
    if (!ta) return;
    const start = ta.selectionStart ?? ta.value.length;
    const end = ta.selectionEnd ?? start;
    ta.value = ta.value.slice(0, start) + text + ta.value.slice(end);
    ta.focus();
    ta.setSelectionRange(start + text.length, start + text.length);
    ta.dispatchEvent(new Event("input"));
  };
  const chips = q.steps.filter((s) => s.name).flatMap((s) => [`{{${s.name}}}`, ...(s.kind === "choice" && s.perOption ? [`{{${s.name}:prompt}}`] : [])]);
  return el(
    "div",
    { class: "step-finish" },
    el(
      "div",
      { class: "field-h" },
      t("Prompt", "프롬프트"),
      helpTip(
        t("Sent at the end; {{name}} becomes that step's answer", "마지막에 보낼 내용. {{이름}}은 그 단계의 답"),
        t("Prompt", "프롬프트"),
      ),
    ),
    chips.length
      ? el(
          "div",
          { class: "row step-chips" },
          ...chips.map((c) =>
            el(
              "button",
              {
                class: "chip",
                title: t("Put it in the prompt", "프롬프트에 넣기"),
                onclick: () => insert(c),
              },
              c,
            ),
          ),
        )
      : null,
    el(
      "textarea",
      {
        class: "step-text",
        "data-key": "steps-prompt",
        "aria-label": t("Prompt", "프롬프트"),
        oninput: (e: Event) => edit((x) => (x.prompt = (e.target as HTMLTextAreaElement).value)),
      },
      q.prompt,
    ),
    el(
      "div",
      { class: "row" },
      el(
        "label",
        { class: "grow" },
        t("Frame", "틀"),
        el(
          "select",
          {
            "data-key": "steps-frame",
            onchange: (e: Event) => edit((x) => (x.frame = (e.target as HTMLSelectElement).value as StepFrame)),
          },
          ...FRAMES().map((f) => el("option", { value: f.value, selected: q.frame === f.value }, f.label)),
        ),
      ),
      el(
        "label",
        { class: "grow" },
        t("Send", "보내기"),
        el(
          "select",
          {
            "data-key": "steps-send",
            onchange: (e: Event) => edit((x) => (x.send = (e.target as HTMLSelectElement).value as StepSend)),
          },
          ...SENDS().map((f) => el("option", { value: f.value, selected: q.send === f.value }, f.label)),
        ),
      ),
      q.send === "result"
        ? el(
            "label",
            { class: "grow" },
            t("Posted as", "보낼 이름"),
            el("input", {
              type: "text",
              value: q.as,
              placeholder: "{{char}}",
              title: t("{{char}}, a step's {{name}}, or any name", "{{char}}, 단계의 {{이름}}, 아무 이름"),
              "data-key": "steps-as",
              oninput: (e: Event) => edit((x) => (x.as = (e.target as HTMLInputElement).value)),
            }),
          )
        : null,
    ),
    el(
      "div",
      { class: "row" },
      el(
        "label",
        { class: "grow" },
        t("When cancelled, say", "취소하면 알림"),
        el("input", {
          type: "text",
          value: q.cancelText ?? "",
          placeholder: t("(nothing)", "(알림 없음)"),
          "data-key": "steps-cancel",
          oninput: (e: Event) => edit((x) => ((e.target as HTMLInputElement).value ? (x.cancelText = (e.target as HTMLInputElement).value) : delete x.cancelText)),
        }),
      ),
      el(
        "label",
        { class: "grow" },
        t("When done, say", "끝나면 알림"),
        el("input", {
          type: "text",
          value: q.doneText ?? "",
          placeholder: t("(nothing)", "(알림 없음)"),
          "data-key": "steps-done",
          oninput: (e: Event) => edit((x) => ((e.target as HTMLInputElement).value ? (x.doneText = (e.target as HTMLInputElement).value) : delete x.doneText)),
        }),
      ),
    ),
    setting(
      t("Delete the answers afterwards", "끝나면 답 지우기"),
      toggle(q.clean !== false, (v) => edit((x) => (v ? delete x.clean : (x.clean = false))), t("Delete the answers afterwards", "끝나면 답 지우기"), "steps-clean"),
      t(
        "The answers (chat variables) go when the QR ends; ticked ones stay",
        "QR이 끝나면 답(채팅 변수)을 지움. 고른 것은 남김",
      ),
    ),
    q.clean !== false && q.steps.some((s) => s.name)
      ? el(
          "div",
          { class: "row step-keep" },
          el("span", { class: "note" }, t("Keep:", "남길 답:")),
          ...q.steps
            .filter((s) => s.name)
            .map((s, n) =>
              el(
                "label",
                { class: "inline" },
                el("input", {
                  type: "checkbox",
                  checked: !!q.keep?.includes(s.name),
                  "data-key": `steps-keep-${n}`,
                  onchange: (e: Event) =>
                    edit((x) => {
                      const keep = new Set(x.keep ?? []);
                      if ((e.target as HTMLInputElement).checked) keep.add(s.name);
                      else keep.delete(s.name);
                      if (keep.size) x.keep = [...keep];
                      else delete x.keep;
                    }),
                }),
                s.name,
              ),
            ),
        )
      : null,
  );
}

export const STEP_EDITOR_CSS = `
.steps { display: flex; flex-direction: column; gap: 8px; }
.step-card { display: flex; flex-direction: column; gap: 8px; padding: 10px; border: 1px solid var(--d-line); border-radius: var(--d-radius); background: var(--d-panel-solid); }
.step-no { display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; border-radius: 999px; background: var(--d-accent); color: var(--d-panel-solid); font-size: 12px; font-weight: 700; align-self: flex-end; margin-bottom: 6px; }
.step-card label:not(.inline) select { width: auto; }
.step-options { display: flex; flex-direction: column; gap: 6px; padding-left: 10px; border-left: 2px solid var(--d-divider); }
.step-option { display: flex; flex-direction: column; gap: 4px; }
.step-option input, .step-card label input, .step-card select { font-size: 13px; }
textarea.step-text { min-height: 70px; font-family: var(--d-font); font-size: 13px; }
.step-option textarea.step-text { min-height: 54px; }
input.bad { border-color: #e6a23c; }
.step-finish { display: flex; flex-direction: column; gap: 8px; margin-top: 4px; padding-top: 10px; border-top: 1px solid var(--d-divider); }
.step-chips { gap: 4px; }
button.chip { padding: 2px 8px; font-family: var(--d-mono); font-size: 12px; border-radius: 999px; }
.step-keep { gap: 10px; }
.step-problems { margin: 0; padding-left: 18px; }
pre.step-script { margin: 6px 0 0; padding: 8px; max-height: 260px; overflow: auto; white-space: pre-wrap; word-break: break-word; font: 12px/1.5 var(--d-mono); border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); }
`;
