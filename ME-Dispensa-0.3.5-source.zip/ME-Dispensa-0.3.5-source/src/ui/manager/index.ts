// The Dispensa window: four tabs (Library, Dock, memo pad, visz settings)
// in one shadow root. This file is the frame: opening and closing, the
// header, which tab and which set or QR is selected, and redrawing. Each
// tab's content is its own module.

import { STORAGE_LIMIT, STORAGE_SHOW_FROM, storageUsed } from "../../host/persisted-store";
import { LANG_NAMES, type LangChoice, langChoice, setLangChoice, t } from "../../shared/i18n";
import type { Memo, MemoState } from "../../memo/model";
import { oneLine } from "../../util";
import type { SetNames } from "../../qr/import";
import { type QrItem, type QrSet, type QrState, newItem, newSet } from "../../qr/model";
import { type ChatScope, NO_CHAT } from "../../qr/scopes";
import { el, icon } from "../dom";
import { helpTip, segmented } from "../../shared/form";
import { MemoView } from "../memo-view";
import { dropMenu } from "../menu";
import { fornello } from "../../host/fornello";
import { ViszSettingsView } from "../visz-settings";
import type { ManagerContext, ManagerDeps, ManagerTab } from "./context";
import { dockTab } from "./dock-tab";
import { QrFiles } from "./import-export";
import { ItemEditor } from "./item-editor";
import { itemColumn } from "./item-list";
import { setColumn } from "./set-column";
import { MANAGER_CSS } from "./style";

export type { ManagerDeps, ManagerTab } from "./context";

/**
 * What the window redraws for. Script text and its unknown-command marks
 * are left out: the script box keeps its own state (caret, suggestions) and
 * updates its warning lines in place, so typing never redraws the window.
 */
const librarySlice = (state: QrState) => JSON.stringify(state, (key, value) => (key === "script" || key === "unsupported" ? undefined : value));
/** Memo text is left out for the same reason: the memo being typed in keeps its caret. */
const memoSlice = (state: MemoState) => JSON.stringify(state, (key, value) => (key === "text" ? undefined : value));

export class QrManager implements ManagerContext {
  private hostEl: HTMLElement | null = null;
  root: ShadowRoot | null = null;
  selectedSet: string | null = null;
  selectedItem: string | null = null;
  scope: ChatScope = NO_CHAT;
  private tab: ManagerTab = "qr";
  private unsubscribers: (() => void)[] = [];
  /** Folded parts kept open through redraws (by key). */
  private readonly openParts = new Set<string>();
  private readonly viszView: ViszSettingsView | null;
  private readonly memoView: MemoView | null;
  private readonly editor = new ItemEditor(this);
  private readonly files = new QrFiles(this);
  /** The window slides in once, when it opens (not on every redraw). */
  private entering = false;
  private readonly names = new Map<string, string>();
  private scrollToEditor = false;

  constructor(readonly deps: ManagerDeps) {
    this.viszView = deps.viszStore
      ? new ViszSettingsView({
          store: deps.viszStore,
          ui: deps.ui,
          connections: async () => (await deps.connections()).map((c) => ({ id: c.id, name: c.name })),
          rerender: () => this.render(),
        })
      : null;
    const memo = deps.memo;
    this.memoView = memo
      ? new MemoView({
          store: memo.store,
          ui: deps.ui,
          sendOoc: memo.sendOoc,
          putInInput: memo.putInInput,
          makePage: memo.makePage,
          toQr: (memo) => this.memoToQr(memo),
          oocSettings: () => this.viszView?.oocCards() ?? [],
          menu: (summary, label, entries) => dropMenu(summary, label, entries),
          close: () => this.close(),
          rerender: () => this.render(),
        })
      : null;
  }

  get state(): QrState {
    return this.deps.store.value;
  }

  readonly setName: SetNames = (id) => this.state.sets.find((s) => s.id === id)?.name;

  storageUsed(): number {
    return storageUsed([this.deps.store, this.deps.viszStore, this.deps.memo?.store]);
  }

  characterName(id: string, fallback = "…"): string {
    return this.names.get(id) ?? fallback;
  }

  /** A new plain QR with the memo in its script box, in the Library's open set, opened in the editor. */
  private memoToQr(memo: Memo): void {
    const item = newItem(memo.title?.trim() || oneLine(memo.text, 14), memo.text);
    let setId = "";
    this.deps.store.update((st) => {
      let target = st.sets.find((x) => x.id === this.selectedSet);
      if (!target) {
        target = newSet(t("Memo QR", "메모 QR"));
        st.sets.push(target);
      }
      target.items.push(item);
      setId = target.id;
    });
    this.openItem(setId, item.id);
  }

  /** The chat on screen (its chat and character switches). */
  setScope(scope: ChatScope): void {
    this.scope = scope;
    for (const id of scope.characterIds) {
      if (this.names.has(id)) continue;
      this.names.set(id, t("Character", "캐릭터"));
      void this.deps.characterName(id).then((name) => {
        this.names.set(id, name);
        this.render();
      });
    }
    this.render();
  }

  open(tab?: ManagerTab): void {
    if (tab) this.tab = tab;
    if (this.hostEl) {
      this.render();
      return;
    }
    this.hostEl = el("div", { id: "dispensa-manager" });
    this.root = this.hostEl.attachShadow({ mode: "open" });
    document.body.append(this.hostEl);
    this.selectedSet ??= this.deps.store.value.sets[0]?.id ?? null;
    const redraw = () => this.render();
    this.unsubscribers = [
      this.deps.store.select(librarySlice, redraw),
      // a script changed elsewhere (a /qr-update while the window is open) shows in its open box
      this.deps.store.subscribe(() => this.editor.syncScripts()),
      this.deps.viszStore?.subscribe(redraw),
      this.deps.memo?.store.select(memoSlice, redraw),
    ].filter((off): off is () => boolean => !!off);
    document.addEventListener("keydown", this.onKey, true);
    this.entering = true;
    this.render();
    this.entering = false;
  }

  /** Redraws when open (the screen language changed). */
  refresh(): void {
    if (this.hostEl) this.render();
  }

  /** Ctrl+click on the Dock: straight to that QR's editor. */
  openItem(setId: string, itemId: string): void {
    this.selectedSet = setId;
    this.selectedItem = itemId;
    this.scrollToEditor = true;
    this.open("qr");
  }

  close(): void {
    this.editor.stopAll();
    for (const off of this.unsubscribers) off();
    this.unsubscribers = [];
    void this.deps.viszStore?.saveNow().catch(() => undefined);
    void this.deps.memo?.store.saveNow().catch(() => undefined);
    document.removeEventListener("keydown", this.onKey, true);
    this.hostEl?.remove();
    this.hostEl = this.root = null;
    void this.deps.store.saveNow();
  }

  private readonly onKey = (e: KeyboardEvent) => {
    if (e.key === "Escape" && !e.defaultPrevented) {
      const active = this.root?.activeElement;
      if (active && active.tagName === "TEXTAREA") return;
      const menu = this.root?.querySelector<HTMLDetailsElement>("details.menu[open]");
      e.stopPropagation();
      if (menu) {
        menu.open = false;
        return;
      }
      this.close();
    }
  };

  mutateSet(set: QrSet, fn: (s: QrSet, st: QrState) => void): void {
    this.deps.store.update((st) => {
      const target = st.sets.find((x) => x.id === set.id);
      if (target) fn(target, st);
    });
  }

  mutateItem(set: QrSet, item: QrItem, fn: (i: QrItem) => void): void {
    this.deps.store.update((st) => {
      const target = st.sets.find((s) => s.id === set.id)?.items.find((i) => i.id === item.id);
      if (target) fn(target);
    });
  }

  removeItem(set: QrSet, item: QrItem): void {
    this.mutateSet(set, (s) => (s.items = s.items.filter((i) => i.id !== item.id)));
    if (this.selectedItem === item.id) this.selectedItem = null;
    this.render();
  }

  fold(key: string, title: string, count: number, help: string | undefined, ...kids: (Node | null)[]): HTMLElement {
    const d = el("details", { class: "box" }, el("summary", {}, title, count ? el("span", { class: "count" }, `· ${count}`) : null, help ? helpTip(help, title) : null), ...kids);
    d.open = this.openParts.has(key);
    d.addEventListener("toggle", () => (d.open ? this.openParts.add(key) : this.openParts.delete(key)));
    return d;
  }

  render(): void {
    if (!this.root) return;
    // keep focus and caret in the editor across redraws
    const active = this.root.activeElement as HTMLInputElement | HTMLTextAreaElement | null;
    const focusKey = active?.dataset?.key;
    const caret = active && "selectionStart" in active ? [active.selectionStart, active.selectionEnd] : null;
    const scrolls = [...this.root.querySelectorAll<HTMLElement>(".col")].map((c) => c.scrollTop);
    this.editor.forgetGone();

    const style = el("style");
    style.textContent = MANAGER_CSS;
    const win = el("div", { class: `win${this.entering ? " d-enter" : ""}`, role: "dialog", "aria-modal": "true", "aria-label": "Dispensa" });
    if (this.tab === "dock") win.append(this.header(), el("div", { class: "main single" }, dockTab(this)));
    else if (this.tab === "visz" && this.viszView) win.append(this.header(), el("div", { class: "main single" }, this.viszView.render()));
    else if (this.tab === "memo" && this.memoView) win.append(this.header(), el("div", { class: "main single" }, this.memoView.render()));
    else win.append(this.header(), el("div", { class: "main" }, setColumn(this), itemColumn(this, this.editor, this.files)));
    const backdrop = el("div", {
      class: `backdrop${this.entering ? " d-fade" : ""}`,
      onmousedown: (e: Event) => {
        if (e.target === backdrop) this.close();
      },
    });
    backdrop.append(win);
    this.root.replaceChildren(style, backdrop);

    [...this.root.querySelectorAll<HTMLElement>(".col")].forEach((c, i) => (c.scrollTop = scrolls[i] ?? 0));
    if (focusKey) {
      const target = this.root.querySelector<HTMLInputElement | HTMLTextAreaElement>(`[data-key="${focusKey}"]`);
      if (target) {
        target.focus({ preventScroll: true });
        if (caret && caret[0] !== null && "setSelectionRange" in target && target.type !== "checkbox" && target.type !== "color") target.setSelectionRange(caret[0], caret[1]);
      }
    }
    if (this.scrollToEditor) {
      this.scrollToEditor = false;
      requestAnimationFrame(() => this.root?.querySelector(".editor")?.scrollIntoView({ block: "start" }));
    }
  }

  private header(): HTMLElement {
    const size = this.storageUsed();
    const tabs = segmented(
      "dispensa-tab",
      [
        { value: "qr", label: t("Library", "보관함") },
        { value: "dock", label: "Dock", title: t("Sets and QRs on the Dock", "Dock에 놓을 세트·QR") },
        ...(this.memoView ? [{ value: "memo", label: "📝", title: t("Memo pad", "메모장") }] : []),
        { value: "visz", label: "🌟", title: t("Visualizer settings", "비주얼라이저 설정") },
      ],
      this.tab,
      (v) => {
        this.tab = v as ManagerTab;
        this.render();
      },
      t("Dispensa tabs", "Dispensa 탭"),
    );
    return el(
      "header",
      {},
      el("h2", {}, "Dispensa"),
      el("div", { class: "row tabs" }, tabs),
      el("span", { class: "grow" }),
      el(
        "select",
        {
          class: "lang",
          title: t("Language", "언어"),
          "aria-label": t("Language", "언어"),
          "data-key": "lang",
          onchange: (e: Event) => setLangChoice((e.target as HTMLSelectElement).value as LangChoice),
        },
        ...(["auto", "en", "ko"] as LangChoice[]).map((c) => el("option", { value: c, selected: c === langChoice() }, `🌐 ${LANG_NAMES[c]()}`)),
      ),
      // the 1 MB storage only shows once it starts filling up
      size > STORAGE_SHOW_FROM ? el("span", { class: "warn", title: `${Math.round(size / 1024)} KB / ${STORAGE_LIMIT / 1000} KB` }, t(`Storage ${Math.round((size / STORAGE_LIMIT) * 100)}% used`, `저장 공간 ${Math.round((size / STORAGE_LIMIT) * 100)}% 사용`)) : el("span"),
      this.tab === "qr"
        ? el("button", { title: t("Import QR files (.json, .qr.json, .mqr.json)", "QR 파일 가져오기 (.json, .qr.json, .mqr.json)"), "aria-label": t("Import QRs", "QR 가져오기"), onclick: () => this.files.importFile() }, icon("download"), el("span", { class: "label" }, t("Import QRs", "QR 가져오기")))
        : el("span"),
      // Fornello (pages with scripts, components) has its own settings
      typeof fornello()?.openSettings === "function"
        ? el("button", { title: t("Fornello settings", "Fornello 설정"), "aria-label": t("Fornello settings", "Fornello 설정"), onclick: () => (this.close(), fornello()?.openSettings?.()) }, "🔥", el("span", { class: "label" }, "Fornello"))
        : el("span"),
      el("button", { class: "icon", title: t("Close", "닫기"), "aria-label": t("Close", "닫기"), onclick: () => this.close() }, icon("x")),
    );
  }
}
