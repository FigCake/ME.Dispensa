// The Dispensa window's CSS (one shadow root): the frame, the Library's two
// columns, the editor, menus, and the CSS of the parts it hosts.

import { DRAG_CSS } from "../drag";
import { FORM_CSS } from "../../shared/form";
import { MEMO_VIEW_CSS } from "../memo-view";
import { RUN_PANEL_CSS } from "../run-panel";
import { SCRIPT_EDITOR_CSS } from "../script-editor";
import { STEP_EDITOR_CSS } from "./step-editor";
import { CONTROLS, THEME_TOKENS } from "../../shared/theme";
import { VISZ_SETTINGS_CSS } from "../visz-settings";

export const MANAGER_CSS = `
:host { all: initial; }
${THEME_TOKENS}
* { box-sizing: border-box; }
${CONTROLS}
.backdrop { position: fixed; inset: 0; z-index: 2147482000; background: rgb(0 0 0 / .5); display: flex; align-items: center; justify-content: center; padding: 12px;
  font: 14px/1.45 var(--d-font); color: var(--d-text); }
.win { width: min(1040px, 100%); height: min(760px, 100%); display: flex; flex-direction: column; overflow: hidden;
  border: 1px solid var(--d-line); border-radius: calc(var(--d-radius) + 0.25rem); box-shadow: 0 20px 60px rgb(0 0 0 / .45);
  background: var(--d-panel-solid); backdrop-filter: var(--d-shell-blur); -webkit-backdrop-filter: var(--d-shell-blur); }
header { display: flex; align-items: center; gap: 8px; padding: 10px 12px; border-bottom: 1px solid var(--d-divider); }
header h2 { font-size: 16px; margin: 0 6px 0 0; color: var(--d-title); }
.main { flex: 1; display: grid; grid-template-columns: 240px 1fr; min-height: 0; }
.col { min-height: 0; overflow: auto; padding: 10px; }
.col + .col { border-left: 1px solid var(--d-divider); }
.list { display: flex; flex-direction: column; gap: 4px; }
.row { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.grow { flex: 1; min-width: 0; }
button { padding: 6px 10px; }
button.icon { padding: 6px; }
.entry { justify-content: flex-start; width: 100%; text-align: left; overflow: hidden; text-overflow: ellipsis; }
.entry .meta { margin-left: auto; color: var(--d-muted); font-size: 12px; font-weight: 500; }
input[type=text], textarea, select { width: 100%; }
textarea { font-family: var(--d-mono); font-size: 13px; min-height: 220px; resize: vertical; tab-size: 2; }
label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--d-muted); }
label.inline { flex-direction: row; align-items: center; gap: 6px; color: var(--d-text); font-size: 13px; }
.section { margin: 12px 0 6px; font-size: 12px; text-transform: uppercase; letter-spacing: .04em; color: var(--d-muted); }
.note { font-size: 12px; color: var(--d-muted); }
.warn { color: #e6a23c; font-size: 12px; }
.editor { display: flex; flex-direction: column; gap: 10px; margin-top: 10px; padding: 10px; border: 1px solid var(--d-line); border-radius: var(--d-radius); background: var(--d-hl-bg); }
.empty { color: var(--d-muted); padding: 24px; text-align: center; }
.note-box { border: 1px dashed #e6a23c; border-radius: var(--d-radius-sm); padding: 8px 10px; font-size: 13px; }
.note-box ul { margin: 6px 0 8px; padding-left: 18px; }
svg { width: 15px; height: 15px; }
.badge { display: inline-block; font-size: 11px; line-height: 1; padding: 3px 6px; border-radius: 999px; border: 1px solid var(--d-line); color: var(--d-muted); white-space: nowrap; font-weight: 600; }
.badge.dispensa { border-color: #3fb97a; color: #3fb97a; }
.badge.marinara { border-color: var(--d-accent); color: var(--d-accent); }
.badge.extension { border-color: #8b7cf6; color: #8b7cf6; }
details.cmds summary { cursor: pointer; font-size: 13px; color: var(--d-text); }
.cmd-list { display: flex; flex-direction: column; gap: 2px; max-height: 260px; overflow: auto; margin-top: 6px; }
.cmd { justify-content: flex-start; width: 100%; text-align: left; border-color: transparent; background: none; padding: 4px 6px; white-space: normal; font-weight: 500; color: var(--d-text); }
.cmd code { font-family: var(--d-mono); font-size: 12px; min-width: 120px; color: var(--d-btn-text-active); }
.cmd .help { color: var(--d-muted); font-size: 12px; flex: 1; }
header .tab { padding: 5px 12px; }
.main.single { grid-template-columns: 1fr; }
${FORM_CSS}
${VISZ_SETTINGS_CSS}
${SCRIPT_EDITOR_CSS}
${STEP_EDITOR_CSS}
${RUN_PANEL_CSS}
${DRAG_CSS}
${MEMO_VIEW_CSS}
.qrow { display: flex; align-items: center; gap: 4px; }
.qrow > .entry { flex: 1; min-width: 0; }
.entry .marks { color: var(--d-muted); font-weight: 500; font-size: 12px; white-space: nowrap; }
.set-row { display: flex; align-items: center; gap: 2px; }
.set-row > .entry { flex: 1; min-width: 0; }
.zone-h { display: flex; align-items: center; gap: 6px; margin: 10px 0 4px; font-size: 12px; font-weight: 600; color: var(--d-muted); }
.zone-h:first-child { margin-top: 0; }
.zone-h .count { font-weight: 500; }
.zone { display: flex; flex-direction: column; gap: 4px; min-height: 32px; border-radius: var(--d-radius-sm); }
.zone.drop-into { outline: 2px dashed var(--d-accent); outline-offset: 1px; }
.zone-empty { padding: 6px 8px; font-size: 12px; color: var(--d-muted); border: 1px dashed var(--d-line); border-radius: var(--d-radius-sm); }
.links { display: flex; flex-direction: column; gap: 4px; margin: 4px 0; }
.links .link { display: flex; align-items: center; gap: 8px; padding: 4px 0; border-top: 1px solid var(--d-divider); }
.links .link:first-child { border-top: 0; }
.links .link .grow { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.links .link label.inline { font-size: 12px; color: var(--d-muted); }
.set > .ctl > input[type=color], input[type=color] { min-width: 0; width: 36px; height: 28px; padding: 2px; border-radius: var(--d-radius-sm); border: 1px solid var(--d-field-border); background: var(--d-field); cursor: pointer; }
details.box { border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); padding: 2px 10px; }
details.box > summary { cursor: pointer; list-style: none; display: flex; align-items: center; gap: 6px; padding: 7px 0; font-size: 13px; color: var(--d-text); }
details.box > summary::-webkit-details-marker { display: none; }
details.box > summary::before { content: "▸"; color: var(--d-muted); transition: transform .15s ease; }
details.box[open] > summary::before { transform: rotate(90deg); }
details.box > summary .count { color: var(--d-muted); font-size: 12px; }
details.box[open] { padding-bottom: 8px; }
.menu-list hr { border: 0; border-top: 1px solid var(--d-divider); margin: 3px 0; width: 100%; }
.menu-list button.danger-item { color: var(--d-danger); }
.field-h { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--d-muted); }
textarea.request { font-family: var(--d-font); min-height: 110px; }
details.more > summary { cursor: pointer; color: var(--d-muted); font-size: 12px; padding: 4px 0; list-style: none; display: flex; align-items: center; gap: 6px; }
details.more > summary::before { content: "▸"; transition: transform .15s ease; }
details.more[open] > summary::before { transform: rotate(90deg); }
.col-h { display: flex; align-items: center; gap: 6px; }
.col-h strong { color: var(--d-title); }
/* switches one per line, each on the right: the names read down one column, the switches down another */
.toggles { display: flex; flex-direction: column; }
.toggles .set { min-height: 38px; padding: 4px 0; }
.toggles .set:first-child { border-top: 0; }
.actions { display: flex; justify-content: flex-end; gap: 6px; }
details.menu { position: relative; }
details.menu > summary { list-style: none; display: inline-flex; align-items: center; gap: 5px; cursor: pointer; font-weight: 600; white-space: nowrap;
  border: 1px solid var(--d-btn-border); background: var(--d-btn-bg); color: var(--d-btn-text); border-radius: var(--d-radius-sm); padding: 6px 10px; transition: background-color 150ms ease, border-color 150ms ease; }
details.menu > summary:hover, details.menu[open] > summary { border-color: var(--d-btn-border-hover); background: var(--d-btn-bg-hover); }
details.menu > summary::-webkit-details-marker { display: none; }
details.menu.right .menu-list { left: 0; right: auto; }
header select.lang { width: auto; flex: none; padding: 4px 6px; font-size: 12px; }
.dock-tab .row select { width: auto; min-width: 160px; max-width: 100%; }
.dock-tab select.layout { width: auto; flex: none; padding: 3px 6px; font-size: 12px; }
details.menu .menu-list { position: absolute; right: 0; top: calc(100% + 4px); z-index: 5; min-width: 240px; display: flex; flex-direction: column; gap: 2px; padding: 4px;
  background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); box-shadow: var(--d-shadow); animation: d-fade-in .12s ease-out; }
details.menu .menu-list button { justify-content: flex-start; flex-direction: column; align-items: flex-start; gap: 1px; border-color: transparent; background: none; white-space: normal; text-align: left; }
details.menu .menu-list button:hover { background: var(--d-hl-bg); }
details.menu .menu-list small { color: var(--d-muted); font-weight: 400; font-size: 11.5px; }
@media (max-width: 720px) { .main { grid-template-columns: 1fr; } .col + .col { border-left: none; border-top: 1px solid var(--d-divider); } }
/* phones: title and buttons on one line, the tabs on the next; header buttons show only their icons */
@media (max-width: 560px) {
  header { flex-wrap: wrap; row-gap: 8px; }
  header .tabs { order: 5; width: 100%; flex-wrap: nowrap; }
  header .tabs .seg2 { flex: 1; }
  header .label { display: none; }
  .win { height: 100%; }
  .col { padding: 10px 12px; }
}
`;
