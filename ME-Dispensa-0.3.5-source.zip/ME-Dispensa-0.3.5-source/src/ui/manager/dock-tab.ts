// The Dock tab of the Dispensa window: what the Dock shows, in order, the
// same in every chat (apart from where sets auto-run).

import { t } from "../../shared/i18n";
import { addToDock, dockSet, layoutOf, onDock, removeFromDock, setLayout, shownDock } from "../../qr/dock";
import type { DockLayout } from "../../qr/model";
import { el, icon } from "../dom";
import { dragHandle, moveTo } from "../drag";
import { section } from "../../shared/form";
import type { ManagerContext } from "./context";
import { newQrMenu } from "./item-list";

export function dockTab(ctx: ManagerContext): HTMLElement {
  const { store } = ctx.deps;
  const st = store.value;
  const shown = shownDock(st);
  const list = el("div", { class: "list" });
  shown.forEach(({ entry, set, item }, i) => {
    const handle = el("button", { class: "drag", type: "button", title: t("Drag (or ↑↓) to reorder", "끌어서(또는 ↑↓) 순서 바꾸기"), "aria-label": t(`Reorder ${item?.label ?? set.name}`, `${item?.label ?? set.name} 순서 바꾸기`), "data-key": `drag-dock-${i}` }, icon("grip"));
    const glyph = (item ? item.icon : set.icon)?.trim();
    const row = el(
      "div",
      { class: "set-row" },
      handle,
      el(
        "button",
        {
          class: "entry",
          title: item ? t("Edit", "편집") : t("Open set", "세트 열기"),
          onclick: () => (item ? ctx.openItem(set.id, item.id) : ((ctx.selectedSet = set.id), (ctx.selectedItem = null), ctx.open("qr"))),
        },
        glyph ? el("span", {}, glyph) : icon(item ? "play" : "folder"),
        el("span", { class: "grow" }, item ? item.label : set.name),
        el("span", { class: "meta" }, item ? `QR · ${set.name}` : t(`Set · ${set.items.filter((x) => !x.hidden).length}`, `세트 · ${set.items.filter((x) => !x.hidden).length}`)),
      ),
      item
        ? el("span")
        : el(
            "select",
            {
              class: "layout",
              title: t("Folder: one bubble · Row: a bubble per QR", "폴더: 버블 하나 · 한 줄: QR마다 버블"),
              "aria-label": t(`${set.name} layout`, `${set.name} 놓는 모양`),
              "data-key": `dock-layout-${i}`,
              onchange: (e: Event) => store.update((x) => setLayout(x, set.id, (e.target as HTMLSelectElement).value as DockLayout)),
            },
            el("option", { value: "folder", selected: layoutOf(entry, set) === "folder" }, t("Folder", "폴더")),
            el("option", { value: "row", selected: layoutOf(entry, set) === "row" }, t("Row", "한 줄")),
          ),
      el("button", { class: "icon", title: t("Remove from the Dock", "Dock에서 빼기"), "aria-label": t(`Remove ${item?.label ?? set.name}`, `${item?.label ?? set.name} 빼기`), onclick: () => store.update((x) => removeFromDock(x, entry)) }, icon("x")),
    );
    dragHandle(handle, row, ".set-row", (from, to) =>
      store.update((x) => {
        const entries = shownDock(x).map((e) => e.entry);
        moveTo(entries, from, to);
        x.dock = entries;
      }),
    );
    list.append(row);
  });
  if (!shown.length) list.append(el("div", { class: "note" }, t("Empty", "비어 있음")));
  const freeSets = st.sets.filter((x) => !onDock(st, { kind: "set", setId: x.id }));
  const freeQrs = st.sets.flatMap((x) => x.items.filter((i) => !onDock(st, { kind: "qr", setId: x.id, itemId: i.id })).map((i) => ({ set: x, item: i })));
  const addSet = el(
    "select",
    {
      "aria-label": t("Add a set to the Dock", "Dock에 세트 넣기"),
      "data-key": "dock-add-set",
      onchange: (e: Event) => {
        const id = (e.target as HTMLSelectElement).value;
        if (id) store.update((x) => addToDock(x, { kind: "set", setId: id }));
      },
    },
    el("option", { value: "" }, t("+ Set", "+ 세트")),
    ...freeSets.map((x) => el("option", { value: x.id }, `${x.icon?.trim() ? `${x.icon.trim()} ` : ""}${x.name}`)),
  );
  const addQr = el(
    "select",
    {
      "aria-label": t("Add a QR to the Dock", "Dock에 QR 넣기"),
      "data-key": "dock-add-qr",
      onchange: (e: Event) => {
        const [setId, itemId] = (e.target as HTMLSelectElement).value.split("/");
        if (itemId) store.update((x) => addToDock(x, { kind: "qr", setId, itemId }));
      },
    },
    el("option", { value: "" }, "+ QR"),
    ...freeQrs.map(({ set, item }) => el("option", { value: `${set.id}/${item.id}` }, `${set.name} › ${item.icon?.trim() ? `${item.icon.trim()} ` : ""}${item.label}`)),
  );
  const make = newQrMenu((item) => {
    let target = "";
    store.update((x) => {
      const set = dockSet(x);
      set.items.push(item);
      target = set.id;
      addToDock(x, { kind: "qr", setId: set.id, itemId: item.id });
    });
    ctx.openItem(target, item.id);
  });
  const card = section(
    "Dock",
    t(
      "The same shortcuts in every chat\n· + Set: a folder or a row of bubbles\n· + QR: one QR · New QR: made here, in the 'Dock' set",
      "모든 채팅에서 같은 바로가기\n· + 세트: 폴더 또는 한 줄\n· + QR: QR 하나 · 새 QR: 여기서 만들기('Dock' 세트에 저장)",
    ),
    [],
    list,
    el("div", { class: "row", style: "margin-top:8px;flex-wrap:wrap" }, addSet, addQr, make),
  );
  card.classList.add("card");
  return el("div", { class: "col cards dock-tab" }, card);
}
