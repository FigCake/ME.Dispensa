// The visz menu that opens from the Dock: a request box (with
// memos to load in), the Visualizer set's QRs and the Gallery of made pages.
// It only makes pages; OOC is the memo pad's. Built once and updated in
// place, so a draft survives the Dock's redraws.

import { type QrItem, type QrSet, builtinSet } from "../qr/model";
import type { QrStore } from "../qr/store";
import type { ArchiveEntry } from "../visz/archive";
import type { ViszAction } from "../visz/model";
import type { ViszService, ViszViewer } from "../visz/service";
import type { ViszStore } from "../visz/store";
import type { HostUI } from "../stscript/host";
import { confirmIn } from "./dialogs";
import { el, icon, onCtrlEnter } from "./dom";
import { helpTip, segmented } from "../shared/form";
import { t } from "../shared/i18n";

export const VISZ_PANEL_CSS = `
.visz-pop { width: min(440px, calc(100vw - 16px)); gap: 6px; }
.visz-pop .tabs { display: flex; gap: 4px; align-items: center; }
.visz-pop .tabs > button { width: auto; padding: 3px 10px; }
.visz-pop textarea { width: 100%; min-height: 52px; max-height: 30vh; resize: vertical; }
.visz-pop textarea { font-size: 13px; }
.visz-pop .acts { display: flex; gap: 4px; flex-wrap: nowrap; align-items: center; }
/* action buttons: label in the middle (list rows stay left-aligned) */
.visz-pop .acts button { width: auto; flex: none; justify-content: center; text-align: center; }
.visz-pop .acts button.main { flex: 1 1 auto; }
.visz-pop .acts button > .t { flex: 0 1 auto; text-align: center; }
.visz-pop .folder { font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: var(--d-muted); padding: 4px 4px 0; letter-spacing: .02em; }
.visz-pop .line { display: flex; gap: 3px; align-items: center; }
.visz-pop .line > button:first-child { flex: 1; min-width: 0; }
.visz-pop .line > button.mini { width: auto; flex: none; padding: 4px 6px; background: transparent; border-color: transparent; color: var(--d-muted); font-weight: 500; }
.visz-pop .line > button.mini:hover { background: var(--d-hl-bg); color: var(--d-hl-text); }
.visz-pop .line > button.mini.on { color: var(--d-accent); }
.visz-pop .meta { flex: none; margin-left: auto; font-size: 11px; color: var(--d-muted); font-weight: 500; }
.visz-pop .none { color: var(--d-muted); padding: 6px 4px; font-size: 12px; }
button.visz.busy { border-color: var(--d-btn-border-active); color: var(--d-btn-text-active); animation: pulse 1.2s ease-in-out infinite; }
@keyframes pulse { 50% { opacity: .55; } }
@media (prefers-reduced-motion: reduce) { button.visz.busy { animation: none; } }
`;

export interface ViszPanelDeps {
  store: ViszStore;
  service: ViszService;
  qrStore: QrStore;
  viewer: () => ViszViewer | null;
  ui: HostUI;
  close(): void;
  openSettings(): void;
  /** Memos chosen from the memo pad (null when none). */
  pickMemos(): Promise<string | null>;
  /** Keeps the typed topic as a memo. */
  addMemo(text: string): void;
  run(set: QrSet, item: QrItem): void;
}

const actionIcon = (a: ViszAction) => (a === "viz" ? "🌟" : "💬");

export class ViszPanel {
  readonly element: HTMLElement;
  private readonly box: HTMLTextAreaElement;
  private readonly list: HTMLElement;
  private tab: "items" | "archive" = "items";
  private archive: ArchiveEntry[] = [];

  constructor(private readonly deps: ViszPanelDeps) {
    this.box = el("textarea", {
      part: "visz-input",
      rows: "2",
    });
    onCtrlEnter(this.box, () => this.runTyped("viz"));
    this.list = el("div", { class: "list" });
    this.element = el("div", { class: "pop visz-pop", part: "visz-menu", role: "dialog" });
    this.render();
  }

  /** Called when the menu opens. */
  async refresh(): Promise<void> {
    this.render();
    if (this.tab === "archive") await this.loadArchive();
    setTimeout(() => this.box.focus(), 0);
  }

  render(): void {
    // here, not in the constructor: they follow the screen language
    this.box.placeholder = t("Topic of the page to make", "만들 페이지의 주제");
    this.box.setAttribute("aria-label", t("Visualizer request", "비주얼라이저 요청"));
    this.element.setAttribute("aria-label", t("Visualizer", "비주얼라이저"));
    const tabs = el(
      "div",
      { class: "tabs" },
      segmented(
        "visz-menu",
        [
          { value: "items", label: t("Items", "항목") },
          { value: "archive", label: t("Gallery", "갤러리"), title: t("Gallery: pages you made", "갤러리: 만든 페이지 모음") },
        ],
        this.tab,
        (v) => this.switchTab(v as "items" | "archive"),
        t("Visualizer menu", "비주얼라이저 메뉴"),
      ),
      el("span", { class: "meta" }),
      helpTip(
        t(
          "· 🌟 Make page (Ctrl+Enter) · ☆: save the topic\n· [[mood|bright|dark]]: asked when run · [[memo]]: pick a memo",
          "· 🌟 페이지 만들기 (Ctrl+Enter) · ☆: 주제 저장\n· [[분위기|밝게|어둡게]]: 실행할 때 물어봄 · [[메모]]: 메모 고르기",
        ),
        t("Visualizer menu", "비주얼라이저 메뉴"),
      ),
      el("button", { class: "mini ghost", title: t("Visualizer settings", "비주얼라이저 설정"), "aria-label": t("Visualizer settings", "비주얼라이저 설정"), onclick: () => this.deps.openSettings() }, icon("settings")),
    );
    if (this.tab === "archive") {
      this.renderArchive();
      this.element.replaceChildren(tabs, this.list);
      return;
    }
    const acts = el(
      "div",
      { class: "acts" },
      el("button", { part: "visz-memo", title: t("Pick memos into the box", "메모를 골라 칸에 넣기"), onclick: () => void this.load() }, t("📝 Memo pad", "📝 메모장")),
      el("button", { part: "visz-viz", class: "main", title: t("Make the page (Ctrl+Enter)", "페이지 만들기 (Ctrl+Enter)"), onclick: () => this.runTyped("viz") }, el("span", { class: "t" }, t("🌟 Make page", "🌟 페이지 만들기"))),
      el("button", { class: "mini ghost", title: t("Save this topic to the Memo pad", "이 주제를 메모장에 저장"), "aria-label": t("Save to the Memo pad", "메모장에 저장"), onclick: () => this.saveTyped() }, icon("star")),
    );
    this.renderItems();
    this.element.replaceChildren(tabs, this.box, acts, this.list);
  }

  private switchTab(tab: "items" | "archive"): void {
    this.tab = tab;
    this.render();
    if (tab === "archive") void this.loadArchive();
  }

  /** The Visualizer set's QRs (whole QRs that make pages). */
  private renderItems(): void {
    const set = builtinSet(this.deps.qrStore.value, "visz");
    const items = set?.items ?? [];
    this.list.replaceChildren();
    if (!set || !items.length) {
      this.list.append(el("div", { class: "none" }, t("QRs in the Library's 'Visualizer' set show up here.", "보관함의 '비주얼라이저' 세트에 QR을 넣으면 여기에 나와요.")));
      return;
    }
    for (const item of items) {
      this.list.append(
        el(
          "div",
          { class: "line" },
          el(
            "button",
            { part: "visz-item", title: item.title || item.label, onclick: () => (this.deps.close(), this.deps.run(set, item)) },
            el("span", { class: "t" }, `${item.icon ? `${item.icon} ` : ""}${item.label}`),
          ),
        ),
      );
    }
  }

  private async loadArchive(): Promise<void> {
    try {
      this.archive = await this.deps.service.archive.list();
    } catch (e) {
      this.archive = [];
      this.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("Gallery", "갤러리") });
    }
    if (this.tab === "archive") this.renderArchive();
  }

  private renderArchive(): void {
    this.list.replaceChildren();
    if (!this.archive.length) {
      this.list.append(el("div", { class: "none" }, t("The Gallery is empty. Press ☆ in the viewer to collect pages here.", "갤러리가 비어 있어요. 보기 창에서 ☆를 누르면 여기에 모여요.")));
      return;
    }
    for (const entry of this.archive) {
      const when = new Date(entry.createdAt);
      const date = `${when.getMonth() + 1}/${when.getDate()} ${String(when.getHours()).padStart(2, "0")}:${String(when.getMinutes()).padStart(2, "0")}`;
      this.list.append(
        el(
          "div",
          { class: "line" },
          el(
            "button",
            {
              part: "visz-archive-item",
              title: [entry.character, entry.chatName].filter(Boolean).join(" · "),
              onclick: () => {
                this.deps.viewer()?.show({ title: entry.title, kind: entry.kind, text: entry.text, archivedId: entry.id });
                this.deps.close();
              },
            },
            el("span", { class: "t" }, `${actionIcon(entry.kind)} ${entry.title}`),
            el("span", { class: "meta" }, date),
          ),
          el(
            "button",
            {
              class: "mini",
              title: t("Delete", "지우기"),
              "aria-label": t("Delete", "지우기"),
              onclick: async () => {
                if (!(await confirmIn(this.deps.ui, t(`Delete "${entry.title}" from the Gallery?`, `갤러리에서 "${entry.title}"을(를) 지울까요?`)))) return;
                await this.deps.service.archive.remove(entry.id);
                await this.loadArchive();
              },
            },
            icon("trash"),
          ),
        ),
      );
    }
  }

  private runTyped(action: ViszAction): void {
    const text = this.box.value;
    if (!text.trim()) {
      this.box.focus();
      return;
    }
    this.deps.close();
    // keep the draft when the run was cancelled or failed
    void this.deps.service.run(action, text).then((sent) => {
      if (sent && this.box.value === text) this.box.value = "";
    });
  }

  private saveTyped(): void {
    const text = this.box.value.trim();
    if (!text) return;
    this.deps.addMemo(text);
    this.deps.ui.toast(t("Saved to the Memo pad.", "메모장에 저장했어요."), "success", { title: "📝" });
  }

  private insert(text: string): void {
    const box = this.box;
    const start = box.selectionStart ?? box.value.length;
    const end = box.selectionEnd ?? start;
    const before = box.value.slice(0, start);
    const gap = before && !before.endsWith("\n") ? "\n\n" : "";
    box.value = before + gap + text + box.value.slice(end);
    const caret = (before + gap + text).length;
    box.focus();
    box.setSelectionRange(caret, caret);
  }

  /** Memos from the memo pad into the box. */
  private async load(): Promise<void> {
    const text = await this.deps.pickMemos();
    if (text) this.insert(text);
    else this.box.focus();
  }
}
