// SillyTavern World Info field names ↔ Marinara lorebook entry fields.

export interface LoreEntry {
  id: string;
  name?: string;
  content?: string;
  description?: string;
  keys?: string[];
  secondaryKeys?: string[];
  enabled?: boolean;
  constant?: boolean;
  selective?: boolean;
  selectiveLogic?: unknown;
  probability?: number;
  scanDepth?: number | null;
  matchWholeWords?: boolean;
  caseSensitive?: boolean;
  position?: number;
  depth?: number;
  order?: number;
  role?: string;
  group?: string;
  groupWeight?: number;
  [key: string]: unknown;
}

/** SillyTavern field → Marinara field. */
const FIELD_MAP: Record<string, string> = {
  key: "keys",
  keys: "keys",
  keysecondary: "secondaryKeys",
  secondarykeys: "secondaryKeys",
  comment: "name",
  name: "name",
  title: "name",
  content: "content",
  description: "description",
  constant: "constant",
  disable: "enabled", // inverted
  enabled: "enabled",
  order: "order",
  probability: "probability",
  depth: "depth",
  position: "position",
  role: "role",
  scandepth: "scanDepth",
  casesensitive: "caseSensitive",
  matchwholewords: "matchWholeWords",
  group: "group",
  groupweight: "groupWeight",
  selectivelogic: "selectiveLogic",
  selective: "selective",
};

function marinaraField(stField: string): string {
  const f = FIELD_MAP[stField.trim().toLowerCase()];
  if (!f) throw new Error(`Unknown lorebook field "${stField}"`);
  return f;
}

const truthy = (v: string) => /^(1|true|on|yes)$/i.test(v.trim());

/** Read a field the way SillyTavern returns it (lists comma-joined, disable inverted). */
export function readEntryField(entry: LoreEntry, stField: string): string {
  const field = marinaraField(stField);
  const raw = entry[field];
  if (stField.trim().toLowerCase() === "disable") return entry.enabled === false ? "true" : "false";
  if (Array.isArray(raw)) return raw.join(", ");
  if (raw === undefined || raw === null) return "";
  return typeof raw === "object" ? JSON.stringify(raw) : String(raw);
}

/** The PATCH body for setting a field from text. */
export function entryPatch(stField: string, value: string): Record<string, unknown> {
  const lower = stField.trim().toLowerCase();
  const field = marinaraField(stField);
  if (lower === "disable") return { enabled: !truthy(value) };
  if (field === "keys" || field === "secondaryKeys") return { [field]: value.split(",").map((s) => s.trim()).filter(Boolean) };
  if (["constant", "enabled", "caseSensitive", "matchWholeWords", "selective"].includes(field)) return { [field]: truthy(value) };
  if (["order", "probability", "depth", "position", "scanDepth", "groupWeight"].includes(field)) {
    const n = Number(value);
    if (Number.isNaN(n)) throw new Error(`Field "${stField}" needs a number`);
    return { [field]: n };
  }
  return { [field]: value };
}

/** SillyTavern /findentry: fuzzy match the text against a field; best entry first. */
export function findEntry(entries: LoreEntry[], stField: string, text: string): LoreEntry | undefined {
  const q = text.trim().toLowerCase();
  if (!q) return undefined;
  const values = (e: LoreEntry) => readEntryField(e, stField).toLowerCase().split(/,\s*/).concat(readEntryField(e, stField).toLowerCase());
  return (
    entries.find((e) => values(e).some((v) => v === q)) ??
    entries.find((e) => values(e).some((v) => v.startsWith(q))) ??
    entries.find((e) => values(e).some((v) => v.includes(q) || (v && q.includes(v))))
  );
}
