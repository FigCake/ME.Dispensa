# Dispensa

A quick reply bar for [Marinara Engine](https://github.com/Pasta-Devs/Marinara-Engine): runs SillyTavern Quick Replies (STscript) in Marinara, from a bar above the chat input. *Dispensa* is Italian for pantry. 한국어: [README-ko.md](README-ko.md)

## Features

* **Dock** — round icon bubbles above the chat input, out of sight until you want them
* **SillyTavern QR sets, as they are** — an STscript interpreter runs `/gen`, `/sendas`, `/if`, `/setvar`, closures, pipes and the rest
* **The whole Quick Reply feature set** — auto-run, sub menus, sets per chat or character, an editor with suggestions and a debugger
* **Marinara from scripts** — the Tracker Panel, lorebooks, character cards, the persona, the AI connection, the Author's Note
* **📝 Memo pad** — keep text from the chat, send it as OOC or use it for a 🌟 page
* **🌟 Visualizer** — HTML pages from the 슈퍼비즈 prompt
* **Screen language** — English or 한국어 (🌐 in the Dispensa window; follows Marinara's language by default, shared with Fornello)

## Dock

Star left of the input → `⋯` handle → point at it or touch it.

| Bubble | Does |
|---|---|
| 🍰 | Visualizer menu |
| 📝 | Memo pad |
| ⚙ | Dispensa window (the Library) |
| Sets · QRs | What the **Dock** tab puts there; a set is a folder |
| Stop | Shows while a QR runs |

| Action | Result |
|---|---|
| Click a QR | Run it |
| **Ctrl+click** (⌘+click on a Mac) | Edit it |
| **Right-click** (long-press on phones) | Open its sub menu |

The Dock is the same row of shortcuts in every chat, apart from where sets auto-run. In the Dispensa window's **Dock** tab: **+ Set** (a set as one **Folder** bubble, or a **Row**: its QRs as bubbles on a line of their own), **+ QR** (one QR), **New QR** (make one right there: command/script, OOC or visualizer page; it is kept in a 'Dock' set that auto-runs everywhere), ⠿ to reorder, ✕ to take off. Example: make `/pg-translate` (Polyglot's paragraph translation of the last reply) a new QR with an icon, turn on auto-run after the AI's reply, or leave it off and click it.

## Library (the Dispensa window)

| Button | Does |
|---|---|
| **Import QRs** | Import SillyTavern QR set JSON (several at once; a one-QR file goes into the open set) |
| **New set** · **New QR** | Make your own (a new QR starts as a command/script, an OOC, or a visualizer page) |
| **Export** | `.qr.json` for SillyTavern (numbering converted back; you are warned about commands it lacks) or `.mqr.json` for Marinara |
| **Paste** | Paste a copied QR (plain text becomes a QR that sends it) |
| ⠿ | Drag to reorder; sets also drag to another list |
| ⋯ | Set: duplicate, delete · QR: copy, cut, duplicate, move/copy to a set, export one, delete |

The set column is split like SillyTavern's lists: **Global** · **This chat** · **Character** (each character in the chat) decide where a set's QRs auto-run; **All sets** lists every set. Drag from All sets to add, back to remove, between lists to move.

| Set setting | Means |
|---|---|
| Auto-run in | Where it auto-runs, as switches: global · this chat · a character |
| Color | Fill or outline color |
| How text QRs send | What a plain-text QR does: put in the input, append to it, or prepend |

| QR editor | |
|---|---|
| Script | STscript; `/` or `{{` brings suggestions |
| Command list | Search, click to insert; marked SillyTavern / Dispensa / Marinara, or with the name of the extension that added it (Polyglot's `/pg-translate`, `/pg-annotate`…) |
| Sub menu | Sub menus: chained items, `%%parent%%` |
| Auto-run | App start · after my message · after the AI's reply · opening a chat · new chat · each group turn · right before the AI writes · a lorebook entry in play · block other auto-runs |
| **▶ Run** (Ctrl+Enter) | Run, result below |
| **🐞 Step** | Step through (into, over, out); breakpoints on line numbers or `/breakpoint` |

## 🌟 Visualizer

* 🍰 bubble → topic box → **🌟 Make page**
* `[[mood|bright|dark]]` asked at run time; `[[memo]]` (or `[[메모]]`) picks a memo
* The Visualizer set holds ordinary QRs that make pages with `/visz`: ask for a topic, the last message's scene, a memo; topics are kept in the memo pad
* Viewer above the bar: ☆ gallery · ➤ into the chat · ⤓ HTML file · 🖼 PNG · ⛶ fullscreen · ✕ close; or straight to the chat
* HTML code blocks in the chat get a 🌟 view button

| Setting | Means |
|---|---|
| Mode | Auto (full with Fornello, light otherwise), full (scripts, needs [Fornello](https://github.com/FigCake/ME.Fornello)), light (HTML and CSS only) |
| Show result in | Viewer or chat |
| Result language | The page's language |
| Chat pages to Gallery too | Keep pages sent to the chat in the gallery too |
| Allow outside resources | Let viewer pages load fonts and images from the web |
| AI connection | A separate connection for the visualizer |
| Prompt | Superviz in chunks to switch, edit, reorder; **Reset** restores it |

* Marinara's CSP stops page scripts; with Fornello, the viewer runs them on ▶ Run
* Additions to the original 슈퍼비즈: Google Fonts and async errors shown in the page (full mode); key visuals as inline SVG (both modes)
* With Fornello, a "Fornello commands" chunk teaches the page commands (`genChat`, `setLore`, `setTracker`, …): DM-style pages get real replies, and what happens there goes back to the story (`"@chat"` lorebook, tracker)

## 📝 Memo pad

* Add: select chat text → **📝 Memo** · the 📝 bubble · paste many in the 📝 tab (`*{OOC: …}*` / `[OOC: …]` wrappers come off)
* **💬 Send OOC** (Ctrl+Enter): as a character reply to the request · steering the next reply (Marinara's `/guided`) · as your message · into the input
* Use in the 🌟 topic box, `[[memo]]`, or scripts: `/memo`, `/memo-add`, `/memo-list`, `/ooc`

## Variables

* Chat variables go into Marinara's chat variables when they fit its rules (`{{getvar::name}}` works in prompts and lorebooks)
* Message numbers: converted once on import (SillyTavern counts from 0, Marinara from 1), back on export

## Setup

1. In the server `.env`, set `ENABLE_EXTERNAL_EXTENSIONS=true` and restart Marinara
2. Settings → Addons → External Extensions: turn on **Allow third-party extension imports**, then import `ME-Dispensa-<version>.zip`
3. Open **Dispensa** in the list → **Review and Run**: read the code and approve the hash (it must equal the one in `SHA256SUMS.txt`)

With [Fetchy](https://github.com/FigCake/ME.Fetchy), add `FigCake/ME.Dispensa` as a source to install and update.

## Is it safe

Dispensa asks for **full_page_access**: it draws the bar above the chat input and runs QRs in the page. It reads and writes the chat and calls the AI only when you run a QR, and talks to no outside server. Commands that delete messages, QRs or sets, or change a character card, ask first.

## Development

Building the extension, from the source zip (`ME-Dispensa-<version>-source.zip`) or the development repository:

```bash
npm install
npm run check     # typecheck
npm run build     # dist/: extension, zip, SHA256SUMS, and dist/public/ for the public repository
```

Tests (`test/`, `e2e/`) live only in the development repository, not in the source zip. There you can also run:

```bash
npm test          # unit tests (STscript interpreter, import/export, Marinara commands, the Dock and window in happy-dom)
npm run lint      # ESLint (typescript-eslint recommended)
npm run verify    # typecheck + lint + unit tests + build
```

* `DISPENSA_FIXTURE=<set.json> npm test` runs a SillyTavern QR set through the interpreter
* `e2e/` drives a local Marinara in Chromium: a mock OpenAI-compatible server (`mock-llm.mjs`), setup (`setup-marinara.mjs`) and the browser test (`qr-e2e.mjs`)
* `dist/` is committed: `npm run verify` rebuilds it, and CI checks that a clean checkout builds the same bytes
* Release: after `npm run build`, publish the contents of `dist/public/` (the build and the source zip) to [FigCake/ME.Dispensa](https://github.com/FigCake/ME.Dispensa)

### Code map

| Folder | What it is | Start reading at |
|---|---|---|
| `src/` | start-up and wiring | `main.ts` (`start()`: load the stores, run `migrations.ts`, build the parts, connect them); `auto-run.ts` (auto-run triggers); `bridge.ts` (`window.__dispensa` for other extensions) |
| `src/stscript/` | the STscript interpreter, ported from SillyTavern | `index.ts` (`createRegistry`), `parser.ts`, `interpreter.ts`, `macros.ts`, `commands/*.ts` (one file per command group); `host.ts` is the Host seam |
| `src/qr/` | Quick Replies: the Library's data and what runs it | `model.ts` (`QrState`, `AUTO_TRIGGERS`), `dock.ts` (the Dock's list), `scopes.ts` (where sets are on), `runner.ts`, `control.ts` (backs the `/qr-*` commands), `import.ts` and `convert.ts` (SillyTavern ⇄ Marinara files and numbering) |
| `src/visz/` | the visualizer: HTML pages from a topic | `service.ts` (a request from start to viewer or chat), `core.ts` (pure prompt and HTML helpers), `model.ts`, `archive.ts` (the Gallery, in IndexedDB), `superviz.ts` (the prompt, CC BY-NC-SA) |
| `src/memo/` | the memo pad's data | `model.ts` |
| `src/host/` | everything that talks to Marinara | `marinara-host.ts` (the Host for the live app), `chat.ts`, `variables.ts`, `marinara-extras.ts`, `persisted-store.ts` (extension storage) |
| `src/marinara/` | Marinara data helpers for commands | `lore.ts` |
| `src/shared/` | the same files in Dispensa and Fornello: change one here, then `npm run shared -- sync ../me.fornello.dev` | `i18n.ts` (`t()`), `api.ts` (Marinara's REST API), `marinara-global.ts`, `composer.ts` (the chat input), `react-bridge.ts`, `tracker.ts` (tracker paths), `theme.ts` (theme tokens), `form.ts` (settings rows), `capture.ts` (save as image); `src/extension.ts` holds what differs |
| `src/ui/` | everything drawn on screen (shadow roots, built with `el()` from `dom.ts`) | `dock.ts` and `dock-placement.ts`, `visz-panel.ts` and `memo-panel.ts` (the Dock's menus), `viewer.ts`, `manager/` (the Dispensa window: `index.ts`, one module per tab), `dialogs.ts` |
| `test/` | Vitest; files that need a page start with `// @vitest-environment happy-dom` | `fake-host.ts` (an in-memory Host) |

**The Host seam.** The interpreter only knows the `Host` interface in `src/stscript/host.ts`: variables, `ui` (toasts, popups, pickers), `chat` (messages, generation, sending), macro facts, and optionally `qr`, `visz`, `memo` and `marinara` (Marinara-only features). `MarinaraHost` (`src/host/marinara-host.ts`) implements it against the live app, with the dialogs passed in; tests use `test/fake-host.ts`. Layers: nothing outside `src/ui/` and `main.ts` imports from `src/ui/`; `main.ts` builds the parts and hands each what it needs.

**Data flow.** Saved data is three `PersistedStore`s in Marinara's extension storage (one 1 MB limit for all): `qr` (the Library, the Dock), `visz` (visz settings and prompt) and `memo` (the memo pad). On start each store loads and normalizes (older builds' keys are read here), then `migrations.ts` makes the one-off changes. A change is `store.update(fn)`: it changes the state in place, tells the listeners, and saves 400 ms later. Views listen with `store.select(slice, fn)` and redraw only when their slice changed (typing a script redraws neither the Dock nor the window). Gallery pages are large and stay in this browser's IndexedDB. Running a QR: a Dock bubble → `QrRunner` → the interpreter's `Runtime` → the Host → Marinara's API. Auto-run: `auto-run.ts` watches Marinara's generation and chat → `AutoExecutor` → `QrRunner`.

**Glossary.**

* **Dock**: the row of bubbles above the chat input (called "bar" up to 0.3.0). Themes can style its parts with `#dispensa-dock::part(…)`: `dock`, `handle`, `visz`, `visz-menu`, `visz-input`, `memo-menu`, `folder-menu`, `viewer`…
* **QR**, **QR set**: a SillyTavern Quick Reply and its set
* **Library**: every QR set, the first tab of the Dispensa window (보관함 in Korean)
* **visz**: the visualizer, which makes an HTML page from a topic (`/visz`, 🌟; "wand" and "viz" in older code). **Superviz** is its prompt; the **Visualizer set** holds the QRs its menu shows
* **memo**, **memo pad**: lines of text kept for later (📝, 메모장)
* **Gallery**: pages kept from the viewer
* **Dialect**: how a script counts messages: `st` from 0 (SillyTavern), `marinara` from 1
* **Fornello**: a separate extension that runs page scripts; looked up in `src/host/fornello.ts`

Every user-facing string goes through `t(english, korean)` (`src/shared/i18n.ts`).

## License and credits

* Dispensa is released under the [GNU AGPL-3.0](LICENSE). Copyright (C) 2026 FigCake
* The STscript interpreter follows the source and behavior of [SillyTavern](https://github.com/SillyTavern/SillyTavern) (AGPL-3.0), and the Marinara integration follows the API and behavior of [Marinara Engine](https://github.com/Pasta-Devs/Marinara-Engine) (AGPL-3.0); Dispensa is treated as derived from both and uses the same license
* The complete source is `ME-Dispensa-<version>-source.zip` in the public repository. If you distribute a modified version or offer it as a service, its source must be released under the AGPL-3.0 too
* The 🌟 슈퍼비즈 visualizer prompt (the text of `src/visz/superviz.ts`) is Copyright (C) 2026 FigCake and licensed separately, under [CC BY-NC-SA 4.0](LICENSE-SUPERVIZ.txt): share and adapt it with credit, not for commercial use, adaptations under the same license. It is text Dispensa sends to the AI, not code; everything else in Dispensa, the default QRs and other samples included, is AGPL-3.0
* Icons from [Lucide](https://lucide.dev) (ISC); image saving uses [html-to-image](https://github.com/bubkoo/html-to-image) (MIT), license text in `THIRD_PARTY_NOTICES.txt` and at the end of `extension.js`
