// The files Dispensa and Fornello share (src/shared/). Each repository keeps
// the same copy, and src/shared/SHARED.json records what that copy is.
//
//   node scripts/shared.mjs check          fails when src/shared/ no longer matches
//                                          SHARED.json (changed here only, by accident)
//   node scripts/shared.mjs sync <other>   copies src/shared/ to the other repository
//                                          and records the new copy in both
//
// (`npm run shared -- sync ../me.fornello.dev` from Dispensa, and the other way round.)

import { createHash } from "node:crypto";
import { copyFileSync, existsSync, readdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";

const DIR = "src/shared";
const MANIFEST = "SHARED.json";

const files = (root) => readdirSync(join(root, DIR)).filter((f) => f.endsWith(".ts")).sort();
const hash = (path) => createHash("sha256").update(readFileSync(path)).digest("hex");
const table = (root) => Object.fromEntries(files(root).map((f) => [f, hash(join(root, DIR, f))]));
const record = (root) => writeFileSync(join(root, DIR, MANIFEST), `${JSON.stringify(table(root), null, 2)}\n`);

const [command, other] = process.argv.slice(2);
if (command === "check") {
  const path = join(DIR, MANIFEST);
  const wanted = existsSync(path) ? JSON.parse(readFileSync(path, "utf8")) : {};
  const now = table(".");
  const names = [...new Set([...Object.keys(wanted), ...Object.keys(now)])].sort();
  const off = names.filter((n) => wanted[n] !== now[n]);
  if (off.length) {
    console.error(`src/shared/ changed here only: ${off.join(", ")}.\nCopy it to the other extension with \`npm run shared -- sync <path to the other repository>\` (that also updates ${MANIFEST}).`);
    process.exit(1);
  }
  console.log(`src/shared/: ${names.length} files match ${MANIFEST}`);
} else if (command === "sync" && other) {
  const there = resolve(other);
  if (!existsSync(join(there, DIR))) throw new Error(`no ${DIR} in ${there}`);
  for (const f of files(there)) if (!existsSync(join(DIR, f))) rmSync(join(there, DIR, f));
  for (const f of files(".")) copyFileSync(join(DIR, f), join(there, DIR, f));
  record(".");
  record(there);
  console.log(`copied ${files(".").length} files to ${join(there, DIR)}; ${MANIFEST} updated in both`);
} else {
  console.error("usage: node scripts/shared.mjs check | sync <path to the other repository>");
  process.exit(2);
}
