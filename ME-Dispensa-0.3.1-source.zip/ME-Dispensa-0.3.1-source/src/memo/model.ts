// The memo pad: lines of text kept for later (OOC notes, ideas for a page).
// They are not QRs: no scripts, no sets; they are found, sent as OOC, put in
// the input or the visz request, or turned into a QR.

import { extractOocNotes } from "../qr/import";
import { newId } from "../qr/model";

export interface Memo {
  id: string;
  text: string;
  /** Kept at the top. */
  pinned?: boolean;
  createdAt: number;
}

export interface MemoState {
  version: 1;
  memos: Memo[];
  /** The memo pad's bubble on the Dock. */
  showButton: boolean;
  dockIcon: string;
  /** The "Memo" button under selected chat text (on unless turned off). */
  capture?: boolean;
  /** OOC notes and the old visz QRs that sent OOC were moved here from the Library. */
  moved?: boolean;
  /** The topics of the old visz QRs were moved here (the Visualizer set got real QRs). */
  viszMoved?: boolean;
}

export const emptyMemos = (): MemoState => ({ version: 1, memos: [], showButton: true, dockIcon: "📝" });

export function newMemo(text: string, at = Date.now()): Memo {
  return { id: newId("memo"), text: text.trim(), createdAt: at };
}

export function normalizeMemos(raw: unknown): MemoState {
  const base = emptyMemos();
  if (!raw || typeof raw !== "object") return base;
  // barIcon and vizMoved: the names builds up to 0.3.0 saved
  const r = raw as Partial<MemoState> & { barIcon?: unknown; vizMoved?: unknown };
  const icon = r.dockIcon ?? r.barIcon;
  return {
    version: 1,
    memos: Array.isArray(r.memos)
      ? r.memos
          .filter((m) => m && typeof m.text === "string")
          .map((m) => ({ id: typeof m.id === "string" ? m.id : newId("memo"), text: m.text, createdAt: Number(m.createdAt) || 0, ...(m.pinned ? { pinned: true } : {}) }))
      : [],
    showButton: r.showButton !== false,
    dockIcon: typeof icon === "string" && icon.trim() ? icon.trim() : base.dockIcon,
    ...(r.capture === false ? { capture: false } : {}),
    ...(r.moved ? { moved: true } : {}),
    ...(r.viszMoved || r.vizMoved ? { viszMoved: true } : {}),
  };
}

/** Memos made from text: OOC wrappers come off, several wrapped notes become several memos. */
export function memosFrom(text: string, at = Date.now()): Memo[] {
  return extractOocNotes(text)
    .map((t) => t.trim())
    .filter(Boolean)
    .map((t, i) => newMemo(t, at + i));
}

const fold = (s: string) => s.normalize("NFC").toLowerCase();

/** Pinned first, then newest; `query` keeps those with every word in them. */
export function shownMemos(memos: Memo[], query = ""): Memo[] {
  const words = fold(query).split(/\s+/).filter(Boolean);
  return memos
    .filter((m) => words.every((w) => fold(m.text).includes(w)))
    .sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned) || b.createdAt - a.createdAt);
}

