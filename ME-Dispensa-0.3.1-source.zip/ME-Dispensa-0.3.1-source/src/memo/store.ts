// The memo pad in Marinara's storage (key "memo"), so it follows you to other devices.

import { PersistedStore } from "../host/persisted-store";
import { type MemoState, normalizeMemos } from "./model";

export class MemoStore extends PersistedStore<MemoState> {
  constructor() {
    super({ key: "memo", normalize: normalizeMemos, label: "memo" });
  }
}
