// Popups accept "simple HTML" (SillyTavern's /popup, /buttons, /input).
// Keep formatting tags, drop scripts, handlers, styles that could escape
// the dialog, and any URL that is not http(s) or a data: image.

const ALLOWED = new Set([
  "b", "strong", "i", "em", "u", "s", "small", "mark", "sub", "sup", "br", "hr", "p", "div", "span",
  "h1", "h2", "h3", "h4", "h5", "h6", "ul", "ol", "li", "blockquote", "pre", "code", "font", "img", "a",
  "table", "thead", "tbody", "tr", "th", "td", "details", "summary",
]);
const ATTRS = new Set(["color", "href", "src", "alt", "title", "colspan", "rowspan", "class"]);

export function sanitizeHtml(html: string): DocumentFragment {
  const template = document.createElement("template");
  template.innerHTML = html;
  const out = document.createDocumentFragment();
  for (const node of [...template.content.childNodes]) {
    const clean = cleanNode(node);
    if (clean) out.append(clean);
  }
  return out;
}

function cleanNode(node: Node): Node | null {
  if (node.nodeType === Node.TEXT_NODE) return document.createTextNode(node.textContent ?? "");
  if (node.nodeType !== Node.ELEMENT_NODE) return null;
  const el = node as Element;
  const tag = el.tagName.toLowerCase();
  if (!ALLOWED.has(tag)) {
    if (["script", "style", "iframe", "object", "embed", "svg", "math", "template"].includes(tag)) return null;
    const frag = document.createDocumentFragment();
    for (const child of [...el.childNodes]) {
      const c = cleanNode(child);
      if (c) frag.append(c);
    }
    return frag;
  }
  const copy = document.createElement(tag);
  for (const attr of [...el.attributes]) {
    const name = attr.name.toLowerCase();
    if (!ATTRS.has(name)) continue;
    if ((name === "href" || name === "src") && !safeUrl(attr.value, name === "src")) continue;
    copy.setAttribute(name, attr.value);
  }
  if (tag === "a") {
    copy.setAttribute("target", "_blank");
    copy.setAttribute("rel", "noopener noreferrer");
  }
  if (tag === "img") copy.setAttribute("referrerpolicy", "no-referrer");
  for (const child of [...el.childNodes]) {
    const c = cleanNode(child);
    if (c) copy.append(c);
  }
  return copy;
}

function safeUrl(url: string, isImage: boolean): boolean {
  const u = url.trim().toLowerCase();
  if (u.startsWith("https://") || u.startsWith("http://")) return true;
  return isImage && u.startsWith("data:image/");
}
