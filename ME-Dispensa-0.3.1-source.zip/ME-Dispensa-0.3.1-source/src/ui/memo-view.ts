// The memo tab of the Dispensa window: every memo (find, edit, pin, send,
// turn into a QR), adding many at once, a backup, and how the memo pad sends OOC.

import { type Memo, type MemoState, memosFrom, newMemo, shownMemos } from "../memo/model";
import { oneLine } from "../util";
import { downloadJson } from "./files";
import type { MemoStore } from "../memo/store";
import type { HostUI } from "../stscript/host";
import { el, icon } from "./dom";
import type { MenuEntry } from "./menu";
import { section, setting, toggle } from "../shared/form";
import { t } from "../shared/i18n";

export const MEMO_VIEW_CSS = `
.memo-list { display: flex; flex-direction: column; gap: 4px; margin-top: 6px; }
.memo-row { display: flex; align-items: center; gap: 4px; }
.memo-row > .entry { flex: 1; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.memo-row .pin.on { color: var(--d-accent); }
.memo-edit { margin: 2px 0 8px 0; display: flex; flex-direction: column; gap: 6px; }
.memo-edit textarea { font-family: var(--d-font); min-height: 90px; }
.memo-count { color: var(--d-muted); font-size: 12px; }
`;


export interface MemoViewDeps {
  store: MemoStore;
  ui: HostUI;
  sendOoc(text: string): Promise<boolean>;
  putInInput(text: string): void;
  makePage(text: string): Promise<boolean>;
  /** Puts the memo into the Library as a QR that sends it as OOC. */
  toQr(text: string): Promise<void>;
  /** The visz settings' OOC parts: how to send, the wrappers. */
  oocSettings(): HTMLElement[];
  menu(summary: Node, label: string, entries: MenuEntry[]): HTMLElement;
  close(): void;
  rerender(): void;
}

export class MemoView {
  private query = "";
  private open: string | null = null;

  constructor(private readonly deps: MemoViewDeps) {}

  private get state(): MemoState {
    return this.deps.store.value;
  }

  private update(fn: (s: MemoState) => void): void {
    this.deps.store.update(fn);
  }

  render(): HTMLElement {
    return el("div", { class: "col cards" }, this.memoCard(), this.dockCard(), ...this.deps.oocSettings(), this.backupCard());
  }

  private memoCard(): HTMLElement {
    const all = this.state.memos;
    const shown = shownMemos(all, this.query);
    const list = el("div", { class: "memo-list" });
    for (const memo of shown) list.append(...this.row(memo));
    if (!all.length) list.append(el("div", { class: "note" }, t("No memos. Select text in the chat and press 📝 Memo, or make a new memo.", "메모가 없어요. 채팅에서 글을 긁어 📝 메모를 누르거나, 새 메모를 만드세요.")));
    else if (!shown.length) list.append(el("div", { class: "note" }, t("No matching memos.", "찾는 메모가 없어요.")));
    return el(
      "div",
      { class: "card" },
      section(
        t("📝 Memos", "📝 메모"),
        t(
          "Text to use later, like OOC lines or page topics\n· Save with the 📝 Memo button that shows up when you select chat text\n· Use them with the 📝 button in the 🍰 menu, a [[memo]] blank, or the /memo command\n· ⭐: pin to top",
          "OOC 문구·페이지 소재처럼 나중에 쓸 글 모음\n· 채팅에서 글을 긁으면 뜨는 📝 메모 버튼으로 저장\n· 🍰 메뉴의 📝 버튼, [[메모]] 빈칸, /memo 명령으로 꺼내 쓰기\n· ⭐: 위에 고정",
        ),
        [
          el(
            "button",
            {
              onclick: () => {
                const memo = newMemo(t("New memo", "새 메모"));
                this.update((s) => s.memos.push(memo));
                this.open = memo.id;
                this.query = "";
                this.deps.rerender();
              },
            },
            icon("plus"),
            t("New memo", "새 메모"),
          ),
          el("button", { title: t("Paste many OOC lines at once. Strips wrappers like *{OOC: …}* and splits them one by one", "OOC 문구 한꺼번에 붙여넣기. *{OOC: …}* 같은 포장은 벗기고 하나씩 나눔"), onclick: () => void this.paste() }, icon("clipboard"), t("Add many", "여러 개 넣기")),
        ],
        el("input", {
          type: "search",
          placeholder: t("Search memos", "메모 찾기"),
          value: this.query,
          "data-key": "memo-search",
          "aria-label": t("Search memos", "메모 찾기"),
          oninput: (e: Event) => {
            this.query = (e.target as HTMLInputElement).value;
            this.deps.rerender();
          },
        }),
        el("div", { class: "memo-count" }, this.query ? t(`${shown.length} / ${all.length}`, `${shown.length} / ${all.length}개`) : t(`${all.length}`, `${all.length}개`)),
        list,
      ),
    );
  }

  private row(memo: Memo): HTMLElement[] {
    const isOpen = this.open === memo.id;
    const row = el(
      "div",
      { class: "memo-row" },
      el(
        "button",
        {
          class: `entry${isOpen ? " sel" : ""}`,
          title: memo.text.slice(0, 400),
          onclick: () => {
            this.open = isOpen ? null : memo.id;
            this.deps.rerender();
          },
        },
        oneLine(memo.text, 90) || t("(empty memo)", "(빈 메모)"),
      ),
      el(
        "button",
        {
          class: `icon pin${memo.pinned ? " on" : ""}`,
          title: memo.pinned ? t("Unpin", "고정 풀기") : t("Pin to top", "위에 고정"),
          "aria-label": memo.pinned ? t("Unpin", "고정 풀기") : t("Pin to top", "위에 고정"),
          "aria-pressed": String(!!memo.pinned),
          onclick: () => this.mutate(memo.id, (m) => (m.pinned ? delete m.pinned : (m.pinned = true))),
        },
        icon("pin"),
      ),
      this.deps.menu(icon("more"), t("Memo menu", "메모 메뉴"), [
        { label: t("💬 Send as OOC", "💬 OOC로 보내기"), run: () => (this.deps.close(), void this.deps.sendOoc(memo.text)) },
        { label: t("Put in the input", "입력창에 넣기"), run: () => (this.deps.close(), this.deps.putInInput(memo.text)) },
        { label: t("🌟 Make page", "🌟 페이지 만들기"), sub: t("From this text", "이 글을 소재로"), run: () => (this.deps.close(), void this.deps.makePage(memo.text)) },
        { label: t("Make a QR…", "QR로 만들기…"), sub: t("A QR in the Library that sends it as OOC", "누르면 OOC로 보내는 QR을 보관함에"), run: () => this.deps.toQr(memo.text) },
        { label: t("Copy", "복사"), run: async () => (await this.deps.ui.copy?.(memo.text), this.deps.ui.toast(t("Copied.", "복사했어요."), "success", { title: "📝" })) },
        "-",
        { label: t("Delete", "삭제"), danger: true, run: () => this.update((s) => (s.memos = s.memos.filter((m) => m.id !== memo.id))) },
      ]),
    );
    if (!isOpen) return [row];
    const ta = el("textarea", {
      "data-key": `memo-${memo.id}`,
      "aria-label": t("Memo text", "메모 내용"),
      oninput: (e: Event) => {
        const text = (e.target as HTMLTextAreaElement).value;
        // the window does not redraw for memo text (see manager/index.ts), so typing keeps its caret
        this.mutate(memo.id, (m) => (m.text = text));
      },
    });
    ta.value = memo.text;
    return [row, el("div", { class: "memo-edit" }, ta)];
  }

  private mutate(id: string, fn: (m: Memo) => void): void {
    this.update((s) => {
      const m = s.memos.find((x) => x.id === id);
      if (m) fn(m);
    });
  }

  private async paste(): Promise<void> {
    const text = await this.deps.ui.input(t("Paste the text.<br><small>Wrappers like *{OOC: …}* are stripped, and several lines are split one by one.</small>", "넣을 글을 붙여 넣으세요.<br><small>*{OOC: …}* 같은 포장은 알아서 벗기고, 여러 개면 하나씩 나눠요.</small>"), { rows: 8, multiline: true, wide: true, okButton: t("Add", "넣기") });
    if (!text?.trim()) return;
    const memos = memosFrom(text);
    this.update((s) => s.memos.push(...memos));
    this.deps.ui.toast(t(`Added ${memos.length} memos.`, `메모 ${memos.length}개를 넣었어요.`), "success", { title: "📝" });
  }

  private dockCard(): HTMLElement {
    const s = this.state;
    return el(
      "div",
      { class: "card" },
      section(
        "Dock",
        undefined,
        [],
        setting(
          t("📝 Bubble", "📝 버블"),
          [
            el("input", { type: "text", class: "icon-input", value: s.dockIcon, maxlength: "8", "data-key": "memo-dock-icon", "aria-label": t("Bubble icon", "버블 아이콘"), oninput: (e: Event) => this.update((x) => (x.dockIcon = (e.target as HTMLInputElement).value.trim() || "📝")) }),
            toggle(s.showButton, (v) => this.update((x) => (x.showButton = v)), t("Show 📝 bubble", "📝 버블 보이기"), "memo-show"),
          ],
          t("Puts the Memo pad bubble on the Dock. Write, pick, and send memos as OOC", "Dock에 메모장 버블 두기. 메모 쓰기·고르기·OOC 보내기"),
        ),
        setting(t("📝 button on selected text", "글을 긁으면 📝 버튼"), toggle(s.capture !== false, (v) => this.update((x) => (x.capture = v)), t("📝 button on selected text", "글을 긁으면 📝 버튼"), "memo-capture"), t("Shows a 📝 Memo button under text selected in a chat message or the input. Saves it to the Memo pad", "채팅 메시지나 입력창에서 글을 고르면 그 아래에 📝 메모 버튼 표시. 누르면 메모장에 저장")),
      ),
    );
  }

  private backupCard(): HTMLElement {
    return el(
      "div",
      { class: "card" },
      section(
        t("Backup", "백업"),
        t("Export or import all memos as a .memo.json file. Imported memos are added to the current ones", "메모 전체를 .memo.json 파일로 내보내기·가져오기. 가져오면 지금 메모에 더해짐"),
        [el("button", { onclick: () => this.exportJson() }, icon("upload"), t("Export", "내보내기")), el("button", { onclick: () => this.importJson() }, icon("download"), t("Import", "가져오기"))],
      ),
    );
  }

  private exportJson(): void {
    downloadJson({ format: "dispensa-memo", version: 1, memos: this.state.memos.map((m) => ({ text: m.text, pinned: m.pinned || undefined, createdAt: m.createdAt })) }, "dispensa.memo.json");
  }

  private importJson(): void {
    const input = el("input", { type: "file", accept: ".json,application/json" });
    input.addEventListener("change", async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const json = JSON.parse(await file.text()) as { memos?: { text?: unknown; pinned?: unknown; createdAt?: unknown }[] };
        const have = new Set(this.state.memos.map((m) => m.text));
        const fresh = (json.memos ?? [])
          .filter((m) => typeof m.text === "string" && m.text.trim() && !have.has(m.text))
          .map((m) => ({ ...newMemo(String(m.text), Number(m.createdAt) || Date.now()), ...(m.pinned ? { pinned: true } : {}) }));
        this.update((s) => s.memos.push(...fresh));
        this.deps.ui.toast(t(`Imported ${fresh.length} memos.`, `메모 ${fresh.length}개를 가져왔어요.`), "success", { title: "📝" });
      } catch (e) {
        this.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("📝 Import", "📝 가져오기") });
      }
    });
    input.click();
  }
}
