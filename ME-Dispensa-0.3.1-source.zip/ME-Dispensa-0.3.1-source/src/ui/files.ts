// Files the user saves from Dispensa (backups, QR exports).

import { saveBlob } from "../shared/capture";

/** Saves `data` as a pretty-printed JSON file; characters file names can't hold become "_". */
export function downloadJson(data: unknown, name: string): void {
  saveBlob(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }), name.replace(/[\\/:*?"<>|]/g, "_"));
}
