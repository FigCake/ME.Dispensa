import { findComposer, setComposerText } from "../shared/composer";

export function getComposerText(): string {
  return findComposer()?.textarea.value ?? "";
}

export function setComposerTextIfPresent(text: string): void {
  const composer = findComposer();
  if (composer) setComposerText(composer.textarea, text);
}
