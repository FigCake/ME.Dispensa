// The QR script box: colored STscript under a plain textarea, line numbers
// (click one for a breakpoint), command and macro suggestions, Tab indents,
// Ctrl+Enter runs.

import { lineOf } from "../qr/debug";
import { el } from "./dom";
import { t } from "../shared/i18n";
import { escapeHtml } from "../util";

export interface Suggestion {
  name: string;
  help?: string;
}

export interface ScriptEditorOptions {
  value: string;
  /** Kept on the textarea so focus survives the manager's redraws. */
  key: string;
  label: string;
  commands(): Suggestion[];
  onChange(value: string): void;
  onRun?(): void;
  onBreakpoints?(lines: Set<number>): void;
}

export const SCRIPT_EDITOR_CSS = `
.se { position: relative; border: 1px solid var(--d-field-border); border-radius: var(--d-radius-sm); background: var(--d-field); min-height: 220px; }
.se:focus-within { border-color: var(--d-btn-border-hover); box-shadow: 0 0 0 2px var(--d-ring); }
.se .hl, .se textarea { margin: 0; border: 0; font: 13px/1.6 var(--d-mono); tab-size: 2; letter-spacing: 0; white-space: pre-wrap; overflow-wrap: anywhere; word-break: normal;
  padding: 8px 10px 8px 46px; }
.se .hl { min-height: 220px; color: var(--d-text); pointer-events: none; }
.se textarea { position: absolute; inset: 0; width: 100%; height: 100%; resize: none; overflow: hidden; background: transparent; color: transparent; caret-color: var(--d-text);
  outline: none; box-shadow: none; min-height: 0; border-radius: inherit; }
.se textarea::selection { background: color-mix(in srgb, var(--d-accent) 35%, transparent); color: transparent; }
.se .ln { position: relative; min-height: 1.6em; }
.se .ln::before { content: attr(data-n); position: absolute; left: -40px; width: 30px; text-align: right; color: var(--d-muted); opacity: .6; font-size: 11.5px; }
.se .ln.bp::after { content: ""; position: absolute; left: -44px; top: .45em; width: 8px; height: 8px; border-radius: 50%; background: #e5534b; }
.se .ln.paused { background: color-mix(in srgb, #e6a23c 18%, transparent); box-shadow: -46px 0 0 color-mix(in srgb, #e6a23c 18%, transparent); }
.se .gutter-hit { position: absolute; left: 0; top: 0; bottom: 0; width: 40px; cursor: pointer; }
.se .t-cmd { color: var(--d-accent); font-weight: 700; }
.se .t-arg { color: #c792ea; }
.se .t-macro { color: #3fb97a; }
.se .t-cl { color: #e6a23c; font-weight: 700; }
.se .t-pipe { color: var(--d-muted); font-weight: 700; }
.se .t-str { color: #f78c6c; }
.se .t-cmt { color: var(--d-muted); font-style: italic; }
.se .t-cur { background: color-mix(in srgb, #e6a23c 45%, transparent); border-radius: 3px; }
.se .ac { position: absolute; z-index: 6; left: 40px; right: 8px; max-width: 460px; max-height: 220px; overflow: auto; display: flex; flex-direction: column; padding: 4px;
  background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); box-shadow: var(--d-shadow); }
.se .ac[hidden] { display: none; }
.se .ac button { justify-content: flex-start; gap: 8px; width: 100%; padding: 4px 8px; border-color: transparent; background: none; font-weight: 500; white-space: nowrap; overflow: hidden; }
.se .ac button.on, .se .ac button:hover { background: var(--d-hl-bg); }
.se .ac code { font-family: var(--d-mono); font-size: 12.5px; color: var(--d-btn-text-active); }
.se .ac small { color: var(--d-muted); overflow: hidden; text-overflow: ellipsis; }
`;

/** Macros offered after "{{". */
const MACROS = (): Suggestion[] => [
  { name: "user", help: t("My name (persona)", "내 이름 (페르소나)") },
  { name: "char", help: t("Character name", "캐릭터 이름") },
  { name: "pipe", help: t("Result of the previous command", "앞 명령의 결과") },
  { name: "input", help: t("Text in the input", "입력창의 글") },
  { name: "lastMessage", help: t("Last message", "마지막 메시지") },
  { name: "lastMessageId", help: t("Last message number", "마지막 메시지 번호") },
  { name: "lastCharMessage", help: t("Character's last message", "캐릭터의 마지막 메시지") },
  { name: "lastUserMessage", help: t("My last message", "내 마지막 메시지") },
  { name: "getvar::", help: t("Chat variable value", "채팅 변수 값") },
  { name: "getglobalvar::", help: t("Global variable value", "전역 변수 값") },
  { name: "var::", help: t("Script variable value", "스크립트 안 변수 값") },
  { name: "random::", help: t("One of several", "여러 개 중 하나") },
  { name: "roll::", help: t("Dice (1d6)", "주사위 (1d6)") },
  { name: "time", help: t("Current time", "지금 시각") },
  { name: "date", help: t("Today's date", "오늘 날짜") },
  { name: "newline", help: t("Line break", "줄바꿈") },
  { name: "timesIndex", help: t("/times loop count", "/times 반복 횟수") },
];

const TOKEN = /(\/[#/][^|\n]*)|(\{\{(?:(?!\}\}).)*\}\})|(\{:|:\}(?:\(\))?)|(\|\|?)|("(?:\\.|[^"\\\n])*")|((?:^|(?<=[\s|]|\{:))\/[\w:.-]+)|((?<=\s)[\w.-]+=)/g;
const CLASSES = ["t-cmt", "t-macro", "t-cl", "t-pipe", "t-str", "t-cmd", "t-arg"];

/** HTML for colored STscript, line by line; `mark` wraps a range (the command being debugged). */
export function highlight(text: string, mark?: { start: number; end: number } | null): string[] {
  // spans per character position, so the mark can cut across tokens
  const cls: (string | null)[] = new Array(text.length).fill(null);
  for (const m of text.matchAll(TOKEN)) {
    const g = m.slice(1).findIndex((x) => x !== undefined);
    if (g < 0) continue;
    for (let i = m.index!; i < m.index! + m[0].length; i++) cls[i] = CLASSES[g];
  }
  const lines: string[] = [];
  let line = "";
  let open: string | null = null;
  let marked = false;
  const close = () => {
    if (open) line += "</span>";
    open = null;
  };
  for (let i = 0; i <= text.length; i++) {
    const inMark = !!mark && i >= mark.start && i < mark.end;
    if (i === text.length || text[i] === "\n") {
      close();
      if (marked) line += "</span>";
      lines.push(line);
      line = "";
      marked = false;
      continue;
    }
    if (inMark !== marked) {
      close();
      line += inMark ? '<span class="t-cur">' : "</span>";
      marked = inMark;
    }
    if (cls[i] !== open) {
      close();
      if (cls[i]) line += `<span class="${cls[i]}">`;
      open = cls[i];
    }
    line += escapeHtml(text[i]);
  }
  return lines;
}

export class ScriptEditor {
  readonly element: HTMLElement;
  readonly textarea: HTMLTextAreaElement;
  private readonly hl: HTMLElement;
  private readonly ac: HTMLElement;
  private breakpoints = new Set<number>();
  private mark: { start: number; end: number } | null = null;
  private choices: { items: Suggestion[]; index: number; from: number; kind: "cmd" | "macro" } | null = null;

  constructor(private readonly options: ScriptEditorOptions) {
    this.hl = el("div", { class: "hl", "aria-hidden": "true" });
    this.textarea = el("textarea", { spellcheck: "false", autocapitalize: "off", autocomplete: "off", "data-key": options.key, "aria-label": options.label });
    this.textarea.value = options.value;
    this.ac = el("div", { class: "ac", role: "listbox", hidden: true });
    const hit = el("div", { class: "gutter-hit", title: t("Click a line number to set a breakpoint", "줄 번호를 눌러 중단점 정하기") });
    hit.addEventListener("mousedown", (e) => {
      e.preventDefault();
      this.toggleBreakpointAt((e as MouseEvent).clientY);
    });
    this.element = el("div", { class: "se" }, this.hl, this.textarea, hit, this.ac);
    this.textarea.addEventListener("input", () => {
      this.paint();
      this.options.onChange(this.textarea.value);
      this.suggest();
    });
    this.textarea.addEventListener("keydown", (e) => this.onKey(e));
    this.textarea.addEventListener("blur", () => setTimeout(() => this.closeSuggestions(), 120));
    this.textarea.addEventListener("click", () => this.closeSuggestions());
    this.paint();
  }

  get value(): string {
    return this.textarea.value;
  }

  set value(v: string) {
    if (v === this.textarea.value) return;
    this.textarea.value = v;
    this.paint();
  }

  get lines(): Set<number> {
    return new Set(this.breakpoints);
  }

  setBreakpoints(lines: Set<number>): void {
    this.breakpoints = new Set(lines);
    this.paint();
  }

  /** Marks the command the debugger stopped at (or clears it). */
  setMark(range: { start: number; end: number } | null): void {
    this.mark = range;
    this.paint();
    if (range) {
      const line = this.hl.children[lineOf(this.textarea.value, range.start)] as HTMLElement | undefined;
      line?.scrollIntoView({ block: "nearest" });
    }
  }

  private paint(): void {
    const text = this.textarea.value;
    const html = highlight(text, this.mark);
    const pausedLine = this.mark ? lineOf(text, this.mark.start) : -1;
    this.hl.innerHTML = html
      .map((l, i) => `<div class="ln${this.breakpoints.has(i) ? " bp" : ""}${i === pausedLine ? " paused" : ""}" data-n="${i + 1}">${l || "​"}</div>`)
      .join("");
  }

  private toggleBreakpointAt(y: number): void {
    const lines = [...this.hl.children] as HTMLElement[];
    const index = lines.findIndex((l) => {
      const r = l.getBoundingClientRect();
      return y >= r.top && y < r.bottom;
    });
    if (index < 0) return;
    if (this.breakpoints.has(index)) this.breakpoints.delete(index);
    else this.breakpoints.add(index);
    this.paint();
    this.options.onBreakpoints?.(this.lines);
  }

  private onKey(e: KeyboardEvent): void {
    const ta = this.textarea;
    if (this.choices) {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        const n = this.choices.items.length;
        this.choices.index = (this.choices.index + (e.key === "ArrowDown" ? 1 : n - 1)) % n;
        this.drawSuggestions();
        return;
      }
      if (e.key === "Enter" || e.key === "Tab") {
        e.preventDefault();
        this.accept(this.choices.items[this.choices.index]);
        return;
      }
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        this.closeSuggestions();
        return;
      }
    }
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      this.options.onRun?.();
      return;
    }
    if (e.key === "Tab" && !e.altKey && !e.ctrlKey && !e.metaKey) {
      e.preventDefault();
      this.indent(e.shiftKey);
      return;
    }
    if (e.key === "Enter" && !e.shiftKey) {
      // keep the indent of the line above
      const start = ta.selectionStart;
      const lineStart = ta.value.lastIndexOf("\n", start - 1) + 1;
      const indent = /^[ \t]*/.exec(ta.value.slice(lineStart, start))![0];
      if (!indent) return;
      e.preventDefault();
      this.replace(start, ta.selectionEnd, `\n${indent}`);
    }
  }

  private indent(out: boolean): void {
    const ta = this.textarea;
    const { selectionStart: s, selectionEnd: end, value } = ta;
    if (s === end && !out) {
      this.replace(s, end, "  ");
      return;
    }
    const lineStart = value.lastIndexOf("\n", s - 1) + 1;
    const block = value.slice(lineStart, end);
    const changed = block
      .split("\n")
      .map((l) => (out ? l.replace(/^( {1,2}|\t)/, "") : `  ${l}`))
      .join("\n");
    ta.setRangeText(changed, lineStart, end, "select");
    if (s === end) ta.setSelectionRange(Math.max(lineStart, s - (block.length - changed.length)), Math.max(lineStart, s - (block.length - changed.length)));
    ta.dispatchEvent(new Event("input"));
  }

  private replace(from: number, to: number, text: string): void {
    this.textarea.setRangeText(text, from, to, "end");
    this.textarea.dispatchEvent(new Event("input"));
  }

  private suggest(): void {
    const ta = this.textarea;
    if (ta.selectionStart !== ta.selectionEnd) return this.closeSuggestions();
    const before = ta.value.slice(0, ta.selectionStart);
    const cmd = /(?:^|[\s|]|\{:)\/([\w:.-]*)$/.exec(before);
    const macro = /\{\{([\w:]*)$/.exec(before);
    let items: Suggestion[] = [];
    let from = 0;
    let kind: "cmd" | "macro" = "cmd";
    if (cmd && !before.endsWith("//")) {
      const q = cmd[1].toLowerCase();
      const all = this.options.commands();
      items = [...all.filter((c) => c.name.startsWith(q)), ...all.filter((c) => !c.name.startsWith(q) && q.length > 1 && c.name.includes(q))];
      from = ta.selectionStart - cmd[1].length;
    } else if (macro) {
      const q = macro[1].toLowerCase();
      items = MACROS().filter((m) => m.name.toLowerCase().startsWith(q));
      from = ta.selectionStart - macro[1].length;
      kind = "macro";
    }
    // nothing to offer, or the word is already complete
    if (!items.length || (items.length === 1 && items[0].name === ta.value.slice(from, ta.selectionStart))) return this.closeSuggestions();
    this.choices = { items: items.slice(0, 30), index: 0, from, kind };
    this.drawSuggestions();
  }

  private drawSuggestions(): void {
    const c = this.choices;
    if (!c) return;
    this.ac.replaceChildren(
      ...c.items.map((s, i) =>
        el(
          "button",
          {
            type: "button",
            role: "option",
            class: i === c.index ? "on" : "",
            "aria-selected": String(i === c.index),
            onmousedown: (e: Event) => {
              e.preventDefault();
              this.accept(s);
            },
          },
          el("code", {}, c.kind === "cmd" ? `/${s.name}` : `{{${s.name}${s.name.endsWith("::") ? "" : "}}"}`),
          s.help ? el("small", {}, s.help) : null,
        ),
      ),
    );
    // under the caret's line
    const line = this.hl.children[lineOf(this.textarea.value, this.textarea.selectionStart)] as HTMLElement | undefined;
    this.ac.style.top = `${(line?.offsetTop ?? 0) + (line?.offsetHeight ?? 20) + 2}px`;
    this.ac.hidden = false;
    (this.ac.children[c.index] as HTMLElement | undefined)?.scrollIntoView({ block: "nearest" });
  }

  private accept(s: Suggestion): void {
    const c = this.choices;
    if (!c) return;
    const ta = this.textarea;
    const tail = c.kind === "cmd" ? " " : s.name.endsWith("::") ? "" : "}}";
    this.closeSuggestions();
    ta.setRangeText(s.name + tail, c.from, ta.selectionStart, "end");
    ta.dispatchEvent(new Event("input"));
    this.closeSuggestions();
  }

  private closeSuggestions(): void {
    this.choices = null;
    this.ac.hidden = true;
  }
}
