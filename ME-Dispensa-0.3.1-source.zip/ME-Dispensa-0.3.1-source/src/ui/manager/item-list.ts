// The Library's right column: the selected set's panel, its QRs (each with
// a ⋯ menu), the open QR's editor, and "New QR".

import { t } from "../../shared/i18n";
import { cloneItem } from "../../qr/copy";
import { type QrItem, type QrSet, newItem } from "../../qr/model";
import { el, icon } from "../dom";
import { dragHandle, moveTo } from "../drag";
import { dropMenu } from "../menu";
import type { ManagerContext } from "./context";
import type { QrFiles } from "./import-export";
import type { ItemEditor } from "./item-editor";
import { setPanel } from "./set-panel";

export function itemColumn(ctx: ManagerContext, editor: ItemEditor, files: QrFiles): HTMLElement {
  const set = ctx.state.sets.find((s) => s.id === ctx.selectedSet);
  const col = el("div", { class: "col" });
  if (!set) {
    col.append(el("div", { class: "empty" }, t("Pick a set or make a new one.", "세트를 고르거나 새로 만드세요.")));
    return col;
  }
  col.append(...setPanel(ctx, set, files));
  col.append(
    el(
      "div",
      { class: "row", style: "margin:14px 0 6px" },
      el("div", { class: "section", style: "margin:0" }, t(`${set.items.length} QRs`, `QR ${set.items.length}개`)),
      el("span", { class: "grow" }),
      el("button", { type: "button", title: t("Paste a copied QR (or text)", "복사한 QR(또는 글) 붙여넣기"), onclick: () => void files.paste(set) }, icon("clipboard"), t("Paste", "붙여넣기")),
    ),
  );
  const list = el("div", { class: "list" });
  set.items.forEach((item) => {
    const handle = el("button", { class: "drag", type: "button", title: t("Drag to reorder (or ↑↓ keys)", "끌어서 순서 바꾸기 (↑↓ 키도 가능)"), "aria-label": t(`Reorder ${item.label}`, `${item.label} 순서 바꾸기`), "data-key": `drag-qr-${item.id}` }, icon("grip"));
    const marks = [
      item.auto && Object.values(item.auto).some(Boolean) ? "⚡" : "",
      item.automationId ? "📚" : "",
      item.contextList?.length ? "☰" : "",
      item.hidden ? t("Hidden", "숨김") : "",
    ].filter(Boolean);
    const row = el(
      "div",
      { class: "qrow" },
      handle,
      el(
        "button",
        {
          class: `entry${item.id === ctx.selectedItem ? " sel" : ""}`,
          onclick: () => {
            ctx.selectedItem = ctx.selectedItem === item.id ? null : item.id;
            ctx.render();
          },
        },
        item.icon?.trim() ? el("span", {}, item.icon.trim()) : item.kind === "ooc" ? icon("message-circle") : icon("play"),
        el("span", { class: "grow" }, item.label || t("(no name)", "(이름 없음)")),
        marks.length ? el("span", { class: "marks", title: t("⚡ auto-run · 📚 lorebook link · ☰ sub menu", "⚡ 자동 실행 · 📚 로어북 연결 · ☰ 하위 메뉴") }, marks.join(" ")) : null,
        item.unsupported?.length ? el("span", { class: "warn", title: item.unsupported.join(", ") }, "⚠") : null,
        item.dialect === "st" ? el("span", { class: "meta", title: item.note ?? "" }, t("SillyTavern style", "실리태번 기준")) : null,
      ),
      el("button", { class: "icon", title: t("Run", "실행"), "aria-label": t(`Run ${item.label}`, `${item.label} 실행`), onclick: () => ctx.deps.run(set, item) }, icon("play")),
      itemMenu(ctx, files, set, item),
    );
    dragHandle(handle, row, ".qrow", (from, to) => ctx.mutateSet(set, (s) => moveTo(s.items, from, to)));
    list.append(row);
    if (item.id === ctx.selectedItem) list.append(editor.render(set, item));
  });
  col.append(
    list,
    el(
      "div",
      { class: "row", style: "margin-top:8px" },
      newQrMenu((item) => {
        ctx.mutateSet(set, (s) => s.items.push(item));
        ctx.selectedItem = item.id;
        ctx.render();
      }),
    ),
  );
  return col;
}

/** "New QR" with the kinds a QR can start as (each is still a plain QR to edit). */
export function newQrMenu(add: (item: QrItem) => void): HTMLElement {
  return dropMenu(
    el("span", { class: "row", style: "gap:5px" }, icon("plus"), el("span", { class: "label" }, t("New QR", "새 QR"))),
    t("New QR", "새 QR"),
    [
      { label: t("Command / script", "명령·스크립트"), sub: t("A /command or STscript", "/명령이나 STscript"), run: () => add(newItem(t("New QR", "새 QR"), t("/echo Hello, {{user}}!", "/echo 안녕하세요, {{user}}!"))) },
      { label: "OOC", sub: t("Sends the written text as OOC", "적은 글을 OOC로 보내기"), run: () => add({ ...newItem(t("New OOC", "새 OOC"), "/ooc "), icon: "💬" }) },
      { label: t("Visualizer", "비주얼라이저"), sub: t("Makes an HTML page from a topic", "주제로 HTML 페이지 만들기"), run: () => add({ ...newItem(t("New page", "새 페이지"), t("/visz [[Topic of the page]]", "/visz [[만들 페이지의 주제]]")), icon: "🌟" }) },
    ],
    true,
  );
}

/** A QR's ⋯ menu: copy, cut, duplicate, move or copy to another set, export, delete. */
function itemMenu(ctx: ManagerContext, files: QrFiles, set: QrSet, item: QrItem): HTMLElement {
  return dropMenu(icon("more"), t(`${item.label} menu`, `${item.label} 메뉴`), [
    { label: t("Copy", "복사"), sub: t("Paste into another set or SillyTavern", "다른 세트나 실리태번에 붙여넣기 가능"), run: () => void files.copyItem(item, false, set) },
    { label: t("Cut", "잘라내기"), run: () => void files.copyItem(item, true, set) },
    {
      label: t("Duplicate", "복제"),
      sub: t("One more right below", "바로 아래에 하나 더"),
      run: () => {
        const copy = cloneItem(item);
        copy.label = t(`${item.label} copy`, `${item.label} 복사본`);
        ctx.mutateSet(set, (s) => s.items.splice(s.items.findIndex((i) => i.id === item.id) + 1, 0, copy));
        ctx.selectedItem = copy.id;
        ctx.render();
      },
    },
    { label: t("Move to another set…", "다른 세트로 옮기기…"), run: () => void transfer(ctx, set, item, false) },
    { label: t("Copy to another set…", "다른 세트로 복사…"), run: () => void transfer(ctx, set, item, true) },
    "-",
    { label: t("Export this QR: for Marinara", "이 QR만 내보내기: 마리나라용"), sub: ".mqr.json", run: () => files.exportItem(item, "marinara") },
    { label: t("Export this QR: for SillyTavern", "이 QR만 내보내기: 실리태번용"), sub: t(".json (first message = #0)", ".json (첫 메시지 = 0번)"), run: () => files.exportItem(item, "st") },
    "-",
    { label: t("Delete QR", "QR 삭제"), danger: true, run: () => ctx.removeItem(set, item) },
  ]);
}

async function transfer(ctx: ManagerContext, from: QrSet, item: QrItem, copy: boolean): Promise<void> {
  const { store, ui } = ctx.deps;
  const others = ctx.state.sets.filter((s) => s.id !== from.id);
  if (!others.length) {
    ui.toast(t("No other set to move it to. Make another set first.", "옮길 다른 세트가 없어요. 먼저 세트를 하나 더 만드세요."), "warning");
    return;
  }
  const labels = others.map((s, i) => `${s.name}${others.filter((o) => o.name === s.name).length > 1 ? ` (${i + 1})` : ""}`);
  const [picked] = (await ui.pick?.(t(`Pick a set to ${copy ? "copy" : "move"} "${item.label}" to.`, `"${item.label}"을 ${copy ? "복사할" : "옮길"} 세트를 고르세요.`), labels)) ?? [];
  const target = picked ? others[labels.indexOf(picked)] : undefined;
  if (!target) return;
  store.update((st) => {
    const to = st.sets.find((s) => s.id === target.id);
    const src = st.sets.find((s) => s.id === from.id);
    if (!to || !src) return;
    if (copy) to.items.push(cloneItem(item));
    else {
      src.items = src.items.filter((i) => i.id !== item.id);
      to.items.push(item);
    }
  });
  if (!copy) {
    ctx.selectedSet = target.id;
    ctx.selectedItem = item.id;
  }
  ctx.render();
  ui.toast(t(`${copy ? "Copied" : "Moved"} to the set "${target.name}".`, `"${target.name}" 세트로 ${copy ? "복사했어요" : "옮겼어요"}.`), "success");
}
