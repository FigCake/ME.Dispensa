// The Library's left column: the sets in SillyTavern's lists (every chat,
// this chat, each character of the chat, then every set made). A set dragged
// to another list moves there.

import { t } from "../../shared/i18n";
import { newSet } from "../../qr/model";
import { type SetZone, moveSet, zoneSets } from "../../qr/scopes";
import { el, icon } from "../dom";
import { dragAcross } from "../drag";
import { helpTip } from "../../shared/form";
import type { ManagerContext } from "./context";

/**
 * The set column. Dropping a set on a list adds it there; dropping it on
 * "All sets" takes it out of the list it came from (off where it was).
 */
export function setColumn(ctx: ManagerContext): HTMLElement {
  const { store } = ctx.deps;
  const st = store.value;
  const chat = ctx.scope.chatId;
  const lists: { zone: SetZone; title: string; empty: string }[] = [
    { zone: { kind: "global" }, title: t("Global", "전체"), empty: t("Drop sets here to auto-run them in every chat", "모든 채팅에서 자동 실행할 세트를 여기로") },
    ...(chat ? [{ zone: { kind: "chat", chatId: chat } as SetZone, title: t("This chat", "이 채팅"), empty: t("Drop sets here to auto-run them in this chat", "이 채팅에서 자동 실행할 세트를 여기로") }] : []),
    ...ctx.scope.characterIds.map((c) => ({ zone: { kind: "char", characterId: c } as SetZone, title: t(`Character: ${ctx.characterName(c)}`, `캐릭터: ${ctx.characterName(c)}`), empty: t("Drop sets here to auto-run them in chats with this character", "이 캐릭터와의 채팅에서 자동 실행할 세트를 여기로") })),
    { zone: { kind: "all" }, title: t("All sets", "모든 세트"), empty: t("None", "없음") },
  ];
  const zoneOf = new Map<HTMLElement, SetZone>();
  const body = el("div", { class: "zones" });
  lists.forEach(({ zone, title, empty }, z) => {
    const ids = zoneSets(st, zone);
    const box = el("div", { class: "zone", "data-zone": String(z), role: "list", "aria-label": zone.kind === "all" ? title : t(`${title} sets`, `${title} 세트`) });
    zoneOf.set(box, zone);
    for (const id of ids) {
      const s = st.sets.find((x) => x.id === id);
      if (!s) continue;
      const handle = el("button", { class: "drag", type: "button", title: t("Drag to reorder or move to another list (↑↓ keys to reorder)", "끌어서 순서 바꾸기·다른 칸으로 옮기기 (↑↓ 키로 순서)"), "aria-label": t(`Move ${s.name}`, `${s.name} 옮기기`), "data-key": `drag-set-${z}-${s.id}` }, icon("grip"));
      const row = el(
        "div",
        { class: "set-row", role: "listitem" },
        handle,
        el(
          "button",
          {
            class: `entry${s.id === ctx.selectedSet ? " sel" : ""}`,
            onclick: () => {
              ctx.selectedSet = s.id;
              ctx.selectedItem = null;
              ctx.render();
            },
          },
          s.icon?.trim() ? el("span", {}, s.icon.trim()) : icon("folder"),
          el("span", { class: "grow" }, s.name),
          el("span", { class: "meta" }, String(s.items.length)),
        ),
      );
      dragAcross(handle, row, ".set-row", ".zone", ".zones", (target, index) => {
        const to = zoneOf.get(target);
        if (to) store.update((x) => moveSet(x, s.id, zone, to, index));
      });
      box.append(row);
    }
    if (!ids.length) box.append(el("div", { class: "zone-empty" }, empty));
    body.append(el("div", { class: "zone-h" }, title, el("span", { class: "count" }, ids.length ? String(ids.length) : "")), box);
  });
  if (!st.sets.length) body.append(el("div", { class: "note" }, t("No sets yet.", "아직 세트가 없어요.")));
  return el(
    "div",
    { class: "col" },
    el(
      "div",
      { class: "col-h" },
      el("strong", {}, t("Sets", "세트")),
      helpTip(
        t(
          "Groups of QRs. The same as SillyTavern's set lists\n· Global · This chat · Character: where auto-run works\n· All sets: every set made. Drag one into a list above to add it; drag it out of a list to remove it\n· The Dock has its own tab",
          "QR 묶음. 실리태번의 세트 목록과 같음\n· 전체 · 이 채팅 · 캐릭터: 자동 실행이 도는 곳\n· 모든 세트: 만든 세트 전부. 위 칸으로 끌어 넣기, 위 칸에서 끌어 오면 빼기\n· Dock은 Dock 탭에서 따로",
        ),
        t("Sets", "세트"),
      ),
    ),
    el(
      "div",
      { class: "row", style: "margin:8px 0" },
      el(
        "button",
        {
          onclick: () => {
            const s = newSet(t("New set", "새 세트"));
            store.update((x) => x.sets.push(s));
            ctx.selectedSet = s.id;
            ctx.selectedItem = null;
          },
        },
        icon("plus"),
        t("New set", "새 세트"),
      ),
    ),
    body,
  );
}
