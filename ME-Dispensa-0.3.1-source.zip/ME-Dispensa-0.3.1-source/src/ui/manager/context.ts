// What the Dispensa window's views share: the window's dependencies, which
// set and QR are selected, and how to redraw. QrManager (index.ts) is the
// one implementation; each view gets it as `ctx`.

import type { MemoStore } from "../../memo/store";
import type { SetNames } from "../../qr/import";
import type { QrItem, QrSet, QrState } from "../../qr/model";
import type { ChatScope } from "../../qr/scopes";
import type { QrStore } from "../../qr/store";
import type { HostUI } from "../../stscript/host";
import type { Debugger } from "../../stscript/interpreter";
import type { CommandRegistry } from "../../stscript/registry";
import type { ViszStore } from "../../visz/store";

export interface ManagerDeps {
  store: QrStore;
  registry: CommandRegistry;
  ui: HostUI;
  run(set: QrSet, item: QrItem): void;
  /** Run from the editor (run / debug): the result comes back. */
  runInEditor(set: QrSet, item: QrItem, options: { signal: AbortSignal; debug?: Debugger }): Promise<{ pipe: string; aborted?: string }>;
  /** A character's name, for the "this character" switches. */
  characterName(id: string): Promise<string>;
  /** Marinara's AI connections (for the visz settings). */
  connections(): Promise<{ id: string; name: string }[]>;
  viszStore?: ViszStore;
  /** The memo pad and what its memos can do. */
  memo?: {
    store: MemoStore;
    sendOoc(text: string): Promise<boolean>;
    putInInput(text: string): void;
    makePage(text: string): Promise<boolean>;
  };
}

export type ManagerTab = "qr" | "dock" | "memo" | "visz";

export interface ManagerContext {
  readonly deps: ManagerDeps;
  readonly state: QrState;
  /** The chat on screen (its chat and character switches). */
  readonly scope: ChatScope;
  /** The window's shadow root while it is open. */
  readonly root: ShadowRoot | null;
  selectedSet: string | null;
  selectedItem: string | null;
  /** A character's name (`fallback` while it is unknown). */
  characterName(id: string, fallback?: string): string;
  readonly setName: SetNames;
  /** Bytes Dispensa's saved data takes (all stores: they share Marinara's limit). */
  storageUsed(): number;
  render(): void;
  open(tab?: ManagerTab): void;
  openItem(setId: string, itemId: string): void;
  close(): void;
  mutateSet(set: QrSet, fn: (s: QrSet, st: QrState) => void): void;
  /** Deletes a QR (and unselects it). */
  removeItem(set: QrSet, item: QrItem): void;
  mutateItem(set: QrSet, item: QrItem, fn: (i: QrItem) => void): void;
  /** A folded part that stays open through redraws. */
  fold(key: string, title: string, count: number, help: string | undefined, ...kids: (Node | null)[]): HTMLElement;
}
