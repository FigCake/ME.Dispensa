// The QR editor in the Library: icon, name and tooltip, the script box with
// its checks and run panel, the command list, the sub menu, auto-run and
// the footer switches. Script boxes and run panels live across redraws (the
// caret, suggestions, a paused debugger), kept here by QR id.

import { t } from "../../shared/i18n";
import { applyConversion, findUnsupported, foreignCommands } from "../../qr/import";
import { AUTO_TRIGGERS, type AutoTrigger, type QrItem, type QrSet } from "../../qr/model";
import type { CommandDef } from "../../stscript/registry";
import { el, icon } from "../dom";
import { helpTip, setting, toggle } from "../../shared/form";
import { RunPanel } from "../run-panel";
import { ScriptEditor } from "../script-editor";
import type { ManagerContext } from "./context";

const ORIGIN_BADGE = {
  st: () => el("span", { class: "badge", title: t("Command SillyTavern also has", "실리태번에도 있는 명령") }, t("SillyTavern", "실리태번")),
  dispensa: () => el("span", { class: "badge dispensa", title: t("Dispensa-only command (not in SillyTavern)", "Dispensa 전용 명령 (실리태번에 없음)") }, "Dispensa"),
  marinara: () => el("span", { class: "badge marinara", title: t("Marinara feature command (not in SillyTavern)", "마리나라 기능 명령 (실리태번에 없음)") }, t("Marinara", "마리나라")),
  extension: (from: string) => el("span", { class: "badge extension", title: t(`Added by the ${from} extension`, `${from} 확장이 추가한 명령`) }, from),
};

/** The editor's words for each auto-run trigger (shown in AUTO_TRIGGERS' order). */
const TRIGGER_LABELS = (): Record<AutoTrigger, { label: string; help?: string }> => ({
  startup: { label: t("When Marinara starts", "마리나라를 켤 때") },
  user: { label: t("After I send a message", "내 메시지를 보낸 뒤") },
  ai: { label: t("After an AI reply", "AI 답변 뒤") },
  chatChange: { label: t("When a chat opens", "채팅을 열 때") },
  newChat: { label: t("When a new chat is made", "새 채팅을 만들 때") },
  groupDraft: { label: t("On each character's turn in a group chat", "그룹 채팅에서 캐릭터 차례마다") },
  beforeGeneration: { label: t("Just before the AI replies", "AI가 답을 쓰기 직전"), help: t("The reply waits until it finishes (up to 1 min)", "끝날 때까지 답 생성 대기 (최대 1분)") },
});

const TRIGGERS = () => {
  const labels = TRIGGER_LABELS();
  return AUTO_TRIGGERS.map(({ key }) => ({ key, ...labels[key] }));
};

const HELP = () => ({
  submenu: t(
    "Other sets attached as a sub menu. Opens with a right-click on the Dock (long press on phones)\n· Chain: the picked QR takes this QR's result\n· %%parent%%: becomes this QR's name",
    "다른 세트를 하위 메뉴로 달기. Dock에서 오른쪽 클릭(휴대폰은 꾹 누르기)으로 열기\n· 이어서 실행: 이 QR의 결과를 고른 QR이 이어받음\n· %%parent%%: 이 QR 이름으로 바뀜",
  ),
  auto: t("Auto-runs at the chosen times. Only where the set is on", "고른 때에 자동 실행. 세트가 켜진 곳에서만"),
  automation: t("Runs when this lorebook entry (name or id) is used in a reply (SillyTavern's Automation ID)", "이 로어북 항목(이름이나 id)이 답변에 쓰이면 실행 (실리태번의 자동화 ID)"),
  preventAuto: t("Stops this QR from auto-running other QRs", "이 QR이 다른 QR을 자동 실행하는 것을 막음"),
  showLabel: t("Shows only the icon in folders and sub menus", "폴더·하위 메뉴에서 아이콘만 표시"),
});

export class ItemEditor {
  private readonly editors = new Map<string, ScriptEditor>();
  private readonly panels = new Map<string, RunPanel>();
  private readonly breakpoints = new Map<string, Set<number>>();
  private commandListOpen = false;
  private commandQuery = "";

  constructor(private readonly ctx: ManagerContext) {}

  /** Drop the script boxes and panels of QRs that are gone. */
  forgetGone(): void {
    const ids = new Set(this.ctx.state.sets.flatMap((s) => s.items.map((i) => i.id)));
    for (const map of [this.editors, this.panels, this.breakpoints] as Map<string, unknown>[]) for (const id of [...map.keys()]) if (!ids.has(id)) map.delete(id);
  }

  /** Open script boxes take a script changed elsewhere (the box ignores its own text). */
  syncScripts(): void {
    for (const [id, editor] of this.editors) {
      const item = this.ctx.state.sets.flatMap((s) => s.items).find((i) => i.id === id);
      if (item) editor.value = item.script;
    }
  }

  /** Stops every run started from the editor (the window closes). */
  stopAll(): void {
    for (const p of this.panels.values()) p.stop();
  }

  render(set: QrSet, item: QrItem): HTMLElement {
    const { registry, ui } = this.ctx.deps;
    const mutate = (fn: (i: QrItem) => void) => this.ctx.mutateItem(set, item, fn);
    const box = el("div", { class: "editor" });
    const panel = this.panelFor(set, item);
    box.append(
      this.basics(item, mutate),
      item.dialect === "st"
        ? el(
            "div",
            { class: "note-box" },
            el("div", { class: "warn" }, t("Runs SillyTavern style (first message = #0). Why it couldn't be converted to Marinara style automatically:", "실리태번 기준(첫 메시지 = 0번)으로 실행돼요. 마리나라 기준으로 자동 변환하지 못한 이유:")),
            el("ul", {}, ...(item.note ?? t("No reason was recorded", "이유가 기록되지 않았어요")).split("\n").map((r) => el("li", {}, r))),
            el(
              "div",
              { class: "row" },
              el(
                "button",
                {
                  onclick: () => {
                    let ok = false;
                    mutate((i) => (ok = applyConversion(i, registry)));
                    ui.toast(ok ? t("Converted to Marinara style.", "마리나라 기준으로 바꿨어요.") : t("Can't convert it automatically yet. Fix the reasons above and try again.", "아직 자동으로 바꿀 수 없어요. 위 이유를 고친 뒤 다시 눌러 주세요."), ok ? "success" : "warning");
                  },
                },
                t("Convert to Marinara style", "마리나라 기준으로 변환"),
              ),
              el(
                "button",
                {
                  title: t("Fixed the script by hand: mark it Marinara style (from #1)", "스크립트를 직접 고쳤으면 마리나라 기준(1번부터)으로 표시"),
                  onclick: () =>
                    mutate((i) => {
                      i.dialect = "marinara";
                      delete i.note;
                    }),
                },
                t("Fixed by hand (mark Marinara style)", "직접 고침 (마리나라 기준으로 표시)"),
              ),
            ),
          )
        : el("span"),
      el(
        "div",
        { class: "field-h" },
        t("Script", "스크립트"),
        helpTip(
          t(
            "STscript. Marinara commands and macros like {{char}} work too\n· Typing / or {{ shows a list\n· Ctrl+Enter runs, Tab indents\n· A clicked line number stops a debug run at that line",
            "STscript. 마리나라 명령과 {{char}} 같은 매크로도 가능\n· / 나 {{ 입력 시 목록\n· Ctrl+Enter 실행, Tab 들여쓰기\n· 줄 번호를 누르면 디버그 때 그 줄에서 멈춤",
          ),
          t("Script", "스크립트"),
        ),
      ),
      this.scriptBox(set, item).element,
      el("div", { "data-checks": item.id }, ...this.checks(item)),
      el("div", { "data-run": item.id }, panel.render()),
      this.commandList(),
      this.submenuPart(set, item),
      this.autoPart(set, item),
      this.footer(set, item, mutate),
    );
    return box;
  }

  private scriptBox(set: QrSet, item: QrItem): ScriptEditor {
    let editor = this.editors.get(item.id);
    if (!editor) {
      let checkTimer: ReturnType<typeof setTimeout> | null = null;
      editor = new ScriptEditor({
        value: item.script,
        key: "item-script",
        label: t("Script", "스크립트"),
        commands: () => this.ctx.deps.registry.list().map((d) => ({ name: d.name, help: d.help })),
        onChange: (value) => {
          this.ctx.mutateItem(set, item, (i) => (i.script = value));
          if (checkTimer) clearTimeout(checkTimer);
          checkTimer = setTimeout(() => this.recheck(set, item, value), 500);
        },
        onRun: () => void this.panelFor(set, item).start(false),
        onBreakpoints: (lines) => this.breakpoints.set(item.id, lines),
      });
      editor.setBreakpoints(this.breakpoints.get(item.id) ?? new Set());
      this.editors.set(item.id, editor);
    }
    editor.value = item.script;
    return editor;
  }

  /** Unknown commands after typing stops: only the warning lines change. */
  private recheck(set: QrSet, item: QrItem, script: string): void {
    const res = findUnsupported(script, this.ctx.deps.registry);
    this.ctx.mutateItem(set, item, (i) => (i.unsupported = Array.isArray(res) ? (res.length ? res : undefined) : [t("(syntax error)", "(문법 오류)")]));
    const slot = this.ctx.root?.querySelector(`[data-checks="${item.id}"]`);
    const fresh = this.ctx.state.sets.find((s) => s.id === set.id)?.items.find((i) => i.id === item.id);
    if (slot && fresh) slot.replaceChildren(...this.checks(fresh));
  }

  private checks(item: QrItem): Node[] {
    const out: Node[] = [];
    if (item.unsupported?.length) out.push(el("div", { class: "warn" }, `⚠ ${t("Not supported yet", "아직 지원하지 않는 명령")}: ${item.unsupported.map((c) => (c.startsWith("(") ? c : `/${c}`)).join(", ")}`));
    out.push(this.foreignLine(item.script));
    return out;
  }

  private panelFor(set: QrSet, item: QrItem): RunPanel {
    let panel = this.panels.get(item.id);
    if (!panel) {
      panel = new RunPanel({
        run: (signal, debug) => {
          const fresh = this.ctx.state.sets.find((s) => s.id === set.id);
          const now = fresh?.items.find((i) => i.id === item.id);
          if (!fresh || !now) throw new Error(t("Couldn't find the QR.", "QR을 찾지 못했어요."));
          return this.ctx.deps.runInEditor(fresh, now, { signal, debug });
        },
        editor: () => this.editors.get(item.id) ?? null,
        breakpoints: () => this.breakpoints.get(item.id) ?? new Set(),
        changed: () => {
          const slot = this.ctx.root?.querySelector(`[data-run="${item.id}"]`);
          if (slot) slot.replaceChildren(panel!.render());
        },
      });
      this.panels.set(item.id, panel);
    }
    return panel;
  }

  /** Icon, name, tooltip. */
  private basics(item: QrItem, mutate: (fn: (i: QrItem) => void) => void): HTMLElement {
    return el(
      "div",
      { class: "row" },
      el("label", {}, t("Icon", "아이콘"), el("input", { type: "text", value: item.icon ?? "", placeholder: item.kind === "ooc" ? "💬" : "", maxlength: "8", style: "width:3.2em;text-align:center", title: t("Dock bubble icon (empty: first letter of the name)", "Dock 버블 아이콘 (비우면 이름 첫 글자)"), "data-key": "item-icon", oninput: (e: Event) => mutate((i) => (i.icon = (e.target as HTMLInputElement).value.trim() || undefined)) })),
      el("label", { class: "grow" }, t("Name", "이름"), el("input", { type: "text", value: item.label, "data-key": "item-label", oninput: (e: Event) => mutate((i) => (i.label = (e.target as HTMLInputElement).value)) })),
      el("label", { class: "grow" }, el("span", { class: "field-h" }, t("Tooltip", "설명"), helpTip(t("Text shown on hover over the Dock bubble", "Dock 버블에 마우스를 올리면 보이는 글"), t("Tooltip", "설명"))), el("input", { type: "text", value: item.title ?? "", "data-key": "item-title", oninput: (e: Event) => mutate((i) => (i.title = (e.target as HTMLInputElement).value || undefined)) })),
    );
  }

  /** Hide, icon only, delete. */
  private footer(set: QrSet, item: QrItem, mutate: (fn: (i: QrItem) => void) => void): HTMLElement {
    return el(
      "div",
      {},
      el(
        "div",
        { class: "toggles" },
        setting(t("Hide from the Dock", "Dock에서 숨기기"), toggle(!!item.hidden, (v) => mutate((i) => (i.hidden = v)), t("Hide from the Dock", "Dock에서 숨기기"), "item-hidden"), t("Hidden in the set's Dock folder. Other QRs and auto-run can still use it", "Dock의 세트 폴더에서 숨김. 다른 QR·자동 실행으로는 사용 가능")),
        item.icon?.trim() ? setting(t("Icon only", "아이콘만 보이기"), toggle(item.showLabel === false, (v) => mutate((i) => (v ? (i.showLabel = false) : delete i.showLabel)), t("Icon only", "아이콘만 보이기"), "item-icon-only"), HELP().showLabel) : null,
      ),
      el("div", { class: "actions" }, el("button", { class: "danger", onclick: () => this.ctx.removeItem(set, item) }, icon("trash"), t("Delete QR", "QR 삭제"))),
    );
  }

  private submenuPart(set: QrSet, item: QrItem): HTMLElement {
    const mutate = (fn: (i: QrItem) => void) => this.ctx.mutateItem(set, item, fn);
    const state = this.ctx.state;
    const links = item.contextList ?? [];
    const rows = el("div", { class: "links" });
    links.forEach((link, index) => {
      const target = state.sets.find((s) => s.id === link.setId);
      if (!target) return;
      rows.append(
        el(
          "div",
          { class: "link" },
          el("span", { class: "grow" }, `${target.icon?.trim() ?? "📁"} ${target.name}`, el("span", { class: "note" }, t(` · ${target.items.length} QRs`, ` · QR ${target.items.length}개`))),
          el(
            "label",
            { class: "inline" },
            toggle(!!link.chained, (v) => mutate((i) => i.contextList && (i.contextList[index] = v ? { ...link, chained: true } : { setId: link.setId })), t("Chain", "이어서 실행"), `link-chain-${index}`),
            t("Chain", "이어서 실행"),
          ),
          el(
            "button",
            {
              class: "icon",
              title: t("Remove from the sub menu", "하위 메뉴에서 빼기"),
              "aria-label": t(`Remove ${target.name}`, `${target.name} 빼기`),
              onclick: () =>
                mutate((i) => {
                  i.contextList = (i.contextList ?? []).filter((_, n) => n !== index);
                  if (!i.contextList.length) delete i.contextList;
                }),
            },
            icon("x"),
          ),
        ),
      );
    });
    const choices = state.sets.filter((s) => !links.some((l) => l.setId === s.id));
    const add = el(
      "select",
      {
        "aria-label": t("Set to attach as a sub menu", "하위 메뉴로 달 세트"),
        "data-key": "link-add",
        onchange: (e: Event) => {
          const id = (e.target as HTMLSelectElement).value;
          if (id) mutate((i) => (i.contextList = [...(i.contextList ?? []), { setId: id }]));
        },
      },
      el("option", { value: "" }, t("+ Attach a set…", "+ 세트 달기…")),
      ...choices.map((s) => el("option", { value: s.id }, s.id === set.id ? t(`${s.name} (this set: only hidden QRs with an icon)`, `${s.name} (이 세트: 숨긴 QR 중 아이콘 있는 것만)`) : s.name)),
    );
    return this.ctx.fold(`submenu-${item.id}`, t("Sub menu", "하위 메뉴"), links.length, HELP().submenu, rows, choices.length ? add : el("div", { class: "note" }, t("No sets to attach", "달 수 있는 세트 없음")));
  }

  private autoPart(set: QrSet, item: QrItem): HTMLElement {
    const mutate = (fn: (i: QrItem) => void) => this.ctx.mutateItem(set, item, fn);
    const on = TRIGGERS().filter((tr) => item.auto?.[tr.key]).length + (item.automationId ? 1 : 0);
    return this.ctx.fold(
      `auto-${item.id}`,
      t("Auto-run", "자동 실행"),
      on,
      HELP().auto,
      el(
        "div",
        { class: "toggles" },
        ...TRIGGERS().map((tr) =>
          setting(
            tr.label,
            toggle(
              !!item.auto?.[tr.key],
              (v) =>
                mutate((i) => {
                  const auto = { ...i.auto };
                  if (v) auto[tr.key] = true;
                  else delete auto[tr.key];
                  i.auto = Object.keys(auto).length ? auto : undefined;
                }),
              tr.label,
              `auto-${tr.key}`,
            ),
            tr.help,
          ),
        ),
      ),
      setting(
        t("When a lorebook entry is used", "로어북 항목이 쓰일 때"),
        el("input", { type: "text", value: item.automationId ?? "", placeholder: t("Entry name", "항목 이름"), "data-key": "item-automation", "aria-label": t("Lorebook entry name", "로어북 항목 이름"), oninput: (e: Event) => mutate((i) => ((e.target as HTMLInputElement).value.trim() ? (i.automationId = (e.target as HTMLInputElement).value) : delete i.automationId)) }),
        HELP().automation,
      ),
      setting(t("Block auto-run chains", "자동 실행 연쇄 막기"), toggle(item.preventAuto !== false, (v) => mutate((i) => (v ? delete i.preventAuto : (i.preventAuto = false))), t("Block auto-run chains", "자동 실행 연쇄 막기"), "item-prevent"), HELP().preventAuto),
    );
  }

  private foreignLine(script: string): HTMLElement {
    const { registry } = this.ctx.deps;
    const found = foreignCommands(script, registry);
    if (!found.length) return el("span");
    return el(
      "div",
      { class: "foreign", title: t("Commands that don't work in SillyTavern. Exporting for SillyTavern warns about them", "실리태번에서 동작하지 않는 명령. 실리태번용으로 내보낼 때 알림") },
      t("Not in SillyTavern:", "실리태번에 없는 명령:"),
      ...found.map((name) => el("span", { class: `badge ${registry.get(name)?.origin ?? ""}` }, `/${name}`)),
    );
  }

  /** Searchable list of every command; clicking one puts it into the script at the caret. */
  private commandList(): HTMLElement {
    const all = this.ctx.deps.registry.list();
    const q = this.commandQuery.trim().toLowerCase();
    const shown = q ? all.filter((d) => d.name.includes(q) || (d.aliases ?? []).some((a) => a.includes(q)) || d.help.toLowerCase().includes(q)) : all;
    const details = el(
      "details",
      { class: "cmds", ontoggle: () => (this.commandListOpen = details.open) },
      el(
        "summary",
        {
          // remember right away: the toggle event comes later, and a redraw in between would lose it
          onclick: () => (this.commandListOpen = !details.open),
        },
        t(`Commands (${all.length}) · `, `명령 목록 (${all.length}개) · `),
        ORIGIN_BADGE.st(),
        " ",
        ORIGIN_BADGE.dispensa(),
        " ",
        ORIGIN_BADGE.marinara(),
      ),
      el("input", {
        type: "text",
        placeholder: t("Find a command (name or description)", "명령 찾기 (이름이나 설명)"),
        value: this.commandQuery,
        "data-key": "command-search",
        oninput: (e: Event) => {
          this.commandQuery = (e.target as HTMLInputElement).value;
          this.ctx.render();
        },
      }),
      el("div", { class: "cmd-list" }, ...shown.map((d) => this.commandRow(d))),
    );
    details.open = this.commandListOpen;
    return details;
  }

  private commandRow(def: CommandDef): HTMLElement {
    const badge =
      def.origin === "dispensa" ? ORIGIN_BADGE.dispensa()
      : def.origin === "marinara" ? ORIGIN_BADGE.marinara()
      : def.origin === "extension" ? ORIGIN_BADGE.extension(def.from ?? "")
      : ORIGIN_BADGE.st();
    return el(
      "button",
      {
        class: "cmd",
        title: def.aliases?.length ? t(`Aliases: /${def.aliases.join(", /")}`, `다른 이름: /${def.aliases.join(", /")}`) : "",
        onclick: () => {
          const ta = this.ctx.root?.querySelector<HTMLTextAreaElement>('textarea[data-key="item-script"]');
          if (!ta) return;
          const start = ta.selectionStart ?? ta.value.length;
          const end = ta.selectionEnd ?? start;
          const before = ta.value.slice(0, start);
          const insert = `${before && !/[\s|]$/.test(before) ? " | " : ""}/${def.name} `;
          ta.value = before + insert + ta.value.slice(end);
          ta.dispatchEvent(new Event("input"));
          const caret = start + insert.length;
          ta.focus();
          ta.setSelectionRange(caret, caret);
        },
      },
      el("code", {}, `/${def.name}`),
      badge,
      el("span", { class: "help" }, def.help),
    );
  }
}
