// The visz tab of the Dispensa window: page defaults and the Superviz chunks.
// (The Visualizer set's QRs live in the Library tab; how OOC is sent and its wrappers show
// in the memo tab.)

import type { HostUI } from "../stscript/host";
import type { PresetChunk } from "../visz/core";
import { OOC_MODES, type OocMode, VISZ_OUTPUTS, type ViszOutput, type ViszItem, type ViszSettings, type ViszState, defaultPreset, newViszId, normalizeViszState } from "../visz/model";
import { SUPERVIZ } from "../visz/superviz";
import type { ViszStore } from "../visz/store";
import { el, icon } from "./dom";
import { downloadJson } from "./files";
import { helpTip, section, setting, toggle } from "../shared/form";
import { t } from "../shared/i18n";

export const VISZ_SETTINGS_CSS = `
.cards { display: flex; flex-direction: column; gap: 12px; }
.cards .card { border: 1px solid var(--d-line); border-radius: var(--d-radius); padding: 12px 14px; display: flex; flex-direction: column; gap: 6px; }
.cards .chunk { border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); padding: 6px 8px; display: flex; flex-direction: column; gap: 6px; transition: opacity .15s ease; }
.cards .chunk.off { opacity: .55; }
.cards textarea.short { min-height: 90px; }
.cards .icon-input { width: 3.4em !important; min-width: 0 !important; text-align: center; }
.cards details.more > summary { cursor: pointer; color: var(--d-muted); font-size: 12px; padding: 4px 0; list-style: none; display: flex; align-items: center; gap: 6px; }
.cards details.more > summary::before { content: "▸"; transition: transform .15s ease; }
.cards details.more[open] > summary::before { transform: rotate(90deg); }
.cards .field-h { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--d-muted); }
`;

type Connection = { id: string; name: string };

export interface ViszSettingsDeps {
  store: ViszStore;
  ui: HostUI;
  connections(): Promise<Connection[]>;
  rerender(): void;
  /** Adds the topics of an old backup's items (to the memo pad). */
  importItems(items: ViszItem[]): void;
}

function select<T extends string>(key: string, entries: [T, string][], value: string, onChange: (v: T) => void, label = ""): HTMLSelectElement {
  return el(
    "select",
    { "data-key": key, "aria-label": label || undefined, onchange: (e: Event) => onChange((e.target as HTMLSelectElement).value as T) },
    ...entries.map(([v, text]) => el("option", { value: v, selected: v === value }, text)),
  );
}

const MODE_LABEL = (): Record<PresetChunk["mode"], string> => ({ all: t("Always", "항상"), full: t("Full only", "풀 모드만"), lite: t("Light only", "라이트 모드만") });
const VISZ_MODES = (): [ViszSettings["viszMode"], string][] => [
  ["auto", t("Auto", "자동")],
  ["full", t("Full (with scripts)", "풀 (스크립트 포함)")],
  ["lite", t("Light (HTML·CSS)", "라이트 (HTML·CSS)")],
];

/** English names of the shipped Superviz chunks (and the preset), by id. */
const CHUNK_NAMES_EN: Record<string, string> = {
  superviz: "Superviz (default)",
  role: "Role · mission",
  content: "Content rules (topic · format mimicry · RP)",
  interaction: "Interaction patterns (modals · event delegation · drag)",
  tech: "Tech base (CSS reset · gameState · updateUI)",
  fornello: "Fornello commands (DM · memory · story link)",
  "lite-rules": "Light mode tech rules (HTML·CSS only)",
  "img-emoji": "Images: emoji · SVG drawings",
  "output-full": "Output format (full HTML document, one html code block)",
};
const SHIPPED_NAMES = new Map([[SUPERVIZ.id, SUPERVIZ.name], ...SUPERVIZ.chunks.map((c): [string, string] => [c.id, c.name])]);

/** A chunk's (or the preset's) name to show: the English name while it still has its shipped name; a renamed one keeps its own. */
function shownName(x: { id: string; name: string }): string {
  const en = CHUNK_NAMES_EN[x.id];
  return en && SHIPPED_NAMES.get(x.id) === x.name ? t(en, x.name) : x.name;
}

// Shown behind the small ? buttons: for someone seeing the setting for the first time
/** Getters: read in the screen language when shown. */
export const VISZ_HELP = {
  get viszMode() {
    return t("Kind of page to make\n· Auto: Full with Fornello, Light without\n· Full: pages with working buttons and animations (needs Fornello)\n· Light: pages with HTML and CSS only", "만들 페이지 종류\n· 자동: Fornello가 있으면 풀, 없으면 라이트\n· 풀: 버튼·애니메이션이 움직이는 페이지 (Fornello 필요)\n· 라이트: HTML·CSS만 쓴 페이지");
  },
  get viszOutput() {
    return t("Where the page shows\n· Viewer: a small window above the Dock. Can post to the chat\n· Chat: straight in as a character message", "만든 페이지를 보여 줄 곳\n· 보기 창: Dock 위 작은 창. 채팅에 넣기 가능\n· 채팅: 바로 캐릭터 메시지로");
  },
  get language() {
    return t("Language of the page text. E.g. Korean, English", "페이지 글의 언어. 예: Korean, English");
  },
  get autoArchive() {
    return t("Also collects pages posted to the chat in the Gallery. The Gallery is kept in this browser only", "채팅에 올린 페이지도 갤러리에 모으기. 갤러리는 이 브라우저에만 저장");
  },
  get external() {
    return t("Lets viewer pages load fonts, images and libraries from the internet", "보기 창 페이지가 인터넷의 글꼴·그림·라이브러리를 불러오도록 허용");
  },
  get oocMode() {
    return t("How 💬 OOC is sent\n· Get the result: the AI writes what you asked for as a character message. For out-of-RP results like community reactions or mini games\n· Steer the next reply: the next reply goes the way you asked (Marinara /guided)\n· Send as me: sends the request as your message\n· Put in the input: only puts it in the input. Edit, then send\nWith the first two, the request does not stay in the chat", "💬 OOC 보내는 방식\n· 결과물 받기: AI가 요청대로 만든 글을 캐릭터 메시지로. 커뮤니티 반응·미니 게임 같은 RP 밖 결과물용\n· 전개에 반영하기: 다음 답이 요청한 방향으로 진행 (마리나라 /guided)\n· 직접 보내기: 요청 글을 내 메시지로 전송\n· 입력창에 넣기: 입력창에만 넣기. 고쳐서 직접 전송\n앞의 둘은 요청 글이 채팅에 남지 않음");
  },
  get wrapper() {
    return t("Text put around the OOC. Edit it under 'Wrappers' below", "OOC 앞뒤에 붙일 문구. 아래 '감싸개'에서 편집");
  },
  get connection() {
    return t("AI connection used to make pages. For a model other than the chat's", "만들 때 쓸 AI 연결. 채팅과 다른 모델을 쓸 때");
  },
  get bubble() {
    return t("Shows the Visualizer menu bubble on the Dock. Change its icon (an emoji) in the box next to it", "Dock에 비주얼라이저 메뉴 버블 표시. 옆 칸에서 아이콘(이모지) 변경");
  },
  get preset() {
    return t("Instructions sent to the AI when making a page. Turn each chunk on or off, or edit it", "페이지를 만들 때 AI에게 보내는 지침. 조각마다 켜기·끄기·편집");
  },
  get wrap() {
    return t("Sends the whole prompt wrapped in <System> … </System>. Usually on", "지침 전체를 <System> … </System>으로 감싸 보내기. 보통 켜 둠");
  },
  get chunkText() {
    return t("{{주제}} becomes the request, {{언어}} the result language", "{{주제}} 자리에 요청, {{언어}} 자리에 결과 언어");
  },
  get chunkMode() {
    return t("When this chunk is included. Full only / Light only: just in that mode", "이 조각을 넣을 때. 풀 모드만 / 라이트 모드만은 그 모드에서만");
  },
  get wrappers() {
    return t("Text put around OOC when it is sent. {{내용}} becomes the OOC, {{언어}} the result language", "OOC를 보낼 때 앞뒤에 붙이는 문구. {{내용}} 자리에 OOC, {{언어}} 자리에 결과 언어");
  },
  get backup() {
    return t("Saves or restores the prompt, wrappers and defaults as one file", "본체·감싸개·기본값을 파일 하나로 저장·복원");
  },
};

export class ViszSettingsView {
  private openChunk: string | null = null;
  private connections: Connection[] | null = null;

  constructor(private readonly deps: ViszSettingsDeps) {}

  private get state(): ViszState {
    return this.deps.store.value;
  }

  private update(fn: (s: ViszState) => void): void {
    this.deps.store.update(fn);
  }

  /** The AI connections to choose from ("" = `inherit`); loaded once, then redrawn. */
  connectionEntries(inherit: string): [string, string][] {
    if (!this.connections) {
      this.connections = [];
      void this.deps
        .connections()
        .then((list) => {
          this.connections = list;
          this.deps.rerender();
        })
        .catch(() => undefined);
    }
    return [["", inherit], ...this.connections.map((c): [string, string] => [c.id, c.name])];
  }

  render(): HTMLElement {
    return el("div", { class: "col cards" }, this.defaults(), this.presetCard(), this.backup());
  }

  /** How the memo pad sends OOC (its tab shows these): the way and the wrappers. */
  oocCards(): HTMLElement[] {
    const s = this.state.settings;
    const set = (fn: (st: ViszState["settings"]) => void) => this.update((st) => fn(st.settings));
    const wrappers = this.state.wrappers.map((w): [string, string] => [w.id, w.name]);
    return [
      el(
        "div",
        { class: "card" },
        section(
          t("💬 Send OOC", "💬 OOC 보내기"),
          undefined,
          [],
          setting(t("How to send", "보내는 방식"), select("visz-ooc-mode", Object.entries(OOC_MODES) as [OocMode, string][], s.oocMode, (v) => set((x) => (x.oocMode = v)), t("How to send", "보내는 방식")), VISZ_HELP.oocMode),
          setting(t("Wrapper", "감싸개"), select("visz-wrapper", wrappers, s.wrapperId, (v) => set((x) => (x.wrapperId = v)), t("Wrapper", "감싸개")), VISZ_HELP.wrapper),
        ),
      ),
      this.wrapperCard(),
    ];
  }

  private defaults(): HTMLElement {
    const s = this.state.settings;
    const set = (fn: (st: ViszState["settings"]) => void) => this.update((st) => fn(st.settings));
    return el(
      "div",
      { class: "card" },
      section(
        t("🌟 Make page", "🌟 페이지 만들기"),
        undefined,
        [],
        setting(t("Mode", "모드"), select("visz-mode", VISZ_MODES(), s.viszMode, (v) => set((x) => (x.viszMode = v)), t("Mode", "모드")), VISZ_HELP.viszMode),
        setting(t("Show result in", "결과를 보여 줄 곳"), select("visz-output", Object.entries(VISZ_OUTPUTS) as [ViszOutput, string][], s.viszOutput, (v) => set((x) => (x.viszOutput = v)), t("Show result in", "결과를 보여 줄 곳")), VISZ_HELP.viszOutput),
        setting(t("Result language", "결과 언어"), el("input", { type: "text", value: s.language, "data-key": "visz-language", "aria-label": t("Result language", "결과 언어"), oninput: (e: Event) => set((x) => (x.language = (e.target as HTMLInputElement).value)) }), VISZ_HELP.language),
        setting(t("Chat pages to Gallery too", "채팅에 올린 페이지도 갤러리에"), toggle(s.autoArchive, (v) => set((x) => (x.autoArchive = v)), t("Chat pages to Gallery too", "채팅에 올린 페이지도 갤러리에"), "visz-auto-archive"), VISZ_HELP.autoArchive),
        setting(t("Allow outside resources", "바깥 자료 불러오기 허용"), toggle(s.allowExternal, (v) => set((x) => (x.allowExternal = v)), t("Allow outside resources", "바깥 자료 불러오기 허용"), "visz-external"), VISZ_HELP.external),
      ),
      section(
        t("General", "공통"),
        undefined,
        [],
        setting(t("AI connection", "AI 연결"), select("visz-connection", this.connectionEntries(t("Same as the chat", "채팅과 같은 연결")), s.connectionId, (v) => set((x) => (x.connectionId = v)), t("AI connection", "AI 연결")), VISZ_HELP.connection),
        setting(
          t("Dock bubble", "Dock 버블"),
          [
            el("input", { type: "text", class: "icon-input", value: s.dockIcon, "data-key": "visz-dock-icon", maxlength: "8", "aria-label": t("Bubble icon", "버블 아이콘"), oninput: (e: Event) => set((x) => (x.dockIcon = (e.target as HTMLInputElement).value.trim() || "🍰")) }),
            toggle(s.showButton, (v) => set((x) => (x.showButton = v)), t("Show Dock bubble", "Dock 버블 보이기"), "visz-show"),
          ],
          VISZ_HELP.bubble,
        ),
      ),
    );
  }

  private presetCard(): HTMLElement {
    const preset = this.state.preset;
    const mutateChunk = (id: string, fn: (c: PresetChunk) => void) =>
      this.update((s) => {
        const c = s.preset.chunks.find((x) => x.id === id);
        if (c) fn(c);
      });
    const modeLabel = MODE_LABEL();
    const chunks = preset.chunks.map((chunk, index) => {
      const open = this.openChunk === chunk.id;
      const name = shownName(chunk);
      const box = el(
        "div",
        { class: `chunk${chunk.enabled ? "" : " off"}` },
        el(
          "div",
          { class: "row" },
          toggle(chunk.enabled, (v) => mutateChunk(chunk.id, (c) => (c.enabled = v)), t(`Turn on ${name}`, `${name} 켜기`)),
          el(
            "button",
            {
              class: "entry grow",
              "aria-expanded": String(open),
              onclick: () => {
                this.openChunk = open ? null : chunk.id;
                this.deps.rerender();
              },
            },
            name,
            el("span", { class: "meta" }, modeLabel[chunk.mode] + (chunk.needs === "fornello" ? t(" · with Fornello", " · Fornello 있을 때") : "")),
          ),
          el("button", { class: "icon", title: t("Move up", "위로"), "aria-label": t("Move up", "위로"), disabled: index === 0, onclick: () => this.moveChunk(index, -1) }, icon("arrow-up")),
          el("button", { class: "icon", title: t("Move down", "아래로"), "aria-label": t("Move down", "아래로"), disabled: index === preset.chunks.length - 1, onclick: () => this.moveChunk(index, 1) }, icon("arrow-down")),
        ),
      );
      if (open) {
        const ta = el("textarea", { "data-key": `chunk-${chunk.id}`, spellcheck: "false", "aria-label": t(`${name} text`, `${name} 내용`), oninput: (e: Event) => mutateChunk(chunk.id, (c) => (c.text = (e.target as HTMLTextAreaElement).value)) });
        ta.value = chunk.text;
        box.append(
          el(
            "div",
            { class: "row" },
            el("label", { class: "grow" }, t("Name", "이름"), el("input", { type: "text", value: name, "data-key": `chunk-name-${chunk.id}`, oninput: (e: Event) => mutateChunk(chunk.id, (c) => (c.name = (e.target as HTMLInputElement).value)) })),
            el(
              "label",
              {},
              el("span", { class: "field-h" }, t("Used when", "쓰는 때"), helpTip(VISZ_HELP.chunkMode, t("Used when", "쓰는 때"))),
              select(`chunk-mode-${chunk.id}`, Object.entries(modeLabel) as [PresetChunk["mode"], string][], chunk.mode, (v) => mutateChunk(chunk.id, (c) => (c.mode = v)), t("Used when", "쓰는 때")),
            ),
          ),
          el("div", { class: "field-h" }, t("Text", "내용"), helpTip(VISZ_HELP.chunkText, t("Text", "내용"))),
          ta,
          el(
            "div",
            { class: "row" },
            el("span", { class: "grow" }),
            el("button", { class: "danger", onclick: () => this.update((s) => (s.preset.chunks = s.preset.chunks.filter((c) => c.id !== chunk.id))) }, icon("trash"), t("Delete chunk", "조각 지우기")),
          ),
        );
      }
      return box;
    });
    const add = el(
      "button",
      {
        onclick: () => {
          const chunk: PresetChunk = { id: newViszId("chunk"), name: t("New chunk", "새 조각"), mode: "all", enabled: true, text: "" };
          this.update((s) => s.preset.chunks.push(chunk));
          this.openChunk = chunk.id;
        },
      },
      icon("plus"),
      t("Add chunk", "조각 추가"),
    );
    const reset = el(
      "button",
      {
        title: t("Back to the original Superviz text", "슈퍼비즈 원래 문구로 되돌리기"),
        onclick: async () => {
          if (!(await this.deps.ui.popup(t("Reset the prompt to the Superviz defaults? Your edits and added chunks will be lost.", "본체를 슈퍼비즈 기본값으로 되돌릴까요? 고친 내용과 추가한 조각이 사라져요."), { okButton: t("Reset", "되돌리기"), cancelButton: t("Cancel", "취소") }))) return;
          this.openChunk = null;
          this.update((s) => (s.preset = defaultPreset()));
        },
      },
      icon("refresh-cw"),
      t("Reset", "기본값으로"),
    );
    return el(
      "div",
      { class: "card" },
      section(
        t(`🌟 Prompt: ${shownName(preset)}`, `🌟 본체: ${preset.name}`),
        VISZ_HELP.preset,
        [add, reset],
        setting(t("Wrap in <System>", "<System>으로 감싸기"), toggle(preset.wrap, (v) => this.update((s) => (s.preset.wrap = v)), t("Wrap in <System>", "<System>으로 감싸기")), VISZ_HELP.wrap),
        ...chunks,
      ),
    );
  }

  private moveChunk(index: number, delta: number): void {
    this.update((s) => {
      const [c] = s.preset.chunks.splice(index, 1);
      s.preset.chunks.splice(index + delta, 0, c);
    });
  }

  private wrapperCard(): HTMLElement {
    const wrappers = this.state.wrappers;
    const add = el("button", { onclick: () => this.update((s) => s.wrappers.push({ id: newViszId("wrap"), name: t("New wrapper", "새 감싸개"), template: "{{내용}}" })) }, icon("plus"), t("Add", "추가"));
    return el(
      "div",
      { class: "card" },
      section(
        t("💬 Wrappers", "💬 감싸개"),
        VISZ_HELP.wrappers,
        [add],
        ...wrappers.map((w) => {
          const ta = el("textarea", {
            class: "short",
            "data-key": `wrap-${w.id}`,
            spellcheck: "false",
            "aria-label": t(`${w.name} text`, `${w.name} 문구`),
            oninput: (e: Event) => this.update((s) => (s.wrappers.find((x) => x.id === w.id)!.template = (e.target as HTMLTextAreaElement).value)),
          });
          ta.value = w.template;
          return el(
            "div",
            { class: "chunk" },
            el(
              "div",
              { class: "row" },
              el("input", { type: "text", class: "grow", value: w.name, "data-key": `wrap-name-${w.id}`, "aria-label": t("Wrapper name", "감싸개 이름"), oninput: (e: Event) => this.update((s) => (s.wrappers.find((x) => x.id === w.id)!.name = (e.target as HTMLInputElement).value)) }),
              el("button", { class: "icon danger", title: t("Delete", "지우기"), "aria-label": t("Delete", "지우기"), disabled: wrappers.length <= 1, onclick: () => this.update((s) => (s.wrappers = s.wrappers.filter((x) => x.id !== w.id))) }, icon("trash")),
            ),
            ta,
          );
        }),
      ),
    );
  }

  private backup(): HTMLElement {
    return el(
      "div",
      { class: "card" },
      section(
        t("Backup", "백업"),
        VISZ_HELP.backup,
        [el("button", { onclick: () => this.exportJson() }, icon("upload"), t("Export", "내보내기")), el("button", { onclick: () => this.importJson() }, icon("download"), t("Import", "가져오기"))],
      ),
    );
  }

  private exportJson(): void {
    // the backup keeps its older name and format, so files move between builds
    downloadJson({ format: "dispensa-wand", ...this.state }, "dispensa.wand.json");
  }

  private importJson(): void {
    const input = el("input", { type: "file", accept: ".json,application/json" });
    input.addEventListener("change", async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const json = JSON.parse(await file.text()) as Record<string, unknown>;
        if (json.format !== "dispensa-wand") throw new Error(t("Not a Dispensa Visualizer file (.wand.json).", "Dispensa 비주얼라이저 파일(.wand.json)이 아니에요."));
        const incoming = normalizeViszState(json);
        // files from before the items moved: their topics go to the memo pad
        const items = Array.isArray(json.items) && json.itemsMoved !== true ? incoming.items : [];
        const extra = items.length ? t(` ${items.length} topics go to the Memo pad.`, ` 주제 ${items.length}개는 메모장에 들어가요.`) : "";
        if (!(await this.deps.ui.popup(t(`Replace the prompt, wrappers and defaults with this file?${extra}`, `본체·감싸개·기본값을 이 파일로 바꿀까요?${extra}`), { okButton: t("Replace", "바꾸기"), cancelButton: t("Cancel", "취소") }))) return;
        this.update((s) => Object.assign(s, incoming, { items: [], itemsMoved: true }));
        if (items.length) this.deps.importItems(items);
        this.deps.ui.toast(t("Imported the Visualizer settings.", "비주얼라이저 설정을 가져왔어요."), "success");
      } catch (e) {
        this.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("Import", "가져오기") });
      }
    });
    input.click();
  }
}
