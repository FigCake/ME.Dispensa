// This extension's name, for what the shared files (src/shared/) need to tell
// the two extensions apart.

export const EXTENSION = { name: "Dispensa", id: "dispensa" } as const;
