import { start } from "./main";

void start().catch((e) => {
  console.error("[Dispensa] failed to start", e);
});
