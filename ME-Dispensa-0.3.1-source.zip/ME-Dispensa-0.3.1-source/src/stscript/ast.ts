// AST produced by the STscript parser. Values stay raw (macros unresolved)
// until the interpreter runs the command that owns them.

export interface ParserFlags {
  STRICT_ESCAPING: boolean;
  REPLACE_GETVAR: boolean;
}

export const defaultParserFlags = (): ParserFlags => ({
  STRICT_ESCAPING: false,
  REPLACE_GETVAR: false,
});

export type ArgValue = string | Closure;

export interface NamedArg {
  name: string;
  value: ArgValue;
}

export interface UnnamedArg {
  value: ArgValue;
  quoted: boolean;
}

export interface CommandNode {
  kind: "command";
  name: string;
  named: NamedArg[];
  unnamed: UnnamedArg[];
  /** False when the previous command ended with `||`. */
  injectPipe: boolean;
  flags: ParserFlags;
  start: number;
  end: number;
}

export interface BreakNode {
  kind: "break";
  unnamed: UnnamedArg[];
  start: number;
  end: number;
}

export type Executor = CommandNode | BreakNode;

export interface Closure {
  kind: "closure";
  /** Declared arguments with default values: `{: a=1 b= ... :}` */
  args: NamedArg[];
  executors: Executor[];
  /** `{: ... :}()` */
  executeNow: boolean;
  raw: string;
}

export interface CommandSpec {
  /** Split the unnamed argument on whitespace (respecting quotes and closures). */
  split?: boolean;
  /** After this many split parts, the rest stays one value. */
  splitCount?: number;
  /** Keep quotes in the unnamed argument verbatim. */
  rawQuotes?: boolean;
}

export type CommandLookup = (name: string) => CommandSpec | undefined;

export class ParseError extends Error {
  constructor(
    message: string,
    readonly index: number,
  ) {
    super(message);
    this.name = "ParseError";
  }
}
