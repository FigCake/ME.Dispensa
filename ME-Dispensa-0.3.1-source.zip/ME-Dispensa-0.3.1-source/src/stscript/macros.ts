// Global (non-scoped) macro pass. Handles SillyTavern's variable macros and
// the context macros STscript relies on. Anything left unresolved is handed
// to the host, which can ask Marinara to resolve its own macros
// ({{#if}}, {{persona}}, {{description}}, ...). Unknown macros stay as text.

import { type VariableStore, addVar, readVar, writeVar } from "./variables";

export interface MacroContext {
  local: VariableStore;
  global: VariableStore;
  /** Synchronous snapshot of chat facts, refreshed by the host before each command. */
  facts: () => MacroFacts;
  /** Resolve leftover Marinara macros. Called only when `{{` remains. */
  resolveHostMacros?: (text: string) => Promise<string>;
}

export interface MacroFacts {
  user: string;
  char: string;
  group: string;
  input: string;
  lastMessage: string;
  lastMessageId: string;
  lastCharMessage: string;
  lastUserMessage: string;
  model: string;
  idleDuration: string;
}

export interface SubstituteOptions {
  /** REPLACE_GETVAR: variable values are inserted last and never re-scanned. */
  replaceGetvar?: boolean;
  /** Ask the host to resolve leftovers. Off for internal plumbing. */
  hostMacros?: boolean;
}

type Replacer = (match: string, ...groups: string[]) => string;

const pad = (n: number) => String(n).padStart(2, "0");

function variableReplacers(ctx: MacroContext, includeGetters: boolean): [RegExp, Replacer][] {
  const { local, global } = ctx;
  const list: [RegExp, Replacer][] = [
    [/\{\{setvar::([^:]+)::([^}]*)\}\}/gi, (_, n, v) => (writeVar(local, n.trim(), v), "")],
    [/\{\{addvar::([^:]+)::([^}]+)\}\}/gi, (_, n, v) => (addVar(local, n.trim(), v), "")],
    [/\{\{incvar::([^}]+)\}\}/gi, (_, n) => String(addVar(local, n.trim(), 1))],
    [/\{\{decvar::([^}]+)\}\}/gi, (_, n) => String(addVar(local, n.trim(), -1))],
    [/\{\{setglobalvar::([^:]+)::([^}]*)\}\}/gi, (_, n, v) => (writeVar(global, n.trim(), v), "")],
    [/\{\{addglobalvar::([^:]+)::([^}]+)\}\}/gi, (_, n, v) => (addVar(global, n.trim(), v), "")],
    [/\{\{incglobalvar::([^}]+)\}\}/gi, (_, n) => String(addVar(global, n.trim(), 1))],
    [/\{\{decglobalvar::([^}]+)\}\}/gi, (_, n) => String(addVar(global, n.trim(), -1))],
  ];
  if (includeGetters) list.push(...getterReplacers(ctx));
  return list;
}

function getterReplacers(ctx: MacroContext): [RegExp, Replacer][] {
  return [
    [/\{\{getvar::([^}]+)\}\}/gi, (_, n) => String(readVar(ctx.local, n.trim()))],
    [/\{\{getglobalvar::([^}]+)\}\}/gi, (_, n) => String(readVar(ctx.global, n.trim()))],
  ];
}

function contextReplacers(ctx: MacroContext): [RegExp, Replacer][] {
  const f = () => ctx.facts();
  const now = () => new Date();
  return [
    [/\{\{\/\/[\s\S]*?\}\}/g, () => ""],
    [/\{\{noop\}\}/gi, () => ""],
    [/\{\{newline\}\}/gi, () => "\n"],
    [/\{\{user\}\}/gi, () => f().user],
    [/\{\{char\}\}/gi, () => f().char],
    [/\{\{charName\}\}/g, () => f().char],
    [/\{\{userName\}\}/g, () => f().user],
    [/\{\{group\}\}/gi, () => f().group],
    [/\{\{input\}\}/gi, () => f().input],
    [/\{\{lastMessage\}\}/gi, () => f().lastMessage],
    [/\{\{lastMessageId\}\}/gi, () => f().lastMessageId],
    [/\{\{lastCharMessage\}\}/gi, () => f().lastCharMessage],
    [/\{\{lastUserMessage\}\}/gi, () => f().lastUserMessage],
    [/\{\{model\}\}/gi, () => f().model],
    [/\{\{idle_duration\}\}/gi, () => f().idleDuration],
    [/\{\{time\}\}/gi, () => `${pad(now().getHours())}:${pad(now().getMinutes())}`],
    [/\{\{date\}\}/gi, () => `${now().getFullYear()}-${pad(now().getMonth() + 1)}-${pad(now().getDate())}`],
    [/\{\{isodate\}\}/gi, () => now().toISOString().slice(0, 10)],
    [/\{\{isotime\}\}/gi, () => now().toISOString().slice(11, 19)],
    [/\{\{weekday\}\}/gi, () => now().toLocaleDateString(undefined, { weekday: "long" })],
    [/\{\{roll[ :]([^}]+)\}\}/gi, (_, formula) => String(rollDice(formula))],
    [/\{\{random\}\}/gi, () => String(Math.floor(Math.random() * 101))],
    [/\{\{random:(-?\d+):(-?\d+)\}\}/gi, (_, a, b) => String(randomInt(Number(a), Number(b)))],
    [/\{\{random::([^}]+)\}\}/gi, (_, list) => pickOne(list.split("::"))],
    [/\{\{random:([^}]+)\}\}/gi, (_, list) => pickOne(list.split(","))],
    [/\{\{pick::([^}]+)\}\}/gi, (_, list) => pickOne(list.split("::"))],
    [/\{\{reverse:(.+?)\}\}/gi, (_, text) => [...text].reverse().join("")],
    [/\{\{trim\}\}/gi, () => "\u0000TRIM\u0000"],
  ];
}

function applyAll(text: string, replacers: [RegExp, Replacer][]): string {
  let out = text;
  for (const [re, fn] of replacers) {
    if (!out.includes("{{")) break;
    out = out.replace(re, fn as (substring: string, ...args: unknown[]) => string);
  }
  return out;
}

function applyTrim(text: string): string {
  // \u0000 marks where {{trim}} stood: a character no typed text holds
  // eslint-disable-next-line no-control-regex
  return text.replace(/\s*\u0000TRIM\u0000\s*/g, "");
}

export async function substituteGlobal(text: string, ctx: MacroContext, options: SubstituteOptions = {}): Promise<string> {
  if (!text.includes("{{")) return text;
  let out = applyAll(text, variableReplacers(ctx, !options.replaceGetvar));
  out = applyAll(out, contextReplacers(ctx));
  if (options.hostMacros !== false && ctx.resolveHostMacros && /\{\{(?!\s*(?:getvar|getglobalvar)::)/.test(out)) {
    out = await ctx.resolveHostMacros(out);
  }
  if (options.replaceGetvar) out = applyAll(out, getterReplacers(ctx));
  return applyTrim(out);
}

function randomInt(a: number, b: number): number {
  const lo = Math.min(a, b);
  const hi = Math.max(a, b);
  return lo + Math.floor(Math.random() * (hi - lo + 1));
}

function pickOne(options: string[]): string {
  return options.length ? options[Math.floor(Math.random() * options.length)].trim() : "";
}

/** Supports NdM, NdM+K, NdM-K and plain numbers. */
export function rollDice(formula: string): number {
  const f = formula.trim().toLowerCase().replace(/\s+/g, "");
  const m = /^(\d*)d(\d+)([+-]\d+)?$/.exec(f);
  if (!m) {
    const n = Number(f);
    return Number.isNaN(n) ? 0 : n;
  }
  const count = Math.min(Number(m[1] || 1), 1000);
  const sides = Number(m[2]);
  let total = Number(m[3] || 0);
  for (let i = 0; i < count; i++) total += 1 + Math.floor(Math.random() * Math.max(1, sides));
  return total;
}
