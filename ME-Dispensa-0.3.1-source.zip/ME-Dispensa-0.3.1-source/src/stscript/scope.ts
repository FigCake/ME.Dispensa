import type { Closure, ParserFlags } from "./ast";

/** A closure bound to the scope it was created in. */
export interface ClosureValue {
  kind: "closure-value";
  closure: Closure;
  scope: Scope;
  flags: ParserFlags;
}

export type Val = string | ClosureValue;

export const isClosureValue = (v: unknown): v is ClosureValue =>
  typeof v === "object" && v !== null && (v as ClosureValue).kind === "closure-value";

export class ScriptError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ScriptError";
  }
}

export class Scope {
  pipe: Val = "";
  private readonly vars = new Map<string, Val>();
  private readonly macros = new Map<string, string>();

  constructor(readonly parent: Scope | null = null) {}

  has(name: string): boolean {
    return this.vars.has(name) || (this.parent?.has(name) ?? false);
  }

  let(name: string, value: Val): void {
    if (this.vars.has(name)) throw new ScriptError(`Variable "${name}" is already declared in this scope`);
    this.vars.set(name, value);
  }

  set(name: string, value: Val, index?: string): Val {
    const owner = this.owner(name);
    if (!owner) throw new ScriptError(`No such scoped variable: "${name}" (declare it with /let first)`);
    if (index !== undefined && index !== "") {
      const current = owner.vars.get(name);
      const parsed = parseJsonContainer(typeof current === "string" ? current : "", index);
      parsed[indexKey(index)] = value;
      owner.vars.set(name, JSON.stringify(parsed));
    } else {
      owner.vars.set(name, value);
    }
    return value;
  }

  get(name: string, index?: string): Val {
    const owner = this.owner(name);
    if (!owner) throw new ScriptError(`No such scoped variable: "${name}"`);
    const value = owner.vars.get(name) ?? "";
    if (index === undefined || index === "" || typeof value !== "string") return value;
    try {
      const item = JSON.parse(value)[indexKey(index)];
      return typeof item === "object" ? JSON.stringify(item) : String(item ?? "");
    } catch {
      return "";
    }
  }

  setMacro(name: string, value: string): void {
    this.macros.set(name, value);
  }

  getMacro(name: string): string | undefined {
    return this.macros.get(name) ?? this.parent?.getMacro(name);
  }

  macroNames(): string[] {
    const names = new Set<string>(this.parent?.macroNames() ?? []);
    for (const key of this.macros.keys()) names.add(key);
    return [...names];
  }

  /** This scope's own variables (for the debugger). */
  ownVars(): [string, Val][] {
    return [...this.vars.entries()];
  }

  private owner(name: string): Scope | null {
    if (this.vars.has(name)) return this;
    return this.parent?.owner(name) ?? null;
  }
}

function indexKey(index: string): string | number {
  const n = Number(index);
  return Number.isNaN(n) ? index : n;
}

function parseJsonContainer(text: string, index: string): Record<string | number, unknown> {
  try {
    const parsed = JSON.parse(text);
    if (parsed && typeof parsed === "object") return parsed;
  } catch {
    // fall through to a fresh container
  }
  return (Number.isNaN(Number(index)) ? {} : []) as Record<string | number, unknown>;
}
