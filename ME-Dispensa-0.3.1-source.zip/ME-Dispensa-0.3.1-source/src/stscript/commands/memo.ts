// The memo pad from a script (Dispensa additions): pick memos, keep text,
// and send OOC the memo pad's way.

import type { MemoControl } from "../host";
import { asText, type CommandCall } from "../interpreter";
import type { CommandDef } from "../registry";
import { ScriptError } from "../scope";

function memo(c: CommandCall): MemoControl {
  if (!c.rt.host.memo) throw new ScriptError(`/${c.node.name} only works inside Dispensa`);
  return c.rt.host.memo;
}

export const memoCommands: CommandDef[] = [
  {
    name: "memo",
    help: "📝 Pick memos from the Memo pad → their text (\"\" when none): /memo [words to find]",
    origin: "dispensa",
    run: async (c) => (await memo(c).pick(asText(c.unnamed).trim() || undefined)) ?? "",
  },
  {
    name: "memo-add",
    help: "📝 Keep text in the Memo pad (OOC wrappers come off) → how many memos: /memo-add text",
    origin: "dispensa",
    run: (c) => {
      const text = asText(c.unnamed).trim();
      if (!text) throw new ScriptError("/memo-add needs the text to keep");
      return String(memo(c).add(text));
    },
  },
  {
    name: "memo-list",
    help: "📝 Every memo as a JSON list",
    origin: "dispensa",
    run: (c) => JSON.stringify(memo(c).list()),
  },
  {
    name: "ooc",
    help: "💬 Send text as OOC the Memo pad's way (its sending setting and wrapper) → true when sent: /ooc text",
    origin: "dispensa",
    run: async (c) => {
      const text = asText(c.unnamed).trim();
      if (!text) throw new ScriptError("/ooc needs the text to send");
      return String(await memo(c).ooc(text));
    },
  },
];
