// Input and screen conveniences. /clipboard-set, /clipboard-get and
// /is-mobile follow SillyTavern; the rest are Dispensa additions.

import type { FormField } from "../host";
import { asText, type CommandCall } from "../interpreter";
import { isTrue } from "../parser";
import type { CommandDef } from "../registry";
import { ScriptError } from "../scope";
import { t } from "../../shared/i18n";

const text = (c: CommandCall) => asText(c.unnamed);
const str = (c: CommandCall, key: string): string | undefined => {
  const v = c.named[key];
  return v === undefined ? undefined : asText(v);
};

/** A JSON list from text, a variable, or comma-separated words. */
function listFrom(c: CommandCall, raw: string | undefined): string[] {
  if (!raw) return [];
  const source = c.rt.host.local.get(raw) ?? c.rt.host.global.get(raw) ?? raw;
  try {
    const parsed = JSON.parse(source);
    if (Array.isArray(parsed)) return parsed.map((x) => (typeof x === "object" ? JSON.stringify(x) : String(x)));
  } catch {
    // comma separated
  }
  return source.split(",").map((s) => s.trim()).filter(Boolean);
}

/** fields='[{"name":"age","type":"number"}]' or fields="name,age,mood" */
function fieldsFrom(c: CommandCall, raw: string | undefined): FormField[] {
  if (!raw) throw new ScriptError('/form needs fields= (e.g. fields="name,age" or a JSON list)');
  const source = c.rt.host.local.get(raw) ?? raw;
  try {
    const parsed = JSON.parse(source);
    if (Array.isArray(parsed)) {
      return parsed.map((f) => (typeof f === "string" ? { name: f } : { ...f, name: String(f.name ?? f.label ?? "field"), options: Array.isArray(f.options) ? f.options.map(String) : undefined }));
    }
  } catch {
    // comma separated names
  }
  return source.split(",").map((s) => s.trim()).filter(Boolean).map((name) => ({ name }));
}

export const uiCommands: CommandDef[] = [
  {
    name: "form",
    help: 'Ask several things at once: /form fields="name,age,mood" title → JSON {"name":…} ("" when cancelled)',
    origin: "dispensa",
    run: async (c) => {
      if (!c.rt.host.ui.form) throw new ScriptError("/form is not available here");
      const result = await c.rt.host.ui.form(text(c), fieldsFrom(c, str(c, "fields")));
      return result ? JSON.stringify(result) : "";
    },
  },
  {
    name: "pick",
    help: 'Searchable list: /pick items=["a","b"] [multiple=on] question → chosen item ("" when cancelled; JSON list with multiple)',
    origin: "dispensa",
    run: async (c) => {
      if (!c.rt.host.ui.pick) throw new ScriptError("/pick is not available here");
      const items = listFrom(c, str(c, "items") ?? str(c, "labels"));
      if (!items.length) throw new ScriptError("/pick needs items= (a JSON list, a variable name or comma-separated words)");
      const multiple = isTrue(str(c, "multiple") ?? "off");
      const picked = await c.rt.host.ui.pick(text(c), items, { multiple, placeholder: str(c, "placeholder") });
      return multiple ? JSON.stringify(picked) : picked[0] ?? "";
    },
  },
  {
    name: "confirm",
    help: "Yes/no question → true or false. /confirm [yes=Yes] [no=No] question",
    origin: "dispensa",
    run: async (c) => JSON.stringify(await c.rt.host.ui.popup(text(c), { okButton: str(c, "yes") ?? t("Yes", "예"), cancelButton: str(c, "no") ?? t("No", "아니요") })),
  },
  {
    name: "clipboard-set",
    aliases: ["copy"],
    help: "Copy text to the clipboard.",
    origin: "st",
    run: async (c) => {
      if (!c.rt.host.ui.copy) throw new ScriptError("Clipboard is not available here");
      await c.rt.host.ui.copy(text(c));
      return text(c);
    },
  },
  {
    name: "clipboard-get",
    aliases: ["paste"],
    help: "Read text from the clipboard (the browser may ask for permission).",
    origin: "st",
    run: async (c) => {
      if (!c.rt.host.ui.paste) throw new ScriptError("Clipboard is not available here");
      return c.rt.host.ui.paste();
    },
  },
  {
    name: "notify",
    help: "System notification, even when you are in another tab: /notify [title=] text",
    origin: "dispensa",
    run: async (c) => {
      if (c.rt.host.ui.notify) await c.rt.host.ui.notify(str(c, "title") ?? "Marinara", text(c));
      else c.rt.host.ui.toast(text(c), "info", { title: str(c, "title") });
      return text(c);
    },
  },
  {
    name: "wait-reply",
    aliases: ["waitreply"],
    help: "Wait until the AI finishes its reply: /wait-reply [timeout=120] → true (finished) or false (timed out)",
    origin: "dispensa",
    run: async (c) => {
      if (!c.rt.host.chat.waitForIdle) return "true";
      const seconds = Math.max(1, Math.min(Number(str(c, "timeout") ?? 120) || 120, 3600));
      return JSON.stringify(await c.rt.host.chat.waitForIdle(seconds * 1000));
    },
  },
  {
    name: "is-mobile",
    help: "True on phones and tablets.",
    origin: "st",
    run: () => JSON.stringify(typeof matchMedia === "function" && matchMedia("(pointer: coarse)").matches),
  },
];
