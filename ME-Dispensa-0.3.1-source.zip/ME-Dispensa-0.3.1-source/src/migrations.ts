// One-off changes to saved data from older builds, run at start once the
// stores have loaded. Pure: they change the states they are given and say
// what they did; main.ts saves the stores and shows the toasts.
//
// Renamed keys (bar → dock, the "wand" store key…) are read by the stores'
// normalize functions instead: those apply on every load and need no flag.

import { type Memo, type MemoState, newMemo } from "./memo/model";
import { DOCK_SET, addToDock, dockSet } from "./qr/dock";
import { type DockEntry, type QrItem, type QrSet, type QrState, builtinSet, newItem } from "./qr/model";
import { forgetSet } from "./qr/scopes";
import { escapePipes } from "./qr/script-text";
import { DEFAULT_ITEMS, OLD_COMMUNITY_TEXT } from "./visz/defaults";
import type { ViszState } from "./visz/model";
import { viszSetWithQrs } from "./visz/set";

/** The saved states; a store that failed to load is left out (and never written). */
export interface SavedData {
  qr?: QrState;
  visz?: ViszState;
  memo?: MemoState;
}

export interface MigrationReport {
  /** The stores whose state changed (to be saved). */
  changed: Set<keyof SavedData>;
  /** No visz items had moved yet: a first run (its samples come in quietly). */
  firstRun: boolean;
  /** OOC notes moved to the memo pad. */
  oocMoved: number;
  /** Old visz QR topics moved to the memo pad. */
  topicsMoved: number;
}

/** Runs every migration that applies, in the order the builds made them. */
export function migrateSavedData(data: SavedData, now = Date.now()): MigrationReport {
  const { qr, visz, memo } = data;
  const report: MigrationReport = { changed: new Set(), firstRun: !!visz && !visz.itemsMoved, oocMoved: 0, topicsMoved: 0 };
  if (memo && rewriteOldMemoTexts(memo)) report.changed.add("memo");
  if (qr && visz && memo) {
    if (!visz.itemsMoved) {
      moveItemsToMemos(visz, memo, now);
      report.changed.add("visz").add("memo");
    }
    if (!memo.moved) {
      report.oocMoved = moveOocToMemos(qr, memo, now);
      report.changed.add("qr").add("memo");
    }
    if (!memo.viszMoved) {
      report.topicsMoved = retireViszQrs(qr, memo, now);
      report.changed.add("qr").add("memo");
    }
  }
  if (qr && !qr.dock) {
    moveToOwnDock(qr);
    report.changed.add("qr");
  }
  if (qr && oldDockSet(qr)) {
    renameOldDockSet(qr);
    report.changed.add("qr");
  }
  return report;
}

/** Once: the visz item library of older builds (and a first run's samples): its topics become memos. */
export function moveItemsToMemos(visz: ViszState, memo: MemoState, now = Date.now()): void {
  const texts = visz.items.map((i) => i.content.trim()).filter(Boolean);
  memo.memos.push(...texts.map((text, i) => newMemo(text, now - i)));
  visz.items = [];
  visz.itemsMoved = true;
}

/** Built-in texts that were rewritten: an unedited memo with the old text gets the new one. */
const REWRITTEN = new Map([[OLD_COMMUNITY_TEXT, DEFAULT_ITEMS.find((i) => i.id === "sample-community")?.content ?? OLD_COMMUNITY_TEXT]]);

/** Unedited memos holding a rewritten built-in text get the new text. True when one changed. */
export function rewriteOldMemoTexts(memo: MemoState): boolean {
  let changed = false;
  for (const m of memo.memos) {
    const next = REWRITTEN.get(m.text);
    if (next !== undefined && next !== m.text) {
      m.text = next;
      changed = true;
    }
  }
  return changed;
}

function oocText(item: QrItem): string {
  if (item.kind === "viz") return item.script;
  return (item.ooc ?? item.title ?? item.script.replace(/^\/guided\s+/, "")).trim();
}

/**
 * Once: OOC notes and the old visz QRs that sent OOC leave the Library for the memo pad,
 * an emptied OOC set goes, and the Visualizer set leaves the Dock (its QRs
 * are in the visz menu). Returns how many memos came in.
 */
export function moveOocToMemos(qr: QrState, memo: MemoState, at = Date.now()): number {
  const moved: Memo[] = [];
  for (const set of qr.sets) {
    const keep: QrItem[] = [];
    for (const item of set.items) {
      const isOoc = item.kind === "ooc" || (item.kind === "viz" && item.viz?.action === "ooc");
      const text = isOoc ? oocText(item) : "";
      if (isOoc && text) moved.push(newMemo(text, at - moved.length));
      else if (!isOoc) keep.push(item);
    }
    set.items = keep;
  }
  for (const set of qr.sets.filter((s) => s.name === "OOC" && !s.items.length)) forgetSet(qr, set.id);
  qr.sets = qr.sets.filter((s) => !(s.name === "OOC" && !s.items.length));
  const visz = builtinSet(qr, "visz");
  if (visz) visz.enabled = false;
  // the first in the Library gets the latest time, so they keep their order (newest on top)
  memo.memos.push(...moved);
  memo.moved = true;
  return moved.length;
}

/**
 * Once: the old visz QRs were only topics for a page, so their text goes
 * to the memo pad. One that sat on the Dock becomes a QR there that makes that
 * page (`/visz topic`), so the bubble keeps working. The Visualizer set gets
 * its real QRs. Returns how many memos came in.
 */
export function retireViszQrs(qr: QrState, memo: MemoState, at = Date.now()): number {
  const have = new Set(memo.memos.map((m) => m.text));
  let n = 0;
  for (const set of qr.sets) {
    const keep: QrItem[] = [];
    for (const item of set.items) {
      if (item.kind !== "viz") {
        keep.push(item);
        continue;
      }
      const text = item.script.trim();
      if (text && !have.has(text)) {
        memo.memos.push(newMemo(text, at - n++));
        have.add(text);
      }
      if (item.viz?.pinned) {
        const target = dockSet(qr);
        const made: QrItem = { ...newItem(item.label, `/visz ${escapePipes(text)}`), ...(item.icon ? { icon: item.icon } : {}) };
        target.items.push(made);
        addToDock(qr, { kind: "qr", setId: target.id, itemId: made.id });
      }
    }
    set.items = keep;
  }
  viszSetWithQrs(qr);
  memo.viszMoved = true;
  return n;
}

/**
 * Once, from builds where the Dock showed the sets that were on: the sets on
 * in every chat (with something to show) become the Dock's entries, in order.
 */
export function moveToOwnDock(state: QrState): void {
  if (state.dock) return;
  state.dock = state.sets.filter((s) => s.enabled && s.items.some((i) => !i.hidden)).map((s): DockEntry => ({ kind: "set", setId: s.id, layout: s.display === "inline" ? "row" : "folder" }));
}

const OLD_DOCK_NAMES = ["퀵바", "Quick bar"];

/** The Dock set still under the name older builds gave it, if any. */
export function oldDockSet(state: QrState): QrSet | undefined {
  const set = state.sets.find((s) => s.builtin === "dock") ?? state.sets.find((s) => !s.builtin && s.name === "퀵바");
  return set && OLD_DOCK_NAMES.includes(set.name) ? set : undefined;
}

/** Once: the Dock set from builds that called it 퀵바 / Quick bar takes its new name. */
export function renameOldDockSet(state: QrState): void {
  const set = oldDockSet(state);
  if (!set) return;
  set.builtin = "dock";
  set.name = DOCK_SET.name();
}
