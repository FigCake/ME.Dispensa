// visz settings, wrappers and preset in Marinara's storage (key "visz";
// builds up to 0.3.0 used "wand", which moves over on the first load).

import { PersistedStore } from "../host/persisted-store";
import { type ViszState, normalizeViszState } from "./model";

export class ViszStore extends PersistedStore<ViszState> {
  constructor() {
    super({ key: "visz", oldKeys: ["wand"], normalize: normalizeViszState, label: "visz" });
  }
}
