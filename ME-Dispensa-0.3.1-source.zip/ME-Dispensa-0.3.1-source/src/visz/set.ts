// The Visualizer set: ordinary QRs that make pages with /visz. It once held
// visz QRs, topics only; those moved to the memo pad (see migrations.ts).

import { t } from "../shared/i18n";
import { type QrSet, type QrState, builtinSet, newItem, newSet } from "../qr/model";

/** The Visualizer set: its name in the screen language when it is made, and its icon. */
export const VISZ_SET = { name: () => t("Visualizer", "비주얼라이저"), icon: "🌟" };

/** The Visualizer set's QRs: whole QRs that run visz (`[[…]]` asks at run time), named in the screen language. */
export const VISZ_QRS = (): { label: string; icon: string; title: string; script: string }[] => [
  { label: t("Superviz", "슈퍼비즈"), icon: "🌟", title: t("Ask for a topic and make a page", "주제를 물어서 페이지 만들기"), script: t("/visz [[Topic of the page]]", "/visz [[만들 페이지의 주제]]") },
  { label: t("From the last message", "마지막 메시지로"), icon: "🎬", title: t("A page of the last message's scene", "마지막 메시지의 장면을 페이지로"), script: t("/visz A page of this scene: {{lastMessage}}", "/visz 이 장면을 담은 페이지: {{lastMessage}}") },
  { label: t("From a memo", "메모로"), icon: "📝", title: t("A page from a memo picked in the memo pad", "메모장에서 고른 메모로 페이지 만들기"), script: t("/visz [[memo]]", "/visz [[메모]]") },
];

/** The Visualizer set, made with its QRs when missing. */
export function viszSetWithQrs(qr: QrState): QrSet {
  let set = builtinSet(qr, "visz");
  if (!set) {
    set = { ...newSet(VISZ_SET.name()), icon: VISZ_SET.icon, enabled: false, builtin: "visz" };
    qr.sets.push(set);
  }
  if (!set.items.length) for (const v of VISZ_QRS()) set.items.push({ ...newItem(v.label, v.script), icon: v.icon, title: v.title });
  return set;
}
