// Default visz library and templates (from the SillyTavern Wand Visualizer).

import type { ViszItem, Wrapper } from "./model";
import { t } from "../shared/i18n";

// Titles, folders and topics are getters: copied (structuredClone) in the screen
// language when a first run makes the samples.
export const DEFAULT_ITEMS: ViszItem[] = [
  {
    "id": "sample-community",
    "emoji": "📰",
    get title() {
      return t("Community reactions", "커뮤니티 반응");
    },
    get folder() {
      return t("Community", "커뮤니티");
    },
    "defaultAction": "ooc",
    "content": "Pause the Current RP. Show online community threads (posts + comments) about recent events.\n\n## Output Guidelines\n\n- Write 12–15 threads posted across 5 different community boards.\n- Give each board 2–5 full threads.\n- Include 2 NSFW boards as well.\n- Show not only the posts but all of their comments too (7–30 per thread, depending on how popular the post is).\n- Be realistic, and depict controversial content explicitly. The goal is to show realistic posts and comments as they are, without toning anything down.\n- If a thread is a debate, let many comments show how the argument unfolds.\n- Imitate the style of real online communities.\n\n## Visualization\n\nVisualize the content written under the guidelines above as multiple HTML outputs. Imitate the UI and board style of online communities. Each HTML must be one complete HTML output wrapped in ```html...```. Style the HTML outputs with CSS and JavaScript. Make them interactive.",
    "connectionId": null,
    "pinned": false
  },
  {
    "id": "sample-wedding",
    "emoji": "💌",
    get title() {
      return t("Mobile wedding invitation", "모바일 청첩장");
    },
    get folder() {
      return t("Anniversaries", "기념일");
    },
    "defaultAction": "viz",
    get content() {
      return t("A mobile wedding invitation for {{char}} and {{user}}. The mood of the vows: [[Mood of the vows]].", "{{char}}와 {{user}}의 모바일 청첩장. 서약문의 분위기는 [[서약문 분위기]].");
    },
    "connectionId": null,
    "pinned": false
  },
  {
    "id": "sample-diary",
    "emoji": "📔",
    get title() {
      return t("Secret diary", "비밀 일기장");
    },
    get folder() {
      return t("Personal", "개인");
    },
    "defaultAction": "viz",
    get content() {
      return t("The diary {{char}} shows no one. Mostly honest entries about recent events.", "{{char}}가 아무에게도 보여주지 않는 일기장. 최근 사건에 대한 솔직한 기록 위주로.");
    },
    "connectionId": null,
    "pinned": false
  },
  {
    "id": "sample-phone",
    "emoji": "📱",
    get title() {
      return t("Phone home screen", "휴대폰 홈 화면");
    },
    get folder() {
      return t("Personal", "개인");
    },
    "defaultAction": "viz",
    get content() {
      return t(
        "{{char}}'s phone home screen. Tapping an app icon opens that app's screen (messages, photos, notes and so on), and a back button returns to the home screen.",
        "{{char}}의 휴대폰 홈 화면. 앱 아이콘을 누르면 메시지 · 사진첩 · 메모 같은 각 앱 화면이 열리고, 뒤로 가기로 돌아올 수 있다.",
      );
    },
    "connectionId": null,
    "pinned": false
  }
];

// Like the user's own SillyTavern QRs (레딧, 케톡, 오오띠, 슈퍼비즈): the request itself between
// <System> tags, nothing added (a request that wants a language or "pause the RP" says so itself).
export const DEFAULT_OOC_TEMPLATE = "<System>\n{{내용}}\n</System>";

/** The community-reactions sample as it was first written (in Korean); a memo still holding it gets the English one. */
export const OLD_COMMUNITY_TEXT = "Pause the Current RP. 최근 사건에 관한 온라인 커뮤니티 Threads(Post+Comments)들을 보여주세요.\n\n## 출력 지침\n\n- 다양한 커뮤니티 게시판(5개)에 게시된 각각의 Thread들(12개-15개)을 작성하세요.\n- 각각의 게시판마다 2-5개의 Full threads가 배정됩니다.\n- NSFW 게시판도 2개 보여주세요.\n- 본문(post) 뿐만 아니라 comments(글의 인기에 따라 7-30개)들도 전부 볼수 있게 하세요.\n- 사실적으로, 논란의 여지가 있는 내용도 노골적으로 묘사하세요. 수위조절 없이 현실적인 posts과 comments들을 그대로 보여주는 것이 목표입니다.\n- 논쟁이 이루어지는 thread라면 많은 comments로 논쟁 흐름이 드러나게 하세요.\n- 실제 온라인 커뮤니티의 스타일을 모방합니다.\n\n## 시각화\n\n위 출력 지침에 따라 생성된 내용물들을 여러 개의 html 출력물로 시각화해주세요. 온라인 커뮤니티의 UI와 게시판 스타일을 모방합니다. 각각의 html은 ```html...```로 감싸인 하나의 완전한 html 출력물이어야합니다. html구조의 출력물들은 CSS과 JavaScript을 이용해 스타일링합니다. interactive한 출력물로 만드세요.";

/** Earlier defaults, swapped for the current one when they were never edited. */
export const OLD_OOC_TEMPLATES: string[] = ["<System>\n[OOC] 진행 중인 RP를 잠시 멈추고, 아래 요청에 맞는 결과물만 출력한다.\n[언어 지침] 모든 결과물은 다음 언어로 출력한다: {{언어}}\n\n{{내용}}\n</System>"];

export const CONTINUE_TEMPLATE = "<System>\nThe HTML you wrote earlier was cut off before it was finished. This is everything written so far:\n```html\n{{앞부분}}\n```\nContinue the code from EXACTLY where it stops. Output ONLY the remaining code: do not repeat anything already written, do not restart the document, do not explain, and do not wrap it in a Markdown code block. Close every open tag and end with </html>.\n</System>";

// Names are getters, copied in the screen language when the wrappers are made.
export const DEFAULT_WRAPPERS: Wrapper[] = [
  {
    id: "system",
    get name() {
      return t("<System> block", "<System> 블록");
    },
    template: DEFAULT_OOC_TEMPLATE,
  },
  {"id":"ooc-paren","name":"((OOC: …))","template":"((OOC: {{내용}}))"},
  {"id":"ooc-bracket","name":"[OOC: …]","template":"[OOC: {{내용}}]"},
  {
    id: "raw",
    get name() {
      return t("No wrapper", "감싸지 않음");
    },
    template: "{{내용}}",
  },
];
