// The Dock: its own list of bubbles (sets and single QRs), the same in
// every chat. Where a set is on (every chat, this chat, a character) decides
// only where its QRs auto-run; the Dock is a row of shortcuts.

import { type DockEntry, type DockLayout, type QrItem, type QrSet, type QrState, builtinSet, newSet } from "./model";

/** The set QRs made right on the Dock go to: its name in the screen language when it is made, and its icon. */
export const DOCK_SET = { name: () => "Dock", icon: "⚡" };

/** A Dock entry with what it points at; entries whose set or QR is gone are left out. */
export type ShownEntry = { entry: DockEntry; set: QrSet; item?: QrItem };

export function shownDock(state: QrState): ShownEntry[] {
  const out: ShownEntry[] = [];
  for (const entry of state.dock ?? []) {
    if (entry.kind === "set") {
      const set = state.sets.find((s) => s.id === entry.setId);
      if (set) out.push({ entry, set });
      continue;
    }
    // a QR moved to another set keeps its bubble (ids are unique)
    for (const set of state.sets) {
      const item = set.items.find((i) => i.id === entry.itemId);
      if (item) {
        out.push({ entry, set, item });
        break;
      }
    }
  }
  return out;
}

const same = (a: DockEntry, b: DockEntry) => a.kind === b.kind && (a.kind === "set" ? a.setId === b.setId : a.itemId === (b as typeof a).itemId);

export function onDock(state: QrState, entry: DockEntry): boolean {
  return (state.dock ?? []).some((e) => same(e, entry));
}

/** Puts an entry on the Dock (at the end, or at `index`); one that is there already stays put. */
export function addToDock(state: QrState, entry: DockEntry, index?: number): void {
  const entries = (state.dock ??= []);
  if (entries.some((e) => same(e, entry))) return;
  entries.splice(index === undefined ? entries.length : Math.max(0, Math.min(index, entries.length)), 0, entry);
}

export function removeFromDock(state: QrState, entry: DockEntry): void {
  if (state.dock) state.dock = state.dock.filter((e) => !same(e, entry));
}

/** The Dock set, made when missing: on in every chat, so the QRs made on the Dock auto-run anywhere. */
export function dockSet(state: QrState): QrSet {
  let set = builtinSet(state, "dock");
  if (!set) {
    set = { ...newSet(DOCK_SET.name()), icon: DOCK_SET.icon, builtin: "dock" };
    state.sets.push(set);
  }
  return set;
}

/** How a set entry sits on the Dock (older entries follow the set's own inline display). */
export function layoutOf(entry: DockEntry, set: QrSet): DockLayout {
  if (entry.kind !== "set") return "folder";
  return entry.layout ?? (set.display === "inline" ? "row" : "folder");
}

export function setLayout(state: QrState, setId: string, layout: DockLayout): void {
  for (const e of state.dock ?? []) if (e.kind === "set" && e.setId === setId) e.layout = layout;
}

/**
 * What the Dock draws from the Library: everything but the script text
 * (only whether a QR has a script matters to it), so typing a script does
 * not redraw the Dock.
 */
export function dockSlice(state: QrState): string {
  return JSON.stringify(state, (key, value) => (key === "script" ? typeof value === "string" && value.trim() !== "" : value));
}
