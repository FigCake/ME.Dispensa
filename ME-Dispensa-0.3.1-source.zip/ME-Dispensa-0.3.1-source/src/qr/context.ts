// A QR's sub menu (SillyTavern's context menu): the sets in its context list,
// nested, with chained scripts and %%parent%% filled in.

import type { QrItem, QrSet, QrState } from "./model";

export interface MenuEntry {
  set: QrSet;
  item: QrItem;
  /** What a press runs: the item with its chained script. */
  run: QrItem;
  children: MenuGroup[];
}

export interface MenuGroup {
  set: QrSet;
  entries: MenuEntry[];
}

export function hasMenu(state: QrState, item: QrItem): boolean {
  return !!item.contextList?.some((l) => state.sets.some((s) => s.id === l.setId));
}

/** The sub menu of a QR (empty when it has none). */
export function contextMenu(state: QrState, set: QrSet, item: QrItem): MenuGroup[] {
  return build(state, set, item, null, [], []);
}

function build(state: QrState, ownSet: QrSet, item: QrItem, chained: string | null, hierarchy: string[], labels: string[]): MenuGroup[] {
  const groups: MenuGroup[] = [];
  const script = joinChain(chained, item.script);
  for (const link of item.contextList ?? []) {
    const set = state.sets.find((s) => s.id === link.setId);
    if (!set || hierarchy.includes(set.id)) continue;
    const nextHierarchy = [...hierarchy, set.id];
    const nextLabels = [...labels, item.label];
    // its own set as its menu ("burger" menu): only the hidden QRs that have an icon
    const own = set.id === ownSet.id || set.items.some((i) => i.id === item.id);
    const visible = set.items.filter((sub) => (own ? sub.hidden && !!sub.icon?.trim() : !sub.hidden));
    const entries = visible.map((sub): MenuEntry => {
      const passOn = link.chained && canChain(item, sub) ? script : null;
      const finalScript = joinChain(passOn, sub.script).replace(/%%parent(-\d+)?%%/g, (_, index?: string) => nextLabels.slice(parseInt(index ?? "-1", 10))[0] ?? "");
      return {
        set,
        item: sub,
        run: { ...sub, script: finalScript },
        children: build(state, set, sub, passOn ? script : null, nextHierarchy, nextLabels),
      };
    });
    groups.push({ set, entries });
  }
  return groups;
}

function joinChain(parent: string | null, script: string): string {
  return parent && script ? `${parent} | ${script}` : script;
}

/** Only scripts chain (an old visz QR or an OOC note has no pipe to pass on). */
function canChain(parent: QrItem, sub: QrItem): boolean {
  return parent.kind === "script" && sub.kind === "script";
}
