// Where a set is on: every chat (set.enabled), one chat, or one character
// (SillyTavern's global / chat / character set lists).

import type { QrSet, QrState } from "./model";

/** The chat on screen: its id and the characters in it. */
export interface ChatScope {
  chatId: string | null;
  characterIds: string[];
}

export const NO_CHAT: ChatScope = { chatId: null, characterIds: [] };

/** Sets that are on here, in SillyTavern's order: every chat, this chat, this character. */
export function activeSets(state: QrState, scope: ChatScope): QrSet[] {
  const ids: string[] = state.sets.filter((s) => s.enabled).map((s) => s.id);
  if (scope.chatId) ids.push(...(state.chatSets[scope.chatId] ?? []));
  for (const c of scope.characterIds) ids.push(...(state.charSets[c] ?? []));
  const out: QrSet[] = [];
  for (const id of new Set(ids)) {
    const set = state.sets.find((s) => s.id === id);
    if (set) out.push(set);
  }
  return out;
}

export function isOnForChat(state: QrState, setId: string, chatId: string | null): boolean {
  return !!chatId && (state.chatSets[chatId] ?? []).includes(setId);
}

export function isOnForCharacter(state: QrState, setId: string, characterId: string): boolean {
  return (state.charSets[characterId] ?? []).includes(setId);
}

function toggleIn(lists: Record<string, string[]>, key: string, setId: string, on: boolean): void {
  const list = (lists[key] ?? []).filter((id) => id !== setId);
  if (on) list.push(setId);
  if (list.length) lists[key] = list;
  else delete lists[key];
}

export function setForChat(state: QrState, chatId: string, setId: string, on: boolean): void {
  toggleIn(state.chatSets, chatId, setId, on);
}

export function setForCharacter(state: QrState, characterId: string, setId: string, on: boolean): void {
  toggleIn(state.charSets, characterId, setId, on);
}

/** How many other chats / characters a set is on for (shown next to the switches). */
export function elsewhere(state: QrState, setId: string, scope: ChatScope): { chats: number; characters: number } {
  const chats = Object.entries(state.chatSets).filter(([id, sets]) => id !== scope.chatId && sets.includes(setId)).length;
  const characters = Object.entries(state.charSets).filter(([id, sets]) => !scope.characterIds.includes(id) && sets.includes(setId)).length;
  return { chats, characters };
}

/** A deleted set leaves no ids behind (in the lists or in other QRs' sub menus). */
export function forgetSet(state: QrState, setId: string): void {
  for (const lists of [state.chatSets, state.charSets]) for (const key of Object.keys(lists)) toggleIn(lists, key, setId, false);
  if (state.dock) state.dock = state.dock.filter((e) => !(e.kind === "set" && e.setId === setId));
  for (const set of state.sets) {
    for (const item of set.items) {
      if (!item.contextList) continue;
      item.contextList = item.contextList.filter((l) => l.setId !== setId);
      if (!item.contextList.length) delete item.contextList;
    }
  }
}

// ── the set column: SillyTavern's lists (every chat, this chat, each character) and every set ──

/** One list of the set column. "all": every set made (SillyTavern's set picker). */
export type SetZone = { kind: "global" } | { kind: "chat"; chatId: string } | { kind: "char"; characterId: string } | { kind: "all" };

/** The set ids of a list, in its order. */
export function zoneSets(state: QrState, zone: SetZone): string[] {
  switch (zone.kind) {
    case "global":
      return state.sets.filter((s) => s.enabled).map((s) => s.id);
    case "chat":
      return [...(state.chatSets[zone.chatId] ?? [])].filter((id) => state.sets.some((s) => s.id === id));
    case "char":
      return [...(state.charSets[zone.characterId] ?? [])].filter((id) => state.sets.some((s) => s.id === id));
    case "all":
      return state.sets.map((s) => s.id);
  }
}

/** The sets in `ids` take their places among state.sets in this order; the others stay where they are. */
function reorderSlots(state: QrState, ids: string[]): void {
  const wanted = ids.map((id) => state.sets.find((s) => s.id === id)).filter((s): s is QrSet => !!s);
  const picked = new Set(wanted);
  let next = 0;
  state.sets = state.sets.map((s) => (picked.has(s) ? wanted[next++] : s));
}

function writeZone(state: QrState, zone: SetZone, ids: string[]): void {
  if (zone.kind === "global") {
    for (const s of state.sets) s.enabled = ids.includes(s.id);
    reorderSlots(state, ids);
  } else if (zone.kind === "all") reorderSlots(state, ids);
  else {
    const lists = zone.kind === "chat" ? state.chatSets : state.charSets;
    const key = zone.kind === "chat" ? zone.chatId : zone.characterId;
    if (ids.length) lists[key] = ids;
    else delete lists[key];
  }
}

const sameZone = (a: SetZone, b: SetZone) =>
  a.kind === b.kind && (a.kind !== "chat" || a.chatId === (b as typeof a).chatId) && (a.kind !== "char" || a.characterId === (b as typeof a).characterId);

/**
 * A set dropped on a list at `index` (among that list's other sets). From
 * "all" it is added (it stays in "all"); into "all" it is taken out of the
 * list it came from; between lists it moves; in its own list it is reordered.
 */
export function moveSet(state: QrState, setId: string, from: SetZone, to: SetZone, index: number): void {
  if (to.kind === "all" && from.kind !== "all") {
    writeZone(state, from, zoneSets(state, from).filter((id) => id !== setId));
    return;
  }
  if (!sameZone(from, to) && from.kind !== "all") writeZone(state, from, zoneSets(state, from).filter((id) => id !== setId));
  const list = zoneSets(state, to).filter((id) => id !== setId);
  list.splice(Math.max(0, Math.min(index, list.length)), 0, setId);
  writeZone(state, to, list);
}
