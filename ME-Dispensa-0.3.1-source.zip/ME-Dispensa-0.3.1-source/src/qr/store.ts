// The QR Library (sets, the Dock, where sets are on) in Marinara's storage (key "qr").

import { PersistedStore } from "../host/persisted-store";
import { type QrState, normalizeState } from "./model";

export class QrStore extends PersistedStore<QrState> {
  constructor() {
    super({ key: "qr", normalize: normalizeState, label: "QR" });
  }
}
