// Copies of QRs and sets with fresh ids (duplicate, copy to another set).

import { t } from "../shared/i18n";
import { type QrItem, type QrSet, type QrState, newId } from "./model";

/** A copy of a QR with a new id. */
export function cloneItem(item: QrItem): QrItem {
  const copy = JSON.parse(JSON.stringify(item)) as QrItem;
  copy.id = newId(item.kind === "ooc" ? "ooc" : "qr");
  return copy;
}

/** A copy of a set: new ids, sub menus that pointed at the set itself point at the copy. */
export function duplicateSet(set: QrSet, state: QrState): QrSet {
  const copy = JSON.parse(JSON.stringify(set)) as QrSet;
  copy.id = newId("set");
  const taken = new Set(state.sets.map((s) => s.name));
  let name = t(`${set.name} copy`, `${set.name} 복사본`);
  for (let n = 2; taken.has(name); n++) name = t(`${set.name} copy ${n}`, `${set.name} 복사본 ${n}`);
  copy.name = name;
  for (const item of copy.items) {
    item.id = newId(item.kind === "ooc" ? "ooc" : "qr");
    if (item.contextList) item.contextList = item.contextList.map((l) => (l.setId === set.id ? { ...l, setId: copy.id } : l));
  }
  return copy;
}
