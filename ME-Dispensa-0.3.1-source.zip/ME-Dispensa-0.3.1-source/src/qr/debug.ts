// The QR editor's debugger: decides where a script stops (a /breakpoint, a
// marked line, the next step) and holds it there until told to go on.

import type { DebugStop, Debugger } from "../stscript/interpreter";

/** continue: to the next breakpoint. into: the very next command. over: the next one at this depth or above. out: back in the caller. */
export type StepMode = "continue" | "into" | "over" | "out";

export interface DebugOptions {
  /** The editor's text and the lines marked in it (0-based). */
  text(): string;
  breakpoints(): Set<number>;
  /** Stop before the first command. */
  startPaused?: boolean;
  /** Called with the stop, and with null when it goes on. */
  onPause(stop: DebugStop | null): void;
}

/** 0-based line of an offset. */
export function lineOf(text: string, offset: number): number {
  let n = 0;
  for (let i = 0; i < offset && i < text.length; i++) if (text[i] === "\n") n++;
  return n;
}

export class DebugSession implements Debugger {
  private mode: StepMode;
  private depth = 0;
  private current: DebugStop | null = null;
  private resume: (() => void) | null = null;
  /** The line it last stopped on: going on does not stop again on the same line's next command. */
  private lastLine = -1;

  constructor(private readonly options: DebugOptions) {
    this.mode = options.startPaused ? "into" : "continue";
  }

  get paused(): DebugStop | null {
    return this.current;
  }

  beforeCommand(stop: DebugStop): Promise<void> | void {
    if (!this.shouldStop(stop)) return;
    this.current = stop;
    this.lastLine = this.lineIn(stop);
    this.options.onPause(stop);
    return new Promise<void>((r) => (this.resume = r));
  }

  /** Go on from a stop. */
  step(mode: StepMode): void {
    this.mode = mode;
    this.depth = this.current?.depth ?? 0;
    const resume = this.resume;
    this.resume = null;
    this.current = null;
    this.options.onPause(null);
    resume?.();
  }

  /** Let a stopped script go (to be aborted by its signal). */
  release(): void {
    this.step("continue");
  }

  private lineIn(stop: DebugStop): number {
    const text = this.options.text();
    return stop.source && stop.source.text === text ? lineOf(text, stop.node.start) : -1;
  }

  private shouldStop(stop: DebugStop): boolean {
    if (stop.node.name === "breakpoint") return true;
    if (this.mode === "into") return true;
    if (this.mode === "over" && stop.depth <= this.depth) return true;
    if (this.mode === "out" && stop.depth < this.depth) return true;
    const line = this.lineIn(stop);
    if (line < 0) return false;
    if (line === this.lastLine) return false;
    this.lastLine = -1;
    return this.options.breakpoints().has(line);
  }
}
