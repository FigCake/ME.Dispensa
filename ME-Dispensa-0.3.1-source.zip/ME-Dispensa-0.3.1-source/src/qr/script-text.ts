// Text put into a generated STscript line (a QR made from a memo, an old
// visz QR turned into /visz …): escaped so it stays one plain argument.

/** `|` and `\` escaped, so the text neither ends the command nor escapes what follows. */
export function escapePipes(text: string): string {
  return text.replace(/[|\\]/g, (c) => `\\${c}`);
}

/** Also `{:` and `:}`, so the text never opens or closes a closure. */
export function escapeScriptText(text: string): string {
  return escapePipes(text).replace(/\{:/g, "\\{:").replace(/:\}/g, "\\:}");
}

/** A /ooc line that sends the text as it is. */
export function oocCommand(text: string): string {
  return `/ooc ${escapeScriptText(text)}`;
}
