// Chat variables live in two drawers:
//  1. Marinara's own chat variables (metadata.macroVariables), so {{getvar}}
//     in Marinara prompts and lorebooks sees them. Marinara only accepts new
//     names like `my_var` (letter/underscore first, max 64) and values up to
//     10,000 characters.
//  2. Dispensa's private storage for everything else (Korean names, long values).
// Scripts see one store; reads check drawer 1 first.

import type { VariableStore } from "../stscript/variables";
import { ApiError, api } from "../shared/api";
import { getMarinara } from "../shared/marinara-global";
import { t } from "../shared/i18n";

const MARINARA_NAME = /^[A-Za-z_]\w{0,63}$/;
const MAX_VALUE = 10_000;
const MAX_VARS = 500;

export function fitsMarinara(name: string, value: string): boolean {
  return MARINARA_NAME.test(name) && value.length <= MAX_VALUE;
}

export class ChatVariables implements VariableStore {
  private chatId: string | null = null;
  private marinaraVars = new Map<string, string>();
  private privateVars = new Map<string, string>();
  private dirtyMarinara = new Map<string, string | null>();
  private dirtyPrivate = false;

  get currentChatId(): string | null {
    return this.chatId;
  }

  /** Switch to a chat (or reload it with fresh metadata). Pending writes are flushed first. */
  async load(chatId: string | null, metadata?: unknown): Promise<void> {
    await this.flush();
    // read first, then swap: a QR running alongside (an auto-run) never sees the maps half empty
    const marinaraVars = new Map<string, string>();
    const privateVars = new Map<string, string>();
    if (chatId) {
      const meta = parseObject(metadata);
      for (const [k, v] of Object.entries(parseObject(meta.macroVariables))) marinaraVars.set(k, String(v));
      const stored = await getMarinara().storage.get();
      const all = parseObject(stored.chatVars);
      for (const [k, v] of Object.entries(parseObject(all[chatId]))) privateVars.set(k, String(v));
    }
    this.chatId = chatId;
    this.marinaraVars = marinaraVars;
    this.privateVars = privateVars;
    this.dirtyMarinara.clear();
    this.dirtyPrivate = false;
  }

  get(name: string): string | undefined {
    return this.marinaraVars.get(name) ?? this.privateVars.get(name);
  }

  has(name: string): boolean {
    return this.marinaraVars.has(name) || this.privateVars.has(name);
  }

  set(name: string, value: string): void {
    this.requireChat();
    const inMarinara = this.marinaraVars.has(name);
    const canUseMarinara = (inMarinara || (fitsMarinara(name, value) && this.marinaraVars.size < MAX_VARS)) && value.length <= MAX_VALUE;
    if (canUseMarinara && !this.privateVars.has(name)) {
      this.marinaraVars.set(name, value);
      this.dirtyMarinara.set(name, value);
    } else {
      if (inMarinara) {
        this.marinaraVars.delete(name);
        this.dirtyMarinara.set(name, null);
      }
      this.privateVars.set(name, value);
      this.dirtyPrivate = true;
    }
  }

  delete(name: string): void {
    if (this.marinaraVars.delete(name)) this.dirtyMarinara.set(name, null);
    if (this.privateVars.delete(name)) this.dirtyPrivate = true;
  }

  entries(): [string, string][] {
    return [...this.marinaraVars.entries(), ...this.privateVars.entries()];
  }

  async flush(): Promise<void> {
    const chatId = this.chatId;
    if (!chatId) return;
    let pending = Object.fromEntries(this.dirtyMarinara);
    this.dirtyMarinara.clear();
    for (let attempt = 0; attempt < 8 && Object.keys(pending).length; attempt++) {
      try {
        await api(`/chats/${encodeURIComponent(chatId)}/metadata`, { method: "PATCH", body: { macroVariables: pending } });
        pending = {};
      } catch (e) {
        const bad = e instanceof ApiError ? /Invalid chat variable name: (.+)$|Chat variable (.+) is too long/.exec(e.message) : null;
        const name = bad?.[1] ?? bad?.[2];
        if (!name || !(name in pending)) throw e;
        // Marinara refused this name or value: keep it in the private drawer instead.
        const value = pending[name];
        delete pending[name];
        this.marinaraVars.delete(name);
        if (value !== null) {
          this.privateVars.set(name, value);
          this.dirtyPrivate = true;
        }
      }
    }
    if (this.dirtyPrivate) {
      this.dirtyPrivate = false;
      const m = getMarinara();
      const stored = await m.storage.get();
      const all = parseObject(stored.chatVars);
      all[chatId] = Object.fromEntries(this.privateVars);
      if (this.privateVars.size === 0) delete all[chatId];
      await m.storage.patch({ chatVars: all });
    }
  }

  private requireChat(): void {
    if (!this.chatId) throw new Error(t("Chat variables work only with a chat open.", "채팅을 연 상태에서만 채팅 변수를 쓸 수 있어요."));
  }
}

/** App-wide variables, kept in Dispensa's storage. */
export class GlobalVariables implements VariableStore {
  private vars = new Map<string, string>();
  private loaded = false;
  private dirty = false;

  async load(): Promise<void> {
    if (this.loaded) return;
    const stored = await getMarinara().storage.get();
    for (const [k, v] of Object.entries(parseObject(stored.globalVars))) this.vars.set(k, String(v));
    this.loaded = true;
  }

  get(name: string) {
    return this.vars.get(name);
  }
  has(name: string) {
    return this.vars.has(name);
  }
  set(name: string, value: string) {
    this.vars.set(name, value);
    this.dirty = true;
  }
  delete(name: string) {
    if (this.vars.delete(name)) this.dirty = true;
  }
  entries(): [string, string][] {
    return [...this.vars.entries()];
  }

  async flush(): Promise<void> {
    if (!this.dirty) return;
    this.dirty = false;
    await getMarinara().storage.patch({ globalVars: Object.fromEntries(this.vars) });
  }
}

export function parseObject(value: unknown): Record<string, unknown> {
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
    } catch {
      return {};
    }
  }
  return value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
}
