// Fornello, a separate extension that runs pages with their scripts (see
// its README). Dispensa only looks it up on window; this is the one place.

/** What Fornello puts on window.__fornello. */
export interface FornelloBridge {
  version: number;
  mount(container: HTMLElement, code: string, options?: { run?: boolean }): { dispose(): void };
  openSettings?(): void;
}

/** Fornello's bridge when a version Dispensa knows is installed. */
export function fornello(): FornelloBridge | null {
  const bridge = (window as { __fornello?: FornelloBridge }).__fornello;
  return bridge && bridge.version === 1 && typeof bridge.mount === "function" ? bridge : null;
}

/** Fornello is installed at all (any version): the visz prompt can tell the model about its commands. */
export function fornelloInstalled(): boolean {
  return !!(window as { __fornello?: unknown }).__fornello;
}
