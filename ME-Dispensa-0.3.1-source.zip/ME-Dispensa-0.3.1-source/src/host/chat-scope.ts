// Which chat is on screen and who is in it (for chat and character sets,
// and the "opening a chat" trigger). Marinara has no chat-changed event, so
// the chat input is checked every second.

import type { ChatScope } from "../qr/scopes";
import { NO_CHAT } from "../qr/scopes";
import { api } from "../shared/api";
import { findComposer } from "../shared/composer";

type Listener = (scope: ChatScope, previous: ChatScope) => void;

export class ChatScopeWatch {
  private scope: ChatScope = NO_CHAT;
  private readonly listeners = new Set<Listener>();
  private timer: ReturnType<typeof setInterval> | null = null;
  private checking = false;

  get current(): ChatScope {
    return this.scope;
  }

  onChange(fn: Listener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  /** Reads the chat on screen now, then keeps watching. */
  async start(): Promise<void> {
    await this.check();
    this.timer = setInterval(() => void this.check(), 1000);
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.listeners.clear();
  }

  /** Reload who is in the chat (after a member was added, say). */
  async refresh(): Promise<void> {
    const id = this.scope.chatId;
    if (!id) return;
    const characterIds = await characterIdsOf(id);
    if (this.scope.chatId !== id || same(characterIds, this.scope.characterIds)) return;
    this.set({ chatId: id, characterIds });
  }

  private async check(): Promise<void> {
    // leaving the chat view keeps the last chat: coming back to it is not "opening a chat"
    const id = findComposer()?.chatId ?? null;
    if (!id || id === this.scope.chatId || this.checking) return;
    this.checking = true;
    try {
      this.set({ chatId: id, characterIds: await characterIdsOf(id) });
    } finally {
      this.checking = false;
    }
  }

  private set(next: ChatScope): void {
    const previous = this.scope;
    this.scope = next;
    for (const fn of [...this.listeners]) {
      try {
        fn(next, previous);
      } catch (e) {
        console.error("[Dispensa]", e);
      }
    }
  }
}

async function characterIdsOf(chatId: string): Promise<string[]> {
  try {
    const chat = await api<{ characterIds?: unknown }>(`/chats/${encodeURIComponent(chatId)}`);
    let ids = chat.characterIds;
    if (typeof ids === "string") ids = JSON.parse(ids);
    return Array.isArray(ids) ? ids.filter((x): x is string => typeof x === "string") : [];
  } catch {
    return [];
  }
}

function same(a: string[], b: string[]): boolean {
  return a.length === b.length && a.every((x, i) => x === b[i]);
}
