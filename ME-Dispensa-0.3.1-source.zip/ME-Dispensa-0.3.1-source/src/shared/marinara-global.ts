// Shared by Dispensa and Fornello: the same file is in both repositories'
// src/shared/. Change it in one, then copy it over with
// `npm run shared -- sync <path to the other repository>`.

// The `marinara` object Marinara hands to full-page extensions.

import { EXTENSION } from "../extension";

export interface MarinaraGlobal {
  version: number;
  extension?: { id: string; name: string; contentHash: string };
  log: { debug(...a: unknown[]): void; info(...a: unknown[]): void; warn(...a: unknown[]): void; error(...a: unknown[]): void };
  storage: {
    get(): Promise<Record<string, unknown>>;
    patch(values: Record<string, unknown>): Promise<Record<string, unknown>>;
    clear?(): Promise<void>;
  };
  fetch?: typeof fetch;
  onCleanup(fn: () => void): void;
  estimateTextTokens?(text: string): number;
}

declare global {
  var marinara: MarinaraGlobal | undefined;
}

/** Works outside Marinara too (tests, previews): falls back to localStorage. */
let resolved: MarinaraGlobal | null = null;

export function getMarinara(): MarinaraGlobal {
  if (resolved) return resolved;
  // Marinara runs the bundle inside `async (marinara) => { ... }`, so the bare
  // name resolves to that parameter, not to a global.
  const scoped = typeof marinara !== "undefined" ? marinara : globalThis.marinara;
  if (scoped) {
    resolved = scoped;
    return scoped;
  }
  const KEY = `${EXTENSION.id}-dev-storage`;
  const read = (): Record<string, unknown> => {
    try {
      return JSON.parse(localStorage.getItem(KEY) ?? "{}");
    } catch {
      return {};
    }
  };
  return {
    version: 0,
    log: console,
    storage: {
      get: async () => read(),
      patch: async (values) => {
        const next = { ...read(), ...values };
        localStorage.setItem(KEY, JSON.stringify(next));
        return next;
      },
    },
    onCleanup: () => {},
  };
}
