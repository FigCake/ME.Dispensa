// window.__dispensa: how other extensions run STscript through Dispensa
// (Fornello's runSlash / triggerSlash, Polyglot's commands).

import type { Host } from "./stscript/host";
import { type ExternalCommand, addExternalCommand } from "./stscript";
import type { CommandRegistry } from "./stscript/registry";
import { Runtime, asText } from "./stscript/interpreter";

/** What other extensions use to run STscript through Dispensa (Fornello's runSlash / triggerSlash). */
export interface DispensaBridge {
  version: 1;
  /** Runs an STscript line (SillyTavern numbering) and returns its pipe. */
  runSlash(text: string): Promise<string>;
  /** Opens Dispensa's window (Fornello's settings link to it). */
  openSettings?(): void;
  /**
   * Adds another extension's command to scripts and QRs (Polyglot's /pg-translate…);
   * returns what takes it out. Dispensa says "dispensa:ready" on window each time it
   * starts, so an extension that started first registers then.
   */
  registerCommand?(def: ExternalCommand): () => void;
}

declare global {
  interface Window {
    __dispensa?: DispensaBridge;
  }
}

/** Puts the bridge on window and says "dispensa:ready"; returns what takes it off again. */
export function publishBridge(host: Host, registry: CommandRegistry, openSettings: () => void): () => void {
  const bridge: DispensaBridge = {
    version: 1,
    runSlash: async (text) => {
      const rt = new Runtime({ host, registry, dialect: "st" });
      return asText((await rt.runScript(String(text ?? ""))).pipe);
    },
    registerCommand: (def) => addExternalCommand(registry, def),
    openSettings,
  };
  window.__dispensa = bridge;
  window.dispatchEvent(new Event("dispensa:ready"));
  return () => {
    if (window.__dispensa === bridge) delete window.__dispensa;
  };
}
