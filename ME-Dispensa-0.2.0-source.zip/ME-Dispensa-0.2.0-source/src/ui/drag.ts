// Reordering a list by dragging a row's handle (mouse or finger), or with
// the arrow keys while the handle has focus.

export const DRAG_CSS = `
.drag { flex: none; width: 22px; padding: 4px 0 !important; justify-content: center; cursor: grab; touch-action: none; color: var(--d-muted); background: none !important; border-color: transparent !important; }
.drag:active { cursor: grabbing; }
.drag svg { width: 14px; height: 14px; }
.dragging { position: relative; z-index: 3; opacity: .92; box-shadow: var(--d-shadow); border-radius: var(--d-radius-sm); background: var(--d-panel-solid); pointer-events: none; }
.drop-before { box-shadow: 0 -2px 0 var(--d-accent); }
.drop-after { box-shadow: 0 2px 0 var(--d-accent); }
`;

/**
 * Makes `handle` drag `row` among its sibling rows (those matching `rowSelector`
 * in the same parent). `move(from, to)` gets the indexes among those rows.
 */
export function dragHandle(handle: HTMLElement, row: HTMLElement, rowSelector: string, move: (from: number, to: number) => void): void {
  handle.setAttribute("aria-roledescription", "순서 바꾸기");
  handle.addEventListener("keydown", (e) => {
    if (e.key !== "ArrowUp" && e.key !== "ArrowDown") return;
    e.preventDefault();
    const rows = siblings(row, rowSelector);
    const from = rows.indexOf(row);
    const to = from + (e.key === "ArrowUp" ? -1 : 1);
    if (to >= 0 && to < rows.length) move(from, to);
  });
  handle.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    const rows = siblings(row, rowSelector);
    const from = rows.indexOf(row);
    const startY = e.clientY;
    let to = from;
    handle.setPointerCapture(e.pointerId);
    row.classList.add("dragging");
    const clear = () => rows.forEach((r) => r.classList.remove("drop-before", "drop-after"));
    const onMove = (ev: PointerEvent) => {
      row.style.transform = `translateY(${ev.clientY - startY}px)`;
      clear();
      to = from;
      rows.forEach((r, i) => {
        if (r === row) return;
        const rect = r.getBoundingClientRect();
        const mid = rect.top + rect.height / 2;
        if (i < from && ev.clientY < mid) to = Math.min(to, i);
        if (i > from && ev.clientY > mid) to = Math.max(to, i);
      });
      if (to !== from) rows[to].classList.add(to < from ? "drop-before" : "drop-after");
    };
    const onUp = () => {
      handle.removeEventListener("pointermove", onMove);
      handle.removeEventListener("pointerup", onUp);
      handle.removeEventListener("pointercancel", onUp);
      row.classList.remove("dragging");
      row.style.transform = "";
      clear();
      if (to !== from) move(from, to);
    };
    handle.addEventListener("pointermove", onMove);
    handle.addEventListener("pointerup", onUp);
    handle.addEventListener("pointercancel", onUp);
  });
}

function siblings(row: HTMLElement, selector: string): HTMLElement[] {
  return row.parentElement ? ([...row.parentElement.children].filter((c) => c.matches(selector)) as HTMLElement[]) : [row];
}

/** Moves one entry of a list from one index to another. */
export function moveTo<T>(list: T[], from: number, to: number): void {
  if (from === to || from < 0 || to < 0 || from >= list.length || to >= list.length) return;
  const [x] = list.splice(from, 1);
  list.splice(to, 0, x);
}
