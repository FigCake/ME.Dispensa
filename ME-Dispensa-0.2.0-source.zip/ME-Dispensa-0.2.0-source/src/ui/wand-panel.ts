// The visualizer menu that opens from the quick bar (🍰): a request box (with
// memos to load in), the 🌟 QRs from the 보관함 and the gallery of made pages.
// It only makes pages; OOC is the 📝 메모장's. Built once and updated in
// place, so a draft survives the bar's re-renders.

import type { QrStore } from "../qr/store";
import type { ArchiveEntry } from "../wand/archive";
import { titleFrom } from "../wand/core";
import { findQr, vizItems, vizQr, vizSet } from "../wand/items";
import type { WandAction, WandItem } from "../wand/model";
import type { WandService, WandViewer } from "../wand/service";
import type { WandStore } from "../wand/store";
import type { Dialogs } from "./dialogs";
import { el, icon } from "./dom";
import { helpTip, segmented } from "./form";

export const WAND_STYLE = `
.wand-pop { width: min(440px, calc(100vw - 16px)); gap: 6px; }
.wand-pop .tabs { display: flex; gap: 4px; align-items: center; }
.wand-pop .tabs > button { width: auto; padding: 3px 10px; }
.wand-pop textarea { width: 100%; min-height: 52px; max-height: 30vh; resize: vertical; }
.wand-pop textarea { font-size: 13px; }
.wand-pop .acts { display: flex; gap: 4px; flex-wrap: nowrap; align-items: center; }
/* action buttons: label in the middle (list rows stay left-aligned) */
.wand-pop .acts button { width: auto; flex: none; justify-content: center; text-align: center; }
.wand-pop .acts button.main { flex: 1 1 auto; }
.wand-pop .acts button > .t { flex: 0 1 auto; text-align: center; }
.wand-pop .folder { font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: var(--d-muted); padding: 4px 4px 0; letter-spacing: .02em; }
.wand-pop .line { display: flex; gap: 3px; align-items: center; }
.wand-pop .line > button:first-child { flex: 1; min-width: 0; }
.wand-pop .line > button.mini { width: auto; flex: none; padding: 4px 6px; background: transparent; border-color: transparent; color: var(--d-muted); font-weight: 500; }
.wand-pop .line > button.mini:hover { background: var(--d-hl-bg); color: var(--d-hl-text); }
.wand-pop .line > button.mini.on { color: var(--d-accent); }
.wand-pop .meta { flex: none; margin-left: auto; font-size: 11px; color: var(--d-muted); font-weight: 500; }
.wand-pop .none { color: var(--d-muted); padding: 6px 4px; font-size: 12px; }
button.wand.busy { border-color: var(--d-btn-border-active); color: var(--d-btn-text-active); animation: pulse 1.2s ease-in-out infinite; }
@keyframes pulse { 50% { opacity: .55; } }
@media (prefers-reduced-motion: reduce) { button.wand.busy { animation: none; } }
`;

export interface WandPanelDeps {
  store: WandStore;
  service: WandService;
  qrStore: QrStore;
  viewer: () => WandViewer | null;
  ui: Dialogs;
  close(): void;
  openSettings(): void;
  /** Memos chosen from the 메모장 (null when none). */
  pickMemos(): Promise<string | null>;
}

const actionIcon = (a: WandAction) => (a === "viz" ? "🌟" : "💬");

export class WandPanel {
  readonly element: HTMLElement;
  private readonly box: HTMLTextAreaElement;
  private readonly list: HTMLElement;
  private tab: "items" | "archive" = "items";
  private archive: ArchiveEntry[] = [];

  constructor(private readonly deps: WandPanelDeps) {
    this.box = el("textarea", {
      part: "wand-input",
      placeholder: "만들 페이지의 주제를 적어요",
      rows: "2",
      "aria-label": "비주얼라이저 요청",
    });
    this.box.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey) && !e.isComposing) {
        e.preventDefault();
        this.runTyped("viz");
      }
    });
    this.list = el("div", { class: "list" });
    this.element = el("div", { class: "pop wand-pop", part: "wand-menu", role: "dialog", "aria-label": "비주얼라이저" });
    this.render();
  }

  /** Called when the menu opens. */
  async refresh(): Promise<void> {
    this.render();
    if (this.tab === "archive") await this.loadArchive();
    setTimeout(() => this.box.focus(), 0);
  }

  render(): void {
    const tabs = el(
      "div",
      { class: "tabs" },
      segmented(
        "wand-menu",
        [
          { value: "items", label: "항목" },
          { value: "archive", label: "갤러리", title: "갤러리: 만든 페이지 모음" },
        ],
        this.tab,
        (v) => this.switchTab(v as "items" | "archive"),
        "비주얼라이저 메뉴",
      ),
      el("span", { class: "meta" }),
      helpTip("· 🌟 페이지 만들기: 적은 주제로 HTML 페이지를 만들어요. (Ctrl+Enter)\n· 📝 메모장: 모아 둔 메모를 골라 주제 칸에 넣어요.\n· [[장소]]나 [[분위기|밝게|어둡게]]처럼 쓰면 실행할 때 물어봐요. [[메모]]는 메모장에서 골라요.\n· ☆: 적은 주제를 🌟 QR로 보관함에 저장해요.\n· 갤러리: 만든 페이지를 모아 두는 곳이에요.", "비주얼라이저 메뉴"),
      el("button", { class: "mini ghost", title: "비주얼라이저 설정", "aria-label": "비주얼라이저 설정", onclick: () => this.deps.openSettings() }, icon("settings")),
    );
    if (this.tab === "archive") {
      this.renderArchive();
      this.element.replaceChildren(tabs, this.list);
      return;
    }
    const acts = el(
      "div",
      { class: "acts" },
      el("button", { part: "wand-memo", title: "메모장에서 골라 주제 칸에 넣기", onclick: () => void this.load() }, "📝 메모장"),
      el("button", { part: "wand-viz", class: "main", title: "적은 주제로 HTML 페이지 만들기 (Ctrl+Enter)", onclick: () => this.runTyped("viz") }, el("span", { class: "t" }, "🌟 페이지 만들기")),
      el("button", { class: "mini ghost", title: "이 주제를 🌟 QR로 보관함에 저장", "aria-label": "🌟 QR로 저장", onclick: () => this.saveTyped() }, icon("star")),
    );
    this.renderItems();
    this.element.replaceChildren(tabs, this.box, acts, this.list);
  }

  private switchTab(tab: "items" | "archive"): void {
    this.tab = tab;
    this.render();
    if (tab === "archive") void this.loadArchive();
  }

  private renderItems(): void {
    const items = vizItems(this.deps.qrStore.value);
    this.list.replaceChildren();
    if (!items.length) {
      this.list.append(el("div", { class: "none" }, "🌟 QR이 없어요. 위에 주제를 적고 ☆을 누르면 보관함에 저장돼요."));
      return;
    }
    const folders = new Map<string, WandItem[]>();
    for (const item of items) {
      const key = item.folder || "";
      if (!folders.has(key)) folders.set(key, []);
      folders.get(key)!.push(item);
    }
    for (const [folder, group] of folders) {
      if (folder) this.list.append(el("div", { class: "folder" }, folder));
      for (const item of group) this.list.append(this.itemLine(item));
    }
  }

  private itemLine(item: WandItem): HTMLElement {
    return el(
      "div",
      { class: "line" },
      el(
        "button",
        { part: "wand-item", title: `🌟 ${item.content.slice(0, 200)}`, onclick: () => this.runItem(item, "viz") },
        el("span", { class: "t" }, `${item.emoji ? `${item.emoji} ` : ""}${item.title}`),
      ),
      el("button", { class: "mini", title: "요청 내용을 위 칸으로 불러오기", "aria-label": "위 칸으로", onclick: () => this.insert(item.content) }, icon("paperclip")),
      el(
        "button",
        {
          class: `mini${item.pinned ? " on" : ""}`,
          title: item.pinned ? "퀵바에서 빼기" : "퀵바에 고정",
          "aria-pressed": String(item.pinned),
          onclick: () =>
            this.deps.qrStore.update((s) => {
              const found = findQr(s, item.id)?.item;
              if (found) found.viz = { ...(found.viz ?? { action: "viz" }), pinned: !item.pinned };
            }),
        },
        icon("pin"),
      ),
    );
  }

  private async loadArchive(): Promise<void> {
    try {
      this.archive = await this.deps.service.archive.list();
    } catch (e) {
      this.archive = [];
      this.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: "갤러리" });
    }
    if (this.tab === "archive") this.renderArchive();
  }

  private renderArchive(): void {
    this.list.replaceChildren();
    if (!this.archive.length) {
      this.list.append(el("div", { class: "none" }, "갤러리가 비어 있어요. 보기 창에서 ☆를 누르면 여기에 모여요."));
      return;
    }
    for (const entry of this.archive) {
      const when = new Date(entry.createdAt);
      const date = `${when.getMonth() + 1}/${when.getDate()} ${String(when.getHours()).padStart(2, "0")}:${String(when.getMinutes()).padStart(2, "0")}`;
      this.list.append(
        el(
          "div",
          { class: "line" },
          el(
            "button",
            {
              part: "wand-archive-item",
              title: [entry.character, entry.chatName].filter(Boolean).join(" · "),
              onclick: () => {
                this.deps.viewer()?.show({ title: entry.title, kind: entry.kind, text: entry.text, archivedId: entry.id });
                this.deps.close();
              },
            },
            el("span", { class: "t" }, `${actionIcon(entry.kind)} ${entry.title}`),
            el("span", { class: "meta" }, date),
          ),
          el(
            "button",
            {
              class: "mini",
              title: "지우기",
              "aria-label": "지우기",
              onclick: async () => {
                if (!(await this.deps.ui.confirm(`갤러리에서 "${entry.title}"을(를) 지울까요?`))) return;
                await this.deps.service.archive.remove(entry.id);
                await this.loadArchive();
              },
            },
            icon("trash"),
          ),
        ),
      );
    }
  }

  private runItem(item: WandItem, action: WandAction): void {
    this.deps.close();
    void this.deps.service.runItem(item, action);
  }

  private runTyped(action: WandAction): void {
    const text = this.box.value;
    if (!text.trim()) {
      this.box.focus();
      return;
    }
    this.deps.close();
    // keep the draft when the run was cancelled or failed
    void this.deps.service.run(action, text).then((sent) => {
      if (sent && this.box.value === text) this.box.value = "";
    });
  }

  private saveTyped(): void {
    const text = this.box.value.trim();
    if (!text) return;
    const qr = vizQr({ title: titleFrom(text) || "새 🌟 QR", content: text, defaultAction: "viz" });
    this.deps.qrStore.update((s) => vizSet(s).items.unshift(qr));
    this.deps.ui.toast(`"${qr.label}"을(를) 🌟 QR로 보관함에 저장했어요.`, "success", { title: "🌟" });
    this.render();
  }

  private insert(text: string): void {
    const box = this.box;
    const start = box.selectionStart ?? box.value.length;
    const end = box.selectionEnd ?? start;
    const before = box.value.slice(0, start);
    const gap = before && !before.endsWith("\n") ? "\n\n" : "";
    box.value = before + gap + text + box.value.slice(end);
    const caret = (before + gap + text).length;
    box.focus();
    box.setSelectionRange(caret, caret);
  }

  /** Memos from the 메모장 into the box. */
  private async load(): Promise<void> {
    const text = await this.deps.pickMemos();
    if (text) this.insert(text);
    else this.box.focus();
  }
}
