// The 🌟 tab of the Dispensa window: page defaults and the 슈퍼비즈 chunks.
// (The 🌟 QRs live in the 보관함 tab; how OOC is sent and its wrappers show
// in the 📝 tab.)

import type { HostUI } from "../stscript/host";
import type { PresetChunk } from "../wand/core";
import { OOC_MODES, type OocMode, VIZ_OUTPUTS, type VizOutput, type WandItem, type WandSettings, type WandState, defaultPreset, newWandId, normalizeWandState } from "../wand/model";
import type { WandStore } from "../wand/store";
import { el, icon } from "./dom";
import { helpTip, section, setting, toggle } from "./form";

export const WAND_SETTINGS_STYLE = `
.wand-settings { display: flex; flex-direction: column; gap: 12px; }
.wand-settings .card { border: 1px solid var(--d-line); border-radius: var(--d-radius); padding: 12px 14px; display: flex; flex-direction: column; gap: 6px; }
.wand-settings .chunk { border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); padding: 6px 8px; display: flex; flex-direction: column; gap: 6px; transition: opacity .15s ease; }
.wand-settings .chunk.off { opacity: .55; }
.wand-settings textarea.short { min-height: 90px; }
.wand-settings .icon-input { width: 3.4em !important; min-width: 0 !important; text-align: center; }
.wand-settings details.more > summary { cursor: pointer; color: var(--d-muted); font-size: 12px; padding: 4px 0; list-style: none; display: flex; align-items: center; gap: 6px; }
.wand-settings details.more > summary::before { content: "▸"; transition: transform .15s ease; }
.wand-settings details.more[open] > summary::before { transform: rotate(90deg); }
.wand-settings .field-h { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--d-muted); }
`;

type Connection = { id: string; name: string };

export interface WandSettingsDeps {
  store: WandStore;
  ui: HostUI;
  connections(): Promise<Connection[]>;
  rerender(): void;
  /** Adds items from an old backup to the QR 보관함 as 🌟 QRs. */
  importItems(items: WandItem[]): void;
}

function select<T extends string>(key: string, entries: [T, string][], value: string, onChange: (v: T) => void, label = ""): HTMLSelectElement {
  return el(
    "select",
    { "data-key": key, "aria-label": label || undefined, onchange: (e: Event) => onChange((e.target as HTMLSelectElement).value as T) },
    ...entries.map(([v, text]) => el("option", { value: v, selected: v === value }, text)),
  );
}

const MODE_LABEL: Record<PresetChunk["mode"], string> = { all: "항상", full: "풀 모드만", lite: "라이트 모드만" };
const VIZ_MODES: [WandSettings["vizMode"], string][] = [
  ["auto", "자동"],
  ["full", "풀 (스크립트 포함)"],
  ["lite", "라이트 (HTML·CSS)"],
];

// Shown behind the small ? buttons: for someone seeing the setting for the first time
export const VIZ_HELP = {
  vizMode: "어떤 페이지를 만들지 정해요.\n· 자동: Fornello가 있으면 풀, 없으면 라이트\n· 풀: 버튼·애니메이션이 움직이는 페이지 (Fornello 필요)\n· 라이트: HTML·CSS만 쓴 페이지",
  vizOutput: "만든 페이지를 어디에 보여 줄지 정해요.\n· 보기 창: 퀵바 위 작은 창. 마음에 들면 채팅에 넣을 수 있어요.\n· 채팅: 바로 캐릭터 메시지로 올려요.",
  language: "페이지 글을 쓸 언어예요. 예: Korean, English",
  autoArchive: "채팅에 올린 페이지도 갤러리에 모아요. 갤러리는 이 브라우저에만 남아요.",
  external: "보기 창의 페이지가 인터넷의 글꼴·그림·라이브러리를 불러올 수 있게 해요.",
  oocMode: "💬 OOC를 어떻게 보낼지 정해요.\n· 결과물 받기: AI가 요청대로 만든 글이 캐릭터 메시지로 올라와요. 커뮤니티 반응·미니 게임처럼 RP 밖의 결과물에 맞아요.\n· 전개에 반영하기: 캐릭터가 평소처럼 다음 답을 쓰면서 요청한 방향으로 이야기를 이어 가요(마리나라 /guided).\n· 직접 보내기: 요청 글이 내 메시지로 전송되고 남아요.\n· 입력창에 넣기: 입력창에만 넣어요. 고쳐서 직접 보내요.\n앞의 둘은 요청 글이 채팅에 남지 않아요.",
  wrapper: "OOC 앞뒤에 붙일 문구예요. 아래 '감싸개'에서 고칠 수 있어요.",
  connection: "만들 때 쓸 AI 연결이에요. 채팅과 다른 모델을 쓰고 싶을 때 골라요.",
  bubble: "퀵바에 비주얼라이저 메뉴를 여는 버블을 보여요. 옆 칸에서 아이콘(이모지)을 바꿀 수 있어요.",
  content: "만들 페이지의 주제예요. {{char}}, {{user}} 같은 매크로를 쓸 수 있어요. [[장소]]나 [[분위기|밝게|어둡게]]처럼 쓰면 실행할 때 물어보고, [[메모]]는 메모장에서 골라요.",
  folder: "🌟 메뉴에서 같은 이름끼리 묶어서 보여요. 비우면 세트 이름으로 묶어요.",
  itemOptions: "비워 두면 비주얼라이저 설정의 기본값을 따라요.",
  preset: "페이지를 만들 때 AI에게 보내는 지침이에요. 조각마다 켜고 끄거나 고칠 수 있어요.",
  wrap: "지침 전체를 <System> … </System>으로 감싸서 보내요. 대부분 켜 두면 돼요.",
  chunkText: "{{주제}} 자리에 요청이, {{언어}} 자리에 결과 언어가 들어가요.",
  chunkMode: "이 조각을 언제 넣을지 정해요. 풀 모드만 / 라이트 모드만을 고르면 그 모드에서만 들어가요.",
  wrappers: "OOC를 보낼 때 앞뒤에 붙이는 문구예요. {{내용}} 자리에 OOC가 들어가요. ({{언어}}를 넣으면 그 자리에 결과 언어가 들어가요.)",
  backup: "본체·감싸개·기본값을 파일 하나로 저장하거나 되돌려요. 🌟 QR은 보관함에서 세트로 내보내요.",
};

export class WandSettingsView {
  private openChunk: string | null = null;
  private connections: Connection[] | null = null;

  constructor(private readonly deps: WandSettingsDeps) {}

  private get state(): WandState {
    return this.deps.store.value;
  }

  private update(fn: (s: WandState) => void): void {
    this.deps.store.update(fn);
  }

  /** The AI connections to choose from ("" = `inherit`); loaded once, then redrawn. */
  connectionEntries(inherit: string): [string, string][] {
    if (!this.connections) {
      this.connections = [];
      void this.deps
        .connections()
        .then((list) => {
          this.connections = list;
          this.deps.rerender();
        })
        .catch(() => undefined);
    }
    return [["", inherit], ...this.connections.map((c): [string, string] => [c.id, c.name])];
  }

  render(): HTMLElement {
    return el("div", { class: "col wand-settings" }, this.defaults(), this.presetCard(), this.backup());
  }

  /** How the 메모장 sends OOC (its tab shows these): the way and the wrappers. */
  oocCards(): HTMLElement[] {
    const s = this.state.settings;
    const set = (fn: (st: WandState["settings"]) => void) => this.update((st) => fn(st.settings));
    const wrappers = this.state.wrappers.map((w): [string, string] => [w.id, w.name]);
    return [
      el(
        "div",
        { class: "card" },
        section(
          "💬 OOC 보내기",
          undefined,
          [],
          setting("보내는 방식", select("wand-ooc-mode", Object.entries(OOC_MODES) as [OocMode, string][], s.oocMode, (v) => set((x) => (x.oocMode = v)), "보내는 방식"), VIZ_HELP.oocMode),
          setting("감싸개", select("wand-wrapper", wrappers, s.wrapperId, (v) => set((x) => (x.wrapperId = v)), "감싸개"), VIZ_HELP.wrapper),
        ),
      ),
      this.wrapperCard(),
    ];
  }

  private defaults(): HTMLElement {
    const s = this.state.settings;
    const set = (fn: (st: WandState["settings"]) => void) => this.update((st) => fn(st.settings));
    return el(
      "div",
      { class: "card" },
      section(
        "🌟 페이지 만들기",
        undefined,
        [],
        setting("모드", select("wand-viz-mode", VIZ_MODES, s.vizMode, (v) => set((x) => (x.vizMode = v)), "모드"), VIZ_HELP.vizMode),
        setting("결과를 보여 줄 곳", select("wand-viz-output", Object.entries(VIZ_OUTPUTS) as [VizOutput, string][], s.vizOutput, (v) => set((x) => (x.vizOutput = v)), "결과를 보여 줄 곳"), VIZ_HELP.vizOutput),
        setting("결과 언어", el("input", { type: "text", value: s.language, "data-key": "wand-language", "aria-label": "결과 언어", oninput: (e: Event) => set((x) => (x.language = (e.target as HTMLInputElement).value)) }), VIZ_HELP.language),
        setting("채팅에 올린 페이지도 갤러리에", toggle(s.autoArchive, (v) => set((x) => (x.autoArchive = v)), "채팅에 올린 페이지도 갤러리에", "wand-auto-archive"), VIZ_HELP.autoArchive),
        setting("바깥 자료 불러오기 허용", toggle(s.allowExternal, (v) => set((x) => (x.allowExternal = v)), "바깥 자료 불러오기 허용", "wand-external"), VIZ_HELP.external),
      ),
      section(
        "공통",
        undefined,
        [],
        setting("AI 연결", select("wand-connection", this.connectionEntries("채팅과 같은 연결"), s.connectionId, (v) => set((x) => (x.connectionId = v)), "AI 연결"), VIZ_HELP.connection),
        setting(
          "퀵바 버블",
          [
            el("input", { type: "text", class: "icon-input", value: s.barIcon, "data-key": "wand-bar-icon", maxlength: "8", "aria-label": "버블 아이콘", oninput: (e: Event) => set((x) => (x.barIcon = (e.target as HTMLInputElement).value.trim() || "🍰")) }),
            toggle(s.showButton, (v) => set((x) => (x.showButton = v)), "퀵바 버블 보이기", "wand-show"),
          ],
          VIZ_HELP.bubble,
        ),
      ),
    );
  }

  private presetCard(): HTMLElement {
    const preset = this.state.preset;
    const mutateChunk = (id: string, fn: (c: PresetChunk) => void) =>
      this.update((s) => {
        const c = s.preset.chunks.find((x) => x.id === id);
        if (c) fn(c);
      });
    const chunks = preset.chunks.map((chunk, index) => {
      const open = this.openChunk === chunk.id;
      const box = el(
        "div",
        { class: `chunk${chunk.enabled ? "" : " off"}` },
        el(
          "div",
          { class: "row" },
          toggle(chunk.enabled, (v) => mutateChunk(chunk.id, (c) => (c.enabled = v)), `${chunk.name} 켜기`),
          el(
            "button",
            {
              class: "entry grow",
              "aria-expanded": String(open),
              onclick: () => {
                this.openChunk = open ? null : chunk.id;
                this.deps.rerender();
              },
            },
            chunk.name,
            el("span", { class: "meta" }, MODE_LABEL[chunk.mode] + (chunk.needs === "fornello" ? " · Fornello 있을 때" : "")),
          ),
          el("button", { class: "icon", title: "위로", "aria-label": "위로", disabled: index === 0, onclick: () => this.moveChunk(index, -1) }, icon("arrow-up")),
          el("button", { class: "icon", title: "아래로", "aria-label": "아래로", disabled: index === preset.chunks.length - 1, onclick: () => this.moveChunk(index, 1) }, icon("arrow-down")),
        ),
      );
      if (open) {
        const ta = el("textarea", { "data-key": `chunk-${chunk.id}`, spellcheck: "false", "aria-label": `${chunk.name} 내용`, oninput: (e: Event) => mutateChunk(chunk.id, (c) => (c.text = (e.target as HTMLTextAreaElement).value)) });
        ta.value = chunk.text;
        box.append(
          el(
            "div",
            { class: "row" },
            el("label", { class: "grow" }, "이름", el("input", { type: "text", value: chunk.name, "data-key": `chunk-name-${chunk.id}`, oninput: (e: Event) => mutateChunk(chunk.id, (c) => (c.name = (e.target as HTMLInputElement).value)) })),
            el(
              "label",
              {},
              el("span", { class: "field-h" }, "쓰는 때", helpTip(VIZ_HELP.chunkMode, "쓰는 때")),
              select(`chunk-mode-${chunk.id}`, Object.entries(MODE_LABEL) as [PresetChunk["mode"], string][], chunk.mode, (v) => mutateChunk(chunk.id, (c) => (c.mode = v)), "쓰는 때"),
            ),
          ),
          el("div", { class: "field-h" }, "내용", helpTip(VIZ_HELP.chunkText, "내용")),
          ta,
          el(
            "div",
            { class: "row" },
            el("span", { class: "grow" }),
            el("button", { class: "danger", onclick: () => this.update((s) => (s.preset.chunks = s.preset.chunks.filter((c) => c.id !== chunk.id))) }, icon("trash"), "조각 지우기"),
          ),
        );
      }
      return box;
    });
    const add = el(
      "button",
      {
        onclick: () => {
          const chunk: PresetChunk = { id: newWandId("chunk"), name: "새 조각", mode: "all", enabled: true, text: "" };
          this.update((s) => s.preset.chunks.push(chunk));
          this.openChunk = chunk.id;
        },
      },
      icon("plus"),
      "조각 추가",
    );
    const reset = el(
      "button",
      {
        title: "슈퍼비즈 원래 문구로 되돌려요",
        onclick: async () => {
          if (!(await this.deps.ui.popup("본체를 슈퍼비즈 기본값으로 되돌릴까요? 고친 내용과 추가한 조각이 사라져요.", { okButton: "되돌리기", cancelButton: "취소" }))) return;
          this.openChunk = null;
          this.update((s) => (s.preset = defaultPreset()));
        },
      },
      icon("refresh-cw"),
      "기본값으로",
    );
    return el(
      "div",
      { class: "card" },
      section(
        `🌟 본체: ${preset.name}`,
        VIZ_HELP.preset,
        [add, reset],
        setting("<System>으로 감싸기", toggle(preset.wrap, (v) => this.update((s) => (s.preset.wrap = v)), "<System>으로 감싸기"), VIZ_HELP.wrap),
        ...chunks,
      ),
    );
  }

  private moveChunk(index: number, delta: number): void {
    this.update((s) => {
      const [c] = s.preset.chunks.splice(index, 1);
      s.preset.chunks.splice(index + delta, 0, c);
    });
  }

  private wrapperCard(): HTMLElement {
    const wrappers = this.state.wrappers;
    const add = el("button", { onclick: () => this.update((s) => s.wrappers.push({ id: newWandId("wrap"), name: "새 감싸개", template: "{{내용}}" })) }, icon("plus"), "추가");
    return el(
      "div",
      { class: "card" },
      section(
        "💬 감싸개",
        VIZ_HELP.wrappers,
        [add],
        ...wrappers.map((w) => {
          const ta = el("textarea", {
            class: "short",
            "data-key": `wrap-${w.id}`,
            spellcheck: "false",
            "aria-label": `${w.name} 문구`,
            oninput: (e: Event) => this.update((s) => (s.wrappers.find((x) => x.id === w.id)!.template = (e.target as HTMLTextAreaElement).value)),
          });
          ta.value = w.template;
          return el(
            "div",
            { class: "chunk" },
            el(
              "div",
              { class: "row" },
              el("input", { type: "text", class: "grow", value: w.name, "data-key": `wrap-name-${w.id}`, "aria-label": "감싸개 이름", oninput: (e: Event) => this.update((s) => (s.wrappers.find((x) => x.id === w.id)!.name = (e.target as HTMLInputElement).value)) }),
              el("button", { class: "icon danger", title: "지우기", "aria-label": "지우기", disabled: wrappers.length <= 1, onclick: () => this.update((s) => (s.wrappers = s.wrappers.filter((x) => x.id !== w.id))) }, icon("trash")),
            ),
            ta,
          );
        }),
      ),
    );
  }

  private backup(): HTMLElement {
    return el(
      "div",
      { class: "card" },
      section(
        "백업",
        VIZ_HELP.backup,
        [el("button", { onclick: () => this.exportJson() }, icon("upload"), "내보내기"), el("button", { onclick: () => this.importJson() }, icon("download"), "가져오기")],
      ),
    );
  }

  private exportJson(): void {
    const data = JSON.stringify({ format: "dispensa-wand", ...this.state }, null, 2);
    const url = URL.createObjectURL(new Blob([data], { type: "application/json" }));
    const a = el("a", { href: url, download: "dispensa.wand.json" });
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  private importJson(): void {
    const input = el("input", { type: "file", accept: ".json,application/json" });
    input.addEventListener("change", async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const json = JSON.parse(await file.text()) as Record<string, unknown>;
        if (json.format !== "dispensa-wand") throw new Error("Dispensa 비주얼라이저 파일(.wand.json)이 아니에요.");
        const incoming = normalizeWandState(json);
        // files from before the items moved: their items become 🌟 QRs in the 보관함
        const items = Array.isArray(json.items) && json.itemsMoved !== true ? incoming.items : [];
        const extra = items.length ? ` 항목 ${items.length}개는 보관함에 🌟 QR로 들어가요.` : "";
        if (!(await this.deps.ui.popup(`본체·감싸개·기본값을 이 파일로 바꿀까요?${extra}`, { okButton: "바꾸기", cancelButton: "취소" }))) return;
        this.update((s) => Object.assign(s, incoming, { items: [], itemsMoved: true }));
        if (items.length) this.deps.importItems(items);
        this.deps.ui.toast("비주얼라이저 설정을 가져왔어요.", "success");
      } catch (e) {
        this.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: "가져오기" });
      }
    });
    input.click();
  }
}
