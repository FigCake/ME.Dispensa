// The 🌟 viewer: a panel right above the quick bar that shows a result. HTML
// pages run in sandboxed frames (scripts allowed, no access to Marinara).

import { buildSrcdoc, extractHtmlBlocks, hasScripts, normalizeOutput } from "../wand/core";
import type { ViewerEntry, WandService, WandViewer } from "../wand/service";
import type { WandStore } from "../wand/store";
import { capturePage, saveBlob } from "./capture";
import type { Dialogs } from "./dialogs";
import { el, icon } from "./dom";
import { CONTROLS, THEME_TOKENS } from "./theme";

const STYLE = `
${THEME_TOKENS}
:host { display: block; }
* { box-sizing: border-box; }
${CONTROLS}
.panel { margin: 0 0 6px; overflow: hidden; display: flex; flex-direction: column; max-height: 70vh;
  font: 13px/1.3 var(--d-font); color: var(--d-text);
  background: var(--d-shell-bg); border: var(--d-shell-border); border-radius: var(--d-shell-radius);
  box-shadow: var(--d-shell-shadow); backdrop-filter: var(--d-shell-blur); -webkit-backdrop-filter: var(--d-shell-blur); }
.panel.full { position: fixed; inset: 8px; z-index: 2147482500; max-height: none; background: var(--d-panel-solid); box-shadow: 0 20px 60px rgb(0 0 0 / .45); }
.head { display: flex; align-items: center; gap: 4px; padding: 4px 6px; border-bottom: 1px solid var(--d-divider); flex-wrap: wrap; }
.title { flex: 1; min-width: 80px; font-weight: 600; color: var(--d-title); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; padding: 0 4px; }
.head button { padding: 4px 8px; }
.head button.ghost { padding: 4px 6px; }
button.warn { border-color: #e6a23c; color: #e6a23c; }
.chip-warn { font-size: 11px; padding: 2px 7px; border-radius: 999px; border: 1px solid #e6a23c; color: #e6a23c; cursor: help; }
.pages { display: flex; gap: 4px; padding: 4px 6px 0; flex-wrap: wrap; }
.pages button { padding: 2px 8px; font-size: 12px; }
.body { overflow: auto; flex: 1; min-height: 80px; }
iframe { display: block; width: 100%; height: 360px; border: 0; background: #fff; }
.panel.full iframe { height: 100% !important; }
.panel.full .body { display: flex; flex-direction: column; }
.panel.full .body iframe { flex: 1; }
pre { margin: 0; padding: 10px 12px; white-space: pre-wrap; word-break: break-word; font: inherit; }
svg { width: 15px; height: 15px; flex: none; }
`;

/**
 * Marinara's Content-Security-Policy blocks inline scripts, and frames built
 * from inline HTML inherit it. Check once whether a page's scripts can run.
 */
let scriptProbe: Promise<boolean> | null = null;
function scriptsRun(): Promise<boolean> {
  scriptProbe ??= new Promise((resolve) => {
    const token = `probe${Math.random().toString(36).slice(2)}`;
    const frame = document.createElement("iframe");
    frame.setAttribute("sandbox", "allow-scripts");
    frame.style.cssText = "position:fixed;width:1px;height:1px;left:-10px;top:-10px;border:0;opacity:0;";
    const done = (ok: boolean) => {
      window.removeEventListener("message", onMessage);
      clearTimeout(timer);
      frame.remove();
      resolve(ok);
    };
    const onMessage = (e: MessageEvent) => {
      if ((e.data as { dispensaProbe?: string } | null)?.dispensaProbe === token) done(true);
    };
    window.addEventListener("message", onMessage);
    const timer = setTimeout(() => done(false), 1500);
    frame.srcdoc = `<script>parent.postMessage({dispensaProbe:${JSON.stringify(token)}},"*")</script>`;
    document.body.append(frame);
  });
  return scriptProbe;
}

/** Fornello (a separate extension) runs pages with their scripts; see its README. */
export interface FornelloBridge {
  version: number;
  mount(container: HTMLElement, code: string, options?: { run?: boolean }): { dispose(): void };
  openSettings?(): void;
}
export const fornello = (): FornelloBridge | null => {
  const bridge = (window as { __fornello?: FornelloBridge }).__fornello;
  return bridge && bridge.version === 1 && typeof bridge.mount === "function" ? bridge : null;
};

export class ViewerPanel implements WandViewer {
  readonly element: HTMLElement;
  private readonly root: ShadowRoot;
  private entry: ViewerEntry | null = null;
  private page = 0;
  private full = false;
  private token = "";
  private frame: HTMLIFrameElement | null = null;
  private scripts: boolean | null = null;
  private resize: ResizeObserver | null = null;
  private mounted: { dispose(): void } | null = null;

  constructor(
    private readonly deps: { service: WandService; store: WandStore; ui: Dialogs; onChange?: () => void },
  ) {
    this.element = document.createElement("div");
    this.element.id = "dispensa-viewer";
    this.root = this.element.attachShadow({ mode: "open" });
    window.addEventListener("message", this.onMessage);
    document.addEventListener("keydown", this.onKey, true);
  }

  get open(): boolean {
    return this.entry !== null;
  }

  dispose(): void {
    window.removeEventListener("message", this.onMessage);
    document.removeEventListener("keydown", this.onKey, true);
    this.element.remove();
  }

  show(entry: ViewerEntry): void {
    this.entry = { ...entry };
    this.page = 0;
    this.render();
    this.deps.onChange?.();
    if (this.scripts === null) {
      void scriptsRun().then((ok) => {
        this.scripts = ok;
        // with Fornello the answer changes nothing on screen; redrawing would restart its page
        if (this.entry && !fornello()) this.render();
      });
    }
  }

  close(): void {
    this.mounted?.dispose();
    this.mounted = null;
    this.resize?.disconnect();
    this.resize = null;
    this.entry = null;
    this.full = false;
    this.frame = null;
    this.root.replaceChildren();
    this.deps.onChange?.();
  }

  private readonly onKey = (e: KeyboardEvent) => {
    if (e.key === "Escape" && this.full) {
      e.stopPropagation();
      this.full = false;
      this.render();
    }
  };

  private readonly onMessage = (event: MessageEvent) => {
    const data = event.data as { wandHeight?: unknown; token?: unknown } | null;
    if (!data || typeof data.wandHeight !== "number" || data.token !== this.token || !this.frame) return;
    if (event.source !== this.frame.contentWindow || this.full) return;
    const max = Math.max(200, this.deps.store.value.settings.maxFrameHeight);
    this.frame.style.height = `${Math.min(max, Math.max(120, Math.ceil(data.wandHeight) + 4))}px`;
  };

  private render(): void {
    const entry = this.entry;
    if (!entry) return;
    const style = document.createElement("style");
    style.textContent = STYLE;
    const out = normalizeOutput(entry.text);
    const blocks = extractHtmlBlocks(out.text);
    this.page = Math.min(this.page, Math.max(0, blocks.length - 1));
    const current = blocks[this.page];
    const busy = !!this.deps.service.busy;
    const head = el(
      "div",
      { class: "head" },
      el("span", { class: "title", title: entry.title }, `${entry.kind === "viz" ? "🌟" : "💬"} ${entry.title}`),
      current && this.scripts === false && !fornello() && hasScripts(current.code)
        ? el(
            "span",
            {
              class: "chip-warn",
              title: "마리나라가 페이지 속 스크립트를 막아서 버튼·애니메이션이 움직이지 않아요. Fornello를 설치하면 움직여요.",
            },
            "스크립트 꺼짐",
          )
        : null,
      current && !current.complete
        ? el("button", { class: "warn", part: "viewer-continue", title: "HTML이 중간에 끊겼어요. 이어서 써요.", disabled: busy, onclick: () => void this.continue() }, icon("refresh-cw"), "이어 쓰기")
        : null,
      el(
        "button",
        { class: entry.archivedId ? "ghost on" : "ghost", part: "viewer-save", title: entry.archivedId ? "갤러리에 있어요" : "갤러리에 저장", "aria-label": "갤러리에 저장", onclick: () => void this.save() },
        icon("star"),
      ),
      el("button", { class: "ghost", part: "viewer-post", title: "채팅에 캐릭터 메시지로 넣기", "aria-label": "채팅에 넣기", disabled: busy, onclick: () => void this.postToChat() }, icon("send")),
      current ? el("button", { class: "ghost", title: "HTML 파일로 받기", "aria-label": "HTML 파일로 받기", onclick: () => this.download(current.code, current.title || entry.title) }, icon("download")) : null,
      current
        ? el("button", { class: "ghost", part: "viewer-image", title: "이미지(PNG)로 저장", "aria-label": "이미지로 저장", onclick: (e: Event) => void this.saveImage(e.currentTarget as HTMLButtonElement, current.code, current.title || entry.title) }, icon("image"))
        : null,
      el("button", { class: "ghost", title: this.full ? "작게 보기" : "크게 보기", "aria-label": "크게 보기", onclick: () => this.toggleFull() }, icon(this.full ? "minimize" : "maximize")),
      entry.archivedId ? el("button", { class: "ghost", part: "viewer-delete", title: "갤러리에서 지우기", "aria-label": "갤러리에서 지우기", onclick: () => void this.remove() }, icon("trash")) : null,
      el("button", { class: "ghost", part: "viewer-close", title: "닫기", "aria-label": "닫기", onclick: () => this.close() }, icon("x")),
    );
    const panel = el("div", { class: `panel${this.full ? " full" : ""}`, part: "viewer", role: "region", "aria-label": "비주얼라이저 보기" }, head);
    if (blocks.length > 1) {
      panel.append(
        el(
          "div",
          { class: "pages" },
          ...blocks.map((b, i) => el("button", { class: i === this.page ? "sel" : "", title: b.title, onclick: () => ((this.page = i), this.render()) }, b.title ? `${i + 1}. ${b.title.slice(0, 20)}` : String(i + 1))),
        ),
      );
    }
    const body = el("div", { class: "body" });
    this.resize?.disconnect();
    this.resize = null;
    this.mounted?.dispose();
    this.mounted = null;
    const bridge = fornello();
    if (current && bridge) {
      // Fornello shows the page and runs its scripts when the person allows it
      this.frame = null;
      const holder = el("div", { class: "fornello" });
      body.append(holder);
      this.mounted = bridge.mount(holder, current.code);
    } else if (current) {
      this.token = `v${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
      // Scripts blocked: no script can run in the frame, so it may share our
      // origin and we measure its height from here instead.
      const noScripts = this.scripts === false;
      const frame = el("iframe", {
        sandbox: noScripts ? "allow-same-origin allow-popups allow-popups-to-escape-sandbox" : "allow-scripts allow-popups allow-modals allow-forms allow-downloads",
        title: current.title || entry.title,
        referrerpolicy: "no-referrer",
      });
      frame.srcdoc = buildSrcdoc(current.code, { token: this.token, allowExternal: this.deps.store.value.settings.allowExternal });
      if (noScripts) frame.addEventListener("load", () => this.measure(frame));
      this.frame = frame;
      body.append(frame);
    } else {
      this.frame = null;
      body.append(el("pre", {}, out.text));
    }
    panel.append(body);
    this.root.replaceChildren(style, panel);
  }

  private measure(frame: HTMLIFrameElement): void {
    const doc = frame.contentDocument;
    if (!doc?.documentElement) return;
    const fit = () => {
      if (this.full) return;
      // documentElement never reports less than the frame itself, so measure the body
      const body = doc.body;
      if (!body) return;
      const cs = doc.defaultView?.getComputedStyle(body);
      const margin = cs ? parseFloat(cs.marginTop) + parseFloat(cs.marginBottom) : 0;
      const h = Math.ceil(body.scrollHeight + margin);
      const max = Math.max(200, this.deps.store.value.settings.maxFrameHeight);
      frame.style.height = `${Math.min(max, Math.max(120, h + 4))}px`;
    };
    fit();
    this.resize?.disconnect();
    this.resize = new ResizeObserver(fit);
    if (doc.body) this.resize.observe(doc.body);
  }

  private toggleFull(): void {
    this.full = !this.full;
    this.render();
  }

  private async continue(): Promise<void> {
    if (!this.entry) return;
    const next = await this.deps.service.continueEntry(this.entry);
    if (next && this.entry) {
      this.entry = next;
      this.render();
    }
  }

  private async save(): Promise<void> {
    if (!this.entry || this.entry.archivedId) return;
    try {
      await this.deps.service.save(this.entry);
      this.deps.ui.toast("갤러리에 저장했어요.", "success", { title: "🌟" });
    } catch (e) {
      this.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: "갤러리" });
    }
    this.render();
  }

  private async postToChat(): Promise<void> {
    if (!this.entry) return;
    const entry = this.entry;
    if (await this.deps.service.postToChat(entry)) {
      if (this.deps.store.value.settings.autoArchive && !entry.archivedId) await this.deps.service.save(entry).catch(() => undefined);
      this.deps.ui.toast("채팅에 넣었어요.", "success", { title: "🌟" });
    }
    this.render();
  }

  private async remove(): Promise<void> {
    const entry = this.entry;
    if (!entry?.archivedId) return;
    if (!(await this.deps.ui.confirm(`갤러리에서 "${entry.title}"을(를) 지울까요?`))) return;
    await this.deps.service.archive.remove(entry.archivedId);
    this.close();
  }

  private download(code: string, title: string): void {
    saveBlob(new Blob([code], { type: "text/html;charset=utf-8" }), `${fileName(title)}.html`);
  }

  /** The page as it looks now, Fornello's running page included. */
  private async saveImage(button: HTMLButtonElement, code: string, title: string): Promise<void> {
    button.disabled = true;
    try {
      // Fornello's page frame sits in its block's (open) shadow root
      const frame = this.frame ?? this.root.querySelector<HTMLElement>(".fornello")?.querySelector(".fornello-block")?.shadowRoot?.querySelector("iframe") ?? null;
      saveBlob(await capturePage(frame, code), `${fileName(title)}.png`);
    } catch (error) {
      this.deps.ui.toast(`이미지로 저장하지 못했어요: ${error instanceof Error ? error.message : String(error)}`, "warning", { title: "🌟" });
    } finally {
      button.disabled = false;
    }
  }
}

const fileName = (title: string) => title.replace(/[\\/:*?"<>|]+/g, " ").trim() || "wand";
