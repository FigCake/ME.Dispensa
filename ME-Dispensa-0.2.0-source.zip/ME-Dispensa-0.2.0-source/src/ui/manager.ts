// QR manager: sets (folders) on the left, the selected set's QRs and the
// editor on the right. Import from SillyTavern, paste OOC notes, export.

import {
  type ImportReport,
  type SetNames,
  MQR_ITEM_FORMAT,
  applyConversion,
  exportMarinara,
  exportMarinaraItem,
  exportSillyTavern,
  findUnsupported,
  foreignCommands,
  importAny,
  importMarinara,
  nonSillyTavernCommands,
  resolveLinks,
  stExportItem,
} from "../qr/import";
import { type AutoTrigger, type QrItem, type QrSet, type QrState, newId, newItem, newSet } from "../qr/model";
import { type ChatScope, NO_CHAT, elsewhere, forgetSet, isOnForCharacter, isOnForChat, setForCharacter, setForChat } from "../qr/scopes";
import type { Debugger } from "../stscript/interpreter";
import { DRAG_CSS, dragHandle, moveTo } from "./drag";
import { RUN_PANEL_CSS, RunPanel } from "./run-panel";
import { SCRIPT_EDITOR_CSS, ScriptEditor } from "./script-editor";
import { MEMO_VIEW_CSS, MemoView } from "./memo-view";
import type { MemoStore } from "../memo/store";
import { memoLine } from "../memo/model";
import type { QrStore } from "../qr/store";
import type { CommandDef, CommandRegistry } from "../stscript/registry";
import type { HostUI } from "../stscript/host";
import { api } from "../host/api";
import type { WandStore } from "../wand/store";
import { el, icon } from "./dom";
import { FORM_CSS, helpTip, section, segmented, setting, toggle } from "./form";
import { CONTROLS, THEME_TOKENS } from "./theme";
import { fornello } from "./viewer";
import { VIZ_HELP, WAND_SETTINGS_STYLE, WandSettingsView } from "./wand-settings";
import { moveItemsToQr, vizQr } from "../wand/items";
import { VIZ_OUTPUTS, type VizOutput } from "../wand/model";

export interface ManagerDeps {
  store: QrStore;
  registry: CommandRegistry;
  ui: HostUI;
  run(set: QrSet, item: QrItem): void;
  /** Run from the editor (▶ / 🐞): the result comes back. */
  runInEditor(set: QrSet, item: QrItem, options: { signal: AbortSignal; debug?: Debugger }): Promise<{ pipe: string; aborted?: string }>;
  /** A character's name, for the "this character" switches. */
  characterName(id: string): Promise<string>;
  wandStore?: WandStore;
  /** The 📝 메모장 and what its memos can do. */
  memo?: {
    store: MemoStore;
    sendOoc(text: string): Promise<boolean>;
    putInInput(text: string): void;
    makePage(text: string): Promise<boolean>;
  };
}

export type ManagerTab = "qr" | "memo" | "wand";

const STYLE = `
:host { all: initial; }
${THEME_TOKENS}
* { box-sizing: border-box; }
${CONTROLS}
.backdrop { position: fixed; inset: 0; z-index: 2147482000; background: rgb(0 0 0 / .5); display: flex; align-items: center; justify-content: center; padding: 12px;
  font: 14px/1.45 var(--d-font); color: var(--d-text); }
.win { width: min(1040px, 100%); height: min(760px, 100%); display: flex; flex-direction: column; overflow: hidden;
  border: 1px solid var(--d-line); border-radius: calc(var(--d-radius) + 0.25rem); box-shadow: 0 20px 60px rgb(0 0 0 / .45);
  background: var(--d-panel-solid); backdrop-filter: var(--d-shell-blur); -webkit-backdrop-filter: var(--d-shell-blur); }
header { display: flex; align-items: center; gap: 8px; padding: 10px 12px; border-bottom: 1px solid var(--d-divider); }
header h2 { font-size: 16px; margin: 0 6px 0 0; color: var(--d-title); }
.main { flex: 1; display: grid; grid-template-columns: 240px 1fr; min-height: 0; }
.col { min-height: 0; overflow: auto; padding: 10px; }
.col + .col { border-left: 1px solid var(--d-divider); }
.list { display: flex; flex-direction: column; gap: 4px; }
.row { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.grow { flex: 1; min-width: 0; }
button { padding: 6px 10px; }
button.icon { padding: 6px; }
.entry { justify-content: flex-start; width: 100%; text-align: left; overflow: hidden; text-overflow: ellipsis; }
.entry .meta { margin-left: auto; color: var(--d-muted); font-size: 12px; font-weight: 500; }
input[type=text], textarea, select { width: 100%; }
textarea { font-family: var(--d-mono); font-size: 13px; min-height: 220px; resize: vertical; tab-size: 2; }
label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--d-muted); }
label.inline { flex-direction: row; align-items: center; gap: 6px; color: var(--d-text); font-size: 13px; }
.section { margin: 12px 0 6px; font-size: 12px; text-transform: uppercase; letter-spacing: .04em; color: var(--d-muted); }
.note { font-size: 12px; color: var(--d-muted); }
.warn { color: #e6a23c; font-size: 12px; }
.editor { display: flex; flex-direction: column; gap: 10px; margin-top: 10px; padding: 10px; border: 1px solid var(--d-line); border-radius: var(--d-radius); background: var(--d-hl-bg); }
.empty { color: var(--d-muted); padding: 24px; text-align: center; }
.note-box { border: 1px dashed #e6a23c; border-radius: var(--d-radius-sm); padding: 8px 10px; font-size: 13px; }
.note-box ul { margin: 6px 0 8px; padding-left: 18px; }
svg { width: 15px; height: 15px; }
.badge { display: inline-block; font-size: 11px; line-height: 1; padding: 3px 6px; border-radius: 999px; border: 1px solid var(--d-line); color: var(--d-muted); white-space: nowrap; font-weight: 600; }
.badge.dispensa { border-color: #3fb97a; color: #3fb97a; }
.badge.marinara { border-color: var(--d-accent); color: var(--d-accent); }
.foreign { font-size: 12px; color: var(--d-muted); display: flex; flex-wrap: wrap; gap: 4px; align-items: center; }
details.cmds summary { cursor: pointer; font-size: 13px; color: var(--d-text); }
.cmd-list { display: flex; flex-direction: column; gap: 2px; max-height: 260px; overflow: auto; margin-top: 6px; }
.cmd { justify-content: flex-start; width: 100%; text-align: left; border-color: transparent; background: none; padding: 4px 6px; white-space: normal; font-weight: 500; color: var(--d-text); }
.cmd code { font-family: var(--d-mono); font-size: 12px; min-width: 120px; color: var(--d-btn-text-active); }
.cmd .help { color: var(--d-muted); font-size: 12px; flex: 1; }
header .tab { padding: 5px 12px; }
.main.single { grid-template-columns: 1fr; }
${FORM_CSS}
${WAND_SETTINGS_STYLE}
${SCRIPT_EDITOR_CSS}
${RUN_PANEL_CSS}
${DRAG_CSS}
${MEMO_VIEW_CSS}
.qrow { display: flex; align-items: center; gap: 4px; }
.qrow > .entry { flex: 1; min-width: 0; }
.entry .marks { color: var(--d-muted); font-weight: 500; font-size: 12px; white-space: nowrap; }
.set-row { display: flex; align-items: center; gap: 2px; }
.set-row > .entry { flex: 1; min-width: 0; }
.place { font-size: 11px; }
.links { display: flex; flex-direction: column; gap: 4px; margin: 4px 0; }
.links .link { display: flex; align-items: center; gap: 8px; padding: 4px 0; border-top: 1px solid var(--d-divider); }
.links .link:first-child { border-top: 0; }
.links .link .grow { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.links .link label.inline { font-size: 12px; color: var(--d-muted); }
.set > .ctl > input[type=color], input[type=color] { min-width: 0; width: 36px; height: 28px; padding: 2px; border-radius: var(--d-radius-sm); border: 1px solid var(--d-field-border); background: var(--d-field); cursor: pointer; }
details.box { border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); padding: 2px 10px; }
details.box > summary { cursor: pointer; list-style: none; display: flex; align-items: center; gap: 6px; padding: 7px 0; font-size: 13px; color: var(--d-text); }
details.box > summary::-webkit-details-marker { display: none; }
details.box > summary::before { content: "▸"; color: var(--d-muted); transition: transform .15s ease; }
details.box[open] > summary::before { transform: rotate(90deg); }
details.box > summary .count { color: var(--d-muted); font-size: 12px; }
details.box[open] { padding-bottom: 8px; }
.menu-list hr { border: 0; border-top: 1px solid var(--d-divider); margin: 3px 0; width: 100%; }
.menu-list button.danger-item { color: var(--d-danger); }
.field-h { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--d-muted); }
textarea.request { font-family: var(--d-font); min-height: 110px; }
.viz-mark { font-weight: 400; }
details.more > summary { cursor: pointer; color: var(--d-muted); font-size: 12px; padding: 4px 0; list-style: none; display: flex; align-items: center; gap: 6px; }
details.more > summary::before { content: "▸"; transition: transform .15s ease; }
details.more[open] > summary::before { transform: rotate(90deg); }
.col-h { display: flex; align-items: center; gap: 6px; }
.col-h strong { color: var(--d-title); }
.toggles { display: flex; flex-wrap: wrap; gap: 4px 18px; }
.toggles .set { border-top: 0; min-height: 34px; padding: 2px 0; }
.toggles .set > .lab { flex: 0 1 auto; }
.toggles .set > .ctl { margin-left: 0; }
details.menu { position: relative; }
details.menu > summary { list-style: none; display: inline-flex; align-items: center; gap: 5px; cursor: pointer; font-weight: 600; white-space: nowrap;
  border: 1px solid var(--d-btn-border); background: var(--d-btn-bg); color: var(--d-btn-text); border-radius: var(--d-radius-sm); padding: 6px 10px; transition: background-color 150ms ease, border-color 150ms ease; }
details.menu > summary:hover, details.menu[open] > summary { border-color: var(--d-btn-border-hover); background: var(--d-btn-bg-hover); }
details.menu > summary::-webkit-details-marker { display: none; }
details.menu .menu-list { position: absolute; right: 0; top: calc(100% + 4px); z-index: 5; min-width: 240px; display: flex; flex-direction: column; gap: 2px; padding: 4px;
  background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); box-shadow: var(--d-shadow); animation: d-fade-in .12s ease-out; }
details.menu .menu-list button { justify-content: flex-start; flex-direction: column; align-items: flex-start; gap: 1px; border-color: transparent; background: none; white-space: normal; text-align: left; }
details.menu .menu-list button:hover { background: var(--d-hl-bg); }
details.menu .menu-list small { color: var(--d-muted); font-weight: 400; font-size: 11.5px; }
@media (max-width: 720px) { .main { grid-template-columns: 1fr; } .col + .col { border-left: none; border-top: 1px solid var(--d-divider); } }
/* phones: title and buttons on one line, the tabs on the next; header buttons show only their icons */
@media (max-width: 560px) {
  header { flex-wrap: wrap; row-gap: 8px; }
  header .tabs { order: 5; width: 100%; flex-wrap: nowrap; }
  header .tabs .seg2 { flex: 1; }
  header .label { display: none; }
  .win { height: 100%; }
  .col { padding: 10px 12px; }
}
`;

const ORIGIN_BADGE = {
  st: () => el("span", { class: "badge", title: "실리태번에도 있는 명령" }, "실리태번"),
  dispensa: () => el("span", { class: "badge dispensa", title: "Dispensa에만 있는 명령 (실리태번에는 없어요)" }, "Dispensa"),
  marinara: () => el("span", { class: "badge marinara", title: "마리나라 자체 기능을 쓰는 명령 (실리태번에는 없어요)" }, "마리나라"),
};

/** Auto-run triggers in the editor, in SillyTavern's order. */
const TRIGGERS: { key: AutoTrigger; label: string; help?: string }[] = [
  { key: "startup", label: "마리나라를 켤 때" },
  { key: "user", label: "내 메시지를 보낸 뒤" },
  { key: "ai", label: "AI 답변 뒤" },
  { key: "chatChange", label: "채팅을 열 때" },
  { key: "newChat", label: "새 채팅을 만들 때" },
  { key: "groupDraft", label: "그룹 채팅에서 캐릭터 차례마다", help: "그룹 채팅에서 캐릭터 한 명이 답을 쓰기 시작할 때마다 실행해요." },
  { key: "beforeGeneration", label: "AI가 답을 쓰기 직전", help: "AI가 답을 쓰기 전에 실행하고, 끝날 때까지 답을 기다리게 해요 (최대 1분). 변수나 메모를 미리 바꿔 둘 때 좋아요." },
];

const HELP = {
  places:
    "이 세트를 어디서 퀵바에 보일지 정해요.\n· 모든 채팅: 어느 채팅에서나\n· 이 채팅: 지금 연 채팅에서만\n· 캐릭터: 그 캐릭터와 하는 모든 채팅에서\n자동 실행도 켜진 곳에서만 돌아요.",
  plain:
    "'/'로 시작하지 않는 QR(그냥 글)을 누를 때의 방식이에요.\n· 보내지 않기: 입력창에 넣기만 해요\n· 입력창 글에 붙이기: 쓰던 글 뒤에 이어 붙여 보내요\n· 앞에 붙이기: 쓰던 글 앞에 붙여요",
  submenu:
    "다른 세트를 이 QR의 하위 메뉴로 달아요. 퀵바에서 QR을 오른쪽 클릭(휴대폰은 꾹 누르기)하면 열려요.\n· 이어서 실행: 이 QR을 먼저 실행하고, 고른 QR이 그 결과를 이어받아요\n· 하위 메뉴 QR 스크립트의 %%parent%%는 이 QR의 이름으로 바뀌어요",
  auto: "정한 때가 오면 이 QR이 저절로 실행돼요. 세트가 켜진 곳(보이는 곳)에서만 돌아요.",
  automation:
    "로어북 항목 이름(또는 id)을 적어 두면, 그 항목이 답변에 쓰였을 때 이 QR이 실행돼요. (실리태번의 자동화 ID)",
  preventAuto:
    "켜 두면, 이 QR이 자동으로 실행되는 동안 이 QR 때문에 생긴 일(메시지 보내기 등)로 다른 자동 실행이 또 일어나지 않아요. 끝없이 서로 부르는 걸 막아 줘요.",
  showLabel: "켜면 폴더·하위 메뉴에서 아이콘만 보여요 (이름은 마우스를 올리면 보여요).",
};

export class QrManager {
  private hostEl: HTMLElement | null = null;
  private root: ShadowRoot | null = null;
  private selectedSet: string | null = null;
  private selectedItem: string | null = null;
  private unsubscribe: (() => void) | null = null;
  private commandListOpen = false;
  private commandQuery = "";
  /** Folded parts kept open through redraws (by key). */
  private readonly openParts = new Set<string>();
  private tab: ManagerTab = "qr";
  private unsubscribeWand: (() => void) | null = null;
  private readonly wandView: WandSettingsView | null;
  private readonly memoView: MemoView | null;
  private unsubscribeMemo: (() => void) | null = null;
  /** The window slides in once, when it opens (not on every redraw). */
  private entering = false;
  private scope: ChatScope = NO_CHAT;
  private readonly names = new Map<string, string>();
  /** Script boxes and run panels live across redraws (caret, suggestions, a paused debugger). */
  private readonly editors = new Map<string, ScriptEditor>();
  private readonly panels = new Map<string, RunPanel>();
  private readonly breakpoints = new Map<string, Set<number>>();
  /** A change made by typing in a script box: no redraw. */
  private quiet = false;
  private scrollToEditor = false;

  constructor(private readonly deps: ManagerDeps) {
    this.wandView = deps.wandStore
      ? new WandSettingsView({
          store: deps.wandStore,
          ui: deps.ui,
          connections: async () => (await api<{ id: string; name: string }[]>("/connections")).map((c) => ({ id: c.id, name: c.name })),
          rerender: () => this.render(),
          importItems: (items) => this.deps.store.update((st) => moveItemsToQr(st, items)),
        })
      : null;
    const memo = deps.memo;
    this.memoView = memo
      ? new MemoView({
          store: memo.store,
          ui: deps.ui,
          sendOoc: memo.sendOoc,
          putInInput: memo.putInInput,
          makePage: memo.makePage,
          toQr: (text) => this.memoToQr(text),
          oocSettings: () => this.wandView?.oocCards() ?? [],
          menu: (summary, label, entries) => this.menu(summary, label, entries),
          quietly: (fn) => {
            this.quiet = true;
            try {
              fn();
            } finally {
              this.quiet = false;
            }
          },
          close: () => this.close(),
          rerender: () => this.render(),
        })
      : null;
  }

  /** A memo becomes a QR that sends it as OOC (/ooc), in a set you pick. */
  private async memoToQr(text: string): Promise<void> {
    const sets = this.state.sets;
    const NEW = "+ 새 세트 \"메모 QR\"";
    const labels = [NEW, ...sets.map((s, i) => `${s.name}${sets.filter((o) => o.name === s.name).length > 1 ? ` (${i + 1})` : ""}`)];
    const [picked] = (await this.deps.ui.pick?.("QR을 넣을 세트를 고르세요.", labels)) ?? [];
    if (!picked) return;
    const item = newItem(memoLine(text, 14), `/ooc ${text.replace(/[|\\]/g, (c) => `\\${c}`).replace(/\{:/g, "\\{:").replace(/:\}/g, "\\:}")}`);
    item.title = memoLine(text, 200);
    let setId = "";
    this.deps.store.update((st) => {
      let target = picked === NEW ? undefined : st.sets[labels.indexOf(picked) - 1];
      if (!target) {
        target = newSet("메모 QR");
        st.sets.push(target);
      }
      target.items.push(item);
      setId = target.id;
    });
    this.deps.ui.toast(`"${item.label}" QR을 만들었어요. 누르면 OOC로 보내요.`, "success", { title: "📝" });
    this.openItem(setId, item.id);
  }

  /** The chat on screen (its chat and character switches). */
  setScope(scope: ChatScope): void {
    this.scope = scope;
    for (const id of scope.characterIds) {
      if (this.names.has(id)) continue;
      this.names.set(id, "캐릭터");
      void this.deps.characterName(id).then((name) => {
        this.names.set(id, name);
        this.render();
      });
    }
    this.render();
  }

  open(tab?: ManagerTab): void {
    if (tab) this.tab = tab;
    if (this.hostEl) {
      this.render();
      return;
    }
    this.hostEl = el("div", { id: "dispensa-manager" });
    this.root = this.hostEl.attachShadow({ mode: "open" });
    document.body.append(this.hostEl);
    this.selectedSet ??= this.deps.store.value.sets[0]?.id ?? null;
    this.unsubscribe = this.deps.store.subscribe(() => {
      if (!this.quiet) this.render();
    });
    this.unsubscribeWand = this.deps.wandStore?.subscribe(() => this.render()) ?? null;
    this.unsubscribeMemo =
      this.deps.memo?.store.subscribe(() => {
        if (!this.quiet) this.render();
      }) ?? null;
    document.addEventListener("keydown", this.onKey, true);
    this.entering = true;
    this.render();
    this.entering = false;
  }

  /** Ctrl+click on the bar: straight to that QR's editor. */
  openItem(setId: string, itemId: string): void {
    this.selectedSet = setId;
    this.selectedItem = itemId;
    this.scrollToEditor = true;
    this.open("qr");
  }

  close(): void {
    for (const p of this.panels.values()) p.stop();
    this.unsubscribe?.();
    this.unsubscribe = null;
    this.unsubscribeWand?.();
    this.unsubscribeWand = null;
    this.unsubscribeMemo?.();
    this.unsubscribeMemo = null;
    void this.deps.wandStore?.saveNow().catch(() => undefined);
    void this.deps.memo?.store.saveNow().catch(() => undefined);
    document.removeEventListener("keydown", this.onKey, true);
    this.hostEl?.remove();
    this.hostEl = this.root = null;
    void this.deps.store.saveNow();
  }

  private readonly onKey = (e: KeyboardEvent) => {
    if (e.key === "Escape" && !e.defaultPrevented) {
      const active = this.root?.activeElement;
      if (active && active.tagName === "TEXTAREA") return;
      const menu = this.root?.querySelector<HTMLDetailsElement>("details.menu[open]");
      e.stopPropagation();
      if (menu) {
        menu.open = false;
        return;
      }
      this.close();
    }
  };

  private get set(): QrSet | undefined {
    return this.deps.store.value.sets.find((s) => s.id === this.selectedSet);
  }

  private get state(): QrState {
    return this.deps.store.value;
  }

  private readonly setName: SetNames = (id) => this.state.sets.find((s) => s.id === id)?.name;

  private render(): void {
    if (!this.root) return;
    // keep focus and caret in the editor across re-renders
    const active = this.root.activeElement as HTMLInputElement | HTMLTextAreaElement | null;
    const focusKey = active?.dataset?.key;
    const caret = active && "selectionStart" in active ? [active.selectionStart, active.selectionEnd] : null;
    const scrolls = [...this.root.querySelectorAll<HTMLElement>(".col")].map((c) => c.scrollTop);
    this.forgetGone();

    const style = el("style");
    style.textContent = STYLE;
    const win = el("div", { class: `win${this.entering ? " d-enter" : ""}`, role: "dialog", "aria-modal": "true", "aria-label": "Dispensa" });
    if (this.tab === "wand" && this.wandView) win.append(this.header(), el("div", { class: "main single" }, this.wandView.render()));
    else if (this.tab === "memo" && this.memoView) win.append(this.header(), el("div", { class: "main single" }, this.memoView.render()));
    else win.append(this.header(), el("div", { class: "main" }, this.setColumn(), this.itemColumn()));
    const backdrop = el("div", {
      class: `backdrop${this.entering ? " d-fade" : ""}`,
      onmousedown: (e: Event) => {
        if (e.target === backdrop) this.close();
      },
    });
    backdrop.append(win);
    this.root.replaceChildren(style, backdrop);

    [...this.root.querySelectorAll<HTMLElement>(".col")].forEach((c, i) => (c.scrollTop = scrolls[i] ?? 0));
    if (focusKey) {
      const target = this.root.querySelector<HTMLInputElement | HTMLTextAreaElement>(`[data-key="${focusKey}"]`);
      if (target) {
        target.focus({ preventScroll: true });
        if (caret && caret[0] !== null && "setSelectionRange" in target && target.type !== "checkbox" && target.type !== "color") target.setSelectionRange(caret[0], caret[1]);
      }
    }
    if (this.scrollToEditor) {
      this.scrollToEditor = false;
      requestAnimationFrame(() => this.root?.querySelector(".editor")?.scrollIntoView({ block: "start" }));
    }
  }

  /** Drop the script boxes and panels of QRs that are gone. */
  private forgetGone(): void {
    const ids = new Set(this.state.sets.flatMap((s) => s.items.map((i) => i.id)));
    for (const map of [this.editors, this.panels, this.breakpoints] as Map<string, unknown>[]) for (const id of [...map.keys()]) if (!ids.has(id)) map.delete(id);
  }

  private header(): HTMLElement {
    const size = this.deps.store.size() + (this.deps.wandStore?.size() ?? 0);
    const tabs = segmented(
      "dispensa-tab",
      [
        { value: "qr", label: "보관함" },
        ...(this.memoView ? [{ value: "memo", label: "📝", title: "메모장" }] : []),
        { value: "wand", label: "🌟", title: "비주얼라이저 설정" },
      ],
      this.tab,
      (v) => {
        this.tab = v as ManagerTab;
        this.render();
      },
      "Dispensa 탭",
    );
    return el(
      "header",
      {},
      el("h2", {}, "Dispensa"),
      this.wandView || this.memoView ? el("div", { class: "row tabs" }, tabs) : el("span"),
      el("span", { class: "grow" }),
      // the 1 MB storage only shows once it starts filling up
      size > 700_000 ? el("span", { class: "warn", title: `${Math.round(size / 1024)} KB / 1000 KB` }, `저장 공간 ${Math.round(size / 10_000)}% 사용`) : el("span"),
      this.tab === "qr"
        ? el("button", { title: "QR 가져오기: 실리태번 QR(.json, .qr.json) 또는 마리나라 QR(.mqr.json) 파일. QR 하나짜리 파일은 열린 세트에 들어가요.", "aria-label": "QR 가져오기", onclick: () => this.importFile() }, icon("download"), el("span", { class: "label" }, "QR 가져오기"))
        : el("span"),
      // Fornello (pages with scripts, widgets) has its own settings
      typeof fornello()?.openSettings === "function"
        ? el("button", { title: "Fornello 설정 열기 (페이지 실행, 위젯)", "aria-label": "Fornello 설정", onclick: () => (this.close(), fornello()?.openSettings?.()) }, "🔥", el("span", { class: "label" }, "Fornello"))
        : el("span"),
      el("button", { class: "icon", title: "닫기", "aria-label": "닫기", onclick: () => this.close() }, icon("x")),
    );
  }

  // ── sets ──

  /** Where a set is on, as small marks: 🌐 every chat, 💬 this chat, 👤 this character. */
  private placeMarks(set: QrSet): string {
    const marks: string[] = [];
    if (set.enabled) marks.push("🌐");
    if (isOnForChat(this.state, set.id, this.scope.chatId)) marks.push("💬");
    if (this.scope.characterIds.some((c) => isOnForCharacter(this.state, set.id, c))) marks.push("👤");
    return marks.join("");
  }

  private setColumn(): HTMLElement {
    const { store } = this.deps;
    const list = el("div", { class: "list" });
    for (const s of store.value.sets) {
      const marks = this.placeMarks(s);
      const handle = el("button", { class: "drag", type: "button", title: "끌어서 순서 바꾸기 (↑↓ 키도 돼요)", "aria-label": `${s.name} 순서 바꾸기`, "data-key": `drag-set-${s.id}` }, icon("grip"));
      const row = el(
        "div",
        { class: "set-row" },
        handle,
        el(
          "button",
          {
            class: `entry${s.id === this.selectedSet ? " sel" : ""}`,
            onclick: () => {
              this.selectedSet = s.id;
              this.selectedItem = null;
              this.render();
            },
          },
          s.icon?.trim() ? el("span", {}, s.icon.trim()) : icon("folder"),
          el("span", { class: "grow" }, s.name),
          el("span", { class: "meta", title: marks ? "🌐 모든 채팅 · 💬 이 채팅 · 👤 이 캐릭터" : "지금 채팅에서는 꺼져 있어요" }, el("span", { class: "place" }, marks || "꺼짐"), ` · ${s.items.length}`),
        ),
      );
      dragHandle(handle, row, ".set-row", (from, to) => store.update((st) => moveTo(st.sets, from, to)));
      list.append(row);
    }
    if (!store.value.sets.length) list.append(el("div", { class: "note" }, "아직 세트가 없어요."));
    return el(
      "div",
      { class: "col" },
      el("div", { class: "col-h" }, el("strong", {}, "세트"), helpTip("세트는 QR 묶음이에요. 퀵바에는 폴더 버블 하나로 보이고, 누르면 그 안의 QR이 펼쳐져요.\n🌐 모든 채팅 · 💬 이 채팅 · 👤 이 캐릭터에서 켜져 있어요.", "세트")),
      el(
        "div",
        { class: "row", style: "margin:8px 0" },
        el(
          "button",
          {
            onclick: () => {
              const s = newSet("새 세트");
              store.update((st) => st.sets.push(s));
              this.selectedSet = s.id;
              this.selectedItem = null;
            },
          },
          icon("plus"),
          "새 세트",
        ),
      ),
      list,
    );
  }

  private mutateSet(set: QrSet, fn: (s: QrSet, st: QrState) => void): void {
    this.deps.store.update((st) => {
      const target = st.sets.find((x) => x.id === set.id);
      if (target) fn(target, st);
    });
  }

  private setPanel(set: QrSet): HTMLElement[] {
    const mutate = (fn: (s: QrSet, st: QrState) => void) => this.mutateSet(set, fn);
    const top = el(
      "div",
      { class: "row" },
      el("input", {
        type: "text",
        value: set.icon ?? "",
        placeholder: "📁",
        maxlength: "8",
        style: "width:3.2em;text-align:center",
        title: "퀵바 버블 아이콘 (이모지 하나)",
        "data-key": "set-icon",
        "aria-label": "세트 아이콘",
        oninput: (e: Event) => mutate((s) => (s.icon = (e.target as HTMLInputElement).value.trim() || undefined)),
      }),
      el("input", { type: "text", class: "grow", value: set.name, "data-key": "set-name", "aria-label": "세트 이름", oninput: (e: Event) => mutate((s) => (s.name = (e.target as HTMLInputElement).value)) }),
      this.exportMenu(set),
      this.setMenu(set),
    );

    // where it is on
    const chat = this.scope.chatId;
    const sw = (on: boolean, change: (v: boolean) => void, label: string, key: string, disabled = false) => {
      const t = toggle(on, change, label, key);
      if (disabled) t.querySelector("input")!.disabled = true;
      return t;
    };
    const other = elsewhere(this.state, set.id, this.scope);
    const otherNote = [other.chats ? `다른 채팅 ${other.chats}곳` : "", other.characters ? `다른 캐릭터 ${other.characters}명` : ""].filter(Boolean).join(", ");
    const places = section(
      "보이는 곳",
      HELP.places,
      [],
      setting("모든 채팅", sw(set.enabled, (v) => mutate((s) => (s.enabled = v)), "모든 채팅", "place-all")),
      setting(
        "이 채팅",
        sw(isOnForChat(this.state, set.id, chat), (v) => chat && mutate((s, st) => setForChat(st, chat, s.id, v)), "이 채팅", "place-chat", !chat),
        chat ? undefined : "채팅을 연 상태에서 고를 수 있어요.",
      ),
      ...this.scope.characterIds.map((c) =>
        setting(`캐릭터: ${this.names.get(c) ?? "…"}`, sw(isOnForCharacter(this.state, set.id, c), (v) => mutate((s, st) => setForCharacter(st, c, s.id, v)), `캐릭터 ${this.names.get(c) ?? ""}`, `place-char-${c}`)),
      ),
      otherNote ? el("div", { class: "note" }, `${otherNote}에서도 켜져 있어요.`) : null,
    );

    // how it looks
    const looks = section(
      "모양",
      undefined,
      [],
      setting("펼쳐서 보이기", toggle(set.display === "inline", (v) => mutate((s) => (s.display = v ? "inline" : "folder")), "펼쳐서 보이기", "set-inline"), "폴더 버블 하나 대신, 이 세트의 QR 버블을 퀵바에 모두 바로 보여요."),
      setting(
        "색",
        set.color
          ? [
              el("input", { type: "color", value: toHex(set.color) ?? "#7c6cf0", "aria-label": "세트 색", "data-key": "set-color", onchange: (e: Event) => mutate((s) => (s.color = (e.target as HTMLInputElement).value)) }),
              el("button", { type: "button", onclick: () => mutate((s) => (delete s.color, delete s.colorBorderOnly)) }, "색 없애기"),
            ]
          : el("button", { type: "button", "data-key": "set-color-add", onclick: () => mutate((s) => (s.color = "#7c6cf0")) }, "색 칠하기"),
        "퀵바에서 이 세트의 버블에 칠할 색이에요.",
      ),
      set.color ? setting("테두리만 칠하기", toggle(!!set.colorBorderOnly, (v) => mutate((s) => (v ? (s.colorBorderOnly = true) : delete s.colorBorderOnly)), "테두리만 칠하기", "set-border")) : null,
    );

    const plain = this.fold(
      `set-plain-${set.id}`,
      "글 QR 보내는 방식",
      [set.disableSend, set.injectInput].filter(Boolean).length,
      HELP.plain,
      setting("보내지 않기", toggle(!!set.disableSend, (v) => mutate((s) => (s.disableSend = v)), "보내지 않기", "set-nosend"), "누르면 입력창에 넣기만 하고 보내지 않아요."),
      setting("입력창 글에 붙이기", toggle(!!set.injectInput, (v) => mutate((s) => (s.injectInput = v)), "입력창 글에 붙이기", "set-inject")),
      set.injectInput ? setting("앞에 붙이기", toggle(!!set.placeBeforeInput, (v) => mutate((s) => (s.placeBeforeInput = v)), "앞에 붙이기", "set-before")) : null,
    );
    return [top, el("div", { style: "margin-top:10px" }, places, looks), plain];
  }

  /** The set's ⋯ menu: duplicate, delete. */
  private setMenu(set: QrSet): HTMLElement {
    return this.menu(icon("more"), "세트 메뉴", [
      {
        label: "세트 복제",
        sub: "QR까지 그대로 하나 더 만들어요",
        run: () => {
          const copy = duplicateSet(set, this.state);
          this.deps.store.update((st) => st.sets.splice(st.sets.findIndex((s) => s.id === set.id) + 1, 0, copy));
          this.selectedSet = copy.id;
          this.selectedItem = null;
          this.render();
          this.deps.ui.toast(`"${copy.name}"을 만들었어요.`, "success");
        },
      },
      "-",
      {
        label: "세트 삭제",
        danger: true,
        run: async () => {
          if (!(await this.deps.ui.popup(`"${set.name}" 세트와 QR ${set.items.length}개를 삭제할까요?`, { okButton: "삭제", cancelButton: "취소" }))) return;
          this.deps.store.update((st) => {
            st.sets = st.sets.filter((x) => x.id !== set.id);
            forgetSet(st, set.id);
          });
          this.selectedSet = this.state.sets[0]?.id ?? null;
          this.render();
        },
      },
    ]);
  }

  // ── QRs ──

  private itemColumn(): HTMLElement {
    const set = this.set;
    const col = el("div", { class: "col" });
    if (!set) {
      col.append(el("div", { class: "empty" }, "세트를 고르거나 새로 만드세요."));
      return col;
    }
    col.append(...this.setPanel(set));
    col.append(
      el(
        "div",
        { class: "row", style: "margin:14px 0 6px" },
        el("div", { class: "section", style: "margin:0" }, `QR ${set.items.length}개`),
        el("span", { class: "grow" }),
        el("button", { type: "button", title: "복사해 둔 QR(또는 글)을 이 세트에 붙여 넣어요", onclick: () => void this.paste(set) }, icon("clipboard"), "붙여넣기"),
      ),
    );
    const list = el("div", { class: "list" });
    set.items.forEach((item) => {
      const handle = el("button", { class: "drag", type: "button", title: "끌어서 순서 바꾸기 (↑↓ 키도 돼요)", "aria-label": `${item.label} 순서 바꾸기`, "data-key": `drag-qr-${item.id}` }, icon("grip"));
      const marks = [
        item.auto && Object.values(item.auto).some(Boolean) ? "⚡" : "",
        item.automationId ? "📚" : "",
        item.contextList?.length ? "☰" : "",
        item.hidden ? "숨김" : "",
      ].filter(Boolean);
      const row = el(
        "div",
        { class: "qrow" },
        handle,
        el(
          "button",
          {
            class: `entry${item.id === this.selectedItem ? " sel" : ""}`,
            onclick: () => {
              this.selectedItem = this.selectedItem === item.id ? null : item.id;
              this.render();
            },
          },
          item.icon?.trim() ? el("span", {}, item.icon.trim()) : item.kind === "ooc" ? icon("message-circle") : icon("play"),
          el("span", { class: "grow" }, item.label || "(이름 없음)", item.kind === "viz" ? el("span", { class: "viz-mark", title: "🌟 QR: 비주얼라이저로 실행해요" }, " 🌟") : null),
          marks.length ? el("span", { class: "marks", title: "⚡ 자동 실행 · 📚 로어북 연결 · ☰ 하위 메뉴" }, marks.join(" ")) : null,
          item.unsupported?.length ? el("span", { class: "warn", title: item.unsupported.join(", ") }, "⚠") : null,
          item.dialect === "st" ? el("span", { class: "meta", title: item.note ?? "" }, "실리태번 기준") : null,
        ),
        el("button", { class: "icon", title: "실행", "aria-label": `${item.label} 실행`, onclick: () => this.deps.run(set, item) }, icon("play")),
        this.itemMenu(set, item),
      );
      dragHandle(handle, row, ".qrow", (from, to) => this.mutateSet(set, (s) => moveTo(s.items, from, to)));
      list.append(row);
      if (item.id === this.selectedItem) list.append(item.kind === "viz" ? this.vizEditor(set, item) : this.editor(set, item));
    });
    col.append(
      list,
      el(
        "div",
        { class: "row", style: "margin-top:8px" },
        el(
          "button",
          {
            onclick: () => {
              const item = newItem("새 QR", "/echo 안녕하세요, {{user}}!");
              this.mutateSet(set, (s) => s.items.push(item));
              this.selectedItem = item.id;
              this.render();
            },
          },
          icon("plus"),
          "새 QR",
        ),
        el(
          "button",
          {
            title: "비주얼라이저로 실행하는 QR: 적은 주제로 페이지를 만들어요",
            onclick: () => {
              const item = vizQr({ title: "새 🌟 QR", content: "", defaultAction: "viz" });
              this.mutateSet(set, (s) => s.items.push(item));
              this.selectedItem = item.id;
              this.render();
            },
          },
          icon("plus"),
          "새 🌟 QR",
        ),
      ),
    );
    return col;
  }

  /** A QR's ⋯ menu: copy, cut, duplicate, move or copy to another set, export, delete. */
  private itemMenu(set: QrSet, item: QrItem): HTMLElement {
    return this.menu(icon("more"), `${item.label} 메뉴`, [
      { label: "복사", sub: "다른 세트나 실리태번에 붙여 넣을 수 있어요", run: () => void this.copyItem(item, false, set) },
      { label: "잘라내기", run: () => void this.copyItem(item, true, set) },
      {
        label: "복제",
        sub: "바로 아래에 하나 더",
        run: () => {
          const copy = cloneItem(item);
          copy.label = `${item.label} 복사본`;
          this.mutateSet(set, (s) => s.items.splice(s.items.findIndex((i) => i.id === item.id) + 1, 0, copy));
          this.selectedItem = copy.id;
          this.render();
        },
      },
      { label: "다른 세트로 옮기기…", run: () => void this.transfer(set, item, false) },
      { label: "다른 세트로 복사…", run: () => void this.transfer(set, item, true) },
      "-",
      { label: "이 QR만 내보내기: 마리나라용", sub: ".mqr.json", run: () => this.download(exportMarinaraItem(item, this.setName), `${item.label || "qr"}.mqr.json`) },
      { label: "이 QR만 내보내기: 실리태번용", sub: ".json (첫 메시지 = 0번)", run: () => this.download(stExportItem(item, 1, this.deps.registry, this.setName), `${item.label || "qr"}.json`) },
      "-",
      { label: "QR 삭제", danger: true, run: () => this.removeItem(set, item) },
    ]);
  }

  private removeItem(set: QrSet, item: QrItem): void {
    this.mutateSet(set, (s) => (s.items = s.items.filter((i) => i.id !== item.id)));
    if (this.selectedItem === item.id) this.selectedItem = null;
    this.render();
  }

  /** A clipboard copy that both Dispensa and SillyTavern can paste. */
  private async copyItem(item: QrItem, cut: boolean, set: QrSet): Promise<void> {
    const data = { ...stExportItem(item, 1, this.deps.registry, this.setName), dispensa: exportMarinaraItem(item, this.setName) };
    await (this.deps.ui.copy?.(JSON.stringify(data, null, 2)) ?? navigator.clipboard.writeText(JSON.stringify(data)));
    if (cut) this.removeItem(set, item);
    this.deps.ui.toast(cut ? `"${item.label}"을 잘라 냈어요. 원하는 세트에서 붙여넣기를 누르세요.` : `"${item.label}"을 복사했어요.`, "success");
  }

  private async paste(set: QrSet): Promise<void> {
    const text = (await (this.deps.ui.paste?.() ?? navigator.clipboard.readText())).trim();
    if (!text) return;
    let report: ImportReport | null = null;
    try {
      const json = JSON.parse(text);
      const own = json?.dispensa;
      report = own?.format === MQR_ITEM_FORMAT ? importMarinara(own, this.deps.registry) : importAny(json, this.deps.registry);
    } catch {
      // not JSON: SillyTavern makes it a QR that sends this text
    }
    if (report && report.sets.length) {
      this.addReport(report, set);
      this.deps.ui.toast(`세트 ${report.sets.length}개를 붙여 넣었어요.`, "success");
      return;
    }
    const items = report?.items.length ? report.items : [newItem(labelOf(text), text, "marinara")];
    this.addReport(report ?? { sets: [], items, links: [], total: items.length, unsupported: [], parseErrors: [], converted: 0, keptSillyTavern: [] }, set, items);
    this.selectedItem = items[0].id;
    this.render();
    this.deps.ui.toast(`QR ${items.length}개를 붙여 넣었어요.`, "success");
  }

  /** Imported sets go to the end; single QRs into `set`; sub menu links find their sets by name. */
  private addReport(report: ImportReport, set: QrSet | undefined, items = report.items): void {
    let missing: string[] = [];
    this.deps.store.update((st) => {
      st.sets.push(...report.sets);
      if (items.length) {
        let target = set ? st.sets.find((s) => s.id === set.id) : undefined;
        if (!target) {
          target = newSet("가져온 QR");
          st.sets.push(target);
        }
        target.items.push(...items);
        this.selectedSet = target.id;
      }
      missing = resolveLinks(st, report.links);
    });
    if (missing.length) this.deps.ui.toast(`하위 메뉴로 쓰던 세트를 찾지 못했어요: ${missing.join(", ")}`, "warning");
  }

  private async transfer(from: QrSet, item: QrItem, copy: boolean): Promise<void> {
    const others = this.state.sets.filter((s) => s.id !== from.id);
    if (!others.length) {
      this.deps.ui.toast("옮길 다른 세트가 없어요. 먼저 세트를 하나 더 만드세요.", "warning");
      return;
    }
    const labels = others.map((s, i) => `${s.name}${others.filter((o) => o.name === s.name).length > 1 ? ` (${i + 1})` : ""}`);
    const [picked] = (await this.deps.ui.pick?.(`"${item.label}"을 ${copy ? "복사할" : "옮길"} 세트를 고르세요.`, labels)) ?? [];
    const target = picked ? others[labels.indexOf(picked)] : undefined;
    if (!target) return;
    this.deps.store.update((st) => {
      const to = st.sets.find((s) => s.id === target.id);
      const src = st.sets.find((s) => s.id === from.id);
      if (!to || !src) return;
      if (copy) to.items.push(cloneItem(item));
      else {
        src.items = src.items.filter((i) => i.id !== item.id);
        to.items.push(item);
      }
    });
    if (!copy) {
      this.selectedSet = target.id;
      this.selectedItem = item.id;
    }
    this.render();
    this.deps.ui.toast(`"${target.name}" 세트로 ${copy ? "복사했어요" : "옮겼어요"}.`, "success");
  }

  // ── the editor ──

  private mutateItem(set: QrSet, item: QrItem, fn: (i: QrItem) => void, quiet = false): void {
    this.quiet = quiet;
    try {
      this.deps.store.update((st) => {
        const target = st.sets.find((s) => s.id === set.id)?.items.find((i) => i.id === item.id);
        if (target) fn(target);
      });
    } finally {
      this.quiet = false;
    }
  }

  private scriptBox(set: QrSet, item: QrItem): ScriptEditor {
    let editor = this.editors.get(item.id);
    if (!editor) {
      let checkTimer: ReturnType<typeof setTimeout> | null = null;
      editor = new ScriptEditor({
        value: item.script,
        key: "item-script",
        label: "스크립트",
        commands: () => this.deps.registry.list().map((d) => ({ name: d.name, help: d.help })),
        onChange: (value) => {
          this.mutateItem(set, item, (i) => (i.script = value), true);
          if (checkTimer) clearTimeout(checkTimer);
          checkTimer = setTimeout(() => this.recheck(set, item, value), 500);
        },
        onRun: () => void this.panelFor(set, item).start(false),
        onBreakpoints: (lines) => this.breakpoints.set(item.id, lines),
      });
      editor.setBreakpoints(this.breakpoints.get(item.id) ?? new Set());
      this.editors.set(item.id, editor);
    }
    editor.value = item.script;
    return editor;
  }

  /** Unknown commands after typing stops: only the warning lines change. */
  private recheck(set: QrSet, item: QrItem, script: string): void {
    const res = findUnsupported(script, this.deps.registry);
    this.mutateItem(set, item, (i) => (i.unsupported = Array.isArray(res) ? (res.length ? res : undefined) : ["(문법 오류)"]), true);
    const slot = this.root?.querySelector(`[data-checks="${item.id}"]`);
    const fresh = this.state.sets.find((s) => s.id === set.id)?.items.find((i) => i.id === item.id);
    if (slot && fresh) slot.replaceChildren(...this.checks(fresh));
  }

  private checks(item: QrItem): Node[] {
    const out: Node[] = [];
    if (item.unsupported?.length) out.push(el("div", { class: "warn" }, `⚠ 아직 지원하지 않는 명령: ${item.unsupported.map((c) => (c.startsWith("(") ? c : `/${c}`)).join(", ")}`));
    out.push(this.foreignLine(item.script));
    return out;
  }

  private panelFor(set: QrSet, item: QrItem): RunPanel {
    let panel = this.panels.get(item.id);
    if (!panel) {
      panel = new RunPanel({
        run: (signal, debug) => {
          const fresh = this.state.sets.find((s) => s.id === set.id);
          const now = fresh?.items.find((i) => i.id === item.id);
          if (!fresh || !now) throw new Error("QR을 찾지 못했어요.");
          return this.deps.runInEditor(fresh, now, { signal, debug });
        },
        editor: () => this.editors.get(item.id) ?? null,
        breakpoints: () => this.breakpoints.get(item.id) ?? new Set(),
        changed: () => {
          const slot = this.root?.querySelector(`[data-run="${item.id}"]`);
          if (slot) slot.replaceChildren(panel!.render());
        },
      });
      this.panels.set(item.id, panel);
    }
    return panel;
  }

  private editor(set: QrSet, item: QrItem): HTMLElement {
    const { registry } = this.deps;
    const mutate = (fn: (i: QrItem) => void) => this.mutateItem(set, item, fn);
    const box = el("div", { class: "editor" });
    const panel = this.panelFor(set, item);
    box.append(
      this.basics(set, item, mutate),
      item.dialect === "st"
        ? el(
            "div",
            { class: "note-box" },
            el("div", { class: "warn" }, "실리태번 기준(첫 메시지 = 0번)으로 실행돼요. 마리나라 기준으로 자동 변환하지 못한 이유:"),
            el("ul", {}, ...(item.note ?? "이유가 기록되지 않았어요").split("\n").map((r) => el("li", {}, r))),
            el(
              "div",
              { class: "row" },
              el(
                "button",
                {
                  onclick: () => {
                    let ok = false;
                    mutate((i) => (ok = applyConversion(i, registry)));
                    this.deps.ui.toast(ok ? "마리나라 기준으로 바꿨어요." : "아직 자동으로 바꿀 수 없어요. 위 이유를 고친 뒤 다시 눌러 주세요.", ok ? "success" : "warning");
                  },
                },
                "마리나라 기준으로 변환",
              ),
              el(
                "button",
                {
                  title: "스크립트를 직접 고쳤다면 눌러서 마리나라 기준(1번부터)으로 표시해요",
                  onclick: () =>
                    mutate((i) => {
                      i.dialect = "marinara";
                      delete i.note;
                    }),
                },
                "직접 고쳤어요 (마리나라 기준으로 표시)",
              ),
            ),
          )
        : el("span"),
      el(
        "div",
        { class: "field-h" },
        "스크립트",
        helpTip("실리태번 STscript로 써요. 마리나라 전용 명령과 {{char}} 같은 매크로도 쓸 수 있어요.\n· /나 {{를 치면 고를 수 있는 목록이 떠요\n· Tab 들여쓰기, Ctrl+Enter 실행\n· 줄 번호를 누르면 디버그할 때 그 줄에서 멈춰요", "스크립트"),
      ),
      this.scriptBox(set, item).element,
      el("div", { "data-checks": item.id }, ...this.checks(item)),
      el("div", { "data-run": item.id }, panel.render()),
      this.commandList(),
      this.submenuPart(set, item),
      this.autoPart(set, item),
      this.footer(set, item, mutate),
    );
    return box;
  }

  /** Icon, name, tooltip. */
  private basics(set: QrSet, item: QrItem, mutate: (fn: (i: QrItem) => void) => void, folderField?: HTMLElement): HTMLElement {
    return el(
      "div",
      { class: "row" },
      el("label", {}, "아이콘", el("input", { type: "text", value: item.icon ?? "", placeholder: item.kind === "ooc" ? "💬" : "", maxlength: "8", style: "width:3.2em;text-align:center", title: "퀵바 버블 아이콘 (비우면 이름 첫 글자)", "data-key": "item-icon", oninput: (e: Event) => mutate((i) => (i.icon = (e.target as HTMLInputElement).value.trim() || undefined)) })),
      el("label", { class: "grow" }, "이름", el("input", { type: "text", value: item.label, "data-key": "item-label", oninput: (e: Event) => mutate((i) => (i.label = (e.target as HTMLInputElement).value)) })),
      folderField ?? el("label", { class: "grow" }, el("span", { class: "field-h" }, "설명", helpTip("퀵바 버블에 마우스를 올리면 보이는 글이에요.", "설명")), el("input", { type: "text", value: item.title ?? "", "data-key": "item-title", oninput: (e: Event) => mutate((i) => (i.title = (e.target as HTMLInputElement).value || undefined)) })),
    );
  }

  /** Hide, icon only, delete. */
  private footer(set: QrSet, item: QrItem, mutate: (fn: (i: QrItem) => void) => void, extra: Node[] = []): HTMLElement {
    return el(
      "div",
      { class: "row" },
      el(
        "div",
        { class: "toggles grow" },
        ...extra,
        setting("퀵바에서 숨기기", toggle(!!item.hidden, (v) => mutate((i) => (i.hidden = v)), "퀵바에서 숨기기", "item-hidden"), "퀵바에는 안 보이지만, 다른 QR이나 자동 실행으로는 계속 쓸 수 있어요."),
        item.icon?.trim() ? setting("아이콘만 보이기", toggle(item.showLabel === false, (v) => mutate((i) => (v ? (i.showLabel = false) : delete i.showLabel)), "아이콘만 보이기", "item-icon-only"), HELP.showLabel) : null,
      ),
      el("button", { class: "danger", onclick: () => this.removeItem(set, item) }, icon("trash"), "QR 삭제"),
    );
  }

  /** A folded part that stays open through redraws. */
  private fold(key: string, title: string, count: number, help: string | undefined, ...kids: (Node | null)[]): HTMLElement {
    const d = el("details", { class: "box" }, el("summary", {}, title, count ? el("span", { class: "count" }, `· ${count}`) : null, help ? helpTip(help, title) : null), ...kids);
    d.open = this.openParts.has(key);
    d.addEventListener("toggle", () => (d.open ? this.openParts.add(key) : this.openParts.delete(key)));
    return d;
  }

  private submenuPart(set: QrSet, item: QrItem): HTMLElement {
    const mutate = (fn: (i: QrItem) => void) => this.mutateItem(set, item, fn);
    const links = item.contextList ?? [];
    const rows = el("div", { class: "links" });
    links.forEach((link, index) => {
      const target = this.state.sets.find((s) => s.id === link.setId);
      if (!target) return;
      rows.append(
        el(
          "div",
          { class: "link" },
          el("span", { class: "grow" }, `${target.icon?.trim() ?? "📁"} ${target.name}`, el("span", { class: "note" }, ` · QR ${target.items.length}개`)),
          el(
            "label",
            { class: "inline" },
            toggle(!!link.chained, (v) => mutate((i) => i.contextList && (i.contextList[index] = v ? { ...link, chained: true } : { setId: link.setId })), "이어서 실행", `link-chain-${index}`),
            "이어서 실행",
          ),
          el(
            "button",
            {
              class: "icon",
              title: "하위 메뉴에서 빼기",
              "aria-label": `${target.name} 빼기`,
              onclick: () =>
                mutate((i) => {
                  i.contextList = (i.contextList ?? []).filter((_, n) => n !== index);
                  if (!i.contextList.length) delete i.contextList;
                }),
            },
            icon("x"),
          ),
        ),
      );
    });
    const choices = this.state.sets.filter((s) => !links.some((l) => l.setId === s.id));
    const add = el(
      "select",
      {
        "aria-label": "하위 메뉴로 달 세트",
        "data-key": "link-add",
        onchange: (e: Event) => {
          const id = (e.target as HTMLSelectElement).value;
          if (id) mutate((i) => (i.contextList = [...(i.contextList ?? []), { setId: id }]));
        },
      },
      el("option", { value: "" }, "+ 세트 달기…"),
      ...choices.map((s) => el("option", { value: s.id }, s.id === set.id ? `${s.name} (이 세트: 숨긴 QR 중 아이콘 있는 것만)` : s.name)),
    );
    return this.fold(`submenu-${item.id}`, "하위 메뉴", links.length, HELP.submenu, rows, choices.length ? add : el("div", { class: "note" }, "달 수 있는 세트가 없어요."));
  }

  private autoPart(set: QrSet, item: QrItem): HTMLElement {
    const mutate = (fn: (i: QrItem) => void) => this.mutateItem(set, item, fn);
    const on = TRIGGERS.filter((t) => item.auto?.[t.key]).length + (item.automationId ? 1 : 0);
    return this.fold(
      `auto-${item.id}`,
      "자동 실행",
      on,
      HELP.auto,
      el(
        "div",
        { class: "toggles" },
        ...TRIGGERS.map((t) =>
          setting(t.label, toggle(!!item.auto?.[t.key], (v) => mutate((i) => {
            const auto = { ...i.auto };
            if (v) auto[t.key] = true;
            else delete auto[t.key];
            i.auto = Object.keys(auto).length ? auto : undefined;
          }), t.label, `auto-${t.key}`), t.help),
        ),
      ),
      setting(
        "로어북 항목이 쓰일 때",
        el("input", { type: "text", value: item.automationId ?? "", placeholder: "항목 이름", "data-key": "item-automation", "aria-label": "로어북 항목 이름", oninput: (e: Event) => mutate((i) => ((e.target as HTMLInputElement).value.trim() ? (i.automationId = (e.target as HTMLInputElement).value) : delete i.automationId)) }),
        HELP.automation,
      ),
      setting("자동 실행 연쇄 막기", toggle(item.preventAuto !== false, (v) => mutate((i) => (v ? delete i.preventAuto : (i.preventAuto = false))), "자동 실행 연쇄 막기", "item-prevent"), HELP.preventAuto),
    );
  }

  /** The editor of a 🌟 QR: its request and how the visualizer runs it. */
  private vizEditor(set: QrSet, item: QrItem): HTMLElement {
    const mutate = (fn: (i: QrItem) => void) => this.mutateItem(set, item, fn);
    const viz = item.viz ?? { action: "viz" as const };
    const setViz = (fn: (v: NonNullable<QrItem["viz"]>) => void) =>
      mutate((i) => {
        i.viz = { ...(i.viz ?? { action: "viz" }) };
        fn(i.viz);
      });
    const pick = (key: string, label: string, entries: [string, string][], value: string, onChange: (v: string) => void) =>
      el("select", { "data-key": key, "aria-label": label, onchange: (e: Event) => onChange((e.target as HTMLSelectElement).value) }, ...entries.map(([v, text]) => el("option", { value: v, selected: v === value }, text)));
    const wrappers = this.deps.wandStore?.value.wrappers ?? [];
    const inherit = "기본값";
    const more = el(
      "details",
      { class: "more" },
      el("summary", {}, "세부 설정", helpTip(VIZ_HELP.itemOptions, "세부 설정")),
      setting("결과를 보여 줄 곳", pick("viz-output", "결과를 보여 줄 곳", [["", inherit], ...(Object.entries(VIZ_OUTPUTS) as [string, string][])], viz.vizOutput ?? "", (v) => setViz((x) => (v ? (x.vizOutput = v as VizOutput) : delete x.vizOutput)))),
      setting("AI 연결", pick("viz-connection", "AI 연결", this.wandView?.connectionEntries(inherit) ?? [["", inherit]], viz.connectionId ?? "", (v) => setViz((x) => (v ? (x.connectionId = v) : delete x.connectionId)))),
    );
    more.open = this.openParts.has(`viz-${item.id}`) || !!(viz.vizOutput || viz.connectionId);
    more.addEventListener("toggle", () => (more.open ? this.openParts.add(`viz-${item.id}`) : this.openParts.delete(`viz-${item.id}`)));
    const request = el("textarea", {
      "data-key": "viz-request",
      spellcheck: "false",
      class: "request",
      "aria-label": "요청 내용",
      oninput: (e: Event) => this.mutateItem(set, item, (i) => (i.script = (e.target as HTMLTextAreaElement).value), true),
    });
    request.value = item.script;
    const folder = el(
      "label",
      { class: "grow" },
      el("span", { class: "field-h" }, "묶음", helpTip(VIZ_HELP.folder, "묶음")),
      el("input", { type: "text", value: viz.folder ?? "", placeholder: set.name, "data-key": "viz-folder", oninput: (e: Event) => setViz((x) => ((e.target as HTMLInputElement).value.trim() ? (x.folder = (e.target as HTMLInputElement).value.trim()) : delete x.folder)) }),
    );
    return el(
      "div",
      { class: "editor" },
      this.basics(set, item, mutate, folder),
      el("div", { class: "field-h" }, "주제", helpTip(VIZ_HELP.content, "주제")),
      request,
      more,
      this.submenuPart(set, item),
      this.autoPart(set, item),
      this.footer(set, item, mutate, [setting("퀵바에 고정 📌", toggle(!!viz.pinned, (v) => setViz((x) => (v ? (x.pinned = true) : delete x.pinned)), "퀵바에 고정", "viz-pinned"), "세트 폴더와 따로, 이 QR만의 버블을 퀵바에 놓아요.")]),
    );
  }

  /** A small drop-down menu (details) of actions. */
  private menu(summaryContent: Node | string, label: string, entries: ({ label: string; sub?: string; danger?: boolean; run: () => void | Promise<void> } | "-")[]): HTMLElement {
    const menu = el("details", { class: "menu" });
    const summary = el("summary", { role: "button", "aria-label": label, title: label }, summaryContent);
    const list = el("div", { class: "menu-list" });
    for (const e of entries) {
      if (e === "-") {
        list.append(el("hr"));
        continue;
      }
      list.append(
        el(
          "button",
          {
            class: e.danger ? "danger-item" : "",
            onclick: () => {
              menu.open = false;
              void e.run();
            },
          },
          e.label,
          e.sub ? el("small", {}, e.sub) : null,
        ),
      );
    }
    menu.append(summary, list);
    menu.addEventListener("focusout", (ev) => {
      if (!menu.contains((ev as FocusEvent).relatedTarget as Node)) menu.open = false;
    });
    return menu;
  }

  /** One "내보내기" button with the two file kinds under it. */
  private exportMenu(set: QrSet): HTMLElement {
    return this.menu(el("span", { class: "row", style: "gap:5px" }, icon("upload"), el("span", { class: "label" }, "내보내기")), "세트 내보내기", [
      { label: "마리나라용 (.mqr.json)", sub: "Dispensa에서 계속 쓸 때", run: () => this.exportSet(set, "marinara") },
      { label: "실리태번용 (.qr.json)", sub: "실리태번에서 쓸 때 (첫 메시지 = 0번)", run: () => this.exportSet(set, "st") },
    ]);
  }

  private foreignLine(script: string): HTMLElement {
    const { registry } = this.deps;
    const found = foreignCommands(script, registry);
    if (!found.length) return el("span");
    return el(
      "div",
      { class: "foreign", title: "실리태번에서는 이 명령이 동작하지 않아요. 실리태번용으로 내보낼 때 알려 드려요." },
      "실리태번에 없는 명령:",
      ...found.map((name) => el("span", { class: `badge ${registry.get(name)?.origin ?? ""}` }, `/${name}`)),
    );
  }

  /** Searchable list of every command; clicking one puts it into the script at the caret. */
  private commandList(): HTMLElement {
    const all = this.deps.registry.list();
    const q = this.commandQuery.trim().toLowerCase();
    const shown = q ? all.filter((d) => d.name.includes(q) || (d.aliases ?? []).some((a) => a.includes(q)) || d.help.toLowerCase().includes(q)) : all;
    const details = el(
      "details",
      { class: "cmds", ontoggle: () => (this.commandListOpen = details.open) },
      el("summary", {
        // remember right away: the toggle event comes later, and a redraw in between would lose it
        onclick: () => (this.commandListOpen = !details.open),
      }, `명령 목록 (${all.length}개) · `, ORIGIN_BADGE.st(), " ", ORIGIN_BADGE.dispensa(), " ", ORIGIN_BADGE.marinara()),
      el("input", {
        type: "text",
        placeholder: "명령 찾기 (이름이나 설명)",
        value: this.commandQuery,
        "data-key": "command-search",
        oninput: (e: Event) => {
          this.commandQuery = (e.target as HTMLInputElement).value;
          this.render();
        },
      }),
      el("div", { class: "cmd-list" }, ...shown.map((d) => this.commandRow(d))),
    );
    details.open = this.commandListOpen;
    return details;
  }

  private commandRow(def: CommandDef): HTMLElement {
    const badge = def.origin === "dispensa" ? ORIGIN_BADGE.dispensa() : def.origin === "marinara" ? ORIGIN_BADGE.marinara() : ORIGIN_BADGE.st();
    return el(
      "button",
      {
        class: "cmd",
        title: def.aliases?.length ? `다른 이름: /${def.aliases.join(", /")}` : "",
        onclick: () => {
          const ta = this.root?.querySelector<HTMLTextAreaElement>('textarea[data-key="item-script"]');
          if (!ta) return;
          const start = ta.selectionStart ?? ta.value.length;
          const end = ta.selectionEnd ?? start;
          const before = ta.value.slice(0, start);
          const insert = `${before && !/[\s|]$/.test(before) ? " | " : ""}/${def.name} `;
          ta.value = before + insert + ta.value.slice(end);
          ta.dispatchEvent(new Event("input"));
          const caret = start + insert.length;
          ta.focus();
          ta.setSelectionRange(caret, caret);
        },
      },
      el("code", {}, `/${def.name}`),
      badge,
      el("span", { class: "help" }, def.help),
    );
  }

  private async importFile(): Promise<void> {
    const input = el("input", { type: "file", accept: ".json,application/json", multiple: true });
    input.addEventListener("change", async () => {
      let added = 0;
      let converted = 0;
      const kept: string[] = [];
      const problems: string[] = [];
      for (const file of [...(input.files ?? [])]) {
        try {
          const json = JSON.parse(await file.text());
          const report = importAny(json, this.deps.registry, file.name.replace(/\.(m?qr\.)?json$/i, ""));
          if (!report.sets.length && !report.items.length) {
            problems.push(`${file.name}: QR 파일이 아니에요.`);
            continue;
          }
          this.addReport(report, this.set);
          if (report.sets.length) this.selectedSet = report.sets[0].id;
          added += report.total;
          converted += report.converted;
          for (const k of report.keptSillyTavern) kept.push(`${k.label}: ${k.reasons.join(" / ")}`);
          for (const u of report.unsupported) problems.push(`${u.label}: /${u.commands.join(", /")}`);
          for (const p of report.parseErrors) problems.push(`${p.label}: 문법 오류 (${p.error})`);
        } catch (e) {
          problems.push(`${file.name}: ${e instanceof Error ? e.message : String(e)}`);
        }
      }
      this.render();
      const summary = [`QR ${added}개를 가져왔어요.`, converted ? `${converted}개는 마리나라 기준으로 바꿔서 저장했어요.` : "", kept.length ? `${kept.length}개는 실리태번 기준으로 남겼어요.` : ""].filter(Boolean).join(" ");
      this.deps.ui.toast(summary, problems.length || kept.length ? "warning" : "success");
      if (problems.length || kept.length) {
        const parts: string[] = [];
        if (kept.length) parts.push(`<b>실리태번 기준으로 남긴 QR</b> (메시지 번호를 자동으로 바꿀 수 없었어요)<br>${kept.map(escapeHtml).join("<br>")}`);
        if (problems.length) parts.push(`<b>아직 지원하지 않는 명령이 들어 있는 QR</b><br>${problems.map(escapeHtml).join("<br>")}`);
        await this.deps.ui.popup(parts.join("<br><br>"), { wide: true });
      }
      if (this.deps.store.overLimit()) this.deps.ui.toast("저장 공간이 거의 찼어요. 쓰지 않는 세트를 지워 주세요.", "warning");
    });
    input.click();
  }

  private async exportSet(set: QrSet, format: "st" | "marinara"): Promise<void> {
    if (format === "st") {
      const foreign = nonSillyTavernCommands(set, this.deps.registry);
      if (foreign.length) {
        const ok = await this.deps.ui.popup(
          `<b>실리태번에는 없는 명령이 들어 있는 QR이 있어요.</b> 실리태번에서는 이 부분이 동작하지 않아요.<br>${foreign.map((f) => escapeHtml(`${f.label}: /${f.commands.join(", /")}`)).join("<br>")}<br><br>그래도 .qr.json으로 내보낼까요? (마리나라에서 계속 쓸 거라면 .mqr.json이 좋아요)`,
          { okButton: "내보내기", cancelButton: "취소", wide: true },
        );
        if (!ok) return;
      }
    }
    const data = format === "st" ? exportSillyTavern(set, this.deps.registry, this.setName) : exportMarinara(set, this.setName);
    this.download(data, `${set.name || "qr-set"}.${format === "st" ? "qr" : "mqr"}.json`);
  }

  private download(data: unknown, name: string): void {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = el("a", { href: url, download: name.replace(/[\\/:*?"<>|]/g, "_") });
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

/** A copy of a QR with a new id. */
function cloneItem(item: QrItem): QrItem {
  const copy = JSON.parse(JSON.stringify(item)) as QrItem;
  copy.id = newId(item.kind === "ooc" ? "ooc" : "qr");
  return copy;
}

/** A copy of a set: new ids, sub menus that pointed at the set itself point at the copy. */
export function duplicateSet(set: QrSet, state: QrState): QrSet {
  const copy = JSON.parse(JSON.stringify(set)) as QrSet;
  copy.id = newId("set");
  const taken = new Set(state.sets.map((s) => s.name));
  let name = `${set.name} 복사본`;
  for (let n = 2; taken.has(name); n++) name = `${set.name} 복사본 ${n}`;
  copy.name = name;
  for (const item of copy.items) {
    item.id = newId(item.kind === "ooc" ? "ooc" : "qr");
    if (item.contextList) item.contextList = item.contextList.map((l) => (l.setId === set.id ? { ...l, setId: copy.id } : l));
  }
  return copy;
}

/** "#rrggbb" for the color picker (other CSS colors pass through when they already are). */
function toHex(color: string | undefined): string | undefined {
  if (!color) return undefined;
  if (/^#[0-9a-f]{6}$/i.test(color)) return color;
  const m = /rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)/i.exec(color);
  return m ? `#${[m[1], m[2], m[3]].map((n) => Number(n).toString(16).padStart(2, "0")).join("")}` : undefined;
}

function labelOf(text: string): string {
  const one = text.replace(/\s+/g, " ").trim();
  return one.length > 14 ? `${one.slice(0, 13)}…` : one || "QR";
}
function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}
