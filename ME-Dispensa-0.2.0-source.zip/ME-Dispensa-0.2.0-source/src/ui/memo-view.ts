// The 📝 tab of the Dispensa window: every memo (find, edit, pin, send,
// turn into a QR), adding many at once, a backup, and how the 메모장 sends OOC.

import { type Memo, type MemoState, memoLine, memosFrom, newMemo, shownMemos } from "../memo/model";
import type { MemoStore } from "../memo/store";
import type { HostUI } from "../stscript/host";
import { el, icon } from "./dom";
import { section, setting, toggle } from "./form";

export const MEMO_VIEW_CSS = `
.memo-list { display: flex; flex-direction: column; gap: 4px; margin-top: 6px; }
.memo-row { display: flex; align-items: center; gap: 4px; }
.memo-row > .entry { flex: 1; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.memo-row .pin.on { color: var(--d-accent); }
.memo-edit { margin: 2px 0 8px 0; display: flex; flex-direction: column; gap: 6px; }
.memo-edit textarea { font-family: var(--d-font); min-height: 90px; }
.memo-count { color: var(--d-muted); font-size: 12px; }
`;

type MenuEntry = { label: string; sub?: string; danger?: boolean; run: () => void | Promise<void> } | "-";

export interface MemoViewDeps {
  store: MemoStore;
  ui: HostUI;
  sendOoc(text: string): Promise<boolean>;
  putInInput(text: string): void;
  makePage(text: string): Promise<boolean>;
  /** Puts the memo into the 보관함 as a QR that sends it as OOC. */
  toQr(text: string): Promise<void>;
  /** The 🌟 settings' OOC parts: how to send, the wrappers. */
  oocSettings(): HTMLElement[];
  menu(summary: Node, label: string, entries: MenuEntry[]): HTMLElement;
  /** Runs a change without redrawing the window (typing in a memo). */
  quietly(fn: () => void): void;
  close(): void;
  rerender(): void;
}

export class MemoView {
  private query = "";
  private open: string | null = null;

  constructor(private readonly deps: MemoViewDeps) {}

  private get state(): MemoState {
    return this.deps.store.value;
  }

  private update(fn: (s: MemoState) => void): void {
    this.deps.store.update(fn);
  }

  render(): HTMLElement {
    return el("div", { class: "col wand-settings" }, this.memoCard(), this.barCard(), ...this.deps.oocSettings(), this.backupCard());
  }

  private memoCard(): HTMLElement {
    const all = this.state.memos;
    const shown = shownMemos(all, this.query);
    const list = el("div", { class: "memo-list" });
    for (const memo of shown) list.append(...this.row(memo));
    if (!all.length) list.append(el("div", { class: "note" }, "메모가 없어요. 채팅에서 글을 긁어 📝 메모를 누르거나, 새 메모를 만드세요."));
    else if (!shown.length) list.append(el("div", { class: "note" }, "찾는 메모가 없어요."));
    return el(
      "div",
      { class: "card" },
      section(
        "📝 메모",
        "OOC 문구, 페이지 소재처럼 나중에 쓸 글을 모아 두는 곳이에요.\n· 채팅에서 글을 긁으면 뜨는 📝 메모 버튼으로 저장돼요\n· 🍰 메뉴의 📝 버튼, [[메모]] 빈칸, /memo 명령으로 꺼내 써요\n· ⭐는 위에 고정해요",
        [
          el(
            "button",
            {
              onclick: () => {
                const memo = newMemo("새 메모");
                this.update((s) => s.memos.push(memo));
                this.open = memo.id;
                this.query = "";
                this.deps.rerender();
              },
            },
            icon("plus"),
            "새 메모",
          ),
          el("button", { title: "OOC 문구를 한꺼번에 붙여 넣어요. *{OOC: …}* 같은 포장은 벗기고 하나씩 나눠요.", onclick: () => void this.paste() }, icon("clipboard"), "여러 개 넣기"),
        ],
        el("input", {
          type: "search",
          placeholder: "메모 찾기",
          value: this.query,
          "data-key": "memo-search",
          "aria-label": "메모 찾기",
          oninput: (e: Event) => {
            this.query = (e.target as HTMLInputElement).value;
            this.deps.rerender();
          },
        }),
        el("div", { class: "memo-count" }, this.query ? `${shown.length} / ${all.length}개` : `${all.length}개`),
        list,
      ),
    );
  }

  private row(memo: Memo): HTMLElement[] {
    const isOpen = this.open === memo.id;
    const row = el(
      "div",
      { class: "memo-row" },
      el(
        "button",
        {
          class: `entry${isOpen ? " sel" : ""}`,
          title: memo.text.slice(0, 400),
          onclick: () => {
            this.open = isOpen ? null : memo.id;
            this.deps.rerender();
          },
        },
        memoLine(memo.text, 90) || "(빈 메모)",
      ),
      el(
        "button",
        {
          class: `icon pin${memo.pinned ? " on" : ""}`,
          title: memo.pinned ? "고정 풀기" : "위에 고정",
          "aria-label": memo.pinned ? "고정 풀기" : "위에 고정",
          "aria-pressed": String(!!memo.pinned),
          onclick: () => this.mutate(memo.id, (m) => (m.pinned ? delete m.pinned : (m.pinned = true))),
        },
        icon("pin"),
      ),
      this.deps.menu(icon("more"), "메모 메뉴", [
        { label: "💬 OOC로 보내기", run: () => (this.deps.close(), void this.deps.sendOoc(memo.text)) },
        { label: "입력창에 넣기", run: () => (this.deps.close(), this.deps.putInInput(memo.text)) },
        { label: "🌟 페이지 만들기", sub: "이 글을 소재로", run: () => (this.deps.close(), void this.deps.makePage(memo.text)) },
        { label: "QR로 만들기…", sub: "누르면 OOC로 보내는 QR을 보관함에", run: () => this.deps.toQr(memo.text) },
        { label: "복사", run: async () => (await this.deps.ui.copy?.(memo.text), this.deps.ui.toast("복사했어요.", "success", { title: "📝" })) },
        "-",
        { label: "삭제", danger: true, run: () => this.update((s) => (s.memos = s.memos.filter((m) => m.id !== memo.id))) },
      ]),
    );
    if (!isOpen) return [row];
    const ta = el("textarea", {
      "data-key": `memo-${memo.id}`,
      "aria-label": "메모 내용",
      oninput: (e: Event) => {
        const text = (e.target as HTMLTextAreaElement).value;
        this.deps.quietly(() => this.mutate(memo.id, (m) => (m.text = text)));
      },
    });
    ta.value = memo.text;
    return [row, el("div", { class: "memo-edit" }, ta)];
  }

  private mutate(id: string, fn: (m: Memo) => void): void {
    this.update((s) => {
      const m = s.memos.find((x) => x.id === id);
      if (m) fn(m);
    });
  }

  private async paste(): Promise<void> {
    const text = await this.deps.ui.input("넣을 글을 붙여 넣으세요.<br><small>*{OOC: …}* 같은 포장은 알아서 벗기고, 여러 개면 하나씩 나눠요.</small>", { rows: 8, multiline: true, wide: true, okButton: "넣기" });
    if (!text?.trim()) return;
    const memos = memosFrom(text);
    this.update((s) => s.memos.push(...memos));
    this.deps.ui.toast(`메모 ${memos.length}개를 넣었어요.`, "success", { title: "📝" });
  }

  private barCard(): HTMLElement {
    const s = this.state;
    return el(
      "div",
      { class: "card" },
      section(
        "퀵바",
        undefined,
        [],
        setting(
          "📝 버블",
          [
            el("input", { type: "text", class: "icon-input", value: s.barIcon, maxlength: "8", "data-key": "memo-bar-icon", "aria-label": "버블 아이콘", oninput: (e: Event) => this.update((x) => (x.barIcon = (e.target as HTMLInputElement).value.trim() || "📝")) }),
            toggle(s.showButton, (v) => this.update((x) => (x.showButton = v)), "📝 버블 보이기", "memo-show"),
          ],
          "퀵바에 메모장 버블을 둬요. 누르면 메모를 쓰고, 고르고, OOC로 보내요.",
        ),
        setting("글을 긁으면 📝 버튼", toggle(s.capture !== false, (v) => this.update((x) => (x.capture = v)), "글을 긁으면 📝 버튼", "memo-capture"), "채팅 메시지나 입력창에서 글을 고르면 그 아래에 📝 메모 버튼이 떠요. 누르면 메모장에 들어가요."),
      ),
    );
  }

  private backupCard(): HTMLElement {
    return el(
      "div",
      { class: "card" },
      section(
        "백업",
        "메모 전체를 .memo.json 파일 하나로 내보내고 가져와요. 가져오면 지금 메모에 더해져요.",
        [el("button", { onclick: () => this.exportJson() }, icon("upload"), "내보내기"), el("button", { onclick: () => this.importJson() }, icon("download"), "가져오기")],
      ),
    );
  }

  private exportJson(): void {
    const data = { format: "dispensa-memo", version: 1, memos: this.state.memos.map((m) => ({ text: m.text, pinned: m.pinned || undefined, createdAt: m.createdAt })) };
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    const a = el("a", { href: url, download: "dispensa.memo.json" });
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  private importJson(): void {
    const input = el("input", { type: "file", accept: ".json,application/json" });
    input.addEventListener("change", async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const json = JSON.parse(await file.text()) as { memos?: { text?: unknown; pinned?: unknown; createdAt?: unknown }[] };
        const have = new Set(this.state.memos.map((m) => m.text));
        const fresh = (json.memos ?? [])
          .filter((m) => typeof m.text === "string" && m.text.trim() && !have.has(m.text))
          .map((m) => ({ ...newMemo(String(m.text), Number(m.createdAt) || Date.now()), ...(m.pinned ? { pinned: true } : {}) }));
        this.update((s) => s.memos.push(...fresh));
        this.deps.ui.toast(`메모 ${fresh.length}개를 가져왔어요.`, "success", { title: "📝" });
      } catch (e) {
        this.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: "📝 가져오기" });
      }
    });
    input.click();
  }
}
