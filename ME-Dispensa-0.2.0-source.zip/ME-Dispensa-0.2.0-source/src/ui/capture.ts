// Saves a page as a PNG without the page loading anything: the extension draws
// the frame's document itself (html-to-image, bundled).

import { toBlob } from "html-to-image";

const BLANK_PIXEL = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";

function isClear(color: string): boolean {
  return !color || color === "transparent" || /rgba\([^)]*,\s*0\)$/.test(color);
}

/** The whole document of a same-origin frame, as it looks now (scripts' changes included). */
export async function captureDocument(doc: Document): Promise<Blob> {
  const html = doc.documentElement;
  const body = doc.body ?? html;
  const view = doc.defaultView ?? window;
  const width = Math.max(html.scrollWidth, body.scrollWidth, 1);
  const height = Math.max(html.scrollHeight, body.scrollHeight, 1);
  const bodyBg = view.getComputedStyle(body).backgroundColor;
  const htmlBg = view.getComputedStyle(html).backgroundColor;
  const backgroundColor = !isClear(bodyBg) ? bodyBg : !isClear(htmlBg) ? htmlBg : "#ffffff";
  const options = { width, height, backgroundColor, pixelRatio: Math.min(2, window.devicePixelRatio || 1), imagePlaceholder: BLANK_PIXEL };
  let blob: Blob | null;
  try {
    blob = await toBlob(body, options);
  } catch {
    // web fonts it could not read: draw with the fonts at hand
    blob = await toBlob(body, { ...options, skipFonts: true });
  }
  if (!blob) throw new Error("이미지를 만들지 못했어요.");
  return blob;
}

/** A frame's page, or the code drawn in a scratch frame when the frame is out of reach. */
export async function capturePage(frame: HTMLIFrameElement | null, code: string): Promise<Blob> {
  const doc = frame && readable(frame);
  if (doc) return captureDocument(doc);
  const scratch = document.createElement("iframe");
  scratch.setAttribute("sandbox", "allow-same-origin");
  scratch.style.cssText = `position:fixed;left:-10000px;top:0;width:${frame?.clientWidth || 800}px;height:600px;border:0;`;
  const loaded = new Promise<void>((resolve) => scratch.addEventListener("load", () => resolve(), { once: true }));
  scratch.srcdoc = code;
  document.body.append(scratch);
  try {
    await loaded;
    const d = readable(scratch);
    if (!d) throw new Error("이미지를 만들지 못했어요.");
    return await captureDocument(d);
  } finally {
    scratch.remove();
  }
}

function readable(frame: HTMLIFrameElement): Document | null {
  try {
    const doc = frame.contentDocument;
    return doc?.documentElement ? doc : null;
  } catch {
    return null;
  }
}

export function saveBlob(blob: Blob, name: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}
