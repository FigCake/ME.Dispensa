// Where a set is on: every chat (set.enabled), one chat, or one character
// (SillyTavern's global / chat / character set lists).

import type { QrSet, QrState } from "./model";

/** The chat on screen: its id and the characters in it. */
export interface ChatScope {
  chatId: string | null;
  characterIds: string[];
}

export const NO_CHAT: ChatScope = { chatId: null, characterIds: [] };

/** Sets that are on here, in SillyTavern's order: every chat, this chat, this character. */
export function activeSets(state: QrState, scope: ChatScope): QrSet[] {
  const ids: string[] = state.sets.filter((s) => s.enabled).map((s) => s.id);
  if (scope.chatId) ids.push(...(state.chatSets[scope.chatId] ?? []));
  for (const c of scope.characterIds) ids.push(...(state.charSets[c] ?? []));
  const out: QrSet[] = [];
  for (const id of new Set(ids)) {
    const set = state.sets.find((s) => s.id === id);
    if (set) out.push(set);
  }
  return out;
}

export function isOnForChat(state: QrState, setId: string, chatId: string | null): boolean {
  return !!chatId && (state.chatSets[chatId] ?? []).includes(setId);
}

export function isOnForCharacter(state: QrState, setId: string, characterId: string): boolean {
  return (state.charSets[characterId] ?? []).includes(setId);
}

function toggleIn(lists: Record<string, string[]>, key: string, setId: string, on: boolean): void {
  const list = (lists[key] ?? []).filter((id) => id !== setId);
  if (on) list.push(setId);
  if (list.length) lists[key] = list;
  else delete lists[key];
}

export function setForChat(state: QrState, chatId: string, setId: string, on: boolean): void {
  toggleIn(state.chatSets, chatId, setId, on);
}

export function setForCharacter(state: QrState, characterId: string, setId: string, on: boolean): void {
  toggleIn(state.charSets, characterId, setId, on);
}

/** How many other chats / characters a set is on for (shown next to the switches). */
export function elsewhere(state: QrState, setId: string, scope: ChatScope): { chats: number; characters: number } {
  const chats = Object.entries(state.chatSets).filter(([id, sets]) => id !== scope.chatId && sets.includes(setId)).length;
  const characters = Object.entries(state.charSets).filter(([id, sets]) => !scope.characterIds.includes(id) && sets.includes(setId)).length;
  return { chats, characters };
}

/** A deleted set leaves no ids behind (in the lists or in other QRs' sub menus). */
export function forgetSet(state: QrState, setId: string): void {
  for (const lists of [state.chatSets, state.charSets]) for (const key of Object.keys(lists)) toggleIn(lists, key, setId, false);
  for (const set of state.sets) {
    for (const item of set.items) {
      if (!item.contextList) continue;
      item.contextList = item.contextList.filter((l) => l.setId !== setId);
      if (!item.contextList.length) delete item.contextList;
    }
  }
}
