// Bringing Quick Replies in from SillyTavern, and turning OOC notes into QRs.

import { ParseError } from "../stscript/ast";
import { parse } from "../stscript/parser";
import type { CommandRegistry } from "../stscript/registry";
import type { Closure } from "../stscript/ast";
import { convertToMarinara, convertToSillyTavern } from "./convert";
import { type QrItem, type QrSet, type QrState, newId, newItem, newSet } from "./model";
import { emojiForIcon, iconForEmoji } from "./icons";

interface StQr {
  label?: string;
  title?: string;
  message?: string;
  mes?: string;
  icon?: string;
  showLabel?: boolean;
  contextList?: { set?: string; isChained?: boolean }[];
  preventAutoExecute?: boolean;
  isHidden?: boolean;
  executeOnStartup?: boolean;
  executeOnUser?: boolean;
  executeOnAi?: boolean;
  executeOnChatChange?: boolean;
  executeOnNewChat?: boolean;
  executeOnGroupMemberDraft?: boolean;
  executeBeforeGeneration?: boolean;
  automationId?: string;
}

interface StSet {
  name?: string;
  qrList?: StQr[];
  quickReplySlots?: StQr[];
  disableSend?: boolean;
  placeBeforeInput?: boolean;
  injectInput?: boolean;
  color?: string;
  onlyBorderColor?: boolean;
}

/** A sub menu link waiting for its set by name (the set may come in the same file or exist already). */
export interface PendingLink {
  item: QrItem;
  setName: string;
  chained: boolean;
}

export interface ImportReport {
  sets: QrSet[];
  /** Single QRs (a file of one QR): they go into the set that is open. */
  items: QrItem[];
  links: PendingLink[];
  total: number;
  /** label → unknown commands */
  unsupported: { set: string; label: string; commands: string[] }[];
  parseErrors: { set: string; label: string; error: string }[];
  /** Rewritten to Marinara numbering on import. */
  converted: number;
  /** Kept in SillyTavern mode, with reasons. */
  keptSillyTavern: { set: string; label: string; reasons: string[] }[];
}

/** Commands used in a script that the interpreter does not know. */
export function findUnsupported(script: string, registry: CommandRegistry): string[] | { error: string } {
  if (!script.trimStart().startsWith("/")) return [];
  let closure: Closure;
  try {
    closure = parse(script, { lookup: (n) => registry.get(n) });
  } catch (e) {
    return { error: e instanceof ParseError ? e.message : String(e) };
  }
  const unknown = new Set<string>();
  const walk = (c: Closure) => {
    for (const ex of c.executors) {
      if (ex.kind === "command") {
        if (!registry.has(ex.name)) unknown.add(ex.name);
        for (const a of ex.named) if (typeof a.value !== "string") walk(a.value);
        for (const a of ex.unnamed) if (typeof a.value !== "string") walk(a.value);
      }
    }
    for (const a of c.args) if (typeof a.value !== "string") walk(a.value);
  };
  walk(closure);
  return [...unknown].sort();
}

const emptyReport = (): ImportReport => ({ sets: [], items: [], links: [], total: 0, unsupported: [], parseErrors: [], converted: 0, keptSillyTavern: [] });

/** One SillyTavern QR (a file of a single QR, from its ⋯ menu's export). */
function isStItem(json: unknown): json is StQr {
  if (!json || typeof json !== "object" || Array.isArray(json)) return false;
  const j = json as Record<string, unknown>;
  return typeof j.label === "string" && typeof j.message === "string" && !("qrList" in j);
}

export function importSillyTavern(json: unknown, registry: CommandRegistry, fallbackName = "가져온 QR"): ImportReport {
  const report = emptyReport();
  if (isStItem(json)) {
    const item = stItem(json, registry, report, "");
    if (item) report.items.push(item);
    return report;
  }
  const list: StSet[] = Array.isArray(json) ? (json as StSet[]) : [json as StSet];
  for (const raw of list) {
    if (!raw || typeof raw !== "object") continue;
    const qrs = raw.qrList ?? raw.quickReplySlots;
    if (!Array.isArray(qrs)) continue;
    const set = newSet(String(raw.name || fallbackName), "st");
    set.disableSend = !!raw.disableSend;
    set.placeBeforeInput = !!raw.placeBeforeInput;
    set.injectInput = !!raw.injectInput;
    if (raw.color && raw.color !== "rgba(0, 0, 0, 0)" && raw.color !== "transparent") set.color = raw.color;
    if (raw.onlyBorderColor) set.colorBorderOnly = true;
    for (const q of qrs) {
      const item = stItem(q, registry, report, set.name);
      if (item) set.items.push(item);
    }
    report.sets.push(set);
  }
  return report;
}

function stItem(q: StQr, registry: CommandRegistry, report: ImportReport, setName: string): QrItem | null {
  const script = String(q.message ?? q.mes ?? "");
  if (!script.trim() && !q.label && !q.contextList?.length) return null;
  const auto: QrItem["auto"] = {};
  if (q.executeOnStartup) auto.startup = true;
  if (q.executeOnUser) auto.user = true;
  if (q.executeOnAi) auto.ai = true;
  if (q.executeOnChatChange) auto.chatChange = true;
  if (q.executeOnNewChat) auto.newChat = true;
  if (q.executeOnGroupMemberDraft) auto.groupDraft = true;
  if (q.executeBeforeGeneration) auto.beforeGeneration = true;
  const item: QrItem = { ...newItem(String(q.label || (q.icon ? "" : "QR")), script, "st") };
  if (q.title) item.title = q.title;
  if (q.isHidden) item.hidden = true;
  if (Object.keys(auto).length) item.auto = auto;
  if (q.automationId?.trim()) item.automationId = q.automationId.trim();
  if (q.preventAutoExecute === false) item.preventAuto = false;
  const emoji = q.icon ? emojiForIcon(q.icon) : undefined;
  if (emoji) {
    item.icon = emoji;
    if (!q.showLabel && item.label) item.showLabel = false;
  }
  if (!item.label) item.label = emoji ?? "QR";
  for (const link of q.contextList ?? []) if (link?.set) report.links.push({ item, setName: link.set, chained: !!link.isChained });
  check(item, registry, report, setName);
  applyConversion(item, registry);
  if (item.dialect === "marinara") report.converted++;
  else report.keptSillyTavern.push({ set: setName, label: item.label, reasons: item.note ? item.note.split("\n") : [] });
  report.total++;
  return item;
}

function check(item: QrItem, registry: CommandRegistry, report: ImportReport, setName: string): void {
  const found = findUnsupported(item.script, registry);
  if (Array.isArray(found)) {
    if (found.length) {
      item.unsupported = found;
      report.unsupported.push({ set: setName, label: item.label, commands: found });
    }
  } else {
    item.unsupported = ["(문법 오류)"];
    report.parseErrors.push({ set: setName, label: item.label, error: found.error });
  }
}

/** Sub menu links by set name → ids, once the imported sets are in (newest set of a name wins). */
export function resolveLinks(state: QrState, links: PendingLink[]): string[] {
  const missing = new Set<string>();
  for (const { item, setName, chained } of links) {
    const set = [...state.sets].reverse().find((s) => s.name === setName);
    if (!set) {
      missing.add(setName);
      continue;
    }
    item.contextList = [...(item.contextList ?? []), chained ? { setId: set.id, chained: true } : { setId: set.id }];
  }
  return [...missing];
}

/**
 * Rewrite an imported QR to Marinara numbering once. On success the QR becomes
 * an ordinary Marinara QR; otherwise it keeps SillyTavern mode and a note.
 */
export function applyConversion(item: QrItem, registry: CommandRegistry): boolean {
  const result = convertToMarinara(item.script, registry);
  if (result.ok) {
    item.script = result.script;
    item.dialect = "marinara";
    delete item.note;
    return true;
  }
  item.dialect = "st";
  item.note = result.reasons.join("\n");
  return false;
}

// ── Marinara (Dispensa) format: .mqr.json ────────────────────

export const MQR_FORMAT = "dispensa-mqr";

/** Set id → name for sub menu links in exported files. */
export type SetNames = (setId: string) => string | undefined;

/** Dispensa's own format: Marinara numbering, QR kinds, auto triggers and Dispensa commands kept as they are. */
export function exportMarinara(set: QrSet, names?: SetNames): unknown {
  return {
    format: MQR_FORMAT,
    version: 1,
    name: set.name,
    display: set.display,
    color: set.color,
    colorBorderOnly: set.colorBorderOnly || undefined,
    icon: set.icon,
    disableSend: !!set.disableSend,
    placeBeforeInput: !!set.placeBeforeInput,
    injectInput: !!set.injectInput,
    items: set.items.map((i) => mqrItem(i, names)),
  };
}

export const MQR_ITEM_FORMAT = "dispensa-mqr-item";

/** One QR in Dispensa's format. */
export function exportMarinaraItem(item: QrItem, names?: SetNames): unknown {
  return { format: MQR_ITEM_FORMAT, version: 1, item: mqrItem(item, names) };
}

function mqrItem(i: QrItem, names?: SetNames): Record<string, unknown> {
  const links = (i.contextList ?? []).map((l) => ({ set: names?.(l.setId), chained: !!l.chained })).filter((l) => l.set);
  return {
    label: i.label,
    title: i.title,
    script: i.script,
    kind: i.kind,
    dialect: i.dialect,
    icon: i.icon,
    showLabel: i.showLabel === false ? false : undefined,
    hidden: !!i.hidden,
    auto: i.auto,
    automationId: i.automationId,
    preventAuto: i.preventAuto === false ? false : undefined,
    contextList: links.length ? links : undefined,
    viz: i.kind === "viz" ? i.viz : undefined,
  };
}

/** Files exported before the rename to Dispensa carry the old format name. */
const isMqrFormat = (format: unknown) => format === MQR_FORMAT || format === "shelter-mqr";

export function isMarinaraQr(json: unknown): boolean {
  if (!json || typeof json !== "object") return false;
  const j = json as { format?: unknown; sets?: unknown };
  return isMqrFormat(j.format) || j.format === MQR_ITEM_FORMAT || (Array.isArray(j.sets) && j.sets.some((s) => s && typeof s === "object" && isMqrFormat((s as { format?: unknown }).format)));
}

/** Read .mqr.json: no numbering conversion, the QRs are already Marinara QRs. */
export function importMarinara(json: unknown, registry: CommandRegistry, fallbackName = "가져온 QR"): ImportReport {
  const report = emptyReport();
  const j = json as { sets?: unknown[]; format?: unknown; item?: unknown };
  if (j.format === MQR_ITEM_FORMAT) {
    if (j.item && typeof j.item === "object") report.items.push(mqrToItem(j.item as Record<string, unknown>, registry, report, ""));
    return report;
  }
  const list = Array.isArray(j.sets) ? j.sets : [json];
  for (const raw of list as Record<string, unknown>[]) {
    if (!raw || !isMqrFormat(raw.format) || !Array.isArray(raw.items)) continue;
    const set = newSet(String(raw.name || fallbackName));
    set.display = raw.display === "inline" ? "inline" : "folder";
    if (typeof raw.color === "string") set.color = raw.color;
    if (raw.colorBorderOnly) set.colorBorderOnly = true;
    if (typeof raw.icon === "string" && raw.icon.trim()) set.icon = raw.icon;
    set.disableSend = !!raw.disableSend;
    set.placeBeforeInput = !!raw.placeBeforeInput;
    set.injectInput = !!raw.injectInput;
    for (const r of raw.items as Record<string, unknown>[]) set.items.push(mqrToItem(r, registry, report, set.name));
    report.sets.push(set);
  }
  return report;
}

function mqrToItem(r: Record<string, unknown>, registry: CommandRegistry, report: ImportReport, setName: string): QrItem {
  const item: QrItem = {
    ...newItem(String(r.label ?? "QR"), String(r.script ?? ""), r.dialect === "st" ? "st" : "marinara", r.kind === "ooc" || r.kind === "viz" ? r.kind : "script"),
    title: typeof r.title === "string" && r.title ? r.title : undefined,
    icon: typeof r.icon === "string" ? r.icon : undefined,
    hidden: !!r.hidden,
    auto: r.auto && typeof r.auto === "object" ? (r.auto as QrItem["auto"]) : undefined,
  };
  if (r.showLabel === false) item.showLabel = false;
  if (typeof r.automationId === "string" && r.automationId.trim()) item.automationId = r.automationId.trim();
  if (r.preventAuto === false) item.preventAuto = false;
  if (Array.isArray(r.contextList)) {
    for (const l of r.contextList as { set?: unknown; chained?: unknown }[]) if (typeof l?.set === "string") report.links.push({ item, setName: l.set, chained: !!l.chained });
  }
  report.total++;
  if (item.kind === "viz") {
    // 🌟 QRs: a request for the visualizer, not a script to check
    const v = r.viz && typeof r.viz === "object" ? (r.viz as Record<string, unknown>) : {};
    item.viz = { ...(v as Partial<NonNullable<QrItem["viz"]>>), action: v.action === "ooc" ? "ooc" : "viz" };
    return item;
  }
  check(item, registry, report, setName);
  if (item.dialect === "st") report.keptSillyTavern.push({ set: setName, label: item.label, reasons: ["실리태번 기준으로 저장된 QR이에요"] });
  return item;
}

/** Either format: .mqr.json as is, anything else as a SillyTavern QR set. */
export function importAny(json: unknown, registry: CommandRegistry, fallbackName?: string): ImportReport {
  return isMarinaraQr(json) ? importMarinara(json, registry, fallbackName) : importSillyTavern(json, registry, fallbackName);
}

/** QRs that use commands SillyTavern does not have (Dispensa or Marinara ones). */
/** Commands in a script that SillyTavern doesn't have (Dispensa or Marinara ones), sorted. */
export function foreignCommands(script: string, registry: CommandRegistry): string[] {
  if (!script.trimStart().startsWith("/")) return [];
  let closure: Closure;
  try {
    closure = parse(script, { lookup: (n) => registry.get(n) });
  } catch {
    return [];
  }
  const found = new Set<string>();
  const walk = (c: Closure) => {
    for (const ex of c.executors) {
      if (ex.kind !== "command") continue;
      const origin = registry.get(ex.name)?.origin;
      // /randomchar goes back to SillyTavern's /random on export
      if (origin && origin !== "st" && ex.name !== "randomchar") found.add(ex.name);
      for (const a of [...ex.named, ...ex.unnamed]) if (typeof a.value !== "string") walk(a.value);
    }
  };
  walk(closure);
  return [...found].sort();
}

export function nonSillyTavernCommands(set: QrSet, registry: CommandRegistry): { label: string; commands: string[] }[] {
  return set.items.map((item) => ({ label: item.label, commands: item.kind === "viz" ? ["visz"] : foreignCommands(item.script, registry) })).filter((f) => f.commands.length);
}

/** A 🌟 QR as STscript: /visz with its request (SillyTavern has no visualizer; Dispensa reads it back). */
export function vizScript(item: QrItem): string {
  const escaped = item.script.replace(/[|\\]/g, (c) => `\\${c}`);
  return `/visz action=${item.viz?.action ?? "viz"} ${escaped}`;
}

/** Back to SillyTavern's QR set format (version 2), numbering included. */
export function exportSillyTavern(set: QrSet, registry?: CommandRegistry, names?: SetNames): unknown {
  return {
    version: 2,
    name: set.name,
    disableSend: !!set.disableSend,
    placeBeforeInput: !!set.placeBeforeInput,
    injectInput: !!set.injectInput,
    color: set.color ?? "rgba(0, 0, 0, 0)",
    onlyBorderColor: !!set.colorBorderOnly,
    qrList: set.items.map((i, index) => stExportItem(i, index + 1, registry, names)),
    idIndex: set.items.length + 1,
  };
}

/** One QR in SillyTavern's format (what its ⋯ → export saves). */
export function stExportItem(i: QrItem, id: number, registry?: CommandRegistry, names?: SetNames): Record<string, unknown> {
  let message = i.script;
  if (i.kind === "viz") message = vizScript(i);
  else if (i.dialect !== "st" && registry) {
    const back = convertToSillyTavern(i.script, registry);
    if (back.ok) message = back.script;
  }
  const icon = i.icon ? iconForEmoji(i.icon) : undefined;
  return {
    id,
    icon: icon ?? "",
    showLabel: icon ? i.showLabel !== false : false,
    // the name stays as it is (/run finds QRs by name); an emoji with no Font Awesome match is left out
    label: i.label,
    title: i.title ?? "",
    message,
    contextList: (i.contextList ?? []).map((l) => ({ set: names?.(l.setId), isChained: !!l.chained })).filter((l) => l.set),
    preventAutoExecute: i.preventAuto !== false,
    isHidden: !!i.hidden,
    executeOnStartup: !!i.auto?.startup,
    executeOnUser: !!i.auto?.user,
    executeOnAi: !!i.auto?.ai,
    executeOnChatChange: !!i.auto?.chatChange,
    executeOnGroupMemberDraft: !!i.auto?.groupDraft,
    executeOnNewChat: !!i.auto?.newChat,
    executeBeforeGeneration: !!i.auto?.beforeGeneration,
    automationId: i.automationId ?? "",
  };
}

// ── OOC ─────────────────────────────────────────────────────

const OOC_PATTERNS: RegExp[] = [
  /\*\s*\{\s*OOC\s*[:：]\s*([\s\S]*?)\s*\}\s*\*/gi, // *{OOC: ...}*
  /\{\s*OOC\s*[:：]\s*([\s\S]*?)\s*\}/gi, // {OOC: ...}
  /\[\s*OOC\s*[:：]\s*([\s\S]*?)\s*\]/gi, // [OOC: ...]
  /\(\(\s*OOC\s*[:：]?\s*([\s\S]*?)\s*\)\)/gi, // ((OOC: ...))
  /\(\s*OOC\s*[:：]\s*([\s\S]*?)\s*\)/gi, // (OOC: ...)
  /\*\s*OOC\s*[:：]\s*([\s\S]*?)\s*\*/gi, // *OOC: ...*
];

/** Pull the instruction text out of OOC wrappers. Text without wrappers is one note. */
export function extractOocNotes(text: string): string[] {
  let rest = text;
  const notes: { index: number; body: string }[] = [];
  for (const re of OOC_PATTERNS) {
    rest = rest.replace(re, (match, body: string, offset: number) => {
      if (body.trim()) notes.push({ index: offset, body: body.trim() });
      return " ".repeat(match.length);
    });
  }
  // Lines like "OOC: ..." that were not wrapped
  rest = rest.replace(/^\s*OOC\s*[:：]\s*(.+)$/gim, (match, body: string, offset: number) => {
    if (body.trim()) notes.push({ index: offset, body: body.trim() });
    return " ".repeat(match.length);
  });
  notes.sort((a, b) => a.index - b.index);
  if (notes.length === 0 && text.trim()) return [text.trim()];
  return notes.map((n) => n.body);
}

export function labelFor(note: string): string {
  const oneLine = note.replace(/\s+/g, " ").trim();
  return oneLine.length > 14 ? `${oneLine.slice(0, 13)}…` : oneLine;
}

/** An OOC QR sends the note with Marinara's /guided: no chat message, the reply comes as the character's turn. */
export function oocScript(note: string): string {
  return `/guided ${note.replace(/\|/g, "\\|").replace(/\{:/g, "\\{:").replace(/:\}/g, "\\:}")}`;
}

export function oocItems(text: string): QrItem[] {
  return extractOocNotes(text).map((note) => ({ ...newItem(labelFor(note), oocScript(note), "marinara", "ooc"), title: note, ooc: note, id: newId("ooc") }));
}
