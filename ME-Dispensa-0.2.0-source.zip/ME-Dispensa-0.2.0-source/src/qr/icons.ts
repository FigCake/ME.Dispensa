// SillyTavern QR icons are Font Awesome classes; the quick bar shows emoji.
// Common ones map both ways; anything else becomes ⭐ on import.

const PAIRS: [string, string][] = [
  ["star", "⭐"], ["heart", "❤️"], ["heart-crack", "💔"], ["gear", "⚙️"], ["gears", "⚙️"], ["cog", "⚙️"], ["dice", "🎲"], ["dice-d20", "🎲"], ["dice-six", "🎲"],
  ["bolt", "⚡"], ["bolt-lightning", "⚡"], ["book", "📖"], ["book-open", "📖"], ["bookmark", "🔖"], ["pen", "🖊️"], ["pencil", "✏️"], ["pen-to-square", "📝"], ["feather", "🪶"],
  ["trash", "🗑️"], ["trash-can", "🗑️"], ["play", "▶️"], ["pause", "⏸️"], ["stop", "⏹️"], ["forward", "⏩"], ["backward", "⏪"],
  ["comment", "💬"], ["comments", "💬"], ["message", "💬"], ["comment-dots", "💬"], ["music", "🎵"], ["image", "🖼️"], ["images", "🖼️"], ["camera", "📷"], ["video", "🎬"],
  ["user", "👤"], ["users", "👥"], ["user-secret", "🕵️"], ["ghost", "👻"], ["fire", "🔥"], ["moon", "🌙"], ["sun", "☀️"], ["cloud", "☁️"], ["snowflake", "❄️"], ["droplet", "💧"], ["umbrella", "☂️"],
  ["wand-magic-sparkles", "🪄"], ["wand-magic", "🪄"], ["magic", "🪄"], ["hat-wizard", "🧙"], ["robot", "🤖"], ["paper-plane", "📨"], ["envelope", "✉️"], ["clock", "🕒"], ["hourglass", "⏳"],
  ["bell", "🔔"], ["flag", "🚩"], ["eye", "👁️"], ["eye-slash", "🙈"], ["lock", "🔒"], ["unlock", "🔓"], ["key", "🔑"], ["magnifying-glass", "🔍"], ["search", "🔍"],
  ["check", "✅"], ["xmark", "❌"], ["times", "❌"], ["plus", "➕"], ["minus", "➖"], ["arrow-right", "➡️"], ["arrow-left", "⬅️"], ["arrow-up", "⬆️"], ["arrow-down", "⬇️"],
  ["rotate", "🔄"], ["rotate-right", "🔄"], ["arrows-rotate", "🔄"], ["repeat", "🔁"], ["shuffle", "🔀"], ["list", "📋"], ["list-ul", "📋"], ["clipboard", "📋"],
  ["map", "🗺️"], ["compass", "🧭"], ["globe", "🌐"], ["earth-asia", "🌏"], ["skull", "💀"], ["crown", "👑"], ["gem", "💎"], ["gift", "🎁"], ["cake-candles", "🎂"],
  ["mug-hot", "☕"], ["coffee", "☕"], ["utensils", "🍴"], ["house", "🏠"], ["home", "🏠"], ["tree", "🌳"], ["leaf", "🍃"], ["seedling", "🌱"], ["paw", "🐾"], ["cat", "🐱"], ["dog", "🐶"], ["dragon", "🐉"],
  ["scroll", "📜"], ["brain", "🧠"], ["lightbulb", "💡"], ["face-smile", "🙂"], ["face-laugh", "😆"], ["face-grin", "😁"], ["face-sad-tear", "😢"], ["face-angry", "😠"], ["face-surprise", "😮"],
  ["floppy-disk", "💾"], ["save", "💾"], ["copy", "📄"], ["paste", "📋"], ["code", "💻"], ["terminal", "💻"], ["bug", "🐛"], ["wrench", "🔧"], ["hammer", "🔨"], ["screwdriver-wrench", "🛠️"],
  ["shield", "🛡️"], ["shield-halved", "🛡️"], ["chess", "♟️"], ["chess-knight", "♞"], ["puzzle-piece", "🧩"], ["trophy", "🏆"], ["medal", "🏅"], ["rocket", "🚀"], ["plane", "✈️"], ["car", "🚗"],
  ["ship", "🚢"], ["anchor", "⚓"], ["mountain", "⛰️"], ["water", "🌊"], ["wind", "💨"], ["masks-theater", "🎭"], ["palette", "🎨"], ["paintbrush", "🖌️"], ["brush", "🖌️"], ["guitar", "🎸"],
  ["headphones", "🎧"], ["microphone", "🎤"], ["phone", "📞"], ["mobile", "📱"], ["mobile-screen", "📱"], ["calendar", "📅"], ["calendar-days", "📅"], ["sparkles", "✨"], ["wand-sparkles", "🪄"],
  ["circle-info", "ℹ️"], ["info", "ℹ️"], ["circle-question", "❓"], ["question", "❓"], ["exclamation", "❗"], ["triangle-exclamation", "⚠️"], ["ban", "🚫"], ["hand", "✋"], ["thumbs-up", "👍"], ["thumbs-down", "👎"],
  ["kiss-wink-heart", "😘"], ["face-kiss-wink-heart", "😘"], ["bed", "🛏️"], ["shower", "🚿"], ["bath", "🛁"], ["money-bill", "💵"], ["coins", "🪙"], ["cart-shopping", "🛒"], ["bag-shopping", "🛍️"],
  ["film", "🎞️"], ["tv", "📺"], ["newspaper", "📰"], ["quote-left", "❝"], ["at", "@"], ["hashtag", "#"], ["link", "🔗"], ["paperclip", "📎"], ["thumbtack", "📌"], ["location-dot", "📍"],
];

const BY_NAME = new Map(PAIRS);
const BY_EMOJI = new Map<string, string>();
for (const [name, emoji] of PAIRS) if (!BY_EMOJI.has(emoji)) BY_EMOJI.set(emoji, name);

/** "fa-solid fa-star" → "⭐" (unknown icons: ⭐, so the QR still has one). */
export function emojiForIcon(icon: string): string | undefined {
  const names = icon
    .split(/\s+/)
    .map((c) => c.replace(/^fa-/, ""))
    .filter((c) => c && !["fa", "solid", "regular", "light", "thin", "duotone", "brands", "fw", "lg", "xl", "sm", "xs"].includes(c) && !/^\d+x$/.test(c));
  if (!names.length) return undefined;
  for (const n of names) {
    const hit = BY_NAME.get(n);
    if (hit) return hit;
  }
  return "⭐";
}

/** "⭐" → "fa-solid fa-star", when SillyTavern has a match. */
export function iconForEmoji(emoji: string): string | undefined {
  const name = BY_EMOJI.get(emoji.trim()) ?? BY_EMOJI.get(emoji.trim().replace(/️/g, "")) ?? BY_EMOJI.get(`${emoji.trim()}️`);
  return name ? `fa-solid fa-${name}` : undefined;
}
