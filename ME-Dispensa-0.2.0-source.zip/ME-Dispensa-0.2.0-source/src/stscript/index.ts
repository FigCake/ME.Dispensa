import { chatCommands } from "./commands/chat";
import { coreCommands } from "./commands/core";
import { textCommands } from "./commands/text";
import { uiCommands } from "./commands/ui";
import { qrCommands } from "./commands/qr";
import { marinaraCommands } from "./commands/marinara";
import { wandCommands } from "./commands/wand";
import { memoCommands } from "./commands/memo";
import { CommandRegistry } from "./registry";

export function createRegistry(): CommandRegistry {
  return new CommandRegistry().register(...coreCommands, ...chatCommands, ...textCommands, ...uiCommands, ...qrCommands, ...marinaraCommands, ...wandCommands, ...memoCommands);
}

export { CommandRegistry } from "./registry";
export type { CommandDef } from "./registry";
export { Runtime, AbortScript, type RunResult } from "./interpreter";
export { parse } from "./parser";
export { ParseError } from "./ast";
export { Scope, ScriptError, type Val } from "./scope";
export { MemoryVariableStore, type VariableStore } from "./variables";
export type * from "./host";
