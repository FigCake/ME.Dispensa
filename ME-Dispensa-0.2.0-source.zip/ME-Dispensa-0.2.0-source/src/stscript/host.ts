// What the interpreter needs from the outside world. The Marinara binding
// implements this against the live app; tests use an in-memory fake.

import type { QrItem, QrSet } from "../qr/model";
import type { MacroFacts } from "./macros";
import type { VariableStore } from "./variables";

export type Severity = "info" | "success" | "warning" | "error";

export interface PopupOptions {
  large?: boolean;
  wide?: boolean;
  okButton?: string;
  cancelButton?: string;
  rows?: number;
  placeholder?: string;
  defaultValue?: string;
  multiline?: boolean;
  /** input(): a button beside OK that fills the field (📝 메모장). */
  extra?: { label: string; title?: string; fill(): Promise<string | null> };
}

export interface HostUI {
  toast(message: string, severity?: Severity, options?: { title?: string }): void;
  /** Resolves with the typed text, or null when cancelled. */
  input(prompt: string, options?: PopupOptions): Promise<string | null>;
  /** Resolves true for OK, false for cancel. */
  popup(html: string, options?: PopupOptions): Promise<boolean>;
  /** Resolves with the clicked label, or "" when cancelled. */
  buttons(html: string, labels: string[], options?: { multiple?: boolean }): Promise<string>;
  setInput(text: string): void;
  getInput(): string;
  beep(): void;
  loader(state: "show" | "hide", text?: string): void;
  /** Several fields at once. Resolves with name → value, or null when cancelled. */
  form?(title: string, fields: FormField[]): Promise<Record<string, string> | null>;
  /** Searchable list. Resolves with the chosen labels ([] when cancelled). */
  pick?(prompt: string, items: string[], options?: { multiple?: boolean; placeholder?: string }): Promise<string[]>;
  /** System notification (falls back to a toast). */
  notify?(title: string, body: string): Promise<void>;
  copy?(text: string): Promise<void>;
  paste?(): Promise<string>;
}

export interface FormField {
  name: string;
  label?: string;
  type?: "text" | "number" | "textarea" | "select" | "checkbox";
  default?: string;
  placeholder?: string;
  options?: string[];
}

export interface ChatMessageInfo {
  /** 1-based position, the way Marinara numbers messages. */
  number: number;
  id: string;
  role: "user" | "assistant" | "system" | "narrator";
  name: string;
  content: string;
  hidden: boolean;
}

export interface GenerateOptions {
  /** "chat": with the chat's context (ST /gen). "raw": only the prompt (ST /genraw). */
  mode: "chat" | "raw";
  prompt: string;
  lock?: boolean;
  stop?: string[];
  /** Raw mode: role of the prompt line. */
  as?: "system" | "char";
  /** Generate on behalf of a specific character (ST /ask, /gen in groups). */
  characterName?: string;
  /** Use this Marinara connection instead of the chat's own (chat mode). */
  connectionId?: string;
}

export interface SendOptions {
  role: "user" | "assistant" | "system" | "narrator";
  text: string;
  /** Character name for assistant messages. */
  name?: string;
  /** 1-based position to insert at (best effort). */
  at?: number;
  /** Shown in the chat but kept out of the AI's context (ST /comment). */
  hidden?: boolean;
}

export interface HostChat {
  /** Throws when no chat is open. */
  requireChat(): Promise<string>;
  messages(): Promise<ChatMessageInfo[]>;
  generate(options: GenerateOptions): Promise<string>;
  send(options: SendOptions): Promise<void>;
  setHidden(numbers: number[], hidden: boolean): Promise<number>;
  /** Run one of Marinara's own slash commands through the composer. */
  runNativeCommand(commandLine: string): Promise<void>;
  continueLast(): Promise<void>;
  regenerate(): Promise<void>;
  /** Start a normal generation, optionally for one group member. */
  trigger(characterName?: string): Promise<void>;
  addSwipe(text: string): Promise<void>;
  deleteMessages(numbers: number[]): Promise<number>;
  /** Refresh chat-related caches after writes. */
  refresh(): Promise<void>;
  /**
   * SillyTavern /random: pick a random character (optionally with a tag) and
   * open that character's latest chat, creating one if needed. Returns the name.
   */
  openRandomCharacter?(tag?: string): Promise<string>;
  /** Resolve when the AI is not generating (or after the timeout). True when idle. */
  waitForIdle?(timeoutMs: number): Promise<boolean>;
}

export interface Host {
  local: VariableStore;
  global: VariableStore;
  ui: HostUI;
  chat: HostChat;
  facts(): MacroFacts;
  /** Recompute facts (chat may have changed). */
  refreshFacts(): Promise<void>;
  resolveHostMacros?(text: string): Promise<string>;
  /** Called once before a script starts (reload chat state). */
  beginRun?(): Promise<void>;
  /** Persist variable changes. */
  flush(): Promise<void>;
  /** Ask the user before something destructive. */
  confirm(message: string): Promise<boolean>;
  /** Quick Reply storage and bar, when running inside Dispensa. */
  qr?: QrControl;
  /** The 🌟 wand, when running inside Dispensa. */
  wand?: WandControl;
  /** The 📝 메모장, when running inside Dispensa. */
  memo?: MemoControl;
  /** Marinara-only features (tracker, lorebooks, connections, ...). */
  marinara?: MarinaraExtras;
}

export interface LoreBookInfo {
  id: string;
  name: string;
  chatId?: string | null;
}

export interface MarinaraExtras {
  getTracker(): Promise<import("../marinara/tracker").TrackerState | null>;
  /** Send the named top-level fields of `state` back (they replace the stored ones). */
  patchTracker(state: import("../marinara/tracker").TrackerState, fields: string[]): Promise<void>;
  retryAgents(types: string[]): Promise<{ ran: string[]; errors: string[] }>;
  /** Lorebooks active in the current chat. */
  activeBooks(): Promise<LoreBookInfo[]>;
  /** The chat's own lorebook, created on request. */
  chatBook(create: boolean): Promise<LoreBookInfo | null>;
  findBook(nameOrId: string): Promise<LoreBookInfo | null>;
  entries(bookId: string): Promise<import("../marinara/lore").LoreEntry[]>;
  createEntry(bookId: string, data: Record<string, unknown>): Promise<import("../marinara/lore").LoreEntry>;
  patchEntry(bookId: string, entryId: string, patch: Record<string, unknown>): Promise<void>;
  /** The current character (or one in the chat by name), with its card data. */
  character(name?: string): Promise<{ id: string; data: Record<string, unknown> } | null>;
  updateCharacter(id: string, data: Record<string, unknown>): Promise<void>;
  persona(): Promise<Record<string, unknown> | null>;
  connections(): Promise<{ id: string; name: string; model?: string }[]>;
  currentConnection(): Promise<{ id: string; name: string } | null>;
  setConnection(id: string): Promise<void>;
  peekPrompt(): Promise<{ role: string; content: string }[]>;
  chatName(): Promise<string>;
  renameChat(name: string): Promise<void>;
  /** New chat with the current character(s), greeting included; opens it. Returns the chat name. */
  newChat(): Promise<string>;
  authorNote(): Promise<{ text: string; depth: number }>;
  setAuthorNote(text: string | undefined, depth?: number): Promise<void>;
  reloadPage(): Promise<void>;
}

export interface QrInfo {
  set: string;
  label: string;
  title: string;
  message: string;
  hidden: boolean;
  startup: boolean;
  user: boolean;
  bot: boolean;
  load: boolean;
  newChat: boolean;
  group: boolean;
  generation: boolean;
  /** An emoji or a Font Awesome class (turned into an emoji). */
  icon: string;
  showLabel: boolean;
}

/** Which QR: by set and label, or by its number in the set (id=, counted from 1). */
export interface QrRef {
  set: string;
  label?: string;
  id?: number;
}

export interface QrSetOptions {
  nosend?: boolean;
  before?: boolean;
  inject?: boolean;
  color?: string;
  onlyBorder?: boolean;
}

export interface MemoControl {
  /** Memos chosen in a list (only those with `query` in them); null when none was chosen. */
  pick(query?: string): Promise<string | null>;
  /** Keeps text as memos (OOC wrappers come off; several notes, several memos). Returns how many. */
  add(text: string): number;
  list(): string[];
  /** Sends text as OOC the 메모장's way (its sending setting and wrapper). */
  ooc(text: string): Promise<boolean>;
}

export interface WandControl {
  /**
   * Run a wand item by title, or the text as a new request. action: "viz" | "ooc"
   * (default: the item's default button, or 🌟 for plain text); output: "viewer" | "chat".
   * Resolves true once the request went out.
   */
  run(textOrTitle: string, options: { action?: "viz" | "ooc"; output?: "viewer" | "chat" }): Promise<boolean>;
  /** Run a 🌟 QR (kind "viz") with its own button and options. */
  runQr?(set: QrSet, item: QrItem): Promise<boolean>;
}

export interface QrControl {
  /** Set names: all, the ones on in every chat ("global"), or the ones on for this chat ("chat"). */
  setNames(where?: "all" | "global" | "chat"): string[];
  labels(set: string): string[];
  /** A QR in SillyTavern's shape (plus Dispensa's own keys). */
  get(ref: QrRef): Record<string, unknown> | undefined;
  create(info: Partial<QrInfo> & { set: string; label: string }, dialect: Dialect): void;
  update(ref: QrRef, changes: Partial<QrInfo> & { newLabel?: string }): boolean;
  remove(ref: QrRef): boolean;
  createSet(name: string, options: QrSetOptions): void;
  updateSet(name: string, options: QrSetOptions): boolean;
  removeSet(name: string): boolean;
  /** On in every chat. state: true/false to set, undefined to toggle. Returns the new state. */
  setEnabled(name: string, state?: boolean): boolean;
  /** On for the open chat. state: true/false to set, undefined to toggle. Returns the new state. */
  setForChat(name: string, state?: boolean): boolean;
  setDisplay(name: string, display: "folder" | "inline"): boolean;
  /** Sub menus: add a set (chained or not), take one off, or clear them. */
  contextAdd(ref: QrRef, setName: string, chained: boolean): void;
  contextDel(ref: QrRef, setName: string): void;
  contextClear(ref: QrRef): void;
  /** state: true/false to set, undefined to toggle. Returns the new state. */
  barVisible(state?: boolean): boolean;
  /** Visible quick bar items in bar order, for SillyTavern's /qr index. */
  visible(): { set: string; label: string }[];
  /** Run a QR by name after a delay (ms). */
  runLater(name: string, delayMs: number): void;
  run(name: string): Promise<void>;
  /** The script of a QR found by "Label" or "Set.Label" (for /import). */
  source(name: string): ScriptSource | undefined;
}

/** A Quick Reply as the interpreter sees it (for /run and /:). */
export interface ScriptSource {
  script: string;
  dialect: Dialect;
  label: string;
  setName: string;
}

/**
 * "st": imported from SillyTavern, messages counted from 0.
 * "marinara": written in Dispensa, messages counted from 1 like Marinara.
 */
export type Dialect = "st" | "marinara";
