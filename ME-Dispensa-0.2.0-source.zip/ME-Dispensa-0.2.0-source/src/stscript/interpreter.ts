// Executes parsed STscript. Argument resolution mirrors SillyTavern: named
// arguments are macro-substituted, the unnamed argument falls back to the
// pipe (except for the first command of a closure or after `||`), closures
// are passed as values unless written `{: ... :}()`.

import type { ArgValue, Closure, CommandNode, Executor, ParserFlags } from "./ast";
import { ParseError } from "./ast";
import type { Dialect, Host, ScriptSource } from "./host";
import { substituteGlobal } from "./macros";
import { parse } from "./parser";
import { type ClosureValue, Scope, ScriptError, type Val, isClosureValue } from "./scope";
import type { CommandDef, CommandRegistry } from "./registry";

/** Shared by a closure and the closures it runs inline (/if bodies). */
export interface Frame {
  broken: boolean;
}

export interface RunResult {
  pipe: Val;
  aborted: boolean;
  abortReason?: string;
  isBreak: boolean;
}

export class AbortScript extends Error {
  constructor(
    readonly reason: string,
    readonly quiet: boolean,
  ) {
    super(reason || "Script aborted");
    this.name = "AbortScript";
  }
}

/** The text a closure was parsed from (offsets in its commands point into it). */
export interface SourceText {
  label: string;
  text: string;
}

/** One closure on the call stack. */
export interface DebugFrame {
  label: string;
  source: SourceText | null;
  scope: Scope;
  /** The command running in it. */
  node?: CommandNode;
}

/** Where a debugged script is about to run a command. */
export interface DebugStop {
  node: CommandNode;
  source: SourceText | null;
  scope: Scope;
  /** Closure depth (1 = the script itself). */
  depth: number;
  named: Record<string, Val>;
  unnamed: Val | Val[];
  /** Outermost first. */
  stack: DebugFrame[];
}

/** Stepping through a script (the QR editor's debugger): awaited before each command. */
export interface Debugger {
  beforeCommand(stop: DebugStop): Promise<void> | void;
}

export interface RuntimeOptions {
  host: Host;
  registry: CommandRegistry;
  dialect: Dialect;
  /** Look up a Quick Reply for /run and /:. */
  findScript?: (name: string) => ScriptSource | undefined;
  signal?: AbortSignal;
  maxDepth?: number;
  /** Names the script for the debugger and error messages. */
  source?: SourceText;
  debug?: Debugger;
}

export interface CommandCall {
  rt: Runtime;
  node: CommandNode;
  named: Record<string, Val>;
  /** Split commands receive an array; others a single value. */
  unnamed: Val | Val[];
  hasUnnamed: boolean;
  scope: Scope;
  frame: Frame;
}

export class Runtime {
  readonly host: Host;
  readonly registry: CommandRegistry;
  dialect: Dialect;
  private readonly findScript?: (name: string) => ScriptSource | undefined;
  private readonly signal?: AbortSignal;
  private depth = 0;
  private readonly maxDepth: number;
  private readonly source?: SourceText;
  private readonly debug?: Debugger;
  private readonly sources = new WeakMap<Closure, SourceText>();
  private readonly frames: DebugFrame[] = [];

  constructor(options: RuntimeOptions) {
    this.host = options.host;
    this.registry = options.registry;
    this.dialect = options.dialect;
    this.findScript = options.findScript;
    this.signal = options.signal;
    this.maxDepth = options.maxDepth ?? 64;
    this.source = options.source;
    this.debug = options.debug;
  }

  /** Remembers which text a closure (and the closures in it) came from. */
  private tagSource(closure: Closure, source: SourceText): void {
    if (!this.debug) return;
    const walk = (c: Closure) => {
      this.sources.set(c, source);
      for (const a of c.args) if (typeof a.value !== "string") walk(a.value);
      for (const ex of c.executors) {
        if (ex.kind !== "command") continue;
        for (const a of ex.named) if (typeof a.value !== "string") walk(a.value);
        for (const u of ex.unnamed) if (typeof u.value !== "string") walk(u.value);
      }
    };
    walk(closure);
  }

  /** Message index written in the script → Marinara's 1-based number. */
  toMarinaraNumber(index: number): number {
    return this.dialect === "st" ? index + 1 : index;
  }

  /** Marinara's 1-based number → index as the script expects it. */
  fromMarinaraNumber(n: number): number {
    return this.dialect === "st" ? n - 1 : n;
  }

  parse(text: string, flags?: Partial<ParserFlags>): Closure {
    return parse(text, { flags, lookup: (name) => this.registry.get(name) });
  }

  /** Run a whole script. Never throws for /abort; returns aborted instead. */
  async runScript(text: string, scope?: Scope): Promise<RunResult> {
    let closure: Closure;
    try {
      closure = this.parse(text);
    } catch (e) {
      if (e instanceof ParseError) throw new ScriptError(`Parse error at ${e.index}: ${e.message}`);
      throw e;
    }
    this.tagSource(closure, this.source && this.source.text === text ? this.source : { label: this.source?.label ?? "스크립트", text });
    await this.host.beginRun?.();
    const fresh = !scope;
    if (!scope) {
      scope = new Scope();
      // a QR's {{arg::name}} reads "" until /qr-arg or /run gives it a value
      scope.setMacro("arg::*", "");
    }
    const root: ClosureValue = { kind: "closure-value", closure, scope, flags: closure.executors[0]?.kind === "command" ? (closure.executors[0] as CommandNode).flags : defaultFlags() };
    try {
      const result = await this.runClosure(root, [], { broken: false }, fresh ? root.scope : undefined);
      return result;
    } catch (e) {
      if (e instanceof AbortScript) return { pipe: "", aborted: true, abortReason: e.reason, isBreak: false };
      throw e;
    } finally {
      await this.host.flush();
    }
  }

  /**
   * Execute a closure. `frame` is shared with the caller for inline bodies so
   * /break propagates to the enclosing loop. `useScope` runs in an existing
   * scope instead of a fresh child (used for the root script).
   */
  async runClosure(cv: ClosureValue, provided: { name: string; value: Val }[] = [], frame: Frame = { broken: false }, useScope?: Scope): Promise<RunResult> {
    if (++this.depth > this.maxDepth) {
      this.depth--;
      throw new ScriptError("Too much recursion (closure nesting exceeded the limit)");
    }
    const scope = useScope ?? new Scope(cv.scope);
    const source = this.sources.get(cv.closure) ?? null;
    if (this.debug) this.frames.push({ label: source?.label ?? this.frames[this.frames.length - 1]?.label ?? "스크립트", source, scope });
    try {
      for (const arg of cv.closure.args) {
        const v = await this.resolveValue(arg.value, scope, frame, cv.flags);
        scope.let(arg.name, v);
      }
      for (const p of provided) {
        if (scope.has(p.name)) scope.set(p.name, p.value);
        else scope.let(p.name, p.value);
      }
      if (cv.closure.executors.length === 0) scope.pipe = "";
      let isFirst = true;
      for (const ex of cv.closure.executors) {
        this.checkAbort();
        if (frame.broken) break;
        await this.runExecutor(ex, scope, frame, isFirst);
        isFirst = false;
      }
      return { pipe: scope.pipe, aborted: false, isBreak: frame.broken };
    } finally {
      this.depth--;
      if (this.debug) this.frames.pop();
    }
  }

  private checkAbort(): void {
    if (this.signal?.aborted) throw new AbortScript("Stopped by user", false);
  }

  private async runExecutor(ex: Executor, scope: Scope, frame: Frame, isFirst: boolean): Promise<void> {
    if (ex.kind === "break") {
      const value = await this.resolveUnnamed(ex.unnamed, scope, frame, defaultFlags(), false);
      if (ex.unnamed.length > 0) scope.pipe = value as Val;
      frame.broken = true;
      return;
    }
    const def = this.registry.get(ex.name);
    if (!def) throw new ScriptError(`Unknown command /${ex.name}`);
    const named: Record<string, Val> = {};
    for (const arg of ex.named) {
      named[arg.name] = await this.resolveValue(arg.value, scope, frame, ex.flags);
    }
    let unnamed: Val | Val[];
    let hasUnnamed = ex.unnamed.length > 0;
    if (!hasUnnamed) {
      if (!isFirst && ex.injectPipe) {
        unnamed = scope.pipe;
        hasUnnamed = true;
      } else {
        unnamed = "";
      }
    } else {
      unnamed = await this.resolveUnnamed(ex.unnamed, scope, frame, ex.flags, def.split ?? false);
    }
    if (def.split && !Array.isArray(unnamed)) unnamed = unnamed === "" && !hasUnnamed ? [] : [unnamed];
    await this.host.refreshFacts();
    if (this.debug) {
      const top = this.frames[this.frames.length - 1];
      if (top) top.node = ex;
      await this.debug.beforeCommand({ node: ex, source: top?.source ?? null, scope, depth: this.depth, named, unnamed, stack: this.frames.map((f) => ({ ...f })) });
      this.checkAbort();
    }
    const result = await def.run({ rt: this, node: ex, named, unnamed, hasUnnamed, scope, frame });
    scope.pipe = normalizePipe(result);
  }

  async resolveValue(value: ArgValue, scope: Scope, frame: Frame, flags: ParserFlags): Promise<Val> {
    if (typeof value !== "string") {
      const cv: ClosureValue = { kind: "closure-value", closure: value, scope, flags };
      if (value.executeNow) return (await this.runClosure(cv, [], frame)).pipe;
      return cv;
    }
    return this.substitute(value, scope, flags);
  }

  private async resolveUnnamed(list: CommandNode["unnamed"], scope: Scope, frame: Frame, flags: ParserFlags, split: boolean): Promise<Val | Val[]> {
    const values: Val[] = [];
    for (const item of list) values.push(await this.resolveValue(item.value, scope, frame, flags));
    if (split) return values;
    if (values.length === 1) return values[0];
    if (values.some(isClosureValue)) return values.find(isClosureValue)!;
    return values.join("");
  }

  /** Scoped macros ({{pipe}}, {{var::}}, {{timesIndex}}) then the global pass. */
  async substitute(text: string, scope: Scope, flags: ParserFlags = defaultFlags()): Promise<Val> {
    if (!text.includes("{{")) return unescapeBraces(text);
    const scopedNames = scope.macroNames().map(escapeRegex);
    const re = new RegExp(
      `\\{\\{pipe\\}\\}|\\{\\{var::([^\\s}]+?)(?:::((?:(?!\\}\\}).)+))?\\}\\}${scopedNames.length ? `|\\{\\{(${scopedNames.join("|")})\\}\\}` : ""}|\\{\\{arg::([^}]+?)\\}\\}`,
    );
    let out = "";
    let rest = text;
    for (;;) {
      const m = re.exec(rest);
      if (!m) break;
      const before = rest.slice(0, m.index);
      let value: Val;
      if (m[0] === "{{pipe}}") value = scope.pipe;
      else if (m[1] !== undefined) value = scope.get(m[1], m[2]);
      else if (m[3] !== undefined) value = scope.getMacro(m[3]) ?? "";
      // a QR argument that was not passed (SillyTavern's arg::* fallback)
      else value = scope.getMacro(`arg::${m[4]}`) ?? scope.getMacro("arg::*") ?? m[0];
      if (isClosureValue(value)) {
        if (before.trim() === "" && rest.slice(m.index + m[0].length).trim() === "" && out === "") return value;
        value = "[closure]";
      }
      out += (await this.global(before, flags)) + value;
      rest = rest.slice(m.index + m[0].length);
    }
    out += await this.global(rest, flags);
    return unescapeBraces(out);
  }

  private global(text: string, flags: ParserFlags): Promise<string> {
    return substituteGlobal(
      text,
      {
        local: this.host.local,
        global: this.host.global,
        facts: () => {
          const f = this.host.facts();
          // hosts report Marinara's 1-based count; SillyTavern scripts expect the last 0-based index
          return this.dialect === "st" ? { ...f, lastMessageId: String(Math.max(0, Number(f.lastMessageId) - 1)) } : f;
        },
        resolveHostMacros: this.host.resolveHostMacros?.bind(this.host),
      },
      { replaceGetvar: flags.REPLACE_GETVAR },
    );
  }

  /** Run a string of commands (quoted /if bodies, /run of a QR, ...). */
  async runSubcommands(text: string, scope: Scope, flags: ParserFlags, frame?: Frame): Promise<RunResult> {
    let body = text;
    if (body.startsWith('"') && body.endsWith('"')) body = body.slice(1, -1);
    const closure = this.parse(body, flags);
    const cv: ClosureValue = { kind: "closure-value", closure, scope, flags };
    return this.runClosure(cv, [], frame ?? { broken: false });
  }

  /** Execute a command body that may be a closure or a string of commands. */
  async runBody(body: Val, call: CommandCall, inheritFrame: boolean, macros?: Record<string, string>): Promise<RunResult> {
    const frame = inheritFrame ? call.frame : { broken: false };
    if (isClosureValue(body)) {
      if (macros) {
        const scope = new Scope(body.scope);
        for (const [k, v] of Object.entries(macros)) scope.setMacro(k, v);
        return this.runClosure({ ...body, scope }, [], frame);
      }
      return this.runClosure(body, [], frame);
    }
    let text = body;
    if (macros) for (const [k, v] of Object.entries(macros)) text = text.split(`{{${k}}}`).join(v);
    return this.runSubcommands(text, call.scope, call.node.flags, frame);
  }

  /** /run and /: — a closure value, a scoped closure variable, or a Quick Reply. */
  async runNamed(target: Val, provided: { name: string; value: Val }[], call: CommandCall): Promise<Val> {
    if (isClosureValue(target)) return (await this.runClosure(target, provided)).pipe;
    const name = target.trim();
    if (call.scope.has(name)) {
      const v = call.scope.get(name);
      if (isClosureValue(v)) return (await this.runClosure(v, provided)).pipe;
    }
    const source = this.findScript?.(name);
    if (!source) throw new ScriptError(`No Quick Reply or closure named "${name}"`);
    const previous = this.dialect;
    this.dialect = source.dialect;
    try {
      const closure = this.parse(source.script);
      this.tagSource(closure, { label: `${source.setName}.${source.label}`, text: source.script });
      // SillyTavern: a QR reads what /run passed as {{arg::name}}; names it was not given read as ""
      const scope = new Scope(call.scope);
      for (const p of provided) scope.setMacro(`arg::${p.name}`, isClosureValue(p.value) ? "[closure]" : p.value);
      scope.setMacro("arg::*", "");
      const cv: ClosureValue = { kind: "closure-value", closure, scope, flags: call.node.flags };
      return (await this.runClosure(cv, provided)).pipe;
    } finally {
      this.dialect = previous;
    }
  }

  getCommand(name: string): CommandDef | undefined {
    return this.registry.get(name);
  }
}

function normalizePipe(result: unknown): Val {
  if (result === undefined || result === null) return "";
  if (typeof result === "string" || isClosureValue(result)) return result;
  if (typeof result === "number" || typeof result === "boolean") return String(result);
  return JSON.stringify(result) ?? "";
}

export function unescapeBraces(text: string): string {
  return text.replace(/\\\{/g, "{").replace(/\\\}/g, "}");
}

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function defaultFlags(): ParserFlags {
  return { STRICT_ESCAPING: false, REPLACE_GETVAR: false };
}

/** Coerce a value to text (closures become a marker). */
export function asText(v: Val | Val[] | undefined): string {
  if (v === undefined) return "";
  if (Array.isArray(v)) return v.map((x) => asText(x)).join(" ");
  return isClosureValue(v) ? "[closure]" : v;
}
