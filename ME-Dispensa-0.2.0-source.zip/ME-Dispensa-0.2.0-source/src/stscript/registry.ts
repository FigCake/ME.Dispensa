import type { CommandSpec } from "./ast";
import type { CommandCall } from "./interpreter";
import type { Val } from "./scope";

export interface CommandDef extends CommandSpec {
  name: string;
  aliases?: string[];
  /** One-line description shown in the editor's command list. */
  help: string;
  /** Present in SillyTavern ("st"), Dispensa-only ("dispensa") or Marinara pass-through ("marinara"). */
  origin?: "st" | "dispensa" | "marinara";
  run(call: CommandCall): Promise<unknown> | unknown;
}

export class CommandRegistry {
  private readonly map = new Map<string, CommandDef>();

  register(...defs: CommandDef[]): this {
    for (const def of defs) {
      this.map.set(def.name, def);
      for (const alias of def.aliases ?? []) this.map.set(alias, def);
    }
    return this;
  }

  get(name: string): CommandDef | undefined {
    return this.map.get(name);
  }

  has(name: string): boolean {
    return this.map.has(name);
  }

  list(): CommandDef[] {
    return [...new Set(this.map.values())].sort((a, b) => a.name.localeCompare(b.name));
  }
}

export type { Val };
