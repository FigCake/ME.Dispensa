// /visz: the 🌟 visualizer from a script (Dispensa addition). Not /visz or
// /viz, so it never meets a command Marinara might add.

import { asText } from "../interpreter";
import type { CommandDef } from "../registry";
import { ScriptError } from "../scope";

export const wandCommands: CommandDef[] = [
  {
    name: "visz",
    help: '🌟 Run a visualizer item by title, or the text as a request: /visz [action=viz|ooc] [output=viewer|chat] 청첩장 → true when sent',
    origin: "dispensa",
    run: async (c) => {
      if (!c.rt.host.wand) throw new ScriptError("/visz only works inside Dispensa");
      const text = asText(c.unnamed).trim();
      if (!text) throw new ScriptError("/visz needs an item title or a request");
      const action = c.named.action === undefined ? undefined : asText(c.named.action);
      const output = c.named.output === undefined ? undefined : asText(c.named.output);
      if (action && action !== "viz" && action !== "ooc") throw new ScriptError('/visz action= is "viz" or "ooc"');
      if (output && output !== "viewer" && output !== "chat") throw new ScriptError('/visz output= is "viewer" or "chat"');
      return String(await c.rt.host.wand.run(text, { action: action as "viz" | "ooc" | undefined, output: output as "viewer" | "chat" | undefined }));
    },
  },
];
