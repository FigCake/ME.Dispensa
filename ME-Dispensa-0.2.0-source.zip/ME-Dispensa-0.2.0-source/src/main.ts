// Dispensa entry point (runs inside Marinara as a full-page extension).

import { api } from "./host/api";
import { findComposer } from "./host/composer";
import { parseObject } from "./host/variables";
import { getMarinara } from "./host/marinara-global";
import { MarinaraHost } from "./host/marinara-host";
import type { AutoTrigger, QrItem, QrSet } from "./qr/model";
import { AutoExecutor, autoTargets, automationTargets } from "./qr/auto";
import { activeSets } from "./qr/scopes";
import { ChatScopeWatch } from "./host/chat-scope";
import { activatedEntries, watchGeneration } from "./host/generation-watch";
import { createQrControl } from "./qr/control";
import { QrRunner } from "./qr/runner";
import { QrStore } from "./qr/store";
import { createRegistry } from "./stscript";
import { Runtime, asText } from "./stscript/interpreter";
import { createWandHost } from "./host/wand-host";
import { QuickBar } from "./ui/bar";
import { addViewButtons } from "./ui/chat-blocks";
import { ComposerToggle } from "./ui/composer-toggle";
import { QrManager } from "./ui/manager";
import { ThemeSync } from "./ui/theme";
import { ViewerPanel } from "./ui/viewer";
import { WandPanel } from "./ui/wand-panel";
import { createArchive } from "./wand/archive";
import { extractHtmlBlocks } from "./wand/core";
import { WandService } from "./wand/service";
import { WandStore } from "./wand/store";
import { moveItemsToQr, vizItems, wandItemOf } from "./wand/items";
import { MemoStore } from "./memo/store";
import { memosFrom, moveOocToMemos } from "./memo/model";
import { MemoPanel } from "./ui/memo-panel";
import { MemoCapture } from "./ui/memo-capture";
import { pickMemos } from "./ui/memo-pick";

/** What other extensions use to run STscript through Dispensa (Fornello's runSlash / triggerSlash). */
export interface DispensaBridge {
  version: 1;
  /** Runs an STscript line (SillyTavern numbering) and returns its pipe. */
  runSlash(text: string): Promise<string>;
  /** Opens Dispensa's window (Fornello's settings link to it). */
  openSettings?(): void;
}

declare global {
  interface Window {
    __dispensa?: DispensaBridge;
  }
}

export async function start(): Promise<() => void> {
  const marinara = getMarinara();
  const previous = document.getElementById("dispensa-bar");
  previous?.remove();

  const theme = new ThemeSync();
  theme.start();
  const host = new MarinaraHost();
  const registry = createRegistry();
  const store = new QrStore();
  try {
    await store.load();
  } catch (e) {
    host.ui.toast("Dispensa: 저장된 QR을 불러오지 못했어요. 이번 화면에서는 변경 내용이 저장되지 않아요.", "error");
    marinara.log.error("load failed", e);
  }

  const wandStore = new WandStore();
  try {
    await wandStore.load();
  } catch (e) {
    host.ui.toast("Dispensa: 비주얼라이저 설정을 불러오지 못했어요. 이번 화면에서는 변경 내용이 저장되지 않아요.", "error");
    marinara.log.error("wand load failed", e);
  }
  // The visualizer's items live in the QR 보관함 as 🌟 QRs: move them there once
  // (the samples on a first run, or a library saved before they moved)
  // a first run: the samples come in (nothing of the user's moves)
  const firstRun = !wandStore.value.itemsMoved;
  if (store.ready && wandStore.ready && !wandStore.value.itemsMoved) {
    const items = wandStore.value.items;
    store.update((s) => moveItemsToQr(s, items));
    wandStore.update((s) => {
      s.items = [];
      s.itemsMoved = true;
    });
  }

  // 📝 메모장: OOC notes and the 🌟 QRs that sent OOC move there once
  const memoStore = new MemoStore();
  try {
    await memoStore.load();
  } catch (e) {
    host.ui.toast("Dispensa: 메모장을 불러오지 못했어요. 이번 화면에서는 메모가 저장되지 않아요.", "error");
    marinara.log.error("memo load failed", e);
  }
  if (store.ready && memoStore.ready && !memoStore.value.moved) {
    let moved = 0;
    memoStore.update((m) => store.update((s) => (moved = moveOocToMemos(s, m))));
    if (moved && !firstRun) host.ui.toast(`OOC 문구 ${moved}개를 📝 메모장으로 옮겼어요.`, "info", { title: "Dispensa" });
  }
  const chooseMemos = (query?: string) => pickMemos(host.ui, memoStore, undefined, query);

  const scope = new ChatScopeWatch();
  const runner = new QrRunner(host, registry, () => store.value, {
    onStart: (item) => bar.setRunning(item),
    onEnd: () => bar.setRunning(null),
  });
  const qrControl = createQrControl(store, () => runner, () => scope.current);
  // Other extensions run STscript through Dispensa (Fornello's runSlash / triggerSlash)
  const bridge: DispensaBridge = {
    version: 1,
    runSlash: async (text) => {
      const rt = new Runtime({ host, registry, dialect: "st" });
      return asText((await rt.runScript(String(text ?? ""))).pipe);
    },
  };
  window.__dispensa = bridge;
  host.qr = qrControl;
  const run = (set: QrSet, item: QrItem) => void runner.run(set, item);
  const manager = new QrManager({
    store,
    registry,
    ui: host.ui,
    run,
    runInEditor: (set, item, options) => runner.runInEditor(set, item, options),
    memo: { store: memoStore, sendOoc: (text) => sendOoc(text), putInInput: (text) => wandHost.putInInput(text), makePage: (text) => wand.run("viz", text) },
    characterName: async (id) => {
      try {
        const raw = await api<{ name?: string; data?: unknown }>(`/characters/${encodeURIComponent(id)}`);
        return String(parseObject(raw.data).name ?? raw.name ?? "캐릭터");
      } catch {
        return "캐릭터";
      }
    },
    wandStore,
  });
  bridge.openSettings = () => manager.open();

  // 🌟 wand: menu on the bar, viewer above it
  let viewer: ViewerPanel | null = null;
  const wandHost = createWandHost(host);
  wandHost.pickMemos = () => chooseMemos();
  const wand = new WandService(wandHost, () => wandStore.value, createArchive(), () => viewer, () => vizItems(store.value));
  const sendOoc = (text: string) => wand.run("ooc", text);
  const addMemos = (text: string) => {
    const memos = memosFrom(text);
    memoStore.update((m) => m.memos.push(...memos));
    return memos.length;
  };
  host.memo = { pick: chooseMemos, add: addMemos, list: () => memoStore.value.memos.map((m) => m.text), ooc: sendOoc };
  host.wand = { run: (text, options) => wand.runTitleOrText(text, options), runQr: (set, item) => wand.runItem(wandItemOf(set, item)) };
  viewer = new ViewerPanel({ service: wand, store: wandStore, ui: host.ui, onChange: () => schedulePlace() });
  const wandPanel = new WandPanel({
    store: wandStore,
    service: wand,
    qrStore: store,
    viewer: () => viewer,
    ui: host.ui,
    close: () => bar.closeMenus(),
    openSettings: () => {
      bar.closeMenus();
      manager.open("wand");
    },
    pickMemos: () => chooseMemos(),
  });
  const memoPanel = new MemoPanel({
    store: memoStore,
    ui: host.ui,
    sendOoc,
    putInInput: (text) => wandHost.putInInput(text),
    close: () => bar.closeMenus(),
    openSettings: () => {
      bar.closeMenus();
      manager.open("memo");
    },
  });
  const capture = new MemoCapture((text) => {
    const n = addMemos(text);
    host.ui.toast(n > 1 ? `메모 ${n}개를 메모장에 넣었어요.` : "메모장에 넣었어요.", "success", { title: "📝" });
  });
  const bar = new QuickBar({
    run,
    stop: () => runner.stop(),
    openManager: () => manager.open("qr"),
    edit: (set, item) => manager.openItem(set.id, item.id),
    wand: { panel: wandPanel, runPinned: (item) => void wand.runItem(item) },
    memo: { panel: memoPanel },
  });
  const viewChatPage = async (messageId: string, index: number) => {
    host.chat.markStale();
    const message = (await host.chat.messages()).find((m) => m.id === messageId);
    // same order as the html code blocks on screen
    const fenced = message ? extractHtmlBlocks(message.content).filter((b) => /^html?$/i.test(b.lang) && message.content.startsWith("```", b.start)) : [];
    const block = fenced[index];
    if (!block) {
      host.ui.toast("이 메시지에서 HTML을 찾지 못했어요.", "warning", { title: "🌟" });
      return;
    }
    viewer?.show({ title: block.title || "채팅 속 HTML", kind: "viz", text: "```html\n" + block.code + "\n```" });
  };
  const syncWand = () =>
    bar.setWand({ show: wandStore.value.settings.showButton, icon: wandStore.value.settings.barIcon, busy: wand.busy, pinned: vizItems(store.value).filter((i) => i.pinned) });
  bar.setState(store.value);
  syncWand();
  // The switch next to the input box: on = a thin ⋯ handle above the input; pointing at it or touching it brings the bar up
  const toggle = new ComposerToggle(() => store.update((s) => (s.barVisible = !s.barVisible)));
  toggle.setArmed(store.value.barVisible);
  const unsubscribe = store.subscribe((s) => {
    bar.setState(s);
    toggle.setArmed(s.barVisible);
    // 🌟 QRs feed the menu and the pinned bubbles
    syncWand();
    wandPanel.render();
  });
  const unsubscribeWand = wandStore.subscribe(() => {
    syncWand();
    wandPanel.render();
  });
  const unsubscribeBusy = wand.onBusy(syncWand);
  const syncMemo = () => {
    bar.setMemo({ show: memoStore.value.showButton, icon: memoStore.value.barIcon });
    capture.setEnabled(memoStore.value.capture !== false);
    memoPanel.render();
  };
  syncMemo();
  const unsubscribeMemo = memoStore.subscribe(syncMemo);

  // Keep the bar right above the chat input through React re-renders.
  let scheduled = false;
  const place = () => {
    scheduled = false;
    const composer = findComposer();
    if (!composer) {
      if (bar.element.isConnected) bar.element.remove();
      return;
    }
    const box = composer.container.querySelector(".mari-chat-input-box");
    toggle.mount(box ?? composer.textarea.parentElement);
    const anchor = box ?? composer.textarea.closest("form") ?? composer.textarea.parentElement;
    const parent = anchor?.parentElement;
    if (!anchor || !parent) return;
    if (bar.element.parentElement !== parent || bar.element.nextElementSibling !== anchor) parent.insertBefore(bar.element, anchor);
    theme.noticeComposer();
    addViewButtons((messageId, index) => void viewChatPage(messageId, index));
    if (viewer?.open) {
      if (viewer.element.parentElement !== parent || viewer.element.nextElementSibling !== bar.element) parent.insertBefore(viewer.element, bar.element);
    } else if (viewer?.element.isConnected) viewer.element.remove();
  };
  const schedulePlace = () => {
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(place);
    }
  };
  const observer = new MutationObserver(schedulePlace);
  observer.observe(document.body, { childList: true, subtree: true });
  place();

  // Auto-run triggers (SillyTavern's executeOn…), over the sets that are on in this chat
  const auto = new AutoExecutor((set, item) => runner.run(set, item, { auto: true }));
  const fire = (trigger: AutoTrigger, blocked?: boolean) => auto.fire(autoTargets(activeSets(store.value, scope.current), trigger), blocked);
  /** New chats, and whether they were made while an auto-run was blocking others. */
  const newChats = new Map<string, boolean>();
  const onScope = () => {
    bar.setScope(scope.current);
    manager.setScope(scope.current);
  };
  // a generation started by an auto-run QR that blocks others sets off nothing (SillyTavern's preventAutoExecute)
  const startedBlocked = new WeakMap<object, boolean>();
  let lastBlocked = false;
  const onGenerationComplete = () => void fire("ai", lastBlocked);
  window.addEventListener("marinara:generation-complete", onGenerationComplete);
  // the saved message shows up in the chat's message list a moment after the event
  const untilListed = async (id: unknown) => {
    if (typeof id !== "string") return;
    for (let i = 0; i < 20; i++) {
      host.chat.markStale();
      const list = await host.chat.messages().catch(() => []);
      if (list.some((m) => m.id === id)) return;
      await new Promise((r) => setTimeout(r, 250));
    }
  };
  let beforeRunning = false;
  const entries = new WeakMap<object, { id?: unknown; name?: unknown }[]>();
  const stopWatching = watchGeneration({
    beforeGeneration: async (body) => {
      const blocked = auto.blocked;
      startedBlocked.set(body, blocked);
      lastBlocked = blocked;
      // a "before" QR that starts a generation itself does not wait on itself
      if (beforeRunning || blocked) return;
      beforeRunning = true;
      try {
        await fire("beforeGeneration");
      } finally {
        beforeRunning = false;
      }
    },
    onEvent: (event, body) => {
      const blocked = startedBlocked.get(body) ?? false;
      const role = (event.data as { role?: unknown } | null)?.role;
      if (event.type === "message_saved" && role === "user") void untilListed((event.data as { id?: unknown }).id).then(() => fire("user", blocked));
      else if (event.type === "message_saved") entries.set(body, [...(entries.get(body) ?? []), ...activatedEntries(event.data)]);
      else if (event.type === "group_turn") void fire("groupDraft", blocked);
      else if (event.type === "dispensa:end") {
        // lorebook entries that came into play run the QRs with their automation id
        const found = entries.get(body) ?? [];
        entries.delete(body);
        if (found.length) void auto.fire(automationTargets(activeSets(store.value, scope.current), found), blocked);
      }
    },
    onChatCreated: ({ id }) => newChats.set(id, auto.blocked),
  });
  let unsubscribeScope = () => {};
  void (async () => {
    await scope.start();
    onScope();
    unsubscribeScope = scope.onChange((now) => {
      onScope();
      void (async () => {
        await fire("chatChange");
        if (now.chatId && newChats.has(now.chatId)) {
          const blocked = newChats.get(now.chatId);
          newChats.delete(now.chatId);
          await fire("newChat", blocked);
        }
      })();
    });
    await fire("startup");
    if (scope.current.chatId) await fire("chatChange");
  })();

  const cleanup = () => {
    if (window.__dispensa === bridge) delete window.__dispensa;
    observer.disconnect();
    unsubscribeScope();
    scope.stop();
    stopWatching();
    window.removeEventListener("marinara:generation-complete", onGenerationComplete);
    unsubscribe();
    unsubscribeWand();
    unsubscribeBusy();
    unsubscribeMemo();
    capture.dispose();
    void memoStore.saveNow().catch(() => undefined);
    viewer?.dispose();
    theme.stop();
    void wandStore.saveNow().catch(() => undefined);
    runner.stop();
    qrControl.dispose();
    manager.close();
    bar.dispose();
    toggle.dispose();
    void host.flush().finally(() => host.dispose());
  };
  marinara.onCleanup(cleanup);
  marinara.log.info("Dispensa ready");
  return cleanup;
}
