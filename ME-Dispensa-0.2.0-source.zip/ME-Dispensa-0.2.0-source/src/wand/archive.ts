// Saved wand results. HTML pages are large, so they live in this browser's
// IndexedDB rather than in Marinara's 1 MB extension storage.

export interface ArchiveEntry {
  id: string;
  title: string;
  kind: "viz" | "ooc";
  /** The whole reply (HTML in fences, or plain text). */
  text: string;
  createdAt: number;
  chatId?: string;
  chatName?: string;
  character?: string;
}

export interface ArchiveBackend {
  list(): Promise<ArchiveEntry[]>;
  put(entry: ArchiveEntry): Promise<void>;
  remove(id: string): Promise<void>;
}

export class MemoryArchive implements ArchiveBackend {
  private readonly map = new Map<string, ArchiveEntry>();
  async list(): Promise<ArchiveEntry[]> {
    return [...this.map.values()].sort((a, b) => b.createdAt - a.createdAt);
  }
  async put(entry: ArchiveEntry): Promise<void> {
    this.map.set(entry.id, structuredClone(entry));
  }
  async remove(id: string): Promise<void> {
    this.map.delete(id);
  }
}

const DB = "dispensa-wand";
const STORE = "archive";

export class IndexedDbArchive implements ArchiveBackend {
  private db: Promise<IDBDatabase> | null = null;

  private open(): Promise<IDBDatabase> {
    this.db ??= new Promise((resolve, reject) => {
      const req = indexedDB.open(DB, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: "id" });
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error ?? new Error("보관함을 열지 못했어요."));
    });
    return this.db;
  }

  private async tx<T>(mode: IDBTransactionMode, run: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const req = run(db.transaction(STORE, mode).objectStore(STORE));
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error ?? new Error("보관함 작업에 실패했어요."));
    });
  }

  async list(): Promise<ArchiveEntry[]> {
    const all = await this.tx<ArchiveEntry[]>("readonly", (s) => s.getAll() as IDBRequest<ArchiveEntry[]>);
    return all.sort((a, b) => b.createdAt - a.createdAt);
  }

  async put(entry: ArchiveEntry): Promise<void> {
    await this.tx("readwrite", (s) => s.put(entry));
  }

  async remove(id: string): Promise<void> {
    await this.tx("readwrite", (s) => s.delete(id));
  }
}

/** IndexedDB when the browser has it, memory otherwise (private windows, tests). */
export function createArchive(): ArchiveBackend {
  return typeof indexedDB !== "undefined" ? new IndexedDbArchive() : new MemoryArchive();
}
