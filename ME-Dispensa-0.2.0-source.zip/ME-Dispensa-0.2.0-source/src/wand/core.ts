// 🌟 Wand: pure helpers (no Marinara or DOM access), ported from the
// SillyTavern 🪄 요술봉 Visualizer.

export const WAND_START = "<!-- WAND_START -->";
export const WAND_END = "<!-- WAND_END -->";

const FENCE_RE = /```[ \t]*([\w-]*)[^\n]*\n([\s\S]*?)(?:\n[ \t]*```|```)/g;
const DOC_RE = /<!doctype\s+html|<html[\s>]|<body[\s>]/i;
const TAG_RE = /<[a-z][a-z0-9-]*[\s>/]/i;
const WAND_RE = /<!--\s*WAND_START\s*-->([\s\S]*?)(?:<!--\s*WAND_END\s*-->|$)/gi;
const BARE_DOC_RE = /<!doctype\s+html[\s\S]*?(?:<\/html\s*>|$)/gi;

export interface HtmlBlock {
  start: number;
  end: number;
  lang: string;
  code: string;
  title: string;
  complete: boolean;
}

export function escapeRegex(text: string): string {
  return String(text).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** True when the code is a whole HTML document (or at least has a body). */
export function looksLikeHtmlDoc(code: string): boolean {
  return DOC_RE.test(String(code ?? ""));
}

/** True when a fenced block holds HTML worth showing as a page. */
export function isRenderableBlock(lang: string, code: string): boolean {
  const l = String(lang ?? "").toLowerCase();
  if (looksLikeHtmlDoc(code)) return true;
  return (l === "html" || l === "htm") && TAG_RE.test(String(code ?? ""));
}

/** False when a document was cut off before its closing tag. Fragments count as complete. */
export function isCompleteHtml(code: string): boolean {
  const c = String(code ?? "").trim();
  if (/<html[\s>]/i.test(c) || /^<!doctype/i.test(c)) return /<\/html\s*>\s*$/i.test(c);
  if (/<body[\s>]/i.test(c)) return /<\/body\s*>/i.test(c);
  return true;
}

export function docTitle(code: string): string {
  const m = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(String(code ?? ""));
  return m ? m[1].replace(/\s+/g, " ").trim() : "";
}

/** HTML pages in a reply, in order: fenced ```html blocks and <!-- WAND_START --> fragments. */
export function extractHtmlBlocks(text: string): HtmlBlock[] {
  const out: HtmlBlock[] = [];
  const src = String(text ?? "");
  FENCE_RE.lastIndex = 0;
  let m: RegExpExecArray | null;
  while ((m = FENCE_RE.exec(src))) {
    const [whole, lang, code] = m;
    if (!isRenderableBlock(lang, code)) continue;
    out.push({ start: m.index, end: m.index + whole.length, lang, code, title: docTitle(code), complete: isCompleteHtml(code) });
  }
  WAND_RE.lastIndex = 0;
  while ((m = WAND_RE.exec(src))) {
    if (out.some((b) => m!.index >= b.start && m!.index < b.end)) continue;
    const code = m[1].trim();
    out.push({ start: m.index, end: m.index + m[0].length, lang: "html", code, title: docTitle(code), complete: /WAND_END/i.test(m[0]) });
  }
  return out.sort((a, b) => a.start - b.start);
}

/** Replaces the code of the n-th HTML block, keeping its fence. */
export function replaceHtmlBlock(text: string, index: number, code: string): string {
  const b = extractHtmlBlocks(text)[index];
  if (!b) return text;
  const fence = "```" + (b.lang || "html") + "\n" + code.replace(/\s+$/, "") + "\n```";
  return text.slice(0, b.start) + fence + text.slice(b.end);
}

export function stripReasoning(text: string, tags: string[] = ["think", "thinking"]): string {
  let t = String(text ?? "");
  for (const tag of tags) {
    const name = escapeRegex(tag);
    t = t.replace(new RegExp(`<${name}>[\\s\\S]*?</${name}>`, "gi"), "");
    // Prefilled opening tag: the reply starts inside the block.
    t = t.replace(new RegExp(`^[\\s\\S]*?</${name}>`, "i"), (m) => (new RegExp(`<${name}>`, "i").test(m) ? m : ""));
    // Unclosed block: drop from the opening tag to the end.
    t = t.replace(new RegExp(`<${name}>[\\s\\S]*$`, "i"), "");
  }
  return t;
}

/** Removes a single Markdown fence wrapped around a whole reply. */
export function stripOuterFence(text: string): string {
  const t = String(text ?? "").trim();
  const m = /^```[\w-]*[^\n]*\n([\s\S]*?)(?:\n?```)?$/.exec(t);
  return m ? m[1] : t;
}

export interface NormalizedOutput {
  text: string;
  blocks: HtmlBlock[];
  truncated: boolean;
}

/**
 * Cleans a generated reply: drops reasoning, closes a dangling fence and fences
 * a bare HTML document so it reads as one block.
 */
export function normalizeOutput(raw: string): NormalizedOutput {
  let t = stripReasoning(raw).trim();
  const fences = (t.match(/```/g) || []).length;
  if (fences % 2 === 1) t += "\n```";
  if (!/```/.test(t)) {
    const start = t.search(/<!doctype\s+html|<html[\s>]/i);
    if (start >= 0) {
      const tail = t.slice(start);
      const endMatch = /<\/html\s*>/i.exec(tail);
      const end = endMatch ? start + endMatch.index + endMatch[0].length : t.length;
      t = t.slice(0, start) + "```html\n" + t.slice(start, end).trim() + "\n```" + t.slice(end);
    }
  }
  const blocks = extractHtmlBlocks(t);
  return { text: t.trim(), blocks, truncated: blocks.some((b) => !b.complete) };
}

/** Joins a continuation onto cut-off code, dropping text the model repeated. */
export function mergeContinuation(code: string, more: string): string {
  let add = stripOuterFence(stripReasoning(more));
  add = add.replace(/^\s*\n/, "");
  const max = Math.min(600, code.length, add.length);
  for (let n = max; n >= 12; n--) {
    if (code.endsWith(add.slice(0, n))) {
      add = add.slice(n);
      break;
    }
  }
  return code + add;
}

/** Replaces HTML pages in a message with a one-line marker (to keep prompts short). */
export function stripHtmlForPrompt(text: string, label = "🌟 비주얼라이저"): string {
  let t = String(text ?? "");
  const blocks = extractHtmlBlocks(t);
  for (let i = blocks.length - 1; i >= 0; i--) {
    const b = blocks[i];
    t = t.slice(0, b.start) + `[${label}: ${b.title || "HTML"}]` + t.slice(b.end);
  }
  t = t.replace(BARE_DOC_RE, (m) => `[${label}: ${docTitle(m) || "HTML"}]`);
  return t;
}

/** Trims whitespace and peels wrappers such as <System>…</System>, ((…)), (OOC: …), *{OOC: …}* and "OOC:". */
export function cleanOoc(text: string): string {
  let t = String(text ?? "").trim();
  const peel = [
    /^<system>\s*([\s\S]*?)\s*<\/system>$/i,
    /^\*\s*\{\s*ooc\s*[:：]\s*([\s\S]*?)\s*\}\s*\*$/i,
    /^\(\(\s*([\s\S]*?)\s*\)\)$/,
    /^\(\s*ooc\s*[:：]\s*([\s\S]*?)\s*\)$/i,
    /^\[\s*ooc\s*[:：]\s*([\s\S]*?)\s*\]$/i,
    /^ooc\s*[:：]\s*([\s\S]*)$/i,
  ];
  let changed = true;
  while (changed) {
    changed = false;
    for (const re of peel) {
      const m = re.exec(t);
      if (m) {
        t = m[1].trim();
        changed = true;
      }
    }
  }
  return t;
}

/** Fills {{name}} placeholders for the given keys only; other macros stay for Marinara. */
export function applyVars(template: string, vars: Record<string, string>): string {
  let out = String(template ?? "");
  for (const [key, value] of Object.entries(vars)) {
    out = out.replace(new RegExp(`\\{\\{${escapeRegex(key)}\\}\\}`, "g"), () => String(value ?? ""));
  }
  return out;
}

export function wrapOoc(template: string, content: string, language: string): string {
  const tpl = String(template ?? "");
  const filled = tpl.includes("{{내용}}") ? tpl : `${tpl}\n\n{{내용}}`;
  return applyVars(filled, { 내용: cleanOoc(content), 언어: language });
}

export interface Blank {
  /** The whole text between [[ and ]], used to fill it back in. */
  key: string;
  label: string;
  options: string[];
}

const BLANK_RE = /\[\[([^[\]\n]{1,400})\]\]/g;

/** `[[label]]` asks for text; `[[label|choice A|choice B]]` offers choices (free text still allowed). */
export function parseBlank(inner: string): Blank {
  const parts = String(inner).split("|").map((x) => x.trim());
  return { key: String(inner), label: parts[0] || "입력", options: parts.slice(1).filter(Boolean) };
}

/** Unique blanks in order of appearance. */
export function findBlanks(text: string): Blank[] {
  const seen = new Map<string, Blank>();
  let m: RegExpExecArray | null;
  BLANK_RE.lastIndex = 0;
  while ((m = BLANK_RE.exec(String(text ?? "")))) if (!seen.has(m[1])) seen.set(m[1], parseBlank(m[1]));
  return [...seen.values()];
}

/** Fills blanks by their full inner text (the `key` from findBlanks). */
export function fillBlanks(text: string, values: Record<string, string>): string {
  return String(text ?? "").replace(BLANK_RE, (whole, inner: string) => (Object.hasOwn(values, inner) ? String(values[inner]) : whole));
}

export interface PresetChunk {
  id: string;
  name: string;
  /** "all", or only in "full" / "lite" mode. */
  mode: "all" | "full" | "lite";
  enabled: boolean;
  text: string;
  /** Only when this extension is installed too (the page commands come from Fornello). */
  needs?: "fornello";
}

export interface VizPreset {
  id: string;
  name: string;
  /** Wrap the assembled prompt in <System>…</System>. */
  wrap: boolean;
  chunks: PresetChunk[];
  /** Built-in chunk ids already offered: a built-in chunk added later joins once, a deleted one stays gone. */
  known?: string[];
}

export type VizMode = "full" | "lite";
/** The setting: "auto" is full when Fornello runs the pages' scripts, light otherwise. */
export type VizModeSetting = VizMode | "auto";

export function resolveVizMode(setting: VizModeSetting, env: VizEnv = {}): VizMode {
  return setting === "auto" ? (env.fornello ? "full" : "lite") : setting;
}

/** What is installed next to Dispensa (chunks that need it are left out otherwise). */
export interface VizEnv {
  fornello?: boolean;
}

export function activeChunks(preset: VizPreset | undefined, mode: VizMode, env: VizEnv = {}): PresetChunk[] {
  return (preset?.chunks ?? []).filter((c) => c.enabled !== false && (!c.mode || c.mode === "all" || c.mode === mode) && (c.needs !== "fornello" || env.fornello === true));
}

/** Builds the visualizer prompt from a preset's chunks with the topic filled in. */
export function assembleVisualizer(preset: VizPreset | undefined, mode: VizMode, { topic, language, env }: { topic: string; language: string; env?: VizEnv }): string {
  let body = activeChunks(preset, mode, env)
    .map((c) => String(c.text ?? "").trim())
    .filter(Boolean)
    .join("\n\n");
  if (!body.includes("{{주제}}")) body = `[요청 주제]\n{{주제}}\n\n${body}`;
  body = applyVars(body, { 주제: cleanOoc(topic), 언어: language });
  return preset?.wrap === false ? body : `<System>\n${body}\n</System>`;
}

/** Finds an item by exact title first, then by a unique partial match. */
export function findByTitle<T extends { title: string }>(items: T[], query: string): T | null {
  const q = String(query ?? "").trim().toLowerCase();
  if (!q) return null;
  const exact = items.find((i) => i.title.trim().toLowerCase() === q);
  if (exact) return exact;
  const partial = items.filter((i) => i.title.toLowerCase().includes(q));
  return partial.length === 1 ? partial[0] : null;
}

/** First line of the request, for titles. */
export function titleFrom(text: string, max = 40): string {
  return cleanOoc(text).split("\n")[0].replace(/\[\[|\]\]/g, "").trim().slice(0, max);
}

// ── page shown in a sandboxed frame ──

/** True when the page needs JavaScript (script tags or inline event handlers). */
export function hasScripts(code: string): boolean {
  return /<script\b|\son[a-z]+\s*=\s*["']|javascript:/i.test(String(code ?? ""));
}

/** Reporter injected into every frame: posts the document height to the parent. */
export function heightReporter(token: string): string {
  return `(function(){var T=${JSON.stringify(token)};var last=0;function h(){var d=document.documentElement,b=document.body;var v=Math.ceil(Math.max(d?d.scrollHeight:0,b?b.scrollHeight:0,b?b.getBoundingClientRect().height:0));if(v&&Math.abs(v-last)>2){last=v;parent.postMessage({wandHeight:v,token:T},'*');}}addEventListener('load',h);addEventListener('resize',h);document.addEventListener('DOMContentLoaded',function(){h();try{new ResizeObserver(h).observe(document.body);}catch(e){}});var n=0,i=setInterval(function(){h();if(++n>20)clearInterval(i);},250);})();`;
}

/** Builds the srcdoc for a sandboxed frame. */
export function buildSrcdoc(code: string, { token, baseUrl = "", allowExternal = true }: { token: string; baseUrl?: string; allowExternal?: boolean }): string {
  const head: string[] = [];
  if (baseUrl) head.push(`<base href="${baseUrl.replace(/"/g, "&quot;")}">`);
  if (!allowExternal) {
    head.push(`<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data: blob:; media-src data: blob:; font-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'">`);
  }
  head.push(`<script>${heightReporter(token)}</script>`);
  const inject = head.join("");
  let doc = String(code ?? "");
  if (!looksLikeHtmlDoc(doc)) {
    doc = `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body>${doc}</body></html>`;
  }
  if (/<head[^>]*>/i.test(doc)) return doc.replace(/<head[^>]*>/i, (m) => m + inject);
  if (/<html[^>]*>/i.test(doc)) return doc.replace(/<html[^>]*>/i, (m) => `${m}<head>${inject}</head>`);
  return inject + doc;
}
