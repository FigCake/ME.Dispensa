// 🌟 QRs: the visualizer's items live in the QR 보관함 as QRs of kind "viz"
// (their script is the request). The 🌟 menu, the bar's pinned bubbles and
// /visz see them as WandItems through these helpers.

import { type QrItem, type QrSet, type QrState, newId, newSet } from "../qr/model";
import type { WandItem } from "./model";

/** The set 🌟 QRs go to when nothing else is chosen. */
export const VIZ_SET = { name: "비주얼라이저", icon: "🌟" };

export function wandItemOf(set: QrSet, item: QrItem): WandItem {
  const v = item.viz ?? { action: "viz" };
  return {
    id: item.id,
    emoji: item.icon ?? "",
    title: item.label,
    folder: v.folder || set.name,
    defaultAction: v.action,
    content: item.script,
    connectionId: v.connectionId ?? null,
    pinned: !!v.pinned,
    oocMode: v.oocMode,
    vizOutput: v.vizOutput,
    wrapperId: v.wrapperId,
  };
}

/** Every 🌟 QR, in 보관함 order. */
export function vizItems(state: QrState): WandItem[] {
  return state.sets.flatMap((set) => set.items.filter((i) => i.kind === "viz").map((i) => wandItemOf(set, i)));
}

/** A 🌟 QR made from an item (a new id unless `keepId`). */
export function vizQr(item: Partial<WandItem>, keepId = false): QrItem {
  const viz: QrItem["viz"] = { action: item.defaultAction ?? "viz" };
  if (item.folder) viz.folder = item.folder;
  if (item.pinned) viz.pinned = true;
  if (item.oocMode) viz.oocMode = item.oocMode;
  if (item.vizOutput) viz.vizOutput = item.vizOutput;
  if (item.wrapperId) viz.wrapperId = item.wrapperId;
  if (item.connectionId) viz.connectionId = item.connectionId;
  const qr: QrItem = { id: keepId && item.id ? item.id : newId("viz"), label: item.title || "새 🌟 QR", script: item.content ?? "", dialect: "marinara", kind: "viz", viz };
  if (item.emoji) qr.icon = item.emoji;
  return qr;
}

/** The 비주얼라이저 set, made (and added) when missing. */
export function vizSet(state: QrState): QrSet {
  let set = state.sets.find((s) => s.name === VIZ_SET.name);
  if (!set) {
    // its 🌟 QRs are in the 🍰 menu, so the set stays off the bar
    set = { ...newSet(VIZ_SET.name), icon: VIZ_SET.icon, enabled: false };
    state.sets.push(set);
  }
  return set;
}

export function findQr(state: QrState, id: string): { set: QrSet; item: QrItem } | undefined {
  for (const set of state.sets) {
    const item = set.items.find((i) => i.id === id);
    if (item) return { set, item };
  }
  return undefined;
}

/** Moves items into the 비주얼라이저 set as 🌟 QRs (keeping their ids); returns how many. */
export function moveItemsToQr(state: QrState, items: WandItem[]): number {
  if (!items.length) return 0;
  const set = vizSet(state);
  const taken = new Set(state.sets.flatMap((s) => s.items.map((i) => i.id)));
  for (const item of items) set.items.push(vizQr(item, !taken.has(item.id)));
  return items.length;
}
