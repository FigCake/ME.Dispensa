// HostChat against Marinara's API.

import type { ChatMessageInfo, GenerateOptions, HostChat, SendOptions } from "../stscript/host";
import type { MacroFacts } from "../stscript/macros";
import { api } from "./api";
import { findComposer, isGenerating, submitThroughComposer, waitUntil } from "./composer";
import { openChat, refreshChatQueries } from "./react-bridge";
import { parseObject } from "./variables";

interface ChatDetail {
  id: string;
  name?: string;
  mode?: string;
  characterIds?: string[] | string;
  personaId?: string | null;
  connectionId?: string | null;
  metadata?: unknown;
}

interface RawMessage {
  id: string;
  role: ChatMessageInfo["role"];
  characterId?: string | null;
  content: string;
  createdAt?: string;
  extra?: unknown;
}

interface Character {
  id: string;
  name: string;
}

interface CatalogCharacter {
  id: string;
  name: string;
  tags?: string[];
  firstMessage?: string;
}

export class MarinaraChat implements HostChat {
  private chat: ChatDetail | null = null;
  private characters: Character[] = [];
  private personaName = "User";
  private messageCache: ChatMessageInfo[] | null = null;
  private stale = true;
  private readonly characterCache = new Map<string, Character>();
  private readonly personaCache = new Map<string, string>();
  private lastActivity = Date.now();

  constructor() {
    window.addEventListener("marinara:generation-complete", this.markStale);
  }

  dispose(): void {
    window.removeEventListener("marinara:generation-complete", this.markStale);
  }

  readonly markStale = (): void => {
    this.stale = true;
    this.lastActivity = Date.now();
  };

  activeChatId(): string | null {
    const fromComposer = findComposer()?.chatId;
    if (fromComposer) return fromComposer;
    try {
      return localStorage.getItem("marinara-active-chat-id");
    } catch {
      return null;
    }
  }

  get detail(): ChatDetail | null {
    return this.chat;
  }

  get cast(): readonly Character[] {
    return this.characters;
  }

  /** Reload chat, cast and messages when the chat changed or after writes. */
  async sync(force = false): Promise<ChatDetail | null> {
    const id = this.activeChatId();
    if (!id) {
      this.chat = null;
      this.characters = [];
      this.messageCache = [];
      return null;
    }
    if (force || this.stale || this.chat?.id !== id) {
      this.chat = await api<ChatDetail>(`/chats/${encodeURIComponent(id)}`);
      this.characters = await Promise.all(this.characterIds().map((cid) => this.character(cid)));
      this.personaName = this.chat.personaId ? await this.persona(this.chat.personaId) : "User";
      this.messageCache = null;
      this.stale = false;
    }
    return this.chat;
  }

  private characterIds(): string[] {
    const ids = this.chat?.characterIds;
    if (Array.isArray(ids)) return ids;
    if (typeof ids === "string") {
      try {
        const parsed = JSON.parse(ids);
        return Array.isArray(parsed) ? parsed : [];
      } catch {
        return [];
      }
    }
    return [];
  }

  private async character(id: string): Promise<Character> {
    const cached = this.characterCache.get(id);
    if (cached) return cached;
    try {
      const raw = await api<{ id: string; data?: unknown; name?: string }>(`/characters/${encodeURIComponent(id)}`);
      const data = parseObject(raw.data);
      const c = { id, name: String(data.name ?? raw.name ?? "Character") };
      this.characterCache.set(id, c);
      return c;
    } catch {
      return { id, name: "Character" };
    }
  }

  private async persona(id: string): Promise<string> {
    const cached = this.personaCache.get(id);
    if (cached) return cached;
    try {
      const p = await api<{ name?: string }>(`/characters/personas/${encodeURIComponent(id)}`);
      const name = p.name || "User";
      this.personaCache.set(id, name);
      return name;
    } catch {
      return "User";
    }
  }

  async requireChat(): Promise<string> {
    const chat = await this.sync();
    if (!chat) throw new Error("열려 있는 채팅이 없어요. 채팅을 연 상태에서 실행해 주세요.");
    return chat.id;
  }

  async messages(): Promise<ChatMessageInfo[]> {
    const chatId = await this.requireChat();
    if (this.messageCache) return this.messageCache;
    const raw = await api<RawMessage[]>(`/chats/${encodeURIComponent(chatId)}/messages`);
    const byId = new Map(this.characters.map((c) => [c.id, c.name]));
    this.messageCache = raw.map((m, i) => {
      const extra = parseObject(m.extra);
      const snapshot = parseObject(extra.personaSnapshot);
      const name =
        m.role === "assistant"
          ? (m.characterId && byId.get(m.characterId)) || this.characters[0]?.name || "Character"
          : m.role === "user"
            ? String(snapshot.name || this.personaName)
            : m.role === "narrator"
              ? "Narrator"
              : "System";
      return { number: i + 1, id: m.id, role: m.role, name, content: m.content ?? "", hidden: extra.hiddenFromAI === true };
    });
    return this.messageCache;
  }

  facts(input: string): MacroFacts {
    const msgs = this.messageCache ?? [];
    const last = msgs[msgs.length - 1];
    const lastOf = (role: string) => [...msgs].reverse().find((m) => m.role === role)?.content ?? "";
    const idleMinutes = Math.round((Date.now() - this.lastActivity) / 60000);
    return {
      user: this.personaName,
      char: this.characters[0]?.name ?? "",
      group: this.characters.map((c) => c.name).join(", "),
      input,
      lastMessage: last?.content ?? "",
      // filled in by the runtime per dialect; this is Marinara's 1-based number
      lastMessageId: String(msgs.length),
      lastCharMessage: lastOf("assistant"),
      lastUserMessage: lastOf("user"),
      model: "",
      idleDuration: idleMinutes <= 0 ? "just now" : `${idleMinutes} minute${idleMinutes === 1 ? "" : "s"}`,
    };
  }

  /** Load messages if facts will need them (cheap when cached). */
  async ensureFacts(): Promise<void> {
    if (!this.activeChatId()) return;
    await this.messages();
  }

  private findCharacterId(name?: string): string | null {
    if (!name) return this.characters[0]?.id ?? null;
    const lower = name.trim().toLowerCase();
    return this.characters.find((c) => c.name.toLowerCase() === lower)?.id ?? this.characters.find((c) => c.name.toLowerCase().includes(lower))?.id ?? this.characters[0]?.id ?? null;
  }

  async generate(o: GenerateOptions): Promise<string> {
    if (o.mode === "chat") {
      const chatId = await this.requireChat();
      const res = await api<{ content?: string }>(`/generate/dryRun`, {
        method: "POST",
        body: {
          chatId,
          // An ephemeral last user turn, like SillyTavern's quiet prompt: the
          // model sees the whole chat and then this instruction. Nothing is saved.
          userMessage: o.prompt,
          streaming: false,
          forCharacterId: o.characterName ? this.findCharacterId(o.characterName) : undefined,
          connectionId: o.connectionId || undefined,
        },
      });
      return stripStops(res.content ?? "", o.stop);
    }
    const connectionId = await this.rawConnectionId();
    const res = await api<{ content?: string }>(`/generate/raw`, {
      method: "POST",
      body: {
        connectionId,
        messages: [{ role: "user", content: o.prompt }],
        streaming: false,
      },
    });
    return stripStops(res.content ?? "", o.stop);
  }

  private async rawConnectionId(): Promise<string> {
    const chat = await this.sync().catch(() => null);
    const id = chat?.connectionId;
    if (id && id !== "random") return id;
    const list = await api<{ id: string; useForRandom?: boolean; isDefault?: boolean }[]>(`/connections`);
    const pool = id === "random" ? list.filter((c) => c.useForRandom) : [];
    const pick = pool.length ? pool[Math.floor(Math.random() * pool.length)] : list.find((c) => c.isDefault) ?? list[0];
    if (!pick) throw new Error("AI 연결(Connection)이 없어요. 마리나라 설정에서 연결을 먼저 추가해 주세요.");
    return pick.id;
  }

  async send(o: SendOptions): Promise<void> {
    const chatId = await this.requireChat();
    const created = await api<{ id?: string }>(`/chats/${encodeURIComponent(chatId)}/messages`, {
      method: "POST",
      body: {
        role: o.role,
        content: o.text,
        characterId: o.role === "assistant" ? this.findCharacterId(o.name) : null,
      },
    });
    if (o.hidden && created?.id) {
      await api(`/chats/${encodeURIComponent(chatId)}/messages/bulk-hidden`, { method: "PATCH", body: { messageIds: [created.id], hidden: true } });
    }
    await this.refresh();
  }

  async setHidden(numbers: number[], hidden: boolean): Promise<number> {
    const chatId = await this.requireChat();
    const msgs = await this.messages();
    const ids = numbers.map((n) => msgs[n - 1]).filter((m) => m && m.hidden !== hidden).map((m) => m.id);
    if (!ids.length) return 0;
    await api(`/chats/${encodeURIComponent(chatId)}/messages/bulk-hidden`, { method: "PATCH", body: { messageIds: ids, hidden } });
    await this.refresh();
    return ids.length;
  }

  async deleteMessages(numbers: number[]): Promise<number> {
    const chatId = await this.requireChat();
    const msgs = await this.messages();
    const ids = numbers.map((n) => msgs[n - 1]?.id).filter(Boolean);
    if (!ids.length) return 0;
    await api(`/chats/${encodeURIComponent(chatId)}/messages/bulk-delete`, { method: "POST", body: { messageIds: ids } });
    await this.refresh();
    return ids.length;
  }

  async runNativeCommand(line: string): Promise<void> {
    await submitThroughComposer(line);
    this.markStale();
  }

  async continueLast(): Promise<void> {
    await this.runNativeCommand("/continue");
  }

  async regenerate(): Promise<void> {
    const chatId = await this.requireChat();
    window.dispatchEvent(new CustomEvent("marinara:chat-regenerate-request", { detail: { chatId } }));
    this.markStale();
  }

  async trigger(characterName?: string): Promise<void> {
    await this.requireChat();
    const name = characterName ?? this.characters[0]?.name;
    if (!name) throw new Error("답변할 캐릭터가 없어요.");
    await this.runNativeCommand(`/as "${name.replace(/"/g, "")}"`);
  }

  async addSwipe(text: string): Promise<void> {
    const chatId = await this.requireChat();
    const msgs = await this.messages();
    const last = [...msgs].reverse().find((m) => m.role === "assistant");
    if (!last) throw new Error("스와이프를 추가할 캐릭터 메시지가 없어요.");
    await api(`/chats/${encodeURIComponent(chatId)}/messages/${encodeURIComponent(last.id)}/swipes`, { method: "POST", body: { content: text } });
    await this.refresh();
  }

  async openRandomCharacter(tag?: string): Promise<string> {
    const current = await this.sync().catch(() => null);
    const characters: CatalogCharacter[] = [];
    for (let offset = 0; offset < 10_000; ) {
      const page = await api<{ items?: CatalogCharacter[]; hasMore?: boolean }>(`/characters/catalog?limit=200&offset=${offset}`);
      const items = page.items ?? [];
      characters.push(...items);
      if (!page.hasMore || items.length === 0) break;
      offset += items.length;
    }
    const wanted = tag?.trim().toLowerCase();
    const pool = wanted ? characters.filter((c) => (c.tags ?? []).some((t) => String(t).toLowerCase() === wanted)) : characters;
    if (!pool.length) throw new Error(wanted ? `"${tag}" 태그가 붙은 캐릭터가 없어요.` : "캐릭터가 없어요.");
    const pick = pool[Math.floor(Math.random() * pool.length)];

    // Like SillyTavern: open the character's latest one-on-one chat, or start one.
    const mode = current?.mode === "conversation" ? "conversation" : "roleplay";
    const chats = await api<(ChatDetail & { lastMessageAt?: string; updatedAt?: string })[]>(`/chats`);
    const own = chats
      .filter((c) => c.mode === mode && Array.isArray(c.characterIds) && c.characterIds.length === 1 && c.characterIds[0] === pick.id)
      .sort((a, b) => String(b.lastMessageAt ?? b.updatedAt ?? "").localeCompare(String(a.lastMessageAt ?? a.updatedAt ?? "")));
    let chatId = own[0]?.id;
    if (!chatId) {
      const created = await api<ChatDetail>(`/chats`, {
        method: "POST",
        body: { name: pick.name, mode, characterIds: [pick.id], connectionId: current?.connectionId ?? null, personaId: current?.personaId ?? null },
      });
      chatId = created.id;
      const greeting = await this.greetings(pick.id, pick.firstMessage);
      if (greeting.first) {
        const msg = await api<{ id?: string }>(`/chats/${encodeURIComponent(chatId)}/messages`, {
          method: "POST",
          body: { role: "assistant", content: greeting.first, characterId: pick.id },
        });
        if (msg?.id && greeting.alternates.length) {
          await api(`/chats/${encodeURIComponent(chatId)}/messages/${encodeURIComponent(msg.id)}/swipes/bulk`, { method: "POST", body: { contents: greeting.alternates } }).catch(() => undefined);
        }
      }
    }
    await openChat(chatId);
    this.markStale();
    return pick.name;
  }

  async greetings(characterId: string, fallback?: string): Promise<{ first: string; alternates: string[] }> {
    try {
      const raw = await api<{ data?: unknown }>(`/characters/${encodeURIComponent(characterId)}`);
      const data = parseObject(raw.data);
      const alternates = Array.isArray(data.alternate_greetings) ? data.alternate_greetings.map(String).filter((g) => g.trim()) : [];
      return { first: String(data.first_mes ?? fallback ?? "").trim(), alternates };
    } catch {
      return { first: (fallback ?? "").trim(), alternates: [] };
    }
  }

  async waitForIdle(timeoutMs: number): Promise<boolean> {
    // give a just-started generation a moment to show its stop button
    await new Promise((r) => setTimeout(r, 400));
    const idle = await waitUntil(() => !isGenerating(findComposer()), timeoutMs, 200);
    this.markStale();
    return idle;
  }

  async refresh(): Promise<void> {
    this.markStale();
    const chatId = this.chat?.id ?? this.activeChatId();
    if (chatId) refreshChatQueries(chatId);
  }
}

function stripStops(text: string, stops?: string[]): string {
  if (!stops?.length) return text;
  let cut = text.length;
  for (const s of stops) {
    if (!s) continue;
    const i = text.indexOf(s);
    if (i >= 0) cut = Math.min(cut, i);
  }
  return text.slice(0, cut);
}
