// Text and data helpers: commands SillyTavern also has keep its names and arguments; the rest are Dispensa's.

import { asText, type CommandCall } from "../interpreter";
import { isFalse, isTrue } from "../parser";
import type { CommandDef } from "../registry";
import { ScriptError } from "../scope";
import { t } from "../../shared/i18n";

const text = (c: CommandCall) => asText(c.unnamed);
const str = (c: CommandCall, key: string): string | undefined => {
  const v = c.named[key];
  return v === undefined ? undefined : asText(v);
};

/** "/pattern/flags" → RegExp; anything else is a regex source without flags. */
function regexFromString(input: string): RegExp {
  const m = /^\/([\s\S]+)\/([dgimsuvy]*)$/.exec(input);
  try {
    return m ? new RegExp(m[1], m[2]) : new RegExp(input);
  } catch {
    throw new ScriptError(t(`Invalid regular expression: ${input}`, `올바르지 않은 정규식이에요: ${input}`));
  }
}

/** A JSON value from text or from a variable holding JSON. */
function jsonFrom(c: CommandCall, raw: string): unknown {
  const source = c.rt.host.local.has(raw) ? c.rt.host.local.get(raw)! : c.rt.host.global.has(raw) ? c.rt.host.global.get(raw)! : raw;
  try {
    return JSON.parse(source);
  } catch {
    throw new ScriptError(t(`Not valid JSON: ${source.slice(0, 60)}`, `올바른 JSON이 아니에요: ${source.slice(0, 60)}`));
  }
}

const toText = (v: unknown): string => (v === undefined || v === null ? "" : typeof v === "object" ? JSON.stringify(v) : String(v));

/** "a.b[2].c" or "a.b.2.c" → ["a","b",2,"c"] */
function pathParts(path: string): (string | number)[] {
  return path
    .replace(/\[(\d+)\]/g, ".$1")
    .split(".")
    .filter((p) => p !== "")
    .map((p) => (/^\d+$/.test(p) ? Number(p) : p));
}

function getPath(root: unknown, path: string): unknown {
  let cur: unknown = root;
  for (const p of pathParts(path)) {
    if (cur === null || typeof cur !== "object") return undefined;
    cur = (cur as Record<string | number, unknown>)[p];
  }
  return cur;
}

function setPath(root: unknown, path: string, value: unknown): unknown {
  const parts = pathParts(path);
  if (!parts.length) return value;
  const top = root && typeof root === "object" ? root : typeof parts[0] === "number" ? [] : {};
  let cur = top as Record<string | number, unknown>;
  parts.forEach((p, i) => {
    if (i === parts.length - 1) {
      cur[p] = value;
      return;
    }
    if (!cur[p] || typeof cur[p] !== "object") cur[p] = typeof parts[i + 1] === "number" ? [] : {};
    cur = cur[p] as Record<string | number, unknown>;
  });
  return top;
}

function parseValue(raw: string): unknown {
  try {
    return JSON.parse(raw);
  } catch {
    return raw;
  }
}

/** "+1d", "-2h", "30m", "1w" → milliseconds */
function parseOffset(raw: string): number {
  let total = 0;
  for (const m of raw.matchAll(/([+-]?\d+(?:\.\d+)?)\s*(ms|s|m|h|d|w)/gi)) {
    const n = Number(m[1]);
    const unit = m[2].toLowerCase();
    total += n * ({ ms: 1, s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000, w: 604_800_000 } as Record<string, number>)[unit];
  }
  return total;
}

function formatDate(d: Date, format: string): string {
  const pad = (n: number, w = 2) => String(n).padStart(w, "0");
  const weekdays = ["일", "월", "화", "수", "목", "금", "토"];
  return format.replace(/YYYY|MM|DD|HH|mm|ss|ddd/g, (t) =>
    t === "YYYY" ? String(d.getFullYear()) : t === "MM" ? pad(d.getMonth() + 1) : t === "DD" ? pad(d.getDate()) : t === "HH" ? pad(d.getHours()) : t === "mm" ? pad(d.getMinutes()) : t === "ss" ? pad(d.getSeconds()) : weekdays[d.getDay()],
  );
}

export const textCommands: CommandDef[] = [
  {
    name: "replace",
    aliases: ["re"],
    help: "Replace text: /replace [mode=literal|regex] pattern=… [replacer=…] text",
    origin: "st",
    run: (c) => {
      const pattern = str(c, "pattern");
      if (!pattern) throw new ScriptError(t("/replace needs pattern=", "/replace에는 pattern=이 필요해요"));
      const replacer = str(c, "replacer") ?? "";
      const mode = str(c, "mode") ?? "literal";
      if (mode === "literal") return text(c).split(pattern).join(replacer);
      if (mode === "regex") return text(c).replace(regexFromString(pattern), replacer);
      throw new ScriptError(t(`/replace mode must be literal or regex, not "${mode}"`, `/replace mode=는 literal이나 regex여야 해요 ("${mode}"는 안 돼요)`));
    },
  },
  { name: "upper", help: "UPPERCASE the text.", origin: "st", run: (c) => text(c).toUpperCase() },
  { name: "lower", help: "Lowercase the text.", origin: "st", run: (c) => text(c).toLowerCase() },
  {
    name: "substr",
    aliases: ["substring"],
    help: "Part of the text: /substr start=0 end=5 text (end optional, negative counts from the end).",
    origin: "st",
    run: (c) => {
      const start = Number(str(c, "start") ?? 0) || 0;
      const endRaw = str(c, "end");
      return endRaw === undefined || endRaw === "" ? text(c).slice(start) : text(c).slice(start, Number(endRaw));
    },
  },
  {
    name: "match",
    help: "Regex match: /match pattern=/re/flags text → JSON groups ('' when none; all matches with the g flag).",
    origin: "st",
    run: (c) => {
      const pattern = str(c, "pattern");
      if (!pattern) throw new ScriptError(t("/match needs pattern=", "/match에는 pattern=이 필요해요"));
      const re = regexFromString(pattern);
      if (re.flags.includes("g")) return JSON.stringify([...text(c).matchAll(re)].map((m) => [...m]));
      const m = re.exec(text(c));
      return m ? JSON.stringify([...m]) : "";
    },
  },
  {
    name: "test",
    help: "Does the regex match? /test pattern=/re/ text → true or false",
    origin: "st",
    run: (c) => {
      const pattern = str(c, "pattern");
      if (!pattern) throw new ScriptError(t("/test needs pattern=", "/test에는 pattern=이 필요해요"));
      return JSON.stringify(regexFromString(pattern).test(text(c)));
    },
  },
  {
    name: "sort",
    help: "Sort a JSON list (or a dictionary's keys; keysort=false sorts keys by value).",
    origin: "st",
    run: (c) => {
      const value = jsonFrom(c, text(c));
      const cmp = (a: unknown, b: unknown) => (typeof a === "number" && typeof b === "number" ? a - b : String(a).localeCompare(String(b)));
      if (Array.isArray(value)) return JSON.stringify([...value].sort(cmp));
      if (value && typeof value === "object") {
        const entries = Object.entries(value as Record<string, unknown>);
        const byKey = !isFalse(str(c, "keysort") ?? "true");
        entries.sort((a, b) => (byKey ? cmp(a[0], b[0]) : cmp(a[1], b[1])));
        return JSON.stringify(entries.map(([k]) => k));
      }
      throw new ScriptError(t("/sort needs a JSON list or dictionary", "/sort에는 JSON 목록이나 딕셔너리가 필요해요"));
    },
  },
  {
    name: "array-wrap",
    aliases: ["list-wrap"],
    help: "Wrap a value in a JSON list (lists stay as they are).",
    origin: "st",
    run: (c) => {
      const value = text(c);
      if (value === "") return "[]";
      try {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed)) return value;
        if (parsed && typeof parsed === "object") return JSON.stringify([parsed]);
        if (isFalse(str(c, "stringify") ?? "true")) return JSON.stringify([parsed]);
      } catch {
        // plain text
      }
      return JSON.stringify([value]);
    },
  },
  {
    name: "array-unwrap",
    aliases: ["list-unwrap"],
    help: "First item of a JSON list (the value itself when it is not a list).",
    origin: "st",
    run: (c) => {
      const value = text(c);
      try {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed)) return toText(parsed[0]);
      } catch {
        // not JSON
      }
      return value;
    },
  },

  // ── Dispensa additions ──
  { name: "trim", help: "Remove spaces and line breaks at both ends.", origin: "dispensa", run: (c) => text(c).trim() },
  {
    name: "split",
    help: 'Text → JSON list: /split [separator=","] [trim=on] text',
    origin: "dispensa",
    run: (c) => {
      const sep = str(c, "separator") ?? str(c, "sep") ?? ",";
      const parts = text(c).split(sep.startsWith("/") && sep.length > 2 ? regexFromString(sep) : sep);
      return JSON.stringify(isFalse(str(c, "trim") ?? "on") ? parts : parts.map((p) => p.trim()).filter((p) => p !== ""));
    },
  },
  {
    name: "join",
    help: 'JSON list → text: /join [separator=", "] ["a","b"]',
    origin: "dispensa",
    run: (c) => {
      const value = jsonFrom(c, text(c));
      if (!Array.isArray(value)) throw new ScriptError(t("/join needs a JSON list", "/join에는 JSON 목록이 필요해요"));
      return value.map(toText).join(str(c, "separator") ?? str(c, "sep") ?? ", ");
    },
  },
  {
    name: "json-get",
    help: "Read a value inside JSON: /json-get path=a.b[0] {json or variable name}",
    origin: "dispensa",
    run: (c) => toText(getPath(jsonFrom(c, text(c)), str(c, "path") ?? "")),
  },
  {
    name: "json-set",
    help: "Change a value inside JSON: /json-set path=a.b value=… {json or variable name} → new JSON",
    origin: "dispensa",
    run: (c) => {
      const raw = text(c).trim();
      const root = raw === "" ? {} : jsonFrom(c, raw);
      return JSON.stringify(setPath(root, str(c, "path") ?? "", parseValue(str(c, "value") ?? "")));
    },
  },
  {
    name: "json-keys",
    help: "The keys of a JSON object (or indexes of a list) as a JSON list.",
    origin: "dispensa",
    run: (c) => {
      const value = jsonFrom(c, text(c));
      if (!value || typeof value !== "object") throw new ScriptError(t("/json-keys needs a JSON object or list", "/json-keys에는 JSON 객체나 목록이 필요해요"));
      return JSON.stringify(Object.keys(value as object));
    },
  },
  {
    name: "randompick",
    help: "One random item from a JSON list or from comma-separated text.",
    origin: "dispensa",
    run: (c) => {
      const raw = text(c).trim();
      let items: unknown[];
      try {
        const parsed = JSON.parse(c.rt.host.local.get(raw) ?? raw);
        items = Array.isArray(parsed) ? parsed : [parsed];
      } catch {
        items = raw.split(",").map((s) => s.trim()).filter(Boolean);
      }
      return items.length ? toText(items[Math.floor(Math.random() * items.length)]) : "";
    },
  },
  {
    name: "date",
    help: 'Date/time text: /date [format="YYYY-MM-DD HH:mm"] [add="+1d"] (units: ms s m h d w; ddd = weekday)',
    origin: "dispensa",
    run: (c) => {
      const base = str(c, "from") ? new Date(str(c, "from")!) : new Date();
      if (Number.isNaN(base.getTime())) throw new ScriptError(t(`Invalid date: ${str(c, "from")}`, `올바르지 않은 날짜예요: ${str(c, "from")}`));
      const d = new Date(base.getTime() + parseOffset(str(c, "add") ?? ""));
      return formatDate(d, str(c, "format") ?? (text(c).trim() || "YYYY-MM-DD HH:mm"));
    },
  },
  {
    name: "count",
    help: 'How many times something appears: /count of="x" text (regex with of=/re/)',
    origin: "dispensa",
    run: (c) => {
      const of = str(c, "of");
      if (!of) throw new ScriptError(t("/count needs of=", "/count에는 of=가 필요해요"));
      if (of.startsWith("/") && of.length > 2) {
        const re = regexFromString(of);
        return String([...text(c).matchAll(new RegExp(re.source, re.flags.includes("g") ? re.flags : `${re.flags}g`))].length);
      }
      return String(text(c).split(of).length - 1);
    },
  },
  {
    name: "isempty",
    help: "True when the value is empty (after trimming), otherwise false.",
    origin: "dispensa",
    run: (c) => JSON.stringify(text(c).trim() === "" || (isTrue(str(c, "json") ?? "off") && ["[]", "{}", "null"].includes(text(c).trim()))),
  },
];
