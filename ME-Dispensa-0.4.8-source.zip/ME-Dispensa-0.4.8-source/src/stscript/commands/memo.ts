// The memo pad from a script (Dispensa additions).

import type { MemoControl } from "../host";
import { asText, type CommandCall } from "../interpreter";
import type { CommandDef } from "../registry";
import { ScriptError } from "../scope";
import { t } from "../../shared/i18n";

function memo(c: CommandCall): MemoControl {
  if (!c.rt.host.memo) throw new ScriptError(t(`/${c.node.name} only works inside Dispensa`, `/${c.node.name}은(는) Dispensa 안에서만 쓸 수 있어요`));
  return c.rt.host.memo;
}

export const memoCommands: CommandDef[] = [
  {
    name: "memo",
    help: "📝 Pick memos from the Memo pad → their text (\"\" when none): /memo [words to find]",
    origin: "dispensa",
    run: async (c) => (await memo(c).pick(asText(c.unnamed).trim() || undefined)) ?? "",
  },
  {
    name: "memo-add",
    help: "📝 Keep text in the Memo pad (OOC wrappers come off) → how many memos: /memo-add text",
    origin: "dispensa",
    run: (c) => {
      const text = asText(c.unnamed).trim();
      if (!text) throw new ScriptError(t("/memo-add needs the text to keep", "/memo-add에는 남길 글이 필요해요"));
      return String(memo(c).add(text));
    },
  },
  {
    name: "memo-list",
    help: "📝 The memos shown in this chat as a JSON list; only one place: /memo-list chat | character | global (or scope=…)",
    origin: "dispensa",
    run: (c) => {
      const places = ["chat", "character", "global"] as const;
      type Place = (typeof places)[number];
      const isPlace = (v: string): v is Place => (places as readonly string[]).includes(v);
      const named = c.named.scope === undefined ? undefined : asText(c.named.scope).trim().toLowerCase();
      if (named && !isPlace(named)) throw new ScriptError(t("/memo-list scope= is chat, character or global", "/memo-list scope=는 chat, character, global 중 하나예요"));
      // the pipe fills the unnamed argument, so other words there are not an error
      const word = asText(c.unnamed).trim().toLowerCase();
      const only = named && isPlace(named) ? named : isPlace(word) ? word : undefined;
      return JSON.stringify(memo(c).list(only));
    },
  },
];
