// /visz from a script (Dispensa addition); not /viz, so it never meets a command Marinara might add.

import { asText } from "../interpreter";
import type { CommandDef } from "../registry";
import { ScriptError } from "../scope";
import { t } from "../../shared/i18n";

export const viszCommands: CommandDef[] = [
  {
    name: "visz",
    help: '🌟 Make a page from the text through the visualizer ([[…]] asks first): /visz [output=viewer|chat|gallery] [prompt=last] topic (prompt=last: the text is a message, made into a new scene) → true when sent',
    origin: "dispensa",
    run: async (c) => {
      if (!c.rt.host.visz) throw new ScriptError(t("/visz only works inside Dispensa", "/visz는 Dispensa 안에서만 쓸 수 있어요"));
      const text = asText(c.unnamed).trim();
      if (!text) throw new ScriptError(t("/visz needs a topic", "/visz에는 주제가 필요해요"));
      const action = c.named.action === undefined ? undefined : asText(c.named.action);
      const output = c.named.output === undefined ? undefined : asText(c.named.output);
      if (action && action !== "viz" && action !== "ooc") throw new ScriptError(t('/visz action= is "viz" or "ooc"', '/visz action=은 "viz"나 "ooc"예요'));
      if (output && output !== "viewer" && output !== "chat" && output !== "gallery") throw new ScriptError(t('/visz output= is "viewer", "chat" or "gallery"', '/visz output=은 "viewer", "chat", "gallery" 중 하나예요'));
      const prompt = c.named.prompt === undefined ? undefined : asText(c.named.prompt);
      if (prompt && prompt !== "superviz" && prompt !== "last") throw new ScriptError(t('/visz prompt= is "superviz" or "last"', '/visz prompt=는 "superviz"나 "last"예요'));
      return String(await c.rt.host.visz.run(text, { action: action as "viz" | "ooc" | undefined, output: output as "viewer" | "chat" | "gallery" | undefined, prompt: prompt as "superviz" | "last" | undefined }));
    },
  },
];
