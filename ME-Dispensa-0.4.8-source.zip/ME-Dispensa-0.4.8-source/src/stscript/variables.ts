// SillyTavern variable semantics (local = per chat, global = app wide) on top
// of a plain string store supplied by the host.

import { t } from "../shared/i18n";

export interface VariableStore {
  get(name: string): string | undefined;
  set(name: string, value: string): void;
  delete(name: string): void;
  has(name: string): boolean;
  entries(): [string, string][];
}

export type VarValue = string | number;

/** Numbers come back as numbers, everything else as a string ("" when missing). */
export function readVar(store: VariableStore, name: string, index?: string): VarValue {
  let value: unknown = store.get(name);
  if (index !== undefined && index !== "") {
    try {
      const container = JSON.parse(String(value));
      const n = Number(index);
      value = Number.isNaN(n) ? container[index] : container[n];
      if (typeof value === "object" && value !== null) value = JSON.stringify(value);
    } catch {
      // not a JSON container: keep the raw value
    }
  }
  if (value === undefined || value === null) return "";
  const text = String(value);
  if (text.trim() === "" || Number.isNaN(Number(text))) return text;
  return Number(text);
}

export function writeVar(store: VariableStore, name: string, value: VarValue, index?: string, as?: string): VarValue {
  if (!name) throw new Error(t("Variable name cannot be empty.", "변수 이름이 비어 있어요."));
  if (index !== undefined && index !== "") {
    let container: unknown;
    try {
      container = JSON.parse(store.get(name) ?? "null");
    } catch {
      container = null;
    }
    const n = Number(index);
    if (Number.isNaN(n)) {
      const obj = (container && typeof container === "object" ? container : {}) as Record<string, unknown>;
      obj[index] = convertType(value, as);
      store.set(name, JSON.stringify(obj));
    } else {
      const arr = (Array.isArray(container) ? container : []) as unknown[];
      arr[n] = convertType(value, as);
      store.set(name, JSON.stringify(arr));
    }
  } else {
    store.set(name, String(value));
  }
  return value;
}

export function addVar(store: VariableStore, name: string, value: VarValue): VarValue {
  const current = readVar(store, name) || 0;
  try {
    const parsed = JSON.parse(String(current));
    if (Array.isArray(parsed)) {
      parsed.push(value);
      store.set(name, JSON.stringify(parsed));
      return JSON.stringify(parsed);
    }
  } catch {
    // not an array
  }
  const increment = Number(value);
  if (Number.isNaN(increment) || Number.isNaN(Number(current))) {
    const text = String(current || "") + String(value);
    store.set(name, text);
    return text;
  }
  const next = Number(current) + increment;
  if (Number.isNaN(next)) return "";
  store.set(name, String(next));
  return next;
}

function convertType(value: VarValue, as?: string): unknown {
  if (!as) return value;
  const text = String(value);
  switch (as.toLowerCase()) {
    case "number":
    case "int":
    case "float":
      return Number(text);
    case "bool":
    case "boolean":
      return ["true", "on", "1"].includes(text.toLowerCase());
    case "array":
    case "object":
    case "list":
    case "dictionary":
    case "json":
      try {
        return JSON.parse(text);
      } catch {
        return text;
      }
    case "null":
      return null;
    case "string":
    default:
      return text;
  }
}
