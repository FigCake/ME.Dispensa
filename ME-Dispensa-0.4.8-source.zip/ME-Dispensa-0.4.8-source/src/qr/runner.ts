// Runs a Quick Reply: STscript through the interpreter, plain text through
// the chat input (honoring SillyTavern's set options).

import { submitThroughComposer } from "../shared/composer";
import { type Debugger, Runtime, asText } from "../stscript/interpreter";
import type { Host } from "../stscript/host";
import type { CommandRegistry } from "../stscript/registry";
import { Scope, ScriptError } from "../stscript/scope";
import { type QrItem, type QrSet, type QrState, findItem } from "./model";
import { galleryHost } from "./gallery-run";
import { t } from "../shared/i18n";

export interface RunnerEvents {
  onStart?(item: QrItem): void;
  onEnd?(item: QrItem): void;
  /** A message the QR posted, or the chat's reply it started (not /guided's). */
  onPosted?(item: QrItem, text: string): void;
}

export interface RunOptions {
  /** Started by a trigger: never blocked by a running QR, never shown on the Dock. */
  auto?: boolean;
}

export class QrRunner {
  private controller: AbortController | null = null;
  private current: QrItem | null = null;
  /** Auto-runs under way (they run alongside a QR started by hand). */
  private readonly autoRuns = new Set<AbortController>();

  constructor(
    private readonly host: Host,
    private readonly registry: CommandRegistry,
    private readonly state: () => QrState,
    private readonly events: RunnerEvents = {},
  ) {}

  /** /run and /: look QRs up by name. */
  private readonly findScript = (name: string) => {
    const found = findItem(this.state(), name);
    return found ? sourceOf(found.set, found.item) : undefined;
  };

  get busy(): boolean {
    return this.controller !== null;
  }

  get running(): QrItem | null {
    return this.current;
  }

  /** Stops the QR started by hand and every auto-run. */
  stop(): void {
    this.controller?.abort();
    for (const c of this.autoRuns) c.abort();
  }

  async run(set: QrSet, item: QrItem, options: RunOptions = {}): Promise<void> {
    if (options.auto) {
      const controller = new AbortController();
      this.autoRuns.add(controller);
      try {
        await this.execute(set, item, controller, true);
      } finally {
        this.autoRuns.delete(controller);
      }
      return;
    }
    if (this.controller) {
      this.host.ui.toast(t("Another QR is running. Try again when it's done.", "다른 QR이 실행 중이에요. 끝난 뒤 다시 눌러 주세요."), "warning");
      return;
    }
    const controller = new AbortController();
    this.controller = controller;
    this.current = item;
    this.events.onStart?.(item);
    try {
      await this.execute(set, item, controller, false);
    } finally {
      this.controller = null;
      this.current = null;
      this.events.onEnd?.(item);
    }
  }

  /**
   * The host for a run, telling onPosted what the QR posts and the reply a /trigger it ran
   * brings (read once the chat is idle again).
   */
  private posting(item: QrItem): Host {
    const posted = this.events.onPosted;
    if (!posted) return this.host;
    const base = this.host;
    const chat = new Proxy(base.chat, {
      get: (obj, key) => {
        if (key === "send") return async (o: Parameters<Host["chat"]["send"]>[0]) => (await obj.send(o), posted(item, o.text));
        if (key === "trigger") return async (name?: string) => {
          const since = await this.lastMessageId();
          await obj.trigger(name);
          void this.replyAfter(item, since);
        };
        const v = Reflect.get(obj, key, obj) as unknown;
        return typeof v === "function" ? (v as (...a: unknown[]) => unknown).bind(obj) : v;
      },
    });
    return new Proxy(base, { get: (obj, key) => (key === "chat" ? chat : ((v) => (typeof v === "function" ? (v as (...a: unknown[]) => unknown).bind(obj) : v))(Reflect.get(obj, key, obj) as unknown)) });
  }

  private async lastMessageId(): Promise<string | null> {
    try {
      return (await this.host.chat.messages()).at(-1)?.id ?? null;
    } catch {
      return null;
    }
  }

  /** The chat's reply to what the QR sent, once it is done. */
  private async replyAfter(item: QrItem, since: string | null): Promise<void> {
    try {
      if (!(await this.host.chat.waitForIdle?.(10 * 60_000))) return;
      const all = await this.host.chat.messages();
      const at = since ? all.findIndex((m) => m.id === since) : -1;
      // the message it followed is gone (deleted meanwhile): which reply is this QR's is unknown
      if (since && at < 0) return;
      const from = at + 1;
      // only the reply itself: a later one (another QR's /guided, say) isn't this QR's
      const reply = all.slice(from).find((m) => m.role !== "user");
      if (reply) this.events.onPosted?.(item, reply.content);
    } catch {
      // the chat changed or went away: nothing to collect
    }
  }

  /**
   * Runs a QR from the Gallery: it reads the chat but doesn't change it, uses `connectionId` with
   * the chat's context, and doesn't wait for (or block) other runs. Returns what it made: the text
   * it would have posted, else what it returned, or null when the visualizer saved it already.
   */
  async runInGallery(set: QrSet, item: QrItem, connectionId: string, input?: string, title = item.label, preset?: boolean, presetId?: string): Promise<string | null> {
    const controller = new AbortController();
    const runQr = async (name: string, host: Host) => {
      const found = this.host.qr?.source(name);
      if (!found) throw new ScriptError(t(`No Quick Reply named "${name}"`, `"${name}"(이)라는 QR이 없어요`));
      const rt = new Runtime({ host, registry: this.registry, dialect: found.dialect, signal: controller.signal, findScript: this.findScript });
      // a plain one would go to the chat input: here it is kept like the rest
      if (found.script.trimStart().startsWith("/")) await rt.runScript(found.script);
      else run.outputs.push(String(await rt.substitute(found.script, new Scope())));
    };
    const run = galleryHost(this.host, connectionId, title, input, preset, runQr, presetId);
    this.autoRuns.add(controller);
    try {
      let pipe = "";
      if (item.script.trimStart().startsWith("/")) {
        const rt = new Runtime({ host: run.host, registry: this.registry, dialect: item.dialect, signal: controller.signal, findScript: this.findScript, source: { label: `${set.name}.${item.label}`, text: item.script } });
        const result = await rt.runScript(item.script);
        if (result.aborted && result.abortReason) throw new ScriptError(result.abortReason);
        pipe = asText(result.pipe);
      } else {
        // a plain QR is text for the AI here, answered with the chat's context
        await run.host.beginRun?.();
        const prompt = String(await new Runtime({ host: run.host, registry: this.registry, dialect: item.dialect }).substitute(item.script, new Scope()));
        run.outputs.push(await run.host.chat.generate({ mode: "chat", prompt }));
      }
      const made = run.outputs.filter((x) => x.trim()).join("\n\n");
      if (made) return made;
      if (run.madePages || run.failedPages) return null;
      return pipe.trim() && pipe !== "true" && pipe !== "false" ? pipe : "";
    } finally {
      this.autoRuns.delete(controller);
    }
  }

  private async execute(set: QrSet, item: QrItem, controller: AbortController, auto: boolean): Promise<void> {
    try {
      const script = item.script;
      if (script.trimStart().startsWith("/")) {
        const rt = new Runtime({
          host: this.posting(item),
          registry: this.registry,
          dialect: item.dialect,
          signal: controller.signal,
          findScript: this.findScript,
          source: { label: `${set.name}.${item.label}`, text: script },
        });
        const result = await rt.runScript(script);
        if (result.aborted && result.abortReason && result.abortReason !== "Stopped by user") {
          this.host.ui.toast(result.abortReason, "info");
        }
      } else {
        await this.sendPlain(set, script, item, auto);
      }
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      this.host.ui.toast(message, "error", { title: t(`QR "${item.label}" failed`, `QR "${item.label}" 실행 실패`) });
      if (!(e instanceof ScriptError)) console.error("[Dispensa]", e);
    }
  }

  /** Run from the QR editor: returns the pipe or the thrown error, optionally stopping in the debugger. */
  async runInEditor(set: QrSet, item: QrItem, options: { signal: AbortSignal; debug?: Debugger }): Promise<{ pipe: string; aborted?: string }> {
    if (!item.script.trimStart().startsWith("/")) {
      await this.sendPlain(set, item.script, item);
      return { pipe: "" };
    }
    const rt = new Runtime({
      host: this.host,
      registry: this.registry,
      dialect: item.dialect,
      signal: options.signal,
      debug: options.debug,
      findScript: this.findScript,
      source: { label: `${set.name}.${item.label}`, text: item.script },
    });
    const result = await rt.runScript(item.script);
    return { pipe: asText(result.pipe), aborted: result.aborted ? result.abortReason || t("Stopped", "중단됨") : undefined };
  }

  /** Run a QR from inside a running QR (/qr). It stops with the caller's `signal`, else with the stop button. */
  async runNested(set: QrSet, item: QrItem, signal?: AbortSignal): Promise<void> {
    if (!item.script.trimStart().startsWith("/")) {
      await this.sendPlain(set, item.script, item);
      return;
    }
    const rt = new Runtime({
      host: this.posting(this.current ?? item),
      registry: this.registry,
      dialect: item.dialect,
      signal: signal ?? this.controller?.signal,
      findScript: this.findScript,
    });
    await rt.runScript(item.script);
  }

  /** SillyTavern: a QR without a leading "/" is text for the chat input (an auto-run sends it as is). */
  private async sendPlain(set: QrSet, text: string, item: QrItem, auto = false): Promise<void> {
    const rt = new Runtime({ host: this.host, registry: this.registry, dialect: item.dialect });
    await this.host.beginRun?.();
    const resolved = String(await rt.substitute(text, new Scope()));
    const current = auto ? "" : this.host.ui.getInput();
    const line = set.injectInput && current ? (set.placeBeforeInput ? `${resolved} ${current}` : `${current} ${resolved}`) : resolved;
    if (set.disableSend) {
      this.host.ui.setInput(line);
      return;
    }
    if (set.injectInput && current) this.host.ui.setInput("");
    const since = await this.lastMessageId();
    await submitThroughComposer(line);
    if (this.events.onPosted) void this.replyAfter(item, since);
  }
}

/** What /run executes for a QR. */
function sourceOf(set: QrSet, item: QrItem) {
  return { script: item.script, dialect: item.dialect, label: item.label, setName: set.name };
}
