// The Example QRs set: two step QRs. Their prompts are FigCake's texts, CC BY-NC-SA
// (LICENSE-SUPERVIZ.txt).

import { t } from "../shared/i18n";
import { type QrItem, type QrSet, newItem, newSet, withSteps } from "./model";
import type { StepQr } from "./steps";

const COOKING_PROMPT = `SYSTEM_COMMAND: You are a master storyteller and recipe crafter.
A user has made choices for a cooking scenario. Your task is to interpret these choices and generate a story and recipe.

Chef and Recipient:
- The Chef is '{{chef}}'.
- The Recipient is '{{chef:prompt}}'.
You MUST narrate from the Chef's point of view.

User Choices to build the context:
- Main Reason/Situation for Cooking: '{{reason}}'
- Dish Concept: '{{concept}}'
- Special Emotion/Intent/Hidden Meaning: '{{touch}}'
- Recipe Style: '{{recipe_style}}'

Your Task:
Imagine the Chef cooking for the Recipient.
This culinary moment is primarily inspired by the comprehensive context built from: the 'Main Reason/Situation for Cooking', 'Dish Concept', and the user-defined 'Special Emotion/Intent/Hidden Meaning' ('{{touch}}').
The narrative MUST naturally reflect the established relationship context between the Chef and Recipient as understood from prior interactions and the overall situation.
Write a 500+ word story from the Chef's perspective.

The story should be structured as:
<Format>
🔥 Cook’s Glow
(Detail the Chef's main thoughts and motivations stemming from the 'Main Reason/Situation for Cooking'. Explicitly consider how their established relationship with the Recipient (informed by prior chat context) influences these motivations and the choice to express the 'Special Emotion/Intent/Hidden Meaning' ('{{touch}}') through a 'Dish Concept' meal. The dish's tone must stem from this rich, multi-faceted, and established context.)

🥄 Heart’s Core
(Describe the dish’s core characteristics and how they connect to the overall context, the 'Main Reason/Situation for Cooking' for the Recipient, the 'Dish Concept', the 'Special Emotion/Intent/Hidden Meaning' ('{{touch}}'), or a particular aspect of the Recipient as understood through their established relationship.)

🪄 Secret Touch
(Incorporate a special touch, flavor, ingredient, or presentation method that is directly inspired by or represents the user-defined 'Special Emotion/Intent/Hidden Meaning' ('{{touch}}'). This is where '{{touch}}' should most clearly manifest.)

🍋 Side Spark
(If a side dish is prepared, describe its nature and how it complements the main dish and the overall theme, possibly reflecting an aspect of the 'Special Emotion/Intent/Hidden Meaning' ('{{touch}}'). Explain its relevance. If no side dish, this section can be very short or omitted by the AI if contextually appropriate.)

🍽️ Dish It Out
(Describe how the Chef presents and serves the meal, reflecting their feelings (informed by '{{touch}}') and the dynamic of their established relationship with the Recipient in this specific context.)

🌟 Shared Moment
(Detail the Recipient's response upon seeing and tasting the meal. Describe the dialogue between the Chef and Recipient, their unfolding emotions, and how this shared experience, centered around the Chef's efforts driven by the 'Main Reason/Situation for Cooking' and colored by their established relationship and the expressed 'Special Emotion/Intent/Hidden Meaning' ('{{touch}}'), influences their interaction, a shift in their dynamic, or the Chef's internal state.)
</Format>

In the Chef's voice: ensure authenticity and depth, reflecting their personality. Base actions and internal thoughts on the Recipient's traits and their established relationship (as known from prior chat context). The emotional tone, and any subtle undercurrents or intentions, should align with the 'Special Emotion/Intent/Hidden Meaning' ('{{touch}}') provided by the user. Detail key cooking steps naturally within the narrative, but keep them integrated rather than a separate focus unless the Recipe Style is 'Detailed (Full Recipe)'.

If the Recipe Style is 'Detailed (Full Recipe)', write a complete recipe anyone could follow: exact amounts, times and every step.

If the Recipe Style is 'Skill-based (Chef Level)', this recipe MUST be tailored to the Chef's ('{{chef}}') INDIVIDUAL cooking skill and knowledge. First, based on '{{chef}}'s established personality, background, and any mentions of cooking in our roleplay so far, you MUST INFER their likely cooking proficiency (e.g., complete novice, decent home cook, gourmet enthusiast, professional chef, or even comically inept). Then, craft a recipe where the chosen ingredients, the complexity of techniques, the number of steps, and the style of instruction DIRECTLY REFLECT this inferred skill level.

<Recipe Card>
End with a separate 'Recipe Card'. This section MUST be presented as a single \`\`\`html code block: an HTML structure styled with CSS to evoke a classic or charming recipe book/card aesthetic.
The HTML structure should clearly delineate the Dish Name, Ingredients List, and Step-by-step Instructions.
CSS styling should aim for:
- Visual Presentation: A clean, aesthetically pleasing layout reminiscent of a physical recipe card or a page from a well-loved cookbook (e.g., consider using borders, a distinct background for the "card", and clear visual separation between the dish name, ingredients, and instructions sections).
- Typography: Primarily use fonts that are highly readable for the ingredients and instructions. A complementary, possibly more decorative or handwritten-style font, could be used for the Dish Name or section titles if it enhances the recipe book theme and remains legible.
The Chef's narrative tone (e.g., sweet, cheeky, reflecting their established relationship and the 'Special Emotion/Intent/Hidden Meaning' ('{{touch}}')) must still be evident in the textual content of the recipe itself (dish name, ingredients descriptions, and steps). The visual styling provides the "recipe book" container for this toned text.
All specified content (dish name, ingredients, steps) MUST be included within this styled HTML structure.
</Recipe Card>

Output Language: the language the roleplay is written in.
---
Begin the story now from the Chef's point of view.`;

const COOKING: StepQr = {
  steps: [
    // each option's own text is the other one: the Recipient
    { name: "chef", kind: "choice", question: "Step 1: Who will cook?", options: [{ label: "{{char}}", prompt: "{{user}}" }, { label: "{{user}}", prompt: "{{char}}" }], perOption: true },
    {
      name: "reason",
      kind: "input",
      question: "Step 2: What is the main reason or situation for {{chef}} cooking?\n(Examples: A date at home, their partner's birthday, a special occasion, for fun, or to celebrate together.)",
      options: [],
    },
    { name: "concept", kind: "choice", question: "Step 3: What is your cooking concept?", options: ["Creative", "Celebratory", "Daily Special", "Light & Fresh", "Warm & Hearty", "Sweet Dessert"].map((label) => ({ label })) },
    {
      name: "touch",
      kind: "choice",
      question: "Step 4: What feeling or message do you want to convey through this dish?",
      options: ["Love", "Gratitude", "Friendship", "Playfulness", "Comfort", "Celebration"].map((label) => ({ label })),
      custom: { label: "Custom (Manual Input)", question: "What special emotion, intention, or hidden meaning do you want to convey? (e.g., revenge, longing, subtle warning, sweet temptation, etc.)" },
    },
    { name: "recipe_style", kind: "choice", question: "Step 5: {{chef}} is cooking. Choose your recipe type.", options: [{ label: "Detailed (Full Recipe)" }, { label: "Skill-based (Chef Level)" }] },
  ],
  prompt: COOKING_PROMPT,
  frame: "system",
  send: "result",
  as: "{{chef}}",
  cancelText: "Cancelled!✨",
  doneText: "Completed!💡",
};

// {{star:prompt}} is the other one: the option's own text names who reacts
const HOLIDAY_DROP_PROMPT = `[Pause the current RP. Execute the following Special Event.]
Based on the current RP context (Era, Currency, Characters' Fame/Job, Relationship, Personalities), write a detailed response covering the following 3 sections.

Scenario: {{holiday}} Merchandise (MD) featuring {{star}} has been released.

Section 1 & 2 Format: Standard Markdown text.

1. The Merchandise Lineup (8 Items)
Introduce 8 distinct MD items released. For each item, describe:
- Name
- Appearance
- Reason for Release
- Price

2. The Reaction ({{star:prompt}}'s Perspective)
Describe {{star:prompt}}'s reaction upon seeing the MD lineup.
- Strictly reflect {{star:prompt}}'s personality, spending habits, and financial status/wealth.
- Explicitly state whether {{star:prompt}} decides to purchase any of the items.

Section 3 Format: A single \`\`\`html code block.

3. Fan Reactions
Generate a complete HTML artifact representing a Social Media Feed.
- Design: Modern social feed layout with profile pics, usernames, and bubbles.
- Content: 12 fan reactions/comments about the MD launch.

Output Language: the language the roleplay is written in.`;

const HOLIDAY_DROP: StepQr = {
  steps: [
    { name: "star", kind: "choice", question: "Whose MD is being released?", options: [{ label: "{{char}}", prompt: "{{user}}" }, { label: "{{user}}", prompt: "{{char}}" }], perOption: true },
    { name: "holiday", kind: "choice", question: "Which holiday?", options: [{ label: "Valentine's Day" }, { label: "Halloween" }, { label: "Christmas" }], custom: { label: "Custom (Manual Input)", question: "Which holiday or occasion?" } },
  ],
  prompt: HOLIDAY_DROP_PROMPT,
  frame: "system",
  send: "result",
  as: "{{char}}",
  cancelText: "Cancelled!",
  doneText: "Generated! 💳",
};

/** The two example step QRs, with their script made. */
export function exampleQrs(): QrItem[] {
  return [
    withSteps({ ...newItem(t("Cooking & recipe", "요리와 레시피"), ""), icon: "🧑‍🍳", title: t("Who cooks, why and how: a story and a recipe card", "누가·왜·어떻게 요리하는지 골라 이야기와 레시피 카드 받기"), steps: structuredClone(COOKING) }),
    withSteps({ ...newItem(t("The Holiday Drop", "홀리데이 MD 출시"), ""), icon: "🎁", title: t("Holiday merch of a character: the lineup, a reaction and the fans' feed", "캐릭터의 기념일 MD: 라인업, 반응, 팬 피드"), steps: structuredClone(HOLIDAY_DROP) }),
  ];
}

/** The Example QRs set (off everywhere: its QRs run from the Dock or the editor). */
export function exampleSet(): QrSet {
  return { ...newSet(t("Example QRs", "예시 QR")), icon: "🧭", enabled: false, items: exampleQrs() };
}
