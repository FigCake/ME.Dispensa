// State kept in Marinara's extension storage (so it follows the user to other devices): under one key, or
// split over "key" and "key:…" so two devices saving different parts don't touch each other's (Marinara
// replaces whole keys and checks nothing). Saves come a moment after update(); a store that failed to load
// never saves, so a read error can't wipe data. Another device or tab may have saved meanwhile: a save
// re-reads the keys and, if they changed, replays this tab's changes on top of what is there instead of
// writing its older copy over it, then writes only the keys that differ from what is stored. A failed
// save is retried later; onSaveError tells the person once.

import { getMarinara } from "../shared/marinara-global";
import { entriesOf, entryBytes, objectBytes } from "./storage-size";

export interface StoreSpec<T> {
  key: string;
  /** Saved data → a complete state (missing or broken parts get defaults); normalize(undefined) is the empty state. */
  normalize(raw: unknown): T;
  /** A fresh install's state (nothing saved under `key` yet), saved right away. */
  initial?(): T;
  /**
   * Splits the state over `key` and keys starting with "key:" (null: a part gone); `join` puts what is
   * stored back together for normalize. Without them the state is the one value under `key`.
   */
  split?(state: T): Record<string, unknown>;
  join?(parts: Record<string, unknown>): unknown;
  /** For log messages. */
  label: string;
}

/** Marinara allows 1,000,000 bytes of extension storage in total. */
export const STORAGE_LIMIT = 1_000_000;
/** Past this, Dispensa warns that storage is almost full. */
export const STORAGE_SOFT_LIMIT = 900_000;
/** Past this, the Dispensa window shows how full storage is. */
export const STORAGE_SHOW_FROM = 700_000;
const SAVE_DELAY_MS = 400;
/** Wait before each retry of a failed save; the last repeats. */
const RETRY_MS = [5_000, 20_000, 60_000];
/** Retries before only a new change (or leaving the page) saves again. */
const MAX_RETRIES = 10;

/** Bytes per key of all extension storage (chat variables and null parts too) as last read or written: Marinara's limit counts it all. */
let storedEntries = new Map<string, number>();

function remember(stored: Record<string, unknown>): void {
  storedEntries = entriesOf(stored);
}

export class PersistedStore<T> {
  private state: T;
  private readonly listeners = new Set<(s: T) => void>();
  private saveTimer: ReturnType<typeof setTimeout> | null = null;
  private loadedOk = false;
  /** The stored keys as JSON when this tab last read or wrote them. */
  private base: Record<string, string> = {};
  /** Changes made here since the last save, to replay on a newer stored value. */
  private pending: ((s: T) => void)[] = [];
  /** The save in progress: a refresh waits for it, and saves run one at a time. */
  private saving: Promise<void> | null = null;
  /** Saves failed in a row (picks the retry wait). */
  private failures = 0;
  /** Called on the first failure after a save that worked; `full`: past Marinara's limit. */
  onSaveError: ((info: { full: boolean; error: unknown }) => void) | null = null;

  constructor(private readonly spec: StoreSpec<T>) {
    this.state = spec.normalize(undefined);
  }

  /** Loaded from storage (writes are safe). */
  get ready(): boolean {
    return this.loadedOk;
  }

  get value(): T {
    return this.state;
  }

  async load(): Promise<void> {
    try {
      const parts = this.partsOf(await this.readStorage());
      const fresh = !Object.keys(parts).length && !!this.spec.initial;
      this.state = fresh ? this.spec.initial!() : this.spec.normalize(this.rawOf(parts));
      this.base = parts;
      this.pending = [];
      this.loadedOk = true;
      if (fresh) this.scheduleSave();
    } catch (e) {
      // Never overwrite storage we could not read.
      this.loadedOk = false;
      throw e;
    }
    this.emit();
  }

  subscribe(fn: (s: T) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  /** Like subscribe, but `fn` runs only when the slice `pick` returns has changed (compared as JSON). */
  select(pick: (s: T) => unknown, fn: (s: T) => void): () => void {
    const key = (s: T) => {
      const v = pick(s);
      return typeof v === "string" ? v : JSON.stringify(v);
    };
    let last = key(this.state);
    return this.subscribe((s) => {
      const next = key(s);
      if (next === last) return;
      last = next;
      fn(s);
    });
  }

  update(mutate: (s: T) => void): void {
    mutate(this.state);
    this.pending.push(mutate);
    this.emit();
    this.scheduleSave();
  }

  /** Takes what another device saved meanwhile (when nothing here waits to be saved). */
  async refresh(): Promise<void> {
    // a save on its way has already taken this tab's changes out of `pending`
    if (this.saving) await this.saving.catch(() => undefined);
    if (!this.loadedOk || this.pending.length || this.saveTimer || this.saving) return;
    const parts = this.partsOf(await this.readStorage());
    if (this.pending.length || this.saveTimer || this.saving) return;
    if (!Object.keys(parts).length || sameParts(parts, this.base)) return;
    this.state = this.spec.normalize(this.rawOf(parts));
    this.base = parts;
    this.emit();
  }

  owns(key: string): boolean {
    return key === this.spec.key || (!!this.spec.split && key.startsWith(`${this.spec.key}:`));
  }

  /** This store's key sizes once saved, emptied parts included (Marinara keeps them as null). */
  storedSizes(): Map<string, number> {
    const out = new Map<string, number>();
    if (!this.loadedOk || (!this.pending.length && !this.saveTimer && !this.saving)) {
      // nothing will be saved: storage already holds it
      for (const [k, b] of storedEntries) if (this.owns(k)) out.set(k, b);
      return out;
    }
    for (const [k, v] of Object.entries(this.parts())) if (v != null) out.set(k, entryBytes(k, v));
    for (const k of storedEntries.keys()) if (this.owns(k) && !out.has(k)) out.set(k, entryBytes(k, null));
    return out;
  }

  /** Bytes of this store's keys, to warn before Marinara's limit. */
  size(): number {
    let sum = 0;
    for (const b of this.storedSizes().values()) sum += b;
    return sum;
  }

  /** Saves waiting changes now (leaving the page); no request when there are none. */
  flush(): Promise<void> {
    if (!this.saveTimer && !this.pending.length) return (this.saving ?? Promise.resolve()).catch(() => undefined);
    return this.saveNow();
  }

  async saveNow(): Promise<void> {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = null;
    if (!this.loadedOk) return;
    while (this.saving) await this.saving.catch(() => undefined);
    this.saving = this.write()
      .then(
        () => {
          this.failures = 0;
        },
        (e: unknown) => {
          this.failed(e);
          throw e;
        },
      )
      .finally(() => (this.saving = null));
    return this.saving;
  }

  /** Schedules a retry (the changes stay in `pending`); tells the person on the first failure. */
  private failed(error: unknown): void {
    console.error(`[Dispensa] ${this.spec.label} save failed`, error);
    const wait = RETRY_MS[Math.min(this.failures, RETRY_MS.length - 1)];
    if (this.failures++ === 0) this.onSaveError?.({ full: storageUsed([this]) > STORAGE_LIMIT, error });
    // an edit meanwhile already scheduled a save
    if (!this.saveTimer && this.failures <= MAX_RETRIES) this.saveTimer = setTimeout(() => void this.saveNow().catch(() => undefined), wait);
  }

  private parts(): Record<string, unknown> {
    return this.spec.split ? this.spec.split(this.state) : { [this.spec.key]: this.state };
  }

  private async readStorage(): Promise<Record<string, unknown>> {
    const stored = await getMarinara().storage.get();
    remember(stored);
    return stored;
  }

  private async write(): Promise<void> {
    // every change already in this.state; those made during the save are kept for the next one
    let taken = this.pending;
    this.pending = [];
    try {
      // always read first: a save that trusted an older read wrote over what another device saved
      const stored = this.partsOf(await this.readStorage());
      taken = [...taken, ...this.pending];
      this.pending = [];
      if (Object.keys(stored).length && !sameParts(stored, this.base)) {
        const next = this.spec.normalize(this.rawOf(stored));
        for (const op of taken) {
          try {
            op(next);
          } catch (e) {
            console.warn(`[Dispensa] ${this.spec.label}: a change could not be replayed`, e);
          }
        }
        this.state = next;
        this.emit();
      }
      // only the keys that differ from what is stored; a part gone is written as null
      const out: Record<string, string> = {};
      for (const [k, v] of Object.entries(this.parts())) if (v != null) out[k] = JSON.stringify(v);
      const patch: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(out)) if (stored[k] !== v) patch[k] = JSON.parse(v) as unknown;
      for (const k of Object.keys(stored)) if (!(k in out)) patch[k] = null;
      if (Object.keys(patch).length) {
        const after = await getMarinara().storage.patch(patch);
        // the reply is all of storage after the patch
        if (after && typeof after === "object") remember(after);
      }
      this.base = out;
    } catch (e) {
      this.pending = [...taken, ...this.pending];
      throw e;
    }
  }

  /** This store's keys in what storage holds, as JSON (parts written as null are gone). */
  private partsOf(stored: Record<string, unknown>): Record<string, string> {
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(stored)) {
      if (v == null || !this.owns(k)) continue;
      out[k] = JSON.stringify(v);
    }
    return out;
  }

  private rawOf(parts: Record<string, string>): unknown {
    if (!this.spec.join) return parts[this.spec.key] === undefined ? undefined : (JSON.parse(parts[this.spec.key]) as unknown);
    return this.spec.join(Object.fromEntries(Object.entries(parts).map(([k, v]) => [k, JSON.parse(v) as unknown])));
  }

  private scheduleSave(): void {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    // saveNow logs and retries a failure
    this.saveTimer = setTimeout(() => void this.saveNow().catch(() => undefined), SAVE_DELAY_MS);
  }

  private emit(): void {
    for (const fn of this.listeners) fn(this.state);
  }
}

function sameParts(a: Record<string, string>, b: Record<string, string>): boolean {
  const keys = Object.keys(a);
  return keys.length === Object.keys(b).length && keys.every((k) => a[k] === b[k]);
}

/** What a store gives storageUsed. */
export interface StoredSizes {
  owns(key: string): boolean;
  storedSizes(): Map<string, number>;
}

/** Bytes of all extension storage as Marinara counts it, these stores' keys as they will be once saved. */
export function storageUsed(stores: (StoredSizes | undefined)[]): number {
  const all = new Map(storedEntries);
  for (const s of stores) {
    if (!s) continue;
    for (const k of all.keys()) if (s.owns(k)) all.delete(k);
    for (const [k, b] of s.storedSizes()) all.set(k, b);
  }
  return objectBytes(all.values());
}
