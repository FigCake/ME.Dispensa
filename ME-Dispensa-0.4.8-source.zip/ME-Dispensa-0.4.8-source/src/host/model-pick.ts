// A chat's quick model pick: another model on its Connection, in metadata `modelOverride`
// (readChatModelOverride in Marinara's shared schemas). The raw route ignores it.

import { parseObject } from "./variables";

export interface ChatModelPick {
  connectionId: string;
  model: string;
  /** Marinara's label for it (else the model id). */
  name: string;
}

/** The chat's pick; null when it is for another connection (Marinara ignores those). */
export function chatModelPick(chat: { connectionId?: string | null; metadata?: unknown } | null | undefined): ChatModelPick | null {
  if (!chat?.connectionId) return null;
  const raw = parseObject(parseObject(chat.metadata).modelOverride);
  const model = typeof raw.model === "string" ? raw.model.trim() : "";
  const connectionId = typeof raw.connectionId === "string" ? raw.connectionId.trim() : "";
  if (!model || connectionId !== chat.connectionId) return null;
  const name = typeof raw.name === "string" && raw.name.trim() ? raw.name.trim() : model;
  return { connectionId, model, name };
}
