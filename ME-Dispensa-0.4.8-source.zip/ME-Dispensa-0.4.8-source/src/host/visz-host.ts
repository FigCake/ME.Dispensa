// visz's view of Marinara: generation, posting, the chat input.

import type { ViszHost } from "../visz/service";
import { findComposer, setComposerText, submitThroughComposer } from "../shared/composer";
import { chatPictures, fornelloInstalled } from "./fornello";
import type { MarinaraHost } from "./marinara-host";
import { t } from "../shared/i18n";
import { LONG_REPLY_TOKENS } from "../stscript/host";

/** `ui`: the dialogs, with their pick-or-type box for [[blank|options]]. */
export function createViszHost(host: MarinaraHost, ui: ViszHost["ui"]): ViszHost {
  return {
    ui,
    // a page with its story is long: the reply may be, whatever the chat's own length
    // and it goes as an instruction, so a texting preset doesn't have the character answer it
    generate: (prompt, connectionId, preset, memory, presetId) => host.chat.generate({ mode: "chat", prompt, connectionId, preset, memory, maxTokens: LONG_REPLY_TOKENS, instruction: true, ...(presetId ? { presetId } : {}) }),
    postAsCharacter: (text) => host.chat.send({ role: "assistant", text }),
    sendAsUser: async (text) => {
      await submitThroughComposer(text);
      host.chat.markStale();
    },
    putInInput: (text) => {
      const composer = findComposer();
      if (!composer) {
        host.ui.toast(t("Couldn't find the input.", "입력창을 찾지 못했어요."), "warning", { title: "🌟" });
        return;
      }
      const current = composer.textarea.value;
      setComposerText(composer.textarea, current.trim() ? `${current.replace(/\s+$/, "")}\n${text}` : text);
      composer.textarea.focus();
      host.ui.toast(t("Put in the input. Edit it, then send.", "입력창에 넣었어요. 고친 뒤 보내세요."), "info", { title: "🌟" });
    },
    guided: (text) => host.chat.runNativeCommand(`/guided ${text}`),
    chatInfo: async () => {
      const detail = await host.chat.sync().catch(() => null);
      return { chatId: detail?.id, chatName: detail?.name ?? undefined, character: host.chat.cast[0]?.name };
    },
    hasFornello: fornelloInstalled,
    pictures: chatPictures,
  };
}
