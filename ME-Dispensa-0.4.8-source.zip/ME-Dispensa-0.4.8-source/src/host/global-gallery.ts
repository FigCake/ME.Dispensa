// Pictures for memo boards, kept in a "Dispensa" folder of Marinara's Global Gallery
// (/api/global-gallery) so every device sees them and they take none of the 1 MB storage.

import { api } from "../shared/api";
import { getMarinara } from "../shared/marinara-global";
import { t } from "../shared/i18n";

const FOLDER = "Dispensa";

/** A picture in the folder (a board keeps it as it is, as a `BoardImage` of the same shape). */
export interface GalleryPicture {
  id: string;
  url: string;
}

interface Folder {
  id: string;
  name: string;
}

let folderId: Promise<string> | null = null;

/** The Dispensa folder's id, made when missing. */
function folder(): Promise<string> {
  folderId ??= (async () => {
    const folders = await api<Folder[]>("/global-gallery/folders");
    const found = Array.isArray(folders) ? folders.find((f) => f?.name === FOLDER) : undefined;
    if (found) return found.id;
    return (await api<Folder>("/global-gallery/folders", { method: "POST", body: { name: FOLDER } })).id;
  })().catch((e) => {
    folderId = null;
    throw e;
  });
  return folderId;
}

/** Looks the folder up again: the kept id may be of a deleted folder. */
function lookUpFolder(): Promise<string> {
  folderId = null;
  return folder();
}

/** The pictures in the Dispensa folder, newest first. */
export async function boardImages(): Promise<GalleryPicture[]> {
  const id = await folder();
  const list = await picturesIn(id);
  if (list.length) return list;
  // a deleted folder lists empty: check it still exists
  const again = await lookUpFolder();
  return again === id ? list : picturesIn(again);
}

async function picturesIn(id: string): Promise<GalleryPicture[]> {
  const list = await api<{ id?: unknown; url?: unknown; createdAt?: unknown }[]>(`/global-gallery?folderId=${encodeURIComponent(id)}`);
  return (Array.isArray(list) ? list : [])
    .filter((i): i is { id: string; url: string; createdAt?: unknown } => typeof i?.id === "string" && typeof i.url === "string")
    .sort((a, b) => String(b.createdAt ?? "").localeCompare(String(a.createdAt ?? "")))
    .map((i) => ({ id: i.id, url: i.url }));
}

/** Uploads a picture to the Dispensa folder (jpg, png, gif, webp or avif, up to 20 MB). */
export async function uploadBoardImage(file: File): Promise<GalleryPicture> {
  const id = await folder();
  const form = new FormData();
  form.append("file", file, file.name);
  // multipart, so not through api() (which sends JSON); writes still need the CSRF header
  const res = await (getMarinara().fetch ?? fetch)(`/api/global-gallery/upload?folderId=${encodeURIComponent(id)}`, {
    method: "POST",
    headers: { "x-marinara-csrf": "1", Accept: "application/json" },
    body: form,
    credentials: "same-origin",
  });
  const body = (await res.json().catch(() => null)) as { id?: string; url?: string; folderId?: string | null; error?: string } | null;
  if (!res.ok || !body?.id || !body.url) throw new Error(body?.error || t(`Upload failed (${res.status}).`, `올리지 못했어요 (${res.status}).`));
  if (body.folderId !== undefined && body.folderId !== id) {
    // the folder was deleted, so the picture landed outside it: move it into a new one
    const again = await lookUpFolder();
    await api(`/global-gallery/${encodeURIComponent(body.id)}`, { method: "PATCH", body: { folderId: again } }).catch(() => undefined);
  }
  return { id: body.id, url: body.url };
}

export async function deleteBoardImage(id: string): Promise<void> {
  await api(`/global-gallery/${encodeURIComponent(id)}`, { method: "DELETE" });
}
