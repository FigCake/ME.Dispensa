// visz requests: OOC (sent one of four ways) and pages
// (shown in the viewer above the Dock, or posted to the chat).

import type { HostUI } from "../stscript/host";
import type { ArchiveBackend, ArchiveEntry } from "./archive";
import { assembleVisualizer, cleanOoc, extractHtmlBlocks, fencedPage, fillBlanks, findBlanks, mergeContinuation, normalizeOutput, replaceHtmlBlock, resolveVizMode, titleFrom, wrapOoc } from "./core";
import { CONTINUE_TEMPLATE } from "./defaults";
import { type ViszOutput, type ViszAction, type ViszState, viszOptions } from "./model";
import { t } from "../shared/i18n";
import { newId } from "../util";
import { assembleLastMessage } from "./last-message";

/** A blank named like this is filled from the memo pad. */
const MEMO_BLANK = /^(메모|memo)$/i;

export interface ViszHost {
  ui: HostUI & { choose?(label: string, options: string[]): Promise<string | null> };
  /**
   * A reply with the chat's context, saving nothing. connectionId "" = the chat's; `preset` false leaves
   * its prompt preset out; `memory`: also the chat's lorebooks and summary; `presetId`: a prompt preset
   * instead of the chat's.
   */
  generate(prompt: string, connectionId: string, preset?: boolean, memory?: boolean, presetId?: string): Promise<string>;
  postAsCharacter(text: string): Promise<void>;
  sendAsUser(text: string): Promise<void>;
  putInInput(text: string): void;
  /** Marinara /guided: no visible message, the reply comes as the character's turn. */
  guided(text: string): Promise<void>;
  chatInfo(): Promise<{ chatId?: string; chatName?: string; character?: string }>;
  /** Fornello is installed: pages get its commands, so the prompt can tell the model about them. */
  hasFornello?(): boolean;
  /** The chat's character pictures a page may name with {{raw::name}} (Fornello fills them in). */
  pictures?(): Promise<{ name: string; person: string }[]>;
  /** Memos chosen from the memo pad (null when none), for [[memo]] and the memo button by a blank. */
  pickMemos?(): Promise<string | null>;
}

export interface ViewerEntry {
  title: string;
  kind: "viz" | "ooc";
  text: string;
  /** Set once the result is in the archive. */
  archivedId?: string;
  /** The chat it was made in, when known (a Gallery page): its picture names mean that chat's characters. */
  chatId?: string;
}

export interface ViszViewer {
  show(entry: ViewerEntry): void;
}

export type ViszPrompt = "superviz" | "last";

export interface RunOptions {
  viszOutput?: ViszOutput;
  prompt?: ViszPrompt;
  /**
   * Run from the Gallery: on this connection, saved to the Gallery only, alongside anything else running.
   * `input`: the memo a [[memo]] blank takes without asking.
   */
  gallery?: { connectionId: string; title?: string; input?: string };
}

/** Automatic attempts to finish a page that came back cut off. */
const AUTO_CONTINUE = 2;

export class ViszService {
  private busyLabel: string | null = null;
  private readonly listeners = new Set<(busy: string | null) => void>();

  constructor(
    private readonly host: ViszHost,
    private readonly state: () => ViszState,
    readonly archive: ArchiveBackend,
    private readonly viewer: () => ViszViewer | null,
  ) {}

  get busy(): string | null {
    return this.busyLabel;
  }

  onBusy(fn: (busy: string | null) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private setBusy(label: string | null): void {
    this.busyLabel = label;
    for (const fn of this.listeners) fn(label);
  }

  /** Asks for every [[blank]] ([[memo]]: picks from the memo pad); null when cancelled. */
  async askBlanks(text: string, memo?: string): Promise<string | null> {
    const values: Record<string, string> = {};
    const pick = memo !== undefined ? async () => memo : this.host.pickMemos;
    for (const blank of findBlanks(text)) {
      let answer: string | null;
      if (pick && !blank.options.length && MEMO_BLANK.test(blank.label.trim())) answer = await pick();
      else if (blank.options.length && this.host.ui.choose) answer = await this.host.ui.choose(blank.label, blank.options);
      else
        answer = await this.host.ui.input(blank.options.length ? `${blank.label} (${blank.options.join(" / ")})` : blank.label, {
          // a memo can be the answer
          extra: pick ? { label: t("📝 Memo pad", "📝 메모장"), title: t("Pick from the Memo pad", "메모장에서 골라 넣기"), fill: pick } : undefined,
        });
      if (answer === null) return null;
      values[blank.key] = answer;
    }
    return fillBlanks(text, values);
  }

  /** /visz: the text as a request. */
  runText(text: string, options: { action?: ViszAction; output?: ViszOutput; prompt?: ViszPrompt; gallery?: { connectionId: string; title?: string; input?: string } } = {}): Promise<boolean> {
    return this.run(options.action ?? "viz", text, { viszOutput: options.output, prompt: options.prompt, gallery: options.gallery });
  }

  /** Resolves true once the request went out (false when cancelled, busy or failed). */
  async run(action: ViszAction, content: string, opts: RunOptions = {}): Promise<boolean> {
    const ui = this.host.ui;
    if (this.busyLabel && !opts.gallery) {
      ui.toast(t("The Visualizer is already making something. Try again when it's done.", "비주얼라이저가 이미 만들고 있어요. 끝난 뒤에 다시 눌러 주세요."), "warning", { title: "🌟" });
      return false;
    }
    const filled = opts.prompt === "last" && action === "viz" ? content : await this.askBlanks(content, opts.gallery?.input);
    if (filled === null) {
      ui.toast(t("Cancelled.", "취소했어요."), "info", { title: "🌟" });
      return false;
    }
    if (!cleanOoc(filled)) {
      ui.toast(t("Nothing to send.", "보낼 내용이 비어 있어요."), "warning", { title: "🌟" });
      return false;
    }
    const state = this.state();
    const o = viszOptions(state);
    const last = action === "viz" && opts.prompt === "last";
    const title = (last ? t("Last message", "마지막 메시지") : titleFrom(filled)) || t("Visualizer", "비주얼라이저");
    const gallery = opts.gallery;
    // the characters' own pictures, told after the prompt (which stays as written)
    const withPictures = async (prompt: string) => prompt + (await this.picturesNote());
    if (gallery) {
      const env = { fornello: this.host.hasFornello?.() === true };
      const fornello = env.fornello ? (state.preset.chunks.find((c) => c.id === "fornello" && c.enabled !== false)?.text ?? null) : null;
      const prompt =
        action === "ooc"
          ? wrapOoc(o.wrapper.template, filled, state.settings.language)
          : last
            ? assembleLastMessage(filled, state.settings.language, fornello)
            : assembleVisualizer(state.preset, resolveVizMode(state.settings.viszMode, env), { topic: filled, language: state.settings.language, env });
      return this.makeForGallery(action === "ooc" ? prompt : await withPictures(prompt), { kind: action === "ooc" ? "ooc" : "viz", title: gallery.title || title, connectionId: gallery.connectionId || o.connectionId });
    }
    if (action === "ooc") {
      const text = wrapOoc(o.wrapper.template, filled, state.settings.language);
      const mode = o.oocMode;
      if (mode === "input") {
        this.host.putInInput(text);
        return true;
      }
      if (mode === "user") return this.busyWhile(`💬 ${title}`, () => this.host.sendAsUser(text));
      if (mode === "guided") return this.busyWhile(`💬 ${title}`, () => this.host.guided(text));
      return this.generateAndDeliver(text, { kind: "ooc", title, connectionId: o.connectionId, output: "chat" });
    }
    const env = { fornello: this.host.hasFornello?.() === true };
    if (last) {
      const fornello = env.fornello ? (state.preset.chunks.find((c) => c.id === "fornello" && c.enabled !== false)?.text ?? null) : null;
      return this.generateAndDeliver(await withPictures(assembleLastMessage(filled, state.settings.language, fornello)), { kind: "viz", title, connectionId: o.connectionId, output: opts.viszOutput ?? o.viszOutput });
    }
    const prompt = await withPictures(assembleVisualizer(state.preset, resolveVizMode(state.settings.viszMode, env), { topic: filled, language: state.settings.language, env }));
    return this.generateAndDeliver(prompt, { kind: "viz", title, connectionId: o.connectionId, output: opts.viszOutput ?? o.viszOutput });
  }

  /** The chat's character pictures for a page: how to use them and their names, or "" when there are none. */
  private async picturesNote(): Promise<string> {
    const list = (await this.host.pictures?.().catch(() => [])) ?? [];
    if (!list.length) return "";
    const byPerson = new Map<string, string[]>();
    for (const p of list) byPerson.set(p.person, [...(byPerson.get(p.person) ?? []), p.name]);
    return [
      "",
      "",
      "[Character pictures]",
      // no HTML tag in it: Marinara's outgoing-prompt cleanup would take the tag out
      "The characters have their own pictures. Where a picture of them fits the page, use one of these instead of a picture from outside: write {{raw::name}} where its address goes (as an image's src value, or inside url() in CSS); it is filled in when the page is shown.",
      ...[...byPerson].map(([who, names]) => `${who}: ${names.join(", ")}`),
    ].join("\n");
  }

  private async busyWhile(label: string, fn: () => Promise<void>): Promise<boolean> {
    this.setBusy(label);
    try {
      await fn();
      return true;
    } catch (e) {
      this.host.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("🌟 Failed", "🌟 실패") });
      return false;
    } finally {
      this.setBusy(null);
    }
  }

  private generateAndDeliver(prompt: string, o: { kind: "viz" | "ooc"; title: string; connectionId: string; output: ViszOutput }): Promise<boolean> {
    return this.busyWhile(`${o.kind === "viz" ? "🌟" : "💬"} ${o.title}`, async () => {
      this.host.ui.toast(t(`Making ${o.title}…`, `${o.title} 만드는 중…`), "info", { title: "🌟" });
      let text = normalizeOutput(await this.host.generate(prompt, o.connectionId, this.state().settings.sendPreset, true)).text;
      if (!text) throw new Error(t("The reply was empty.", "응답이 비어 있어요."));
      for (let i = 0; i < AUTO_CONTINUE && normalizeOutput(text).truncated; i++) text = await this.continueText(text, o.connectionId);
      const entry: ViewerEntry = { title: o.title, kind: o.kind, text };
      if (o.output === "viewer") {
        this.viewer()?.show(entry);
        return;
      }
      // asked for the Gallery: kept whatever the Gallery's own settings say
      if (o.output === "gallery") {
        await this.save(entry);
        this.host.ui.toast(t(`${o.title}: saved to the Gallery.`, `${o.title}: 갤러리에 저장했어요.`), "success", { title: "🖼" });
        return;
      }
      await this.host.postAsCharacter(text);
      if (this.keeps("chat", text)) await this.save(entry);
    });
  }

  /**
   * Makes it on its own connection with the chat's context (card, persona, chat, preset, lorebooks,
   * summary) and keeps it in the Gallery only; it doesn't take the visualizer's busy slot, so it can
   * run while the chat replies or another page is being made.
   */
  async makeForGallery(prompt: string, o: { kind: "viz" | "ooc"; title: string; connectionId: string }): Promise<boolean> {
    const ui = this.host.ui;
    ui.toast(t(`Making ${o.title} inside the Gallery…`, `갤러리 내부에서 ${o.title} 만드는 중…`), "info", { title: "🖼" });
    try {
      const presetId = this.state().settings.galleryPresetId || undefined;
      let text = normalizeOutput(await this.host.generate(prompt, o.connectionId, this.state().settings.sendPreset, true, presetId)).text;
      if (!text) throw new Error(t("The reply was empty.", "응답이 비어 있어요."));
      for (let i = 0; i < AUTO_CONTINUE && normalizeOutput(text).truncated; i++) text = await this.continueText(text, o.connectionId, presetId);
      text = fencedPage(text);
      // a page the visualizer made is what the Gallery keeps even when it keeps HTML only
      if (!this.keeps("gallery", text, o.kind === "viz")) {
        ui.toast(this.notKept("gallery", o.title), "warning", { title: "🖼" });
        return false;
      }
      await this.save({ title: o.title, kind: o.kind, text });
      ui.toast(t(`${o.title}: saved to the Gallery.`, `${o.title}: 갤러리에 저장했어요.`), "success", { title: "🖼" });
      return true;
    } catch (e) {
      ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("🖼 Failed", "🖼 실패") });
      return false;
    }
  }

  /** Finishes the first cut-off page in the text. */
  async continueText(text: string, connectionId = this.state().settings.connectionId, presetId?: string): Promise<string> {
    const blocks = extractHtmlBlocks(text);
    const index = blocks.findIndex((b) => !b.complete);
    if (index < 0) return text;
    const more = await this.host.generate(CONTINUE_TEMPLATE.replace("{{앞부분}}", blocks[index].code), connectionId, this.state().settings.sendPreset, true, presetId);
    return replaceHtmlBlock(text, index, mergeContinuation(blocks[index].code, more));
  }

  /** The viewer's "Continue" button. */
  async continueEntry(entry: ViewerEntry): Promise<ViewerEntry | null> {
    if (this.busyLabel) return null;
    let result: ViewerEntry | null = null;
    await this.busyWhile(t(`🌟 Continuing ${entry.title}`, `🌟 ${entry.title} 이어 쓰기`), async () => {
      result = { ...entry, text: await this.continueText(entry.text) };
      if (entry.archivedId) await this.save(result);
    });
    return result;
  }

  /** Whether the Gallery's settings keep a result: from the open chat or from a Gallery run, with or without a page. */
  keeps(from: "chat" | "gallery", text: string, page = false): boolean {
    const s = this.state().settings;
    if (s.collect !== "all" && s.collect !== from) return false;
    return page || !s.htmlOnly || extractHtmlBlocks(text).length > 0;
  }

  /** Why a result wasn't kept, for the toast. */
  notKept(from: "chat" | "gallery", title: string): string {
    const s = this.state().settings;
    if (s.collect !== "all" && s.collect !== from) return t(`${title}: the Gallery's settings keep only results from the chat.`, `${title}: 갤러리 설정이 채팅 결과만 저장하게 되어 있어요.`);
    return t(`${title}: no HTML page in it, and the Gallery keeps only pages.`, `${title}: HTML 페이지가 없어요. 갤러리는 HTML만 저장하게 되어 있어요.`);
  }

  async save(entry: ViewerEntry): Promise<string> {
    const info = await this.host.chatInfo().catch(() => ({}) as Awaited<ReturnType<ViszHost["chatInfo"]>>);
    const record: ArchiveEntry = {
      id: entry.archivedId ?? newId("page"),
      title: entry.title,
      kind: entry.kind,
      text: entry.text,
      createdAt: Date.now(),
      ...info,
    };
    await this.archive.put(record);
    entry.archivedId = record.id;
    return record.id;
  }
  postToChat(entry: ViewerEntry): Promise<boolean> {
    return this.busyWhile(t(`Posting ${entry.title} to chat`, `${entry.title} 채팅에 넣기`), () => this.host.postAsCharacter(entry.text));
  }
}
