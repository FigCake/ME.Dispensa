// The free layout of a memo board: cards and magnets on a surface that pans and zooms.
// While something moves only its element changes; the board is saved on let go, so nothing redraws mid-drag.

import { type Board, type BoardMagnet, BOARD_H, BOARD_W, CARD_W, MAGNET_SIZE, cardNumbers, clampTo, rotationFrom, topZ } from "../memo/board";
import { snapTo } from "../memo/board-themes";
import { t } from "../shared/i18n";
import { cardEl } from "./board-card";
import type { BoardContext } from "./board-context";
import { el, icon } from "./dom";

export const BOARD_STAGE_CSS = `
.board-stage { position: relative; flex: 1; min-height: 240px; overflow: hidden; border-radius: var(--d-radius); border: 1px solid var(--d-line);
  background: var(--d-field); touch-action: none; user-select: none; -webkit-user-select: none; cursor: grab; }
.board-stage.panning { cursor: grabbing; }
.board-surface { position: absolute; left: 0; top: 0; transform-origin: 0 0; background-color: #e8dcc8; background-size: cover; background-position: center;
  box-shadow: inset 0 0 0 1px rgb(0 0 0 / .08); }
.board-magnet { position: absolute; transform-origin: 50% 50%; cursor: pointer; touch-action: none; filter: drop-shadow(0 3px 4px rgb(0 0 0 / .3)); }
.board-magnet img { display: block; width: 100%; height: auto; pointer-events: none; -webkit-user-drag: none; }
/* a Gallery page's picture: framed like a print */
.board-magnet.page img { box-sizing: border-box; border: 6px solid #fff; border-bottom-width: 20px; border-radius: 2px; background: #fff; }
.board-card.moving, .board-magnet.moving { outline: 2px dashed var(--d-accent); outline-offset: 4px; cursor: move; }
.board-handle { position: absolute; width: 22px; height: 22px; border-radius: 50%; background: var(--d-accent); border: 2px solid #fff; box-shadow: 0 1px 4px rgb(0 0 0 / .4); touch-action: none; }
/* inside the card's corners: a card keeps its overflow hidden */
.board-handle { z-index: 1; }
.board-handle.resize { right: 3px; bottom: 3px; cursor: nwse-resize; }
.board-handle.turn { left: calc(50% - 11px); top: 3px; cursor: grab; }
.board-handle.drop { left: 3px; top: 3px; background: var(--d-danger); display: grid; place-items: center; color: #fff; font-size: 12px; cursor: pointer; }
`;

const LONG_PRESS_MS = 450;
/** Screen pixels a pointer may wander and still be a tap. */
const TAP_SLOP = 8;
const ZOOM = { min: 0.3, max: 2 };

type Moving = { kind: "card"; id: string } | { kind: "magnet"; id: string };

export class BoardStage {
  /** null zoom: not set yet (it depends on the screen width). */
  private view = { x: 0, y: 0, zoom: null as number | null };
  private moving: Moving | null = null;
  private stageEl: HTMLElement | null = null;
  /** Two fingers are down: a one-finger drag or long press under way stops counting. */
  private pinching = false;
  private surfaceEl: HTMLElement | null = null;
  /** Removes the last drawn stage's window listeners. */
  private stageWatch: AbortController | null = null;

  constructor(private readonly ctx: BoardContext) {}

  resetView(): void {
    this.view = { x: 0, y: 0, zoom: this.view.zoom };
  }

  putDown(): void {
    this.moving = null;
  }

  /** Called when the section layout shows instead. */
  forget(): void {
    this.stageWatch?.abort();
    this.stageWatch = null;
    this.stageEl = null;
    this.surfaceEl = null;
  }

  zoomButtons(): HTMLElement[] {
    return [
      el("button", { title: t("Zoom out", "축소"), "aria-label": t("Zoom out", "축소"), onclick: () => this.zoomBy(1 / 1.25) }, icon("minus")),
      el("span", { class: "zoom" }, `${Math.round(this.zoom() * 100)}%`),
      el("button", { title: t("Zoom in", "확대"), "aria-label": t("Zoom in", "확대"), onclick: () => this.zoomBy(1.25) }, icon("plus")),
      el("button", { title: t("Show every card", "모든 카드 보기"), "aria-label": t("Fit", "맞춤"), onclick: () => this.fit() }, icon("scan"), el("span", { class: "lbl" }, t("Fit", "맞춤"))),
    ];
  }

  centerPoint(): { x: number; y: number } {
    const s = this.stageEl;
    if (!s) return { x: 60, y: 60 };
    const r = s.getBoundingClientRect();
    return this.toBoard(r.left + r.width / 2, r.top + r.height / 3);
  }

  render(board: Board): HTMLElement {
    const surface = el("div", { class: "board-surface" });
    surface.style.width = `${BOARD_W}px`;
    surface.style.height = `${BOARD_H}px`;
    if (board.background?.image) {
      surface.style.backgroundImage = `url("${board.background.image.url}")`;
      // inline, to override the theme's pattern size and repeat
      surface.style.backgroundSize = "cover";
      surface.style.backgroundRepeat = "no-repeat";
    }
    const memos = new Map(this.ctx.state().memos.map((m) => [m.id, m]));
    const numbers = cardNumbers(board, this.ctx.state().memos);
    const straight = keepsStraight(board, this.ctx.grid());
    for (const card of board.cards) {
      const memo = memos.get(card.memoId);
      if (!memo) continue;
      const moving = this.isMoving("card", card.memoId);
      const node = cardEl(this.ctx, card, memo, numbers.get(card.memoId) ?? 0, moving);
      this.place(node, card.x, card.y, card.w, straight ? 0 : card.rotate, card.z);
      if (moving) node.append(...this.handles("card", card.memoId));
      surface.append(node);
    }
    for (const magnet of board.magnets) surface.append(this.magnetEl(magnet, straight));
    const stage = el("div", { class: "board-stage", "aria-label": board.name });
    stage.append(surface);
    this.stageEl = stage;
    this.surfaceEl = surface;
    this.applyView();
    this.watchStage(stage);
    return stage;
  }

  private zoom(): number {
    this.view.zoom ??= window.innerWidth < 720 ? 0.6 : 0.9;
    return this.view.zoom;
  }

  private zoomBy(factor: number, at?: { x: number; y: number }): void {
    const before = this.zoom();
    const after = clampTo(before * factor, ZOOM.min, ZOOM.max);
    const stage = this.stageEl;
    const point = at ?? (stage ? { x: stage.clientWidth / 2, y: stage.clientHeight / 2 } : { x: 0, y: 0 });
    this.view.x = point.x - ((point.x - this.view.x) * after) / before;
    this.view.y = point.y - ((point.y - this.view.y) * after) / before;
    this.view.zoom = after;
    this.applyView();
  }

  private fit(): void {
    const stage = this.stageEl;
    if (!stage) return;
    const items = [...stage.querySelectorAll<HTMLElement>(".board-card, .board-magnet")];
    if (!items.length) {
      this.view = { x: 0, y: 0, zoom: this.zoom() };
      return this.applyView();
    }
    const left = Math.min(...items.map((i) => i.offsetLeft));
    const top = Math.min(...items.map((i) => i.offsetTop));
    const right = Math.max(...items.map((i) => i.offsetLeft + i.offsetWidth));
    const bottom = Math.max(...items.map((i) => i.offsetTop + i.offsetHeight));
    const zoom = clampTo(Math.min(stage.clientWidth / (right - left + 80), stage.clientHeight / (bottom - top + 80)), ZOOM.min, 1.2);
    this.view = { x: (stage.clientWidth - (right - left) * zoom) / 2 - left * zoom, y: (stage.clientHeight - (bottom - top) * zoom) / 2 - top * zoom, zoom };
    this.applyView();
  }

  private applyView(): void {
    if (this.surfaceEl) this.surfaceEl.style.transform = `translate(${this.view.x}px, ${this.view.y}px) scale(${this.zoom()})`;
    const label = this.stageEl?.parentElement?.querySelector(".board-bar .zoom");
    if (label) label.textContent = `${Math.round(this.zoom() * 100)}%`;
  }

  private toBoard(clientX: number, clientY: number): { x: number; y: number } {
    const r = this.stageEl!.getBoundingClientRect();
    return { x: (clientX - r.left - this.view.x) / this.zoom(), y: (clientY - r.top - this.view.y) / this.zoom() };
  }

  private magnetEl(m: BoardMagnet, straight: boolean): HTMLElement {
    const moving = this.isMoving("magnet", m.id);
    const node = el("div", { class: `board-magnet${moving ? " moving" : ""}${m.page ? " page" : ""}`, "data-magnet": m.id, ...(m.page ? { title: m.page.title } : {}) }, el("img", { src: m.image.url, alt: "", draggable: "false" }));
    this.place(node, m.x, m.y, m.size, straight ? 0 : m.rotate, m.z);
    if (moving) node.append(...this.handles("magnet", m.id));
    return node;
  }

  private place(node: HTMLElement, x: number, y: number, w: number, rotate = 0, z = 0): void {
    node.style.left = `${x}px`;
    node.style.top = `${y}px`;
    node.style.width = `${w}px`;
    node.style.transform = rotate ? `rotate(${rotate}deg)` : "";
    node.style.zIndex = String(z);
  }

  private isMoving(kind: Moving["kind"], id: string): boolean {
    return this.moving?.kind === kind && this.moving.id === id;
  }

  private handles(kind: Moving["kind"], id: string): HTMLElement[] {
    const drop = el("div", { class: "board-handle drop", role: "button", "data-handle": "drop", title: kind === "card" ? t("Off the board", "보드에서 빼기") : t("Remove the magnet", "마그넷 떼기") }, "✕");
    return [
      ...(this.ctx.board() && keepsStraight(this.ctx.board()!, this.ctx.grid()) ? [] : [el("div", { class: "board-handle turn", "data-handle": "turn", title: t("Drag to turn", "끌어서 돌리기") })]),
      el("div", { class: "board-handle resize", "data-handle": "resize", title: t("Drag to resize", "끌어서 크기 바꾸기") }),
      Object.assign(drop, { onclick: () => (kind === "card" ? this.ctx.takeOff(id) : this.removeMagnet(id)) }),
    ];
  }

  private removeMagnet(id: string): void {
    this.moving = null;
    this.ctx.updateBoard((b) => (b.magnets = b.magnets.filter((m) => m.id !== id)));
  }

  private watchStage(stage: HTMLElement): void {
    this.stageWatch?.abort();
    const watch = new AbortController();
    this.stageWatch = watch;
    // fingers on the old stage are gone
    this.pinching = false;
    const pointers = new Map<number, { x: number; y: number }>();
    let pinch: { dist: number; zoom: number } | null = null;
    stage.addEventListener(
      "wheel",
      (e) => {
        e.preventDefault();
        const r = stage.getBoundingClientRect();
        this.zoomBy(e.deltaY < 0 ? 1.1 : 1 / 1.1, { x: e.clientX - r.left, y: e.clientY - r.top });
      },
      { passive: false },
    );
    stage.addEventListener("pointerdown", (e) => {
      const target = e.target as HTMLElement;
      // a checkbox in a card ticks; it does not start a drag
      if (target.closest("input, label, a")) return;
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pointers.size === 2) {
        this.pinching = true;
        const [a, b] = [...pointers.values()];
        pinch = { dist: Math.hypot(a.x - b.x, a.y - b.y), zoom: this.zoom() };
        return;
      }
      const handle = target.closest<HTMLElement>("[data-handle]");
      const item = target.closest<HTMLElement>("[data-card], [data-magnet]");
      if (handle?.dataset.handle === "drop") return;
      if (handle && item) return this.dragHandle(e, item, handle.dataset.handle as "turn" | "resize");
      if (item) return this.pressItem(e, item);
      this.pan(e, stage);
    });
    const forget = (e: PointerEvent) => {
      pointers.delete(e.pointerId);
      if (pointers.size < 2) pinch = null;
      if (!pointers.size) this.pinching = false;
    };
    stage.addEventListener("pointermove", (e) => {
      if (!pointers.has(e.pointerId)) return;
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pinch && pointers.size === 2) {
        const [a, b] = [...pointers.values()];
        const r = stage.getBoundingClientRect();
        const mid = { x: (a.x + b.x) / 2 - r.left, y: (a.y + b.y) / 2 - r.top };
        this.zoomBy((pinch.zoom * Math.hypot(a.x - b.x, a.y - b.y)) / pinch.dist / this.zoom(), mid);
      }
    });
    // forget fingers lifted off the stage or lost in a redraw: two stale ones make every touch a pinch
    const { signal } = watch;
    for (const type of ["pointerup", "pointercancel", "lostpointercapture"] as const) window.addEventListener(type, forget, { capture: true, signal });
    stage.addEventListener("lostpointercapture", forget, { signal });
  }

  /** `pinched`: a second finger came down meanwhile, or the system cancelled the pointer (palm rejection): nothing is tapped or saved. */
  private follow(e: PointerEvent, move: (ev: PointerEvent) => void, up: (ev: PointerEvent, moved: boolean, pinched: boolean) => void): void {
    const target = e.target as HTMLElement;
    target.setPointerCapture?.(e.pointerId);
    const start = { x: e.clientX, y: e.clientY };
    let moved = false;
    let pinched = false;
    const onMove = (ev: PointerEvent) => {
      if (ev.pointerId !== e.pointerId) return;
      if (this.pinching) pinched = true;
      if (pinched) return;
      if (!moved && Math.hypot(ev.clientX - start.x, ev.clientY - start.y) > TAP_SLOP) moved = true;
      if (moved) move(ev);
    };
    const onUp = (ev: PointerEvent) => {
      if (ev.pointerId !== e.pointerId) return;
      window.removeEventListener("pointermove", onMove, true);
      window.removeEventListener("pointerup", onUp, true);
      window.removeEventListener("pointercancel", onUp, true);
      up(ev, moved, pinched || this.pinching || ev.type === "pointercancel");
    };
    window.addEventListener("pointermove", onMove, true);
    window.addEventListener("pointerup", onUp, true);
    window.addEventListener("pointercancel", onUp, true);
  }

  private pan(e: PointerEvent, stage: HTMLElement): void {
    const from = { x: this.view.x, y: this.view.y, cx: e.clientX, cy: e.clientY };
    stage.classList.add("panning");
    this.follow(
      e,
      (ev) => {
        this.view.x = from.x + ev.clientX - from.cx;
        this.view.y = from.y + ev.clientY - from.cy;
        this.applyView();
      },
      (_ev, moved, pinched) => {
        stage.classList.remove("panning");
        // a tap on the empty board puts down what was in move mode
        if (!moved && !pinched && this.moving) {
          this.moving = null;
          this.ctx.deps.rerender();
        }
      },
    );
  }

  private pressItem(e: PointerEvent, item: HTMLElement): void {
    const kind: Moving["kind"] = item.dataset.card ? "card" : "magnet";
    const id = (item.dataset.card ?? item.dataset.magnet)!;
    const touch = e.pointerType !== "mouse";
    const wasMoving = this.isMoving(kind, id);
    // a mouse drags at once; a finger needs a long press unless the item is already in move mode
    let lifted = !touch || wasMoving;
    let byLongPress = false;
    let timer: ReturnType<typeof setTimeout> | null = null;
    if (!wasMoving) {
      timer = setTimeout(() => {
        timer = null;
        // a second finger came down: a pinch, not a long press
        if (this.pinching) return;
        lifted = byLongPress = true;
        navigator.vibrate?.(15);
        item.classList.add("moving");
      }, LONG_PRESS_MS);
    }
    const start = { x: parseFloat(item.style.left), y: parseFloat(item.style.top), cx: e.clientX, cy: e.clientY };
    const pan = { x: this.view.x, y: this.view.y };
    let panned = false;
    this.follow(
      e,
      (ev) => {
        if (timer) clearTimeout(timer);
        timer = null;
        if (!lifted) {
          // a finger moving before the long press is panning the board
          panned = true;
          this.view.x = pan.x + ev.clientX - start.cx;
          this.view.y = pan.y + ev.clientY - start.cy;
          return this.applyView();
        }
        const z = this.zoom();
        item.style.left = `${clampTo(start.x + (ev.clientX - start.cx) / z, 0, BOARD_W - item.offsetWidth)}px`;
        item.style.top = `${clampTo(start.y + (ev.clientY - start.cy) / z, 0, BOARD_H - 40)}px`;
      },
      (_ev, moved, pinched) => {
        if (timer) clearTimeout(timer);
        if (pinched) {
          // a pinch cancels: a card dragged before it goes back
          if (byLongPress) item.classList.remove("moving");
          item.style.left = `${start.x}px`;
          item.style.top = `${start.y}px`;
          return;
        }
        if (panned) return;
        if (moved) {
          // a finger keeps it in move mode
          if (touch) this.moving = { kind, id };
          return this.commitPlace(kind, id, { x: parseFloat(item.style.left), y: parseFloat(item.style.top) }, true);
        }
        if (byLongPress) {
          this.moving = { kind, id };
          return this.ctx.deps.rerender();
        }
        if (kind === "card") return this.ctx.openCard(id);
        const page = this.ctx.board()?.magnets.find((m) => m.id === id)?.page;
        if (page && !wasMoving) {
          void this.ctx.deps.openPage(page.archiveId).then((ok) => ok || this.ctx.deps.ui.toast(t("This page isn't in this browser's Gallery.", "이 페이지는 이 브라우저의 갤러리에 없어요."), "info", { title: "📋" }));
          return;
        }
        this.moving = wasMoving ? null : { kind, id };
        this.ctx.deps.rerender();
      },
    );
  }

  private dragHandle(e: PointerEvent, item: HTMLElement, handle: "turn" | "resize"): void {
    const kind: Moving["kind"] = item.dataset.card ? "card" : "magnet";
    const id = (item.dataset.card ?? item.dataset.magnet)!;
    const start = { w: item.offsetWidth, cx: e.clientX };
    const limits = kind === "card" ? CARD_W : MAGNET_SIZE;
    const rect = item.getBoundingClientRect();
    const center = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    let rotate = 0;
    this.follow(
      e,
      (ev) => {
        if (handle === "resize") {
          item.style.width = `${clampTo(start.w + (ev.clientX - start.cx) / this.zoom(), limits.min, limits.max)}px`;
        } else {
          rotate = rotationFrom(ev.clientX - center.x, ev.clientY - center.y);
          item.style.transform = rotate ? `rotate(${rotate}deg)` : "";
        }
      },
      (_ev, moved, pinched) => {
        if (!moved || pinched) return;
        if (handle === "resize") this.commitPlace(kind, id, { w: parseFloat(item.style.width) });
        else this.commitPlace(kind, id, { rotate });
      },
    );
  }

  private commitPlace(kind: Moving["kind"], id: string, change: { x?: number; y?: number; w?: number; rotate?: number }, toTop = false): void {
    const grid = this.ctx.grid();
    this.ctx.updateBoard((b) => {
      const z = topZ(b);
      const target = kind === "card" ? b.cards.find((c) => c.memoId === id) : b.magnets.find((m) => m.id === id);
      if (!target) return;
      if (change.x !== undefined) target.x = Math.max(0, snapTo(change.x, grid));
      if (change.y !== undefined) target.y = Math.max(0, snapTo(change.y, grid));
      if (change.w !== undefined) {
        const w = Math.max(grid, snapTo(change.w, grid));
        if ("memoId" in target) target.w = clampTo(w, CARD_W.min, CARD_W.max);
        else target.size = clampTo(w, MAGNET_SIZE.min, MAGNET_SIZE.max);
      }
      if (change.rotate !== undefined) {
        if (change.rotate) target.rotate = change.rotate;
        else delete target.rotate;
      }
      if (toTop) target.z = z;
    });
  }
}

/** The look's choice, else straight on a theme with a grid. */
export function keepsStraight(board: Board, grid: number): boolean {
  const tilt = board.theme?.style?.tilt;
  return tilt === "straight" ? true : tilt === "tilted" ? false : grid > 0;
}
