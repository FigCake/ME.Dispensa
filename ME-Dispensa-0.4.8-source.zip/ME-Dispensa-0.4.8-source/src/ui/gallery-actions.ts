// What the Gallery and the memo boards do together: run a QR for the Gallery only, pick that QR,
// open a saved page, and put a Gallery page on a board.

import { capturePage } from "../shared/capture";
import { t } from "../shared/i18n";
import { uploadBoardImage } from "../host/global-gallery";
import { pageWithPictures } from "../host/fornello";
import { type Board, CARD_W, MAGNET_SIZE, freeSpot, newBoard, placeMemos, topZ } from "../memo/board";
import { type MemoOwner, type MemoState, newMemo } from "../memo/model";
import type { MemoStore } from "../memo/store";
import type { QrItem, QrSet, QrState } from "../qr/model";
import type { QrRunner } from "../qr/runner";
import type { QrStore } from "../qr/store";
import type { HostUI } from "../stscript/host";
import { newId } from "../util";
import type { ArchiveEntry } from "../visz/archive";
import { extractHtmlBlocks, fencedPage } from "../visz/core";
import type { ViszService } from "../visz/service";
import type { ViszStore } from "../visz/store";
import type { ViewerPanel } from "./viewer";

/** A QR the user picks from the whole Library; null when there is none or nothing was picked. */
export async function pickQr(ui: HostUI, state: QrState, prompt: string): Promise<{ set: QrSet; item: QrItem } | null> {
  const entries = state.sets.flatMap((set) => set.items.map((item) => ({ set, item, label: `${set.name} › ${item.label}` })));
  if (!entries.length || !ui.pick) {
    ui.toast(t("There are no QRs yet.", "아직 QR이 없어요."), "info", { title: "🖼" });
    return null;
  }
  // the sets first, like folders; a set opens to its QRs (a search looks through all of them)
  const groups = state.sets.map((set) => ({ label: set.name, ...(set.icon ? { icon: set.icon } : {}), items: set.items.map((item) => `${set.name} › ${item.label}`), names: set.items.map((item) => item.label) }));
  const [label] = await ui.pick(prompt, entries.map((e) => e.label), { placeholder: t("Search QRs", "QR 찾기"), groups });
  return entries.find((e) => e.label === label) ?? null;
}

export interface GalleryActionDeps {
  ui: HostUI;
  runner: QrRunner;
  visz: ViszService;
  viszStore: ViszStore;
  store: QrStore;
  memoStore: MemoStore;
  memoOwner(): MemoOwner | undefined;
  viewer(): ViewerPanel | null;
}

export function galleryActions(d: GalleryActionDeps) {
  const { ui, runner, visz, memoStore } = d;
  /** Runs a QR for the Gallery only (`input`: the memo or board it is given) and saves what it made. */
  const galleryRun = async (set: QrSet, item: QrItem, input?: string, about?: string): Promise<void> => {
    const s = d.viszStore.value.settings;
    const title = about ? `${item.label} · ${about}` : item.label;
    ui.toast(t(`${title}: making it inside the Gallery…`, `${title}: 갤러리 내부에서 만드는 중…`), "info", { title: "🖼" });
    try {
      const made = await runner.runInGallery(set, item, s.galleryConnectionId || s.connectionId, input, title, s.sendPreset, s.galleryPresetId || undefined);
      if (made === null) return; // the visualizer saved it (or said why not)
      const text = fencedPage(made);
      if (!text.trim()) {
        ui.toast(t(`${title} made nothing to keep.`, `${title}: 남길 결과가 없어요.`), "warning", { title: "🖼" });
        return;
      }
      if (!visz.keeps("gallery", text)) {
        ui.toast(visz.notKept("gallery", title), "warning", { title: "🖼" });
        return;
      }
      await visz.save({ title, kind: extractHtmlBlocks(text).length ? "viz" : "ooc", text });
      ui.toast(t(`${title}: saved to the Gallery.`, `${title}: 갤러리에 저장했어요.`), "success", { title: "🖼" });
    } catch (e) {
      ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t(`🖼 ${title} failed`, `🖼 ${title} 실패`) });
    }
  };
  /** A memo or board run through a QR the user picks, for the Gallery. */
  const runForGallery = async (text: string, about: string): Promise<void> => {
    const chosen = await pickQr(ui, d.store.value, t(`A QR to run inside the Gallery on "${about}"`, `"${about}"을(를) 소재로 갤러리 내부에서 실행할 QR`));
    if (chosen) await galleryRun(chosen.set, chosen.item, text, about);
  };
  const openPage = async (id: string): Promise<boolean> => {
    const entry = (await visz.archive.list()).find((e) => e.id === id);
    const viewer = d.viewer();
    if (!entry || !viewer) return false;
    viewer.show({ title: entry.title, kind: entry.kind, text: entry.text, archivedId: entry.id, ...(entry.chatId ? { chatId: entry.chatId } : {}) });
    return true;
  };
  /** A Gallery page onto a memo board: a page as its picture (a tap opens it), a text result as a memo card. */
  const sendToBoard = async (entry: ArchiveEntry): Promise<void> => {
    const boards = memoStore.value.boards ?? [];
    const names = [...boards.map((b, i) => `${i + 1}. ${b.name}`), t("＋ A new board", "＋ 새 보드")];
    const [choice] = ui.pick ? await ui.pick(t("Put it on which board?", "어느 보드에 붙일까요?"), names) : [];
    if (!choice) return;
    const index = names.indexOf(choice);
    const onBoard = (s: MemoState): Board => {
      const known = index < boards.length ? s.boards?.find((b) => b.id === boards[index].id) : undefined;
      if (known) return known;
      const made = newBoard(entry.title);
      (s.boards ??= []).push(made);
      return made;
    };
    const code = extractHtmlBlocks(entry.text)[0]?.code;
    try {
      if (!code) {
        const memo = { ...newMemo(entry.text, Date.now(), d.memoOwner()), title: entry.title };
        memoStore.update((s) => {
          s.memos.push(memo);
          const b = onBoard(s);
          placeMemos(b, [memo.id], freeSpot(b, CARD_W.default));
        });
      } else {
        ui.toast(t("Taking the page's picture…", "페이지 그림을 찍는 중…"), "info", { title: "📋" });
        const blob = await capturePage(null, await pageWithPictures(code, entry.chatId));
        const image = await uploadBoardImage(new File([blob], `${entry.title.replace(/[\\/:*?"<>|]+/g, " ").trim() || "page"}.png`, { type: "image/png" }));
        memoStore.update((s) => {
          const b = onBoard(s);
          b.magnets.push({ id: newId("magnet"), image, ...freeSpot(b, MAGNET_SIZE.max), size: MAGNET_SIZE.max, z: topZ(b) + 1, page: { archiveId: entry.id, title: entry.title } });
        });
      }
      ui.toast(t(`On the board: ${entry.title}`, `보드에 붙였어요: ${entry.title}`), "success", { title: "📋" });
    } catch (e) {
      ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("📋 Couldn't put it on the board", "📋 보드에 붙이지 못했어요") });
    }
  };
  return { galleryRun, runForGallery, openPage, sendToBoard };
}
