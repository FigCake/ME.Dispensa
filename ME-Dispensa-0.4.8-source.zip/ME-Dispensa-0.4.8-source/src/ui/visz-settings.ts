// The visualizer's settings (the Library's Visualizer panel: defaults, backup and the Superviz chunks),
// plus the parts shown elsewhere: Dispensa's AI and the 🍰 bubble (the window's ⚙), OOC (the memo tab).

import type { HostUI } from "../stscript/host";
import type { PresetChunk } from "../visz/core";
import { OOC_MODES, type OocMode, VISZ_OUTPUTS, type ViszOutput, type ViszState, defaultPreset, normalizeViszState } from "../visz/model";
import { SUPERVIZ } from "../visz/superviz";
import type { ViszStore } from "../visz/store";
import { el, icon } from "./dom";
import { downloadJson, pickFiles } from "./files";
import { helpTip, section, setting, toggle } from "../shared/form";
import { t } from "../shared/i18n";
import { newId } from "../util";

export const VISZ_SETTINGS_CSS = `
.cards { display: flex; flex-direction: column; gap: 12px; }
.cards .card { border: 1px solid var(--d-line); border-radius: var(--d-radius); padding: 12px 14px; display: flex; flex-direction: column; gap: 6px; }
.cards .chunk { border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); padding: 6px 8px; display: flex; flex-direction: column; gap: 6px; transition: opacity .15s ease; }
.cards .chunk.off { opacity: .55; }
.cards textarea.short { min-height: 90px; }
.cards .icon-input { width: 3.4em !important; min-width: 0 !important; text-align: center; }
.cards details.more > summary { cursor: pointer; color: var(--d-muted); font-size: 12px; padding: 4px 0; list-style: none; display: flex; align-items: center; gap: 6px; }
.cards details.more > summary::before { content: "▸"; transition: transform .15s ease; }
.cards details.more[open] > summary::before { transform: rotate(90deg); }
.cards .field-h { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--d-muted); }
`;

type Connection = { id: string; name: string };

export interface ViszSettingsDeps {
  store: ViszStore;
  ui: HostUI;
  connections(): Promise<Connection[]>;
  /** Marinara's prompt presets. */
  presets(): Promise<Connection[]>;
  rerender(): void;
}

function select<T extends string>(key: string, entries: [T, string][], value: string, onChange: (v: T) => void, label = ""): HTMLSelectElement {
  return el(
    "select",
    { "data-key": key, "aria-label": label || undefined, onchange: (e: Event) => onChange((e.target as HTMLSelectElement).value as T) },
    ...entries.map(([v, text]) => el("option", { value: v, selected: v === value }, text)),
  );
}

const MODE_LABEL = (): Record<PresetChunk["mode"], string> => ({ all: t("Always", "항상"), full: t("Full only", "풀 모드만"), lite: t("Light only", "라이트 모드만") });

/** English names of the shipped Superviz chunks and preset, by id. */
const CHUNK_NAMES_EN: Record<string, string> = {
  superviz: "Visualizer (default)",
  role: "Role · mission",
  content: "Content rules (topic · format mimicry · RP)",
  interaction: "Interaction patterns (modals · event delegation · drag)",
  tech: "Tech base (CSS reset · gameState · updateUI)",
  fornello: "Fornello commands (DM · memory · story link)",
  "lite-rules": "Light mode tech rules (HTML·CSS only)",
  "img-emoji": "Images: emoji · SVG drawings",
  "output-full": "Output format (full HTML document, one html code block)",
};
const SHIPPED_NAMES = new Map([[SUPERVIZ.id, SUPERVIZ.name], ...SUPERVIZ.chunks.map((c): [string, string] => [c.id, c.name])]);

/** The English name while a chunk keeps its shipped name; a renamed one keeps its own. */
function shownName(x: { id: string; name: string }): string {
  const en = CHUNK_NAMES_EN[x.id];
  return en && SHIPPED_NAMES.get(x.id) === x.name ? t(en, x.name) : x.name;
}

/** Help behind the ? buttons; getters, so they follow the screen language. */
const VISZ_HELP = {
  get viszOutput() {
    return t("· Viewer: a window above the Dock\n· Current chat: straight in as a character message\n· Gallery: kept in the Gallery only", "· 보기 창: Dock 위 작은 창\n· 현재 채팅: 바로 캐릭터 메시지로\n· 갤러리: 갤러리에만 저장");
  },
  get full() {
    return t("With Fornello, pages with scripts. Off: HTML and CSS only", "Fornello가 있으면 스크립트가 도는 페이지. 끄면 HTML·CSS만");
  },
  get external() {
    return t("Pages may load fonts, images and libraries from the web", "페이지가 인터넷의 글꼴·그림·라이브러리를 불러옴");
  },
  get oocMode() {
    return t("· Get the result: the AI's answer as a character message\n· Steer the next reply: Marinara's /guided\n· Send as me: as your message\n· Put in the input: edit, then send", "· 결과물 받기: AI의 답을 캐릭터 메시지로\n· 전개에 반영하기: 마리나라 /guided\n· 직접 보내기: 내 메시지로\n· 입력창에 넣기: 고친 뒤 직접 전송");
  },
  get wrapper() {
    return t("Put around the request so the AI reads it as a request, not an RP line", "AI가 RP 대사가 아닌 요청으로 알아듣게 앞뒤에 붙는 문구");
  },
  get sendPreset() {
    return t("Pages and OOC results get the chat's RP preset too (cards, chat, lorebooks and summary always go)", "페이지·OOC 결과물에 RP 프리셋도 보냄 (카드·채팅·로어북·서사 요약은 늘 들어감)");
  },
  get chunkText() {
    return t("{{주제}} becomes the request, {{언어}} the result language", "{{주제}} 자리에 요청, {{언어}} 자리에 결과 언어");
  },
  get wrappers() {
    return t("{{내용}}: the OOC · {{언어}}: the result language", "{{내용}}: OOC · {{언어}}: 결과 언어");
  },
  get backup() {
    return t("Export / Import: the prompt, wrappers and defaults in one file", "내보내기·가져오기: 본체·틀·기본값을 파일 하나로");
  },
};

export class ViszSettingsView {
  private openChunk: string | null = null;
  private connections: Connection[] | null = null;
  private presets: Connection[] | null = null;

  constructor(private readonly deps: ViszSettingsDeps) {}

  private get state(): ViszState {
    return this.deps.store.value;
  }

  private update(fn: (s: ViszState) => void): void {
    this.deps.store.update(fn);
  }

  /** The prompt presets to choose from ("" = the chat's own); loaded once, then redrawn. */
  presetEntries(): [string, string][] {
    if (!this.presets) {
      this.presets = [];
      void this.deps
        .presets()
        .then((list) => {
          this.presets = list;
          this.deps.rerender();
        })
        .catch(() => undefined);
    }
    return [["", t("The chat's own", "채팅의 프리셋")], ...this.presets.map((p): [string, string] => [p.id, p.name])];
  }

  /** The AI connections to choose from ("" = `inherit`); loaded once, then redrawn. */
  connectionEntries(inherit: string): [string, string][] {
    if (!this.connections) {
      this.connections = [];
      void this.deps
        .connections()
        .then((list) => {
          this.connections = list;
          this.deps.rerender();
        })
        .catch(() => undefined);
    }
    return [["", inherit], ...this.connections.map((c): [string, string] => [c.id, c.name])];
  }

  /** The Library's Visualizer panel: its defaults with backup, then the prompt's chunks. */
  render(): HTMLElement {
    return el("div", { class: "cards visz-settings" }, this.defaults(), this.presetCard());
  }

  /**
   * The AI Dispensa calls itself — pages, OOC results and Gallery runs (QRs' /gen go to the chat's
   * own connection): shown from the window's header.
   */
  commonAi(): HTMLElement {
    const s = this.state.settings;
    const set = (fn: (st: ViszState["settings"]) => void) => this.update((st) => fn(st.settings));
    return el(
      "div",
      { class: "card" },
      section(
        "AI",
        t("A QR's /gen uses the chat's own connection", "QR의 /gen은 채팅 연결을 씀"),
        [],
        setting(t("AI connection", "AI 연결"), select("visz-connection", this.connectionEntries(t("Same as the chat", "채팅과 같은 연결")), s.connectionId, (v) => set((x) => (x.connectionId = v)), t("AI connection", "AI 연결"))),
        setting(t("Gallery runs' AI", "갤러리 실행용 AI"), select("visz-gallery-connection", this.connectionEntries(t("Same as above", "위와 같은 연결")), s.galleryConnectionId, (v) => set((x) => (x.galleryConnectionId = v)), t("Gallery runs' AI", "갤러리 실행용 AI")), t("For ▶ in the Gallery", "갤러리의 ▶용")),
        setting(t("RP preset too", "RP 프리셋 같이 보내기"), toggle(s.sendPreset, (v) => set((x) => (x.sendPreset = v)), t("RP preset too", "RP 프리셋 같이 보내기"), "visz-send-preset"), VISZ_HELP.sendPreset),
        s.sendPreset
          ? setting(
              t("Gallery runs' preset", "갤러리 실행 프리셋"),
              select("visz-gallery-preset", this.presetEntries(), s.galleryPresetId, (v) => set((x) => (x.galleryPresetId = v)), t("Gallery runs' preset", "갤러리 실행 프리셋")),
              t(
                "Gallery runs and their pages are made with this preset. In a conversation chat Marinara takes only a preset's conversation prompt (its sections are for roleplay chats): fill that in for an RP style there",
                "갤러리 실행과 그 페이지는 이 프리셋으로 만들어요. 대화(conversation) 채팅에서는 마리나라가 프리셋의 대화용 프롬프트만 써요(섹션은 롤플레이 채팅용). 거기서 RP 문체를 원하면 그 칸을 채워 주세요",
              ),
            )
          : null,
      ),
    );
  }

  /** How the memo pad sends OOC; shown in the memo tab. */
  oocCards(): HTMLElement[] {
    const s = this.state.settings;
    const set = (fn: (st: ViszState["settings"]) => void) => this.update((st) => fn(st.settings));
    const wrappers = this.state.wrappers.map((w): [string, string] => [w.id, w.name]);
    return [
      el(
        "div",
        { class: "card" },
        section(
          t("💬 Send OOC", "💬 OOC 보내기"),
          undefined,
          [],
          setting(t("How to send", "보내는 방식"), select("visz-ooc-mode", Object.entries(OOC_MODES) as [OocMode, string][], s.oocMode, (v) => set((x) => (x.oocMode = v)), t("How to send", "보내는 방식")), VISZ_HELP.oocMode),
          setting(t("Wrapper", "틀"), select("visz-wrapper", wrappers, s.wrapperId, (v) => set((x) => (x.wrapperId = v)), t("Wrapper", "틀")), VISZ_HELP.wrapper),
        ),
      ),
      this.wrapperCard(),
    ];
  }

  /** The 🍰 bubble's row, for the window's ⚙ settings. */
  dockBubble(): HTMLElement {
    const s = this.state.settings;
    const set = (fn: (st: ViszState["settings"]) => void) => this.update((st) => fn(st.settings));
    return setting(
      t("🍰 Visualizer bubble", "🍰 비주얼라이저 버블"),
      [
        el("input", { type: "text", class: "icon-input", value: s.dockIcon, "data-key": "visz-dock-icon", maxlength: "8", "aria-label": t("Bubble icon", "버블 아이콘"), oninput: (e: Event) => set((x) => (x.dockIcon = (e.target as HTMLInputElement).value.trim() || "🍰")) }),
        toggle(s.showButton, (v) => set((x) => (x.showButton = v)), t("Show Dock bubble", "Dock 버블 보이기"), "visz-show"),
      ],
    );
  }

  private defaults(): HTMLElement {
    const s = this.state.settings;
    const set = (fn: (st: ViszState["settings"]) => void) => this.update((st) => fn(st.settings));
    return el(
      "div",
      { class: "card" },
      section(
        t("Visualizer", "비주얼라이저"),
        VISZ_HELP.backup,
        [el("button", { onclick: () => this.exportJson() }, icon("upload"), t("Export", "내보내기")), el("button", { onclick: () => this.importJson() }, icon("download"), t("Import", "가져오기"))],
        setting(t("Result language", "결과 언어"), el("input", { type: "text", value: s.language, "data-key": "visz-language", "aria-label": t("Result language", "결과 언어"), oninput: (e: Event) => set((x) => (x.language = (e.target as HTMLInputElement).value)) })),
        setting(t("Result goes to", "결과물 보낼 곳"), select("visz-output", Object.entries(VISZ_OUTPUTS) as [ViszOutput, string][], s.viszOutput, (v) => set((x) => (x.viszOutput = v)), t("Result goes to", "결과물 보낼 곳")), VISZ_HELP.viszOutput),
        setting(t("Full pages", "풀 페이지"), toggle(s.viszMode !== "lite", (v) => set((x) => (x.viszMode = v ? "auto" : "lite")), t("Full pages", "풀 페이지"), "visz-full"), VISZ_HELP.full),
        setting(t("Allow outside resources", "외부 자료 불러오기 허용"), toggle(s.allowExternal, (v) => set((x) => (x.allowExternal = v)), t("Allow outside resources", "외부 자료 불러오기 허용"), "visz-external"), VISZ_HELP.external),
      ),
    );
  }

  private presetCard(): HTMLElement {
    const preset = this.state.preset;
    const mutateChunk = (id: string, fn: (c: PresetChunk) => void) =>
      this.update((s) => {
        const c = s.preset.chunks.find((x) => x.id === id);
        if (c) fn(c);
      });
    const modeLabel = MODE_LABEL();
    const chunks = preset.chunks.map((chunk, index) => {
      const open = this.openChunk === chunk.id;
      const name = shownName(chunk);
      const box = el(
        "div",
        { class: `chunk${chunk.enabled ? "" : " off"}` },
        el(
          "div",
          { class: "row" },
          toggle(chunk.enabled, (v) => mutateChunk(chunk.id, (c) => (c.enabled = v)), t(`Turn on ${name}`, `${name} 켜기`)),
          el(
            "button",
            {
              class: "entry grow",
              "aria-expanded": String(open),
              onclick: () => {
                this.openChunk = open ? null : chunk.id;
                this.deps.rerender();
              },
            },
            name,
            el("span", { class: "meta" }, modeLabel[chunk.mode] + (chunk.needs === "fornello" ? t(" · with Fornello", " · Fornello 있을 때") : "")),
          ),
          el("button", { class: "icon", title: t("Move up", "위로"), "aria-label": t("Move up", "위로"), disabled: index === 0, onclick: () => this.moveChunk(index, -1) }, icon("arrow-up")),
          el("button", { class: "icon", title: t("Move down", "아래로"), "aria-label": t("Move down", "아래로"), disabled: index === preset.chunks.length - 1, onclick: () => this.moveChunk(index, 1) }, icon("arrow-down")),
        ),
      );
      if (open) {
        const ta = el("textarea", { "data-key": `chunk-${chunk.id}`, spellcheck: "false", "aria-label": t(`${name} text`, `${name} 내용`), oninput: (e: Event) => mutateChunk(chunk.id, (c) => (c.text = (e.target as HTMLTextAreaElement).value)) });
        ta.value = chunk.text;
        box.append(
          el(
            "div",
            { class: "row" },
            el("label", { class: "grow" }, t("Name", "이름"), el("input", { type: "text", value: name, "data-key": `chunk-name-${chunk.id}`, oninput: (e: Event) => mutateChunk(chunk.id, (c) => (c.name = (e.target as HTMLInputElement).value)) })),
            el(
              "label",
              {},
              el("span", { class: "field-h" }, t("Used when", "쓰는 때")),
              select(`chunk-mode-${chunk.id}`, Object.entries(modeLabel) as [PresetChunk["mode"], string][], chunk.mode, (v) => mutateChunk(chunk.id, (c) => (c.mode = v)), t("Used when", "쓰는 때")),
            ),
          ),
          el("div", { class: "field-h" }, t("Text", "내용"), helpTip(VISZ_HELP.chunkText, t("Text", "내용"))),
          ta,
          el(
            "div",
            { class: "row" },
            el("span", { class: "grow" }),
            el("button", { class: "danger", onclick: () => this.update((s) => (s.preset.chunks = s.preset.chunks.filter((c) => c.id !== chunk.id))) }, icon("trash"), t("Delete chunk", "조각 지우기")),
          ),
        );
      }
      return box;
    });
    const add = el(
      "button",
      {
        onclick: () => {
          const chunk: PresetChunk = { id: newId("chunk"), name: t("New chunk", "새 조각"), mode: "all", enabled: true, text: "" };
          this.update((s) => s.preset.chunks.push(chunk));
          this.openChunk = chunk.id;
        },
      },
      icon("plus"),
      t("Add chunk", "조각 추가"),
    );
    const reset = el(
      "button",
      {
        onclick: async () => {
          if (!(await this.deps.ui.popup(t("Reset the prompt to the default? Your edits and added chunks will be lost.", "본체를 기본값으로 되돌릴까요? 고친 내용과 추가한 조각이 사라져요."), { okButton: t("Reset", "되돌리기"), cancelButton: t("Cancel", "취소") }))) return;
          this.openChunk = null;
          this.update((s) => (s.preset = defaultPreset()));
        },
      },
      icon("refresh-cw"),
      t("Reset", "기본값으로"),
    );
    return el(
      "div",
      { class: "card" },
      section(
        t(`🌟 Prompt: ${shownName(preset)}`, `🌟 본체: ${preset.name}`),
        undefined,
        [add, reset],
        setting(t("Wrap in <System>", "<System>으로 감싸기"), toggle(preset.wrap, (v) => this.update((s) => (s.preset.wrap = v)), t("Wrap in <System>", "<System>으로 감싸기"))),
        ...chunks,
      ),
    );
  }

  private moveChunk(index: number, delta: number): void {
    this.update((s) => {
      const [c] = s.preset.chunks.splice(index, 1);
      s.preset.chunks.splice(index + delta, 0, c);
    });
  }

  private wrapperCard(): HTMLElement {
    const wrappers = this.state.wrappers;
    const add = el("button", { onclick: () => this.update((s) => s.wrappers.push({ id: newId("wrap"), name: t("New wrapper", "새 틀"), template: "{{내용}}" })) }, icon("plus"), t("Add", "추가"));
    return el(
      "div",
      { class: "card" },
      section(
        t("💬 Wrappers", "💬 틀"),
        VISZ_HELP.wrappers,
        [add],
        ...wrappers.map((w) => {
          const ta = el("textarea", {
            class: "short",
            "data-key": `wrap-${w.id}`,
            spellcheck: "false",
            "aria-label": t(`${w.name} text`, `${w.name} 문구`),
            oninput: (e: Event) => this.update((s) => (s.wrappers.find((x) => x.id === w.id)!.template = (e.target as HTMLTextAreaElement).value)),
          });
          ta.value = w.template;
          return el(
            "div",
            { class: "chunk" },
            el(
              "div",
              { class: "row" },
              el("input", { type: "text", class: "grow", value: w.name, "data-key": `wrap-name-${w.id}`, "aria-label": t("Wrapper name", "틀 이름"), oninput: (e: Event) => this.update((s) => (s.wrappers.find((x) => x.id === w.id)!.name = (e.target as HTMLInputElement).value)) }),
              el("button", { class: "icon danger", title: t("Delete", "지우기"), "aria-label": t("Delete", "지우기"), disabled: wrappers.length <= 1, onclick: () => this.update((s) => (s.wrappers = s.wrappers.filter((x) => x.id !== w.id))) }, icon("trash")),
            ),
            ta,
          );
        }),
      ),
    );
  }

  private exportJson(): void {
    downloadJson({ format: "dispensa-visz", ...this.state }, "dispensa.visz.json");
  }

  private importJson(): void {
    pickFiles(async ([file]) => {
      try {
        let json: Record<string, unknown> = {};
        try {
          json = JSON.parse(await file.text()) as Record<string, unknown>;
        } catch {
          // not JSON: the same answer as any other wrong file
        }
        if (json?.format !== "dispensa-visz") throw new Error(t("Not a Dispensa Visualizer file (.visz.json).", "Dispensa 비주얼라이저 파일(.visz.json)이 아니에요."));
        const incoming = normalizeViszState(json);
        if (!(await this.deps.ui.popup(t("Replace the prompt, wrappers and defaults with this file?", "본체·틀·기본값을 이 파일로 바꿀까요?"), { okButton: t("Replace", "바꾸기"), cancelButton: t("Cancel", "취소") }))) return;
        this.update((s) => Object.assign(s, incoming));
        this.deps.ui.toast(t("Imported the Visualizer settings.", "비주얼라이저 설정을 가져왔어요."), "success");
      } catch (e) {
        this.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("Import", "가져오기") });
      }
    }, { json: true });
  }
}
