// Dispensa entry point: loads the saved data, then builds the parts and wires them together.

import { icon } from "./ui/dom";
import { startAutoRun } from "./auto-run";
import { publishBridge } from "./bridge";
import { DISPENSA_DOCK, type DockGroup } from "./shared/dispensa-bridge";
import { ChatScopeWatch } from "./host/chat-scope";
import { getMarinara } from "./shared/marinara-global";
import { MarinaraHost } from "./host/marinara-host";
import { createViszHost } from "./host/visz-host";
import { onLangChange, t } from "./shared/i18n";
import { textForAi } from "./memo/markdown";
import { memosFrom, memosOf, newMemo, ownerFor, visibleMemos } from "./memo/model";
import { installedFonts, useFont } from "./host/fonts";
import { boardImages, deleteBoardImage, uploadBoardImage } from "./host/global-gallery";
import { MemoStore } from "./memo/store";
import { createQrControl } from "./qr/control";
import { dockSlice } from "./qr/dock";
import { type QrItem, type QrSet, builtinSet } from "./qr/model";
import { QrRunner } from "./qr/runner";
import { QrStore } from "./qr/store";
import { createRegistry } from "./stscript";
import type { HostUI } from "./stscript/host";
import { addViewButtons } from "./ui/chat-blocks";
import { ComposerToggle } from "./ui/composer-toggle";
import { Dialogs } from "./ui/dialogs";
import { Dock } from "./ui/dock";
import { keepDockPlaced } from "./ui/dock-placement";
import { QrManager } from "./ui/manager";
import { MemoCapture } from "./ui/memo-capture";
import { MemoPanel } from "./ui/memo-panel";
import { pickMemos } from "./ui/memo-pick";
import { ThemeSync } from "./shared/theme";
import { addMenuSource, keepTopMenu } from "./shared/top-menu";
import { ViewerPanel } from "./ui/viewer";
import { ViszPanel } from "./ui/visz-panel";
import { galleryActions } from "./ui/gallery-actions";
import { createArchive } from "./visz/archive";
import { SyncedArchive, localSyncStore } from "./visz/synced-archive";
import { galleryFiles } from "./host/gallery-files";
import { extractHtmlBlocks } from "./visz/core";
import { ViszService } from "./visz/service";
import { ViszStore } from "./visz/store";

/** Loads a store; on failure says so (the store then never writes, so nothing saved is lost). */
async function load(store: { load(): Promise<void> }, ui: HostUI, message: string, what: string): Promise<void> {
  try {
    await store.load();
  } catch (e) {
    ui.toast(message, "error");
    getMarinara().log.error(`${what} load failed`, e);
  }
}

export async function start(): Promise<() => void> {
  const marinara = getMarinara();
  // a Dock left by an earlier start
  document.getElementById("dispensa-dock")?.remove();

  const theme = new ThemeSync("dispensa-theme");
  theme.start();
  const dialogs = new Dialogs();
  const host = new MarinaraHost(dialogs);
  const registry = createRegistry();

  // ── saved data ──
  const store = new QrStore();
  const viszStore = new ViszStore();
  const memoStore = new MemoStore();
  // one toast per 10 s, whichever store failed
  let toldSaveError = 0;
  const onSaveError = ({ full }: { full: boolean }) => {
    if (Date.now() - toldSaveError < 10_000) return;
    toldSaveError = Date.now();
    host.ui.toast(
      full
        ? t("Dispensa: storage is full, so changes aren't saved. Delete QR sets, memos or boards you don't use.", "Dispensa: 저장 공간이 가득 차서 변경 내용이 저장되지 않아요. 쓰지 않는 QR 세트, 메모, 보드를 지워 주세요.")
        : t("Dispensa: couldn't save changes. Trying again shortly.", "Dispensa: 변경 내용을 저장하지 못했어요. 잠시 뒤 다시 저장해 볼게요."),
      "error",
    );
  };
  for (const s of [store, viszStore, memoStore]) s.onSaveError = onSaveError;
  await load(store, host.ui, t("Dispensa: couldn't load the saved QRs. Changes on this screen won't be saved.", "Dispensa: 저장된 QR을 불러오지 못했어요. 이번 화면에서는 변경 내용이 저장되지 않아요."), "QR");
  await load(viszStore, host.ui, t("Dispensa: couldn't load the Visualizer settings. Changes on this screen won't be saved.", "Dispensa: 비주얼라이저 설정을 불러오지 못했어요. 이번 화면에서는 변경 내용이 저장되지 않아요."), "visz");
  await load(memoStore, host.ui, t("Dispensa: couldn't load the Memo pad. Memos on this screen won't be saved.", "Dispensa: 메모장을 불러오지 못했어요. 이번 화면에서는 메모가 저장되지 않아요."), "memo");

  // ── running QRs ──
  const scope = new ChatScopeWatch();
  const runner = new QrRunner(host, registry, () => store.value, {
    onStart: (item) => dock.setRunning(item),
    onEnd: () => dock.setRunning(null),
    // a page a QR posted (or the reply it started) goes to the Gallery too, once
    onPosted: (item, text) => {
      if (!visz.keeps("chat", text) || collected.has(text)) return;
      collected.add(text);
      if (collected.size > 50) collected.delete(collected.values().next().value!);
      void visz.save({ title: item.label, kind: extractHtmlBlocks(text).length ? "viz" : "ooc", text }).catch((e) => marinara.log.warn("Gallery save failed", e));
    },
  });
  const collected = new Set<string>();
  const qrControl = createQrControl(store, () => runner, () => scope.current);
  host.qr = qrControl;
  const run = (set: QrSet, item: QrItem) => void runner.run(set, item);

  // ── visz and the memo pad ──
  let viewer: ViewerPanel | null = null;
  const viszHost = createViszHost(host, dialogs);
  const chooseMemos = (query?: string) => pickMemos(host.ui, memoStore, scope.current, undefined, query);
  // a new memo goes where the memo pad's setting says, in the chat on screen
  const memoOwner = () => ownerFor(memoStore.value.savePlace ?? "all", scope.current);
  viszHost.pickMemos = () => chooseMemos();
  // the Gallery: files on the server for every device, this browser's copy for speed and offline
  const archive = new SyncedArchive(createArchive(), galleryFiles, localSyncStore("dispensa-gallery-sync"));
  const visz = new ViszService(viszHost, () => viszStore.value, archive, () => viewer);
  const sendOoc = (text: string) => visz.run("ooc", text);
  // a memo's color, size and font tags are for the memo pad: what leaves it goes without them
  const memoOut = {
    sendOoc: (text: string) => sendOoc(textForAi(text)),
    putInInput: (text: string) => viszHost.putInInput(textForAi(text)),
    makePage: (text: string) => visz.run("viz", textForAi(text)),
  };
  const addMemos = (text: string) => {
    const memos = memosFrom(text, Date.now(), memoOwner());
    memoStore.update((m) => m.memos.push(...memos));
    return memos.length;
  };
  host.memo = { pick: chooseMemos, add: addMemos, list: (only) => (only ? memosOf(memoStore.value.memos, scope.current, only === "global" ? "all" : only) : visibleMemos(memoStore.value.memos, scope.current)).map((m) => textForAi(m.text)) };
  host.visz = { run: (text, options) => visz.runText(text, options) };

  // ── the Gallery and the memo boards ──
  const { galleryRun, runForGallery, openPage, sendToBoard } = galleryActions({ ui: host.ui, runner, visz, viszStore, store, memoStore, memoOwner, viewer: () => viewer });

  // ── the Dispensa window, and the bridge that opens it for other extensions ──
  const manager: QrManager = new QrManager({
    store,
    registry,
    ui: host.ui,
    gallery: { service: visz, store: viszStore, qrStore: store, viewer: () => viewer, runInGallery: (set, item) => galleryRun(set, item), sendToBoard: (entry) => sendToBoard(entry) },
    run,
    runInEditor: (set, item, options) => runner.runInEditor(set, item, options),
    memo: { store: memoStore, ...memoOut, runForGallery: (text, about) => void runForGallery(text, about), openPage, fonts: installedFonts, useFont: (family) => void useFont(family), images: { list: boardImages, upload: uploadBoardImage, remove: deleteBoardImage } },
    characterName: (id) => host.characterName(id),
    connections: () => host.marinara.connections(),
    promptPresets: () => host.marinara.promptPresets(),
    viszStore,
    dockGroups: () => [...dockGroups].map(([id, g]) => ({ id, name: g.name, icon: g.icon, count: g.items.length, ...(g.remove ? { remove: () => g.remove!() } : {}) })),
  });
  // other extensions' buttons for the Dock (Fornello's scripts): kept until the Dock is built
  const dockGroups = new Map<string, DockGroup>();
  let dockBuilt: Dock | null = null;
  const setDockGroup = (id: string, group: DockGroup | null) => {
    if (group) dockGroups.set(id, group);
    else dockGroups.delete(id);
    dockBuilt?.setGroups(dockGroups);
    manager.refresh();
  };
  const unpublish = publishBridge(host, registry, () => manager.open(), setDockGroup, () => store.value.dockVisible, (json, name, characterId) => manager.importQrs(json, name, characterId));
  // Dispensa's entry in the top-bar menu
  const removeMenu = addMenuSource({ id: "dispensa", name: "Dispensa", order: 10, items: () => [
      { icon: icon("square-sparkles").outerHTML, label: t("QR library", "QR 보관함"), run: () => manager.open("qr") },
      { icon: icon("layout-dashboard").outerHTML, label: t("Memo boards", "메모 보드"), run: () => manager.open("board") },
      { icon: icon("images").outerHTML, label: t("Gallery", "갤러리"), run: () => manager.open("gallery") },
    ] });
  const stopTopMenu = keepTopMenu();

  // ── the Dock, its menus and the viewer ──
  viewer = new ViewerPanel({ service: visz, store: viszStore, ui: host.ui, onChange: () => placement.schedule() });
  const viszPanel = new ViszPanel({
    store: viszStore,
    service: visz,
    qrStore: store,
    viewer: () => viewer,
    ui: host.ui,
    close: () => dock.closeMenus(),
    openSettings: () => {
      dock.closeMenus();
      manager.open("visz");
    },
    pickMemos: () => chooseMemos(),
    addMemo: (text) => memoStore.update((m) => m.memos.push(newMemo(text, Date.now(), memoOwner()))),
    run: (set, item) => run(set, item),
    runInGallery: (set, item) => galleryRun(set, item),
    sendToBoard: (entry) => sendToBoard(entry),
    openGallery: () => manager.open("gallery"),
  });
  const memoPanel = new MemoPanel({
    store: memoStore,
    ui: host.ui,
    sendOoc: memoOut.sendOoc,
    putInInput: memoOut.putInInput,
    close: () => dock.closeMenus(),
    openSettings: () => {
      dock.closeMenus();
      manager.open("memo");
    },
    scope: () => scope.current,
    openBoard: (id) => {
      dock.closeMenus();
      manager.openBoard(id);
    },
  });
  const capture = new MemoCapture((text) => {
    const n = addMemos(text);
    host.ui.toast(n > 1 ? t(`Added ${n} memos to the Memo pad.`, `메모 ${n}개를 메모장에 넣었어요.`) : t("Added to the Memo pad.", "메모장에 넣었어요."), "success", { title: "📝" });
  });
  const dock = new Dock({
    run,
    stop: () => runner.stop(),
    openManager: () => manager.open("qr"),
    edit: (set, item) => manager.openItem(set.id, item.id),
    visz: { panel: viszPanel },
    memo: { panel: memoPanel },
  });
  dockBuilt = dock;
  dock.setGroups(dockGroups);
  const toggle = new ComposerToggle(() => store.update((s) => (s.dockVisible = !s.dockVisible)));
  const viewChatPage = async (messageId: string, index: number) => {
    host.chat.markStale();
    const message = (await host.chat.messages()).find((m) => m.id === messageId);
    // same order as the html code blocks on screen
    const fenced = message ? extractHtmlBlocks(message.content).filter((b) => /^html?$/i.test(b.lang) && message.content.startsWith("```", b.start)) : [];
    const block = fenced[index];
    if (!block) {
      host.ui.toast(t("No HTML found in this message.", "이 메시지에서 HTML을 찾지 못했어요."), "warning", { title: "🌟" });
      return;
    }
    viewer?.show({ title: block.title || t("HTML in chat", "채팅 속 HTML"), kind: "viz", text: "```html\n" + block.code + "\n```" });
  };

  // ── keeping the screen in step with the data: each part redraws only for the slice it shows ──
  const syncVisz = () => dock.setVisz({ show: viszStore.value.settings.showButton, icon: viszStore.value.settings.dockIcon, busy: visz.busy });
  const syncMemo = () => dock.setMemo({ show: memoStore.value.showButton, icon: memoStore.value.dockIcon });
  const syncCapture = () => capture.setEnabled(memoStore.value.capture !== false);
  dock.setState(store.value);
  syncVisz();
  toggle.setArmed(store.value.dockVisible);
  syncMemo();
  syncCapture();
  memoPanel.render();
  const unsubscribers = [
    store.select(dockSlice, (s) => dock.setState(s)),
    store.select((s) => s.dockVisible, (s) => {
      toggle.setArmed(s.dockVisible);
      // Fornello moves its buttons between the Dock and the top-bar menu
      window.dispatchEvent(new Event(DISPENSA_DOCK));
    }),
    // the Visualizer set's QRs are the visz menu's items
    store.select((s) => builtinSet(s, "visz")?.items.map((i) => [i.id, i.label, i.icon, i.title]) ?? null, () => viszPanel.render()),
    viszStore.select((s) => [s.settings.showButton, s.settings.dockIcon], syncVisz),
    visz.onBusy(syncVisz),
    memoStore.select((s) => [s.showButton, s.dockIcon], syncMemo),
    memoStore.select((s) => s.capture !== false, syncCapture),
    memoStore.select((s) => s.memos, () => memoPanel.render()),
    // the screen language changed: everything open draws again
    onLangChange(() => {
      dock.render();
      toggle.setArmed(store.value.dockVisible);
      viszPanel.render();
      memoPanel.render();
      manager.refresh();
    }),
  ];

  const placement = keepDockPlaced({
    dock: dock.element,
    toggle,
    viewer: () => viewer,
    afterPlace: () => {
      theme.noticeComposer();
      addViewButtons((messageId, index) => void viewChatPage(messageId, index));
    },
  });

  const stopAutoRun = startAutoRun({
    state: () => store.value,
    scope,
    chat: host.chat,
    run: (set, item) => runner.run(set, item, { auto: true }),
    onScope: (now) => {
      manager.setScope(now);
      memoPanel.render();
    },
  });

  // back to this tab: take what another device or tab saved meanwhile
  const onVisible = () => {
    if (document.visibilityState === "visible") for (const s of [store, viszStore, memoStore]) void s.refresh().catch(() => undefined);
  };
  document.addEventListener("visibilitychange", onVisible);
  // save waiting changes when the page is left or hidden (phones)
  const flushStores = () => {
    for (const s of [store, viszStore, memoStore]) void s.flush().catch(() => undefined);
  };
  const onHidden = () => {
    if (document.visibilityState === "hidden") flushStores();
  };
  document.addEventListener("visibilitychange", onHidden);
  window.addEventListener("pagehide", flushStores);

  const cleanup = () => {
    document.removeEventListener("visibilitychange", onVisible);
    document.removeEventListener("visibilitychange", onHidden);
    window.removeEventListener("pagehide", flushStores);
    unpublish();
    stopTopMenu();
    removeMenu();
    placement.dispose();
    stopAutoRun();
    for (const off of unsubscribers) off();
    capture.dispose();
    viewer?.dispose();
    theme.stop();
    runner.stop();
    qrControl.dispose();
    manager.close();
    // last, so changes made while closing are saved too
    flushStores();
    dock.dispose();
    toggle.dispose();
    void host.flush().finally(() => host.dispose());
  };
  marinara.onCleanup(cleanup);
  marinara.log.info("Dispensa ready");
  return cleanup;
}
