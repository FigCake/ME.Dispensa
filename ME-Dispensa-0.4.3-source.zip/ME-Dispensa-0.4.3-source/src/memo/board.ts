// Memo boards: memos laid out like a cork board. A card points at a memo; one memo can be on several boards.
// Pictures live in Marinara's Global Gallery ("Dispensa" folder); a board keeps only their id and address.

import { arrangeFrame } from "./board-frame";
import { type BoardLook, DEFAULT_THEME, normalizeTheme } from "./board-themes";
import { textForAi } from "./markdown";
import type { Memo } from "./model";
import { newId } from "../util";

export interface BoardImage {
  id: string;
  url: string;
}

/** Column, row, and how many of each it spans in the section layout. */
export interface BoardCell {
  c: number;
  r: number;
  w: number;
  h: number;
}

export interface BoardCard {
  memoId: string;
  x: number;
  y: number;
  /** Width in board pixels; the height follows the memo. */
  w: number;
  /** Degrees, -30 … 30. */
  rotate?: number;
  color?: string;
  z: number;
  cell?: BoardCell;
}

export interface BoardMagnet {
  id: string;
  image: BoardImage;
  x: number;
  y: number;
  /** Width in board pixels (the picture keeps its shape). */
  size: number;
  rotate?: number;
  z: number;
  cell?: BoardCell;
  /**
   * In the section layout: a sticker on top of the sections instead of filling one. x and w are
   * shares of the sections' width, y counts section rows from the top, so it stays over the same
   * sections whatever the screen.
   */
  sticker?: BoardSticker;
  /** A picture of a Gallery page: a tap opens the page where this browser has it. */
  page?: { archiveId: string; title: string };
}

export interface BoardSticker {
  x: number;
  y: number;
  w: number;
}

export const STICKER_W = { min: 0.03, max: 1, default: 0.16 };

function stickerOf(raw: unknown): BoardSticker | undefined {
  const r = raw as Partial<BoardSticker> | null;
  if (!r || typeof r !== "object" || typeof r.x !== "number" || typeof r.y !== "number" || typeof r.w !== "number") return undefined;
  if (![r.x, r.y, r.w].every(Number.isFinite)) return undefined;
  const w = Math.round(Math.max(STICKER_W.min, Math.min(STICKER_W.max, r.w)) * 1000) / 1000;
  return { x: Math.round(Math.max(0, Math.min(1 - STICKER_W.min, r.x)) * 1000) / 1000, y: Math.round(Math.max(0, Math.min(400, r.y)) * 1000) / 1000, w };
}

export interface Board {
  id: string;
  name: string;
  createdAt: number;
  background?: { image?: BoardImage };
  theme?: BoardLook;
  /** "frame": the section layout (board-frame.ts); free placement otherwise. */
  layout?: "frame";
  cols?: number;
  headCell?: BoardCell;
  /** false: cards show no number. */
  numbers?: false;
  cards: BoardCard[];
  magnets: BoardMagnet[];
}

export const BOARD_W = 2400;
export const BOARD_H = 1600;
export const CARD_W = { min: 140, max: 640, default: 240 };
export const MAGNET_SIZE = { min: 24, max: 400, default: 72 };
export const MAX_ROTATE = 30;

const HEX = /^#[0-9a-f]{6}$/i;

function cellOf(raw: unknown): BoardCell | undefined {
  const r = raw as Partial<BoardCell> | null;
  if (!r || typeof r !== "object") return undefined;
  const n = (v: unknown, min: number, max: number) => (typeof v === "number" && Number.isFinite(v) ? Math.max(min, Math.min(max, Math.round(v))) : min);
  return { c: n(r.c, 0, 5), r: n(r.r, 0, 200), w: n(r.w, 1, 6), h: n(r.h, 1, 6) };
}
const num = (v: unknown, fallback: number) => (typeof v === "number" && Number.isFinite(v) ? v : fallback);
const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v));
const round = (v: number) => Math.round(v * 10) / 10;

export function newBoard(name: string, at = Date.now()): Board {
  return { id: newId("board"), name: name.trim() || "Board", createdAt: at, theme: { id: DEFAULT_THEME }, cards: [], magnets: [] };
}

function image(raw: unknown): BoardImage | undefined {
  const r = raw as Partial<BoardImage> | null;
  return r && typeof r.id === "string" && typeof r.url === "string" && r.url.startsWith("/api/") ? { id: r.id, url: r.url } : undefined;
}

/** Holds numbers in range and drops cards of memos that no longer exist. */
export function normalizeBoards(raw: unknown, memos: Memo[]): Board[] {
  if (!Array.isArray(raw)) return [];
  const ids = new Set(memos.map((m) => m.id));
  return raw
    .filter((b): b is Partial<Board> => !!b && typeof b === "object" && typeof (b as Board).id === "string")
    .map((b) => {
      const bgImage = image(b.background?.image);
      const oldColor = (b.background as { color?: unknown } | undefined)?.color;
      const bgColor = typeof oldColor === "string" && HEX.test(oldColor) ? oldColor : undefined;
      const cards = (Array.isArray(b.cards) ? b.cards : [])
        .filter((c) => c && typeof c.memoId === "string" && ids.has(c.memoId))
        .map((c) => ({
          memoId: c.memoId,
          x: round(clamp(num(c.x, 0), 0, BOARD_W - CARD_W.min)),
          y: round(clamp(num(c.y, 0), 0, BOARD_H - 40)),
          w: round(clamp(num(c.w, CARD_W.default), CARD_W.min, CARD_W.max)),
          z: num(c.z, 0),
          ...(cellOf(c.cell) ? { cell: cellOf(c.cell) } : {}),
          ...(num(c.rotate, 0) ? { rotate: round(clamp(num(c.rotate, 0), -MAX_ROTATE, MAX_ROTATE)) } : {}),
          ...(typeof c.color === "string" && HEX.test(c.color) ? { color: c.color } : {}),
        }));
      const magnets = (Array.isArray(b.magnets) ? b.magnets : []).flatMap((m) => {
        const img = m && image(m.image);
        if (!img) return [];
        return [
          {
            id: typeof m.id === "string" ? m.id : newId("magnet"),
            image: img,
            x: round(clamp(num(m.x, 0), 0, BOARD_W - MAGNET_SIZE.min)),
            y: round(clamp(num(m.y, 0), 0, BOARD_H - MAGNET_SIZE.min)),
            size: round(clamp(num(m.size, MAGNET_SIZE.default), MAGNET_SIZE.min, MAGNET_SIZE.max)),
            z: num(m.z, 0),
            ...(cellOf(m.cell) ? { cell: cellOf(m.cell) } : {}),
            ...(stickerOf(m.sticker) ? { sticker: stickerOf(m.sticker) } : {}),
            ...(num(m.rotate, 0) ? { rotate: round(clamp(num(m.rotate, 0), -MAX_ROTATE, MAX_ROTATE)) } : {}),
            ...(m.page && typeof m.page.archiveId === "string" && typeof m.page.title === "string" ? { page: { archiveId: m.page.archiveId, title: m.page.title.slice(0, 120) } } : {}),
          },
        ];
      });
      return {
        id: b.id!,
        name: typeof b.name === "string" && b.name.trim() ? b.name.trim().slice(0, 60) : "Board",
        createdAt: num(b.createdAt, 0),
        ...(bgImage ? { background: { image: bgImage } } : {}),
        // a board saved before themes kept its own background color: it becomes the theme's background chip
        theme: normalizeTheme(b.theme) ?? normalizeTheme({ id: DEFAULT_THEME, colors: bgColor ? { paper: bgColor } : {} })!,
        ...(b.layout === "frame" ? { layout: "frame" as const } : {}),
        ...(typeof b.cols === "number" ? { cols: Math.max(2, Math.min(6, Math.round(b.cols))) } : {}),
        ...(cellOf(b.headCell) ? { headCell: cellOf(b.headCell) } : {}),
        ...(b.numbers === false ? { numbers: false as const } : {}),
        cards,
        magnets,
      };
    });
}

export function topZ(board: Board): number {
  return Math.max(0, ...board.cards.map((c) => c.z), ...board.magnets.map((m) => m.z)) + 1;
}

/** Where something `w` wide goes without covering what is there: right of it, else below it. */
export function freeSpot(board: Board, w: number): { x: number; y: number } {
  const right = Math.max(0, ...board.cards.map((c) => c.x + c.w), ...board.magnets.map((m) => m.x + m.size));
  if (right + 40 + w <= BOARD_W) return { x: Math.max(60, right + 40), y: 60 };
  // a card's height isn't kept: about a card and a half
  const bottom = Math.max(0, ...board.cards.map((c) => c.y + 260), ...board.magnets.map((m) => m.y + m.size));
  return { x: 60, y: Math.min(bottom + 40, BOARD_H - 120) };
}

/** Puts memos not yet on the board in a loose cascade from `at`; returns how many went on. */
export function placeMemos(board: Board, memoIds: string[], at = { x: 40, y: 40 }): number {
  const fresh = memoIds.filter((id, i) => memoIds.indexOf(id) === i && !board.cards.some((c) => c.memoId === id));
  let z = topZ(board);
  fresh.forEach((memoId) => {
    // counted with the cards already there, so a second batch does not land on the first
    const n = board.cards.length;
    const col = n % 4;
    const row = Math.floor(n / 4) % 6;
    board.cards.push({
      memoId,
      x: clamp(at.x + col * (CARD_W.default + 24) + row * 12, 0, BOARD_W - CARD_W.default),
      y: clamp(at.y + row * 180 + col * 10, 0, BOARD_H - 160),
      w: CARD_W.default,
      rotate: [-2, 1.5, -1, 2.5][n % 4],
      z: z++,
    });
  });
  return fresh.length;
}

export function boardsWith(boards: Board[], memoId: string): Board[] {
  return boards.filter((b) => b.cards.some((c) => c.memoId === memoId));
}

function sentParts(board: Board, memos: Memo[]): { memoId: string; text: string }[] {
  const byId = new Map(memos.map((m) => [m.id, m]));
  const frame = board.layout === "frame";
  // from an arranged copy, so a card not placed yet reads where it is shown
  const cards = frame ? liveCards(board, memos).cards : board.cards;
  if (frame) arrangeFrame({ ...board, cards });
  return [...cards]
    .sort((a, b) => (frame ? a.cell!.r - b.cell!.r || a.cell!.c - b.cell!.c : a.y - b.y || a.x - b.x))
    .map((c) => ({ memoId: c.memoId, memo: byId.get(c.memoId) }))
    .filter((p): p is { memoId: string; memo: Memo } => !!p.memo)
    .map(({ memoId, memo: m }) => ({ memoId, text: textForAi([m.title?.trim() ? `## ${m.title.trim()}` : "", m.text].filter(Boolean).join("\n")).trim() }))
    .filter((p) => p.text);
}

/** A copy without cards whose memo is gone (they stay on the board for Undo until the next load). */
export function liveCards(board: Board, memos: Memo[]): Board {
  const ids = new Set(memos.map((m) => m.id));
  return { ...structuredClone(board), cards: board.cards.filter((c) => ids.has(c.memoId)).map((c) => structuredClone(c)) };
}

export function boardText(board: Board, memos: Memo[]): string {
  return sentParts(board, memos)
    .map((p) => p.text)
    .join("\n\n");
}

/** Each card's place in what is sent (a card with no text has none). */
export function cardNumbers(board: Board, memos: Memo[]): Map<string, number> {
  return new Map(sentParts(board, memos).map((p, i) => [p.memoId, i + 1]));
}

/** Held to ±MAX_ROTATE and snapped to 0 near it. */
export function rotationFrom(dx: number, dy: number): number {
  const deg = (Math.atan2(dx, -dy) * 180) / Math.PI;
  const held = clamp(deg, -MAX_ROTATE, MAX_ROTATE);
  return Math.abs(held) < 2 ? 0 : round(held);
}

export { clamp as clampTo };
