// The memo pad in Marinara's storage, so it follows you to other devices. Each memo and each board has
// a key of its own ("memo:m:<id>", "memo:b:<id>") and "memo" holds the rest with their order, so two
// devices changing different memos or boards never write over each other.

import { PersistedStore } from "../host/persisted-store";
import type { Board } from "./board";
import { type Memo, type MemoState, normalizeMemos } from "./model";

const MEMO = "memo:m:";
const BOARD = "memo:b:";

export function splitMemos(s: MemoState): Record<string, unknown> {
  const { memos, boards, ...rest } = s;
  const parts: Record<string, unknown> = { memo: { ...rest, order: memos.map((m) => m.id), boardOrder: (boards ?? []).map((b) => b.id) } };
  for (const m of memos) parts[MEMO + m.id] = m;
  for (const b of boards ?? []) parts[BOARD + b.id] = b;
  return parts;
}

/** In the saved order; ones not in it yet (made on another device meanwhile) go after, oldest first. */
function inOrder<T extends { id: string }>(items: T[], order: unknown, age: (x: T) => number): T[] {
  const ids = Array.isArray(order) ? order.filter((x): x is string => typeof x === "string") : [];
  const rank = new Map(ids.map((id, i) => [id, i]));
  return [...items].sort((a, b) => (rank.get(a.id) ?? Infinity) - (rank.get(b.id) ?? Infinity) || age(a) - age(b));
}

export function joinMemos(parts: Record<string, unknown>): unknown {
  const main = (parts.memo && typeof parts.memo === "object" ? parts.memo : {}) as Record<string, unknown>;
  const own = <T>(prefix: string) =>
    Object.entries(parts)
      .filter(([k, v]) => k.startsWith(prefix) && v && typeof v === "object")
      .map(([k, v]) => ({ ...(v as T), id: k.slice(prefix.length) }));
  const memos = own<Memo>(MEMO);
  const boards = own<Board>(BOARD);
  // saved before the split: the lists are in "memo" (a part saved since wins)
  const merge = <T extends { id: string }>(old: unknown, split: T[]) => [...(Array.isArray(old) ? (old as T[]).filter((x) => !split.some((y) => y.id === x?.id)) : []), ...split];
  return {
    ...main,
    memos: Array.isArray(main.memos) ? merge(main.memos, memos) : inOrder(memos, main.order, (m) => Number(m.createdAt) || 0),
    boards: Array.isArray(main.boards) ? merge(main.boards, boards) : inOrder(boards, main.boardOrder, () => 0),
  };
}

export class MemoStore extends PersistedStore<MemoState> {
  constructor() {
    super({ key: "memo", normalize: normalizeMemos, split: splitMemos, join: joinMemos, label: "memo" });
  }
}
