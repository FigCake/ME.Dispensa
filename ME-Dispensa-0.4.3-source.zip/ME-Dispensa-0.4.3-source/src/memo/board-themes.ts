// The looks a memo board can take. A theme names its color chips (CSS
// variables) with defaults; a board saves only the chips the user changed.

export type ThemeColor = "paper" | "pageInk" | "card" | "card2" | "ink" | "accent" | "accent2";

export interface BoardTheme {
  id: string;
  name: [en: string, ko: string];
  colors: { key: ThemeColor; label: [en: string, ko: string]; value: string }[];
  /** Grid size in board pixels for snapping (0: free, cards may tilt). */
  grid: number;
  /** The section layout's title block shows the board's number large (№01). */
  numbered?: boolean;
}

const chip = (key: ThemeColor, en: string, ko: string, value: string) => ({ key, label: [en, ko] as [string, string], value });
const PAPER = (v: string) => chip("paper", "Background", "바탕", v);
const PAGE_INK = (v: string) => chip("pageInk", "Title", "제목 글자", v);
const CARD = (v: string) => chip("card", "Card", "카드", v);
const CARD2 = (v: string) => chip("card2", "Second card", "보조 카드", v);
const INK = (v: string) => chip("ink", "Text", "글자", v);
const ACCENT = (v: string) => chip("accent", "Accent", "강조색", v);
const ACCENT2 = (v: string) => chip("accent2", "Second accent", "보조 강조색", v);

export const BOARD_THEMES: BoardTheme[] = [
  { id: "warm", name: ["Warm workspace", "웜 워크스페이스"], grid: 0, colors: [PAPER("#e9e5df"), CARD("#fffdfa"), INK("#2a2520"), ACCENT("#e8743b")] },
  { id: "bento", name: ["Bento", "벤토"], grid: 24, colors: [PAPER("#ecebe6"), CARD("#ffffff"), CARD2("#121212"), INK("#121212"), ACCENT("#d4ff3a")] },
  { id: "editorial", name: ["Editorial serif", "에디토리얼 세리프"], grid: 16, numbered: true, colors: [PAPER("#f4f0e8"), INK("#1a1714"), ACCENT("#e2401c")] },
  { id: "tech", name: ["Dark tech", "다크 테크"], grid: 16, colors: [PAPER("#09090b"), PAGE_INK("#e6e6ea"), CARD("#111114"), INK("#e6e6ea"), ACCENT("#5b8cff")] },
  { id: "spec", name: ["Guideline sheet", "가이드 시트"], grid: 16, numbered: true, colors: [PAPER("#f3f1ec"), INK("#141414"), ACCENT("#e8381f"), ACCENT2("#d9d5cc")] },
  { id: "duotone", name: ["Duotone", "듀오톤"], grid: 16, colors: [PAPER("#f6f4ef"), ACCENT("#2340ff"), PAGE_INK("#ffffff"), CARD("#ffffff"), INK("#0f1140")] },
  { id: "kinetic", name: ["Kinetic type", "키네틱 타이포"], grid: 16, numbered: true, colors: [PAPER("#0e0e0e"), PAGE_INK("#efe9dc"), CARD("#efe9dc"), INK("#0e0e0e"), ACCENT("#d7ff3d")] },
  { id: "archi", name: ["Architect grid", "건축 도면"], grid: 40, numbered: true, colors: [PAPER("#f2f2ef"), CARD("#fafaf8"), INK("#1d1d1b"), ACCENT("#ff5a1f")] },
  { id: "pop", name: ["Pop sticker", "팝 스티커"], grid: 0, colors: [PAPER("#fff8e7"), CARD("#ffffff"), INK("#111111"), ACCENT("#ff2e88"), ACCENT2("#ffe600")] },
  { id: "cottage", name: ["Cottage scrapbook", "코티지 스크랩북"], grid: 0, colors: [PAPER("#cdb38c"), CARD("#fbf6ea"), INK("#3d3227"), ACCENT("#b5646b"), ACCENT2("#8a9a6b")] },
  { id: "clean", name: ["Clean neutral", "클린 뉴트럴"], grid: 0, colors: [PAPER("#efe8de"), CARD("#f8f4ee"), CARD2("#e2d6c6"), INK("#3f3a34"), ACCENT("#b29a80")] },
  { id: "linen", name: ["Linen journal", "린넨 저널"], grid: 0, colors: [PAPER("#e6dfd3"), CARD("#faf7f1"), INK("#3b352d"), ACCENT("#9b7b5c")] },
];

export const DEFAULT_THEME = "warm";

const HEX = /^#[0-9a-f]{6}$/i;

export function themeById(id: string | undefined): BoardTheme {
  return BOARD_THEMES.find((t) => t.id === id) ?? BOARD_THEMES.find((t) => t.id === DEFAULT_THEME)!;
}

/** Every chip, in the theme panel's order. */
export const ALL_COLORS: { key: ThemeColor; label: [en: string, ko: string] }[] = [
  PAPER(""), PAGE_INK(""), CARD(""), CARD2(""), INK(""), ACCENT(""), ACCENT2(""),
].map(({ key, label }) => ({ key, label }));

/** A chip's default: the theme's own, or the color that part already has (so setting it changes only that part). */
export function chipDefault(theme: BoardTheme, key: ThemeColor): string {
  const own = (k: ThemeColor) => theme.colors.find((c) => c.key === k)?.value;
  const derived: Record<ThemeColor, () => string | undefined> = {
    paper: () => own("paper"),
    pageInk: () => own("ink"),
    card: () => own("paper"),
    card2: () => own("ink"),
    ink: () => own("ink"),
    accent: () => own("accent"),
    accent2: () => own("accent"),
  };
  return own(key) ?? derived[key]() ?? "#888888";
}

export const ownsChip = (theme: BoardTheme, key: ThemeColor) => theme.colors.some((c) => c.key === key);

export type CardShadow = "none" | "soft" | "strong";
export type SurfacePattern = "none" | "dots" | "grid" | "lines";
export const SHADOWS: CardShadow[] = ["none", "soft", "strong"];
export const PATTERNS: SurfacePattern[] = ["none", "dots", "grid", "lines"];
/** Fonts every device has a version of, named by their kind. */
export const FONT_KINDS = ["sans", "serif", "italic", "mono", "display"] as const;
export const MAX_CSS = 20000;

/** What a look changes besides colors. A font is a FONT_KINDS entry or a font family installed in Marinara. */
export interface ThemeStyle {
  titleFont?: string;
  cardFont?: string;
  radius?: number;
  shadow?: CardShadow;
  pattern?: SurfacePattern;
  tilt?: "straight" | "tilted";
  css?: string;
}

export interface BoardLook {
  id: string;
  colors?: Partial<Record<ThemeColor, string>>;
  style?: ThemeStyle;
}

const fontName = (v: unknown) => (typeof v === "string" && v.trim() && v.length <= 80 && !/[;{}<>"\\]/.test(v) ? v.trim() : undefined);

export function normalizeStyle(raw: unknown): ThemeStyle | undefined {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const out: ThemeStyle = {};
  const tf = fontName(r.titleFont);
  const cf = fontName(r.cardFont);
  if (tf) out.titleFont = tf;
  if (cf) out.cardFont = cf;
  if (typeof r.radius === "number" && Number.isFinite(r.radius)) out.radius = Math.round(Math.min(40, Math.max(0, r.radius)));
  if (SHADOWS.includes(r.shadow as CardShadow)) out.shadow = r.shadow as CardShadow;
  if (PATTERNS.includes(r.pattern as SurfacePattern)) out.pattern = r.pattern as SurfacePattern;
  if (r.tilt === "straight" || r.tilt === "tilted") out.tilt = r.tilt;
  if (typeof r.css === "string" && r.css.trim() && !cssProblem(r.css)) out.css = r.css.trim();
  return Object.keys(out).length ? out : undefined;
}

/** Keeps only a known theme and colors that differ from their defaults. */
export function normalizeTheme(raw: unknown): BoardLook | undefined {
  const r = raw as { id?: unknown; colors?: unknown; style?: unknown } | null;
  if (!r || typeof r.id !== "string" || !BOARD_THEMES.some((t) => t.id === r.id)) return undefined;
  const theme = themeById(r.id);
  const colors: Partial<Record<ThemeColor, string>> = {};
  const given = (r.colors && typeof r.colors === "object" ? r.colors : {}) as Record<string, unknown>;
  for (const { key } of ALL_COLORS) {
    const v = given[key];
    if (typeof v === "string" && HEX.test(v) && v.toLowerCase() !== chipDefault(theme, key).toLowerCase()) colors[key] = v.toLowerCase();
  }
  const style = normalizeStyle(r.style);
  return { id: theme.id, ...(Object.keys(colors).length ? { colors } : {}), ...(style ? { style } : {}) };
}

/** The chips to set: the theme's own plus the user's. Others stay unset so the theme's styles read as before. */
export function themeColors(saved: BoardLook | undefined): Record<string, string> {
  const theme = themeById(saved?.id);
  const out: Record<string, string> = Object.fromEntries(theme.colors.map((c) => [c.key, saved?.colors?.[c.key] ?? c.value]));
  for (const [key, value] of Object.entries(saved?.colors ?? {})) if (value) out[key] = value;
  return out;
}

export function allColors(saved: BoardLook | undefined): Record<ThemeColor, string> {
  const theme = themeById(saved?.id);
  return Object.fromEntries(ALL_COLORS.map(({ key }) => [key, saved?.colors?.[key] ?? chipDefault(theme, key)])) as Record<ThemeColor, string>;
}

/** The CSS with comments taken out and each string as "#n" (its text in `strings`); null when one is left open. */
function cssParts(css: string): { code: string; strings: string[] } | null {
  let code = "";
  const strings: string[] = [];
  for (let i = 0; i < css.length; ) {
    if (css.startsWith("/*", i)) {
      const end = css.indexOf("*/", i + 2);
      if (end < 0) return null;
      code += " ";
      i = end + 2;
    } else if (css[i] === '"' || css[i] === "'") {
      const end = css.indexOf(css[i], i + 1);
      if (end < 0 || css.slice(i + 1, end).includes("\n")) return null;
      code += `"#${strings.length}"`;
      strings.push(css.slice(i + 1, end));
      i = end + 1;
    } else code += css[i++];
  }
  return { code, strings };
}

/**
 * Why the user's CSS can't be used, or null. It is nested under the board and must stay there:
 * balanced braces, no "<", nothing that loads from the network or covers the page
 * (url() other than data: pictures, @import, fixed positions), no backslash escapes.
 * Comments and strings are read the way a browser reads them, so neither can hide anything.
 */
export function cssProblem(css: string): "too-long" | "unbalanced" | "not-allowed" | null {
  if (css.length > MAX_CSS) return "too-long";
  if (/[<\\]/.test(css)) return "not-allowed";
  const parts = cssParts(css);
  if (!parts) return "unbalanced";
  const { code, strings } = parts;
  if (/@(?!media\b|supports\b|container\b|keyframes\b|-webkit-keyframes\b)[\w-]+/i.test(code)) return "not-allowed";
  if (/image-set\s*\(|\bimage\s*\(|cross-fade\s*\(|expression\s*\(|javascript:|-moz-binding|behavior\s*:/i.test(code)) return "not-allowed";
  if (/position\s*:\s*(fixed|sticky)/i.test(code)) return "not-allowed";
  for (const m of code.matchAll(/\burl\s*\(([^)]*)(\)?)/gi)) {
    const arg = m[1].trim();
    const quoted = /^"#(\d+)"$/.exec(arg);
    const target = quoted ? strings[Number(quoted[1])] : arg;
    if (!m[2] || !/^data:image\//i.test(target.trim())) return "not-allowed";
  }
  let depth = 0;
  for (const c of code) {
    if (c === "{") depth++;
    else if (c === "}" && --depth < 0) return "unbalanced";
  }
  return depth === 0 ? null : "unbalanced";
}

export function snapTo(value: number, grid: number): number {
  return grid ? Math.round(value / grid) * grid : Math.round(value);
}

export function inkOn(hex: string): string {
  const n = parseInt(hex.slice(1), 16);
  const lum = (0.299 * ((n >> 16) & 255) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
  return lum > 0.55 ? "#2b2b2b" : "#f4f4f4";
}

// ── saved themes and theme files ──

export interface SavedTheme {
  id: string;
  name: string;
  /** The theme it is built on. */
  base: string;
  colors?: Partial<Record<ThemeColor, string>>;
  style?: ThemeStyle;
}

/** The `kind` of a `.board-theme.json` file. */
export const THEME_FILE_KIND = "dispensa.board-theme";

export interface ThemeFile {
  kind: typeof THEME_FILE_KIND;
  version: 1;
  name: string;
  base: string;
  colors: Partial<Record<ThemeColor, string>>;
  style?: ThemeStyle;
}

export const lookOf = (s: SavedTheme): BoardLook => ({ id: s.base, ...(s.colors ? { colors: { ...s.colors } } : {}), ...(s.style ? { style: { ...s.style } } : {}) });

export const savedOf = (id: string, name: string, look: BoardLook): SavedTheme => ({
  id, name: name.trim().slice(0, 60), base: look.id, ...(look.colors ? { colors: { ...look.colors } } : {}), ...(look.style ? { style: { ...look.style } } : {}),
});

export function normalizeSavedThemes(raw: unknown): SavedTheme[] {
  if (!Array.isArray(raw)) return [];
  const out: SavedTheme[] = [];
  for (const r of raw as { id?: unknown; name?: unknown; base?: unknown; colors?: unknown; style?: unknown }[]) {
    const look = normalizeTheme({ id: r?.base, colors: r?.colors, style: r?.style });
    if (!look || typeof r.id !== "string" || !r.id || out.some((x) => x.id === r.id)) continue;
    const name = typeof r.name === "string" && r.name.trim() ? r.name : themeById(look.id).name[0];
    out.push(savedOf(r.id, name, look));
  }
  return out;
}

/** Writes every chip out, so the file reads the same even if a theme's defaults change later. */
export function themeFile(name: string, look: BoardLook): ThemeFile {
  return { kind: THEME_FILE_KIND, version: 1, name, base: look.id, colors: { ...allColors(look) }, ...(look.style ? { style: { ...look.style } } : {}) };
}

export function readThemeFile(json: unknown): { name: string; look: BoardLook; droppedCss: boolean } | { error: "not-a-theme" | "unknown-theme" } {
  const r = json as Partial<ThemeFile> | null;
  if (!r || typeof r !== "object" || r.kind !== THEME_FILE_KIND) return { error: "not-a-theme" };
  const look = normalizeTheme({ id: r.base, colors: r.colors, style: r.style });
  if (!look) return { error: "unknown-theme" };
  const name = typeof r.name === "string" && r.name.trim() ? r.name.trim().slice(0, 60) : themeById(look.id).name[0];
  const css = (r.style as { css?: unknown } | undefined)?.css;
  return { name, look, droppedCss: typeof css === "string" && !!css.trim() && !look.style?.css };
}

export function sameLook(a: BoardLook | undefined, saved: SavedTheme): boolean {
  if (!a || a.id !== saved.base) return false;
  const x = allColors(a);
  const y = allColors(lookOf(saved));
  return (Object.keys(x) as ThemeColor[]).every((k) => x[k] === y[k]) && JSON.stringify(normalizeStyle(a.style) ?? {}) === JSON.stringify(normalizeStyle(saved.style) ?? {});
}
