// A memo's text: a small Markdown plus <u> and <span style> for looks only; text that
// leaves the memo pad goes without them (`textForAi`). Also the format buttons' editing steps.

/** Checked boxes are written with this mark: `- [✓] done`. `[x]` is read as checked too. */
export const CHECK_MARK = "✓";

export interface SpanStyle {
  color?: string;
  size?: string;
  font?: string;
}

export type Inline =
  | { kind: "text"; text: string }
  | { kind: "bold" | "italic" | "strike" | "underline"; children: Inline[] }
  | { kind: "code"; text: string }
  | { kind: "span"; style: SpanStyle; children: Inline[] };

export type Block =
  | { kind: "heading"; level: 1 | 2 | 3; content: Inline[] }
  | { kind: "paragraph"; lines: Inline[][] }
  | { kind: "list"; ordered: boolean; start: number; items: { indent: number; content: Inline[] }[] }
  | { kind: "checks"; items: { indent: number; checked: boolean; index: number; content: Inline[] }[] };

const HEADING = /^(#{1,3})\s+(.*)$/;
const CHECK = /^(\s*)[-*]\s+\[( |x|X|✓|✔)\](?:\s(.*))?$/;
const BULLET = /^(\s*)[-*]\s+(.*)$/;
const NUMBER = /^(\s*)(\d{1,9})[.)]\s+(.*)$/;
const indentOf = (spaces: string) => Math.min(6, Math.floor(spaces.replace(/\t/g, "  ").length / 2));

/** Checkbox `index` counts the boxes from the top (for `toggleCheck`). */
export function parseMemo(text: string): Block[] {
  const blocks: Block[] = [];
  let checks = 0;
  let gap = false;
  const last = (): Block | undefined => (gap ? undefined : blocks[blocks.length - 1]);
  for (const line of text.replace(/\r\n?/g, "\n").split("\n")) {
    let m: RegExpMatchArray | null;
    if (!line.trim()) {
      gap = true;
      continue;
    }
    if ((m = line.match(HEADING))) {
      blocks.push({ kind: "heading", level: m[1].length as 1 | 2 | 3, content: parseInline(m[2]) });
    } else if ((m = line.match(CHECK))) {
      const item = { indent: indentOf(m[1]), checked: m[2] !== " ", index: checks++, content: parseInline(m[3] ?? "") };
      const prev = last();
      if (prev?.kind === "checks") prev.items.push(item);
      else blocks.push({ kind: "checks", items: [item] });
    } else if ((m = line.match(NUMBER)) || (m = line.match(BULLET))) {
      const ordered = m.length === 4;
      const item = { indent: indentOf(m[1]), content: parseInline(ordered ? m[3] : m[2]) };
      const prev = last();
      if (prev?.kind === "list" && prev.ordered === ordered) prev.items.push(item);
      else blocks.push({ kind: "list", ordered, start: ordered ? Number(m[2]) : 1, items: [item] });
    } else {
      const prev = last();
      if (prev?.kind === "paragraph") prev.lines.push(parseInline(line));
      else blocks.push({ kind: "paragraph", lines: [parseInline(line)] });
    }
    gap = false;
  }
  return blocks;
}

// the style in double quotes may hold single-quoted font names, and the other way round
const STYLE_ATTR = `style\\s*=\\s*(?:"([^"<>]*)"|'([^'<>]*)')`;
const SPAN_OPEN = new RegExp(`^<span\\s+${STYLE_ATTR}\\s*>`, "i");
const PAIRS: [string, "bold" | "italic" | "strike"][] = [
  ["**", "bold"],
  ["~~", "strike"],
  ["*", "italic"],
  ["_", "italic"],
];

export function parseInline(text: string): Inline[] {
  const out: Inline[] = [];
  let plain = "";
  const flush = () => {
    if (plain) out.push({ kind: "text", text: plain });
    plain = "";
  };
  let i = 0;
  while (i < text.length) {
    const rest = text.slice(i);
    if (rest[0] === "`") {
      const end = text.indexOf("`", i + 1);
      if (end > i + 1) {
        flush();
        out.push({ kind: "code", text: text.slice(i + 1, end) });
        i = end + 1;
        continue;
      }
    }
    if (rest[0] === "<") {
      const tag = matchTag(text, i);
      if (tag) {
        flush();
        out.push(tag.node);
        i = tag.end;
        continue;
      }
    }
    const pair = PAIRS.find(([mark]) => rest.startsWith(mark));
    if (pair) {
      const [mark, kind] = pair;
      let end = text.indexOf(mark, i + mark.length);
      // `***` closing `**` and `*` together: the outer mark takes the last two
      while (end > 0 && text[end + mark.length] === mark[0]) end++;
      // `_` inside a word (snake_case) is not italic
      const wordy = mark === "_" && (/\w/.test(text[i - 1] ?? "") || /\w/.test(text[end + 1] ?? ""));
      if (end > i + mark.length && !/\s/.test(text[i + mark.length]) && !/\s/.test(text[end - 1]) && !wordy) {
        flush();
        out.push({ kind, children: parseInline(text.slice(i + mark.length, end)) });
        i = end + mark.length;
        continue;
      }
    }
    plain += text[i];
    i++;
  }
  flush();
  return out;
}

/** <u> or <span style> at `at`, its closing tag found past nested ones. */
function matchTag(text: string, at: number): { node: Inline; end: number } | null {
  const rest = text.slice(at);
  const u = /^<u>/i.exec(rest);
  const span = u ? null : SPAN_OPEN.exec(rest);
  if (!u && !span) return null;
  const name = u ? "u" : "span";
  const openLen = (u ?? span)![0].length;
  const tags = new RegExp(`<${name}(?:\\s[^<>]*)?>|</${name}>`, "gi");
  tags.lastIndex = at + openLen;
  let depth = 1;
  for (let m = tags.exec(text); m; m = tags.exec(text)) {
    depth += m[0][1] === "/" ? -1 : 1;
    if (depth) continue;
    const children = parseInline(text.slice(at + openLen, m.index));
    const end = m.index + m[0].length;
    if (u) return { node: { kind: "underline", children }, end };
    return { node: { kind: "span", style: parseStyle(span![1] ?? span![2]), children }, end };
  }
  return null;
}

const COLOR = /^(#[0-9a-f]{3,8}|[a-z]{3,20})$/i;
const SIZE = /^(\d{1,3}(?:\.\d{1,2})?)(em|rem|px|%)$/i;
const FONT = /^[\p{L}\p{N} _\-'",.]{1,100}$/u;

/** Only colors, sizes and font names are kept; a size is held to something readable. */
export function parseStyle(style: string): SpanStyle {
  const out: SpanStyle = {};
  for (const part of style.split(";")) {
    const at = part.indexOf(":");
    if (at < 0) continue;
    const key = part.slice(0, at).trim().toLowerCase();
    const value = part.slice(at + 1).trim();
    if (key === "color" && COLOR.test(value)) out.color = value;
    else if (key === "font-size") {
      const m = value.match(SIZE);
      if (!m) continue;
      const n = Number(m[1]);
      const unit = m[2].toLowerCase();
      const [min, max] = unit === "px" ? [8, 48] : unit === "%" ? [50, 300] : [0.5, 3];
      out.size = `${Math.min(max, Math.max(min, n))}${unit}`;
    } else if (key === "font-family" && FONT.test(value)) out.font = value;
  }
  return out;
}

/** Without the look-only tags: what goes to the AI and the chat. */
export function textForAi(text: string): string {
  return text.replace(new RegExp(`<span\\s+${STYLE_ATTR}\\s*>|</span>|</?u>`, "gi"), "");
}

/** The text as it reads, for one-line labels: no tags and no Markdown marks. */
export function plainText(text: string): string {
  return textForAi(text)
    .replace(/^[ \t]*(?:#{1,6}[ \t]+|[-*+][ \t]+\[[ xX✓]\][ \t]+|[-*+][ \t]+|\d+[.)][ \t]+|>[ \t]?)/gm, "")
    .replace(/(\*\*|__|~~|`)(.+?)\1/g, "$2")
    .replace(/(^|[^*\w])\*(?!\s)([^*\n]+?)\*(?!\w)/g, "$1$2");
}

export function toggleCheck(text: string, index: number): string {
  let n = 0;
  return text
    .split("\n")
    .map((line) => {
      const m = line.match(CHECK);
      if (!m || n++ !== index) return line;
      const at = line.indexOf("[") + 1;
      return line.slice(0, at) + (m[2] === " " ? CHECK_MARK : " ") + line.slice(at + 1);
    })
    .join("\n");
}

// ── the format buttons ──

/** A textarea's value and selection. */
export interface Edit {
  text: string;
  start: number;
  end: number;
}

/** Puts `open`/`close` around the selection, or takes them off when already there. */
export function wrap(e: Edit, open: string, close: string): Edit {
  const { text, start, end } = e;
  const inner = text.slice(start, end);
  if (text.slice(start - open.length, start) === open && text.slice(end, end + close.length) === close) {
    return { text: text.slice(0, start - open.length) + inner + text.slice(end + close.length), start: start - open.length, end: end - open.length };
  }
  if (inner.startsWith(open) && inner.endsWith(close) && inner.length >= open.length + close.length) {
    const bare = inner.slice(open.length, inner.length - close.length);
    return { text: text.slice(0, start) + bare + text.slice(end), start, end: start + bare.length };
  }
  return { text: text.slice(0, start) + open + inner + close + text.slice(end), start: start + open.length, end: end + open.length };
}

const SPAN_AROUND = new RegExp(`<span\\s+${STYLE_ATTR}\\s*>$`, "i");

/** Changes the span the selection is already in, or adds one. */
export function styleSelection(e: Edit, prop: "color" | "font-size" | "font-family", value: string): Edit {
  const before = e.text.slice(0, e.start);
  const m = before.match(SPAN_AROUND);
  if (m && e.text.startsWith("</span>", e.end)) {
    const parts = (m[1] ?? m[2])
      .split(";")
      .map((p) => p.trim())
      .filter((p) => p && p.split(":")[0].trim().toLowerCase() !== prop);
    if (value) parts.push(`${prop}: ${value}`);
    const openStart = e.start - m[0].length;
    if (!parts.length) {
      const inner = e.text.slice(e.start, e.end);
      return { text: e.text.slice(0, openStart) + inner + e.text.slice(e.end + "</span>".length), start: openStart, end: openStart + inner.length };
    }
    const open = `<span style="${parts.join("; ")}">`;
    const shift = open.length - m[0].length;
    return { text: e.text.slice(0, openStart) + open + e.text.slice(e.start), start: e.start + shift, end: e.end + shift };
  }
  if (!value) return e;
  return wrap(e, `<span style="${prop}: ${value}">`, "</span>");
}

export type LineKind = "h1" | "h2" | "h3" | "bullet" | "number" | "check";

const MARKER = /^(\s*)(#{1,3}\s+|[-*]\s+\[(?: |x|X|✓|✔)\]\s?|[-*]\s+|\d{1,9}[.)]\s+)?/;
const markerKind = (marker: string): LineKind | null => {
  const m = marker.trim();
  if (!m) return null;
  if (m.startsWith("#")) return `h${m.length}` as LineKind;
  if (/\[/.test(m)) return "check";
  if (/^\d/.test(m)) return "number";
  return "bullet";
};

/** Makes every selected line `kind`, or plain again when all already are. */
export function setLines(e: Edit, kind: LineKind): Edit {
  const from = e.text.lastIndexOf("\n", e.start - 1) + 1;
  const toBreak = e.text.indexOf("\n", e.end);
  const to = toBreak < 0 ? e.text.length : toBreak;
  const lines = e.text.slice(from, to).split("\n");
  const parsed = lines.map((line) => {
    const m = line.match(MARKER)!;
    return { indent: m[1], kind: markerKind(m[2] ?? ""), body: line.slice(m[0].length) };
  });
  const off = parsed.every((p) => p.kind === kind);
  let n = 0;
  const marker = (indent: string) => {
    if (off) return indent;
    if (kind === "number") return `${indent}${++n}. `;
    if (kind === "bullet") return `${indent}- `;
    if (kind === "check") return `${indent}- [ ] `;
    return `${"#".repeat(Number(kind[1]))} `;
  };
  const block = parsed.map((p) => marker(p.indent) + p.body).join("\n");
  const text = e.text.slice(0, from) + block + e.text.slice(to);
  // a caret goes to the end of its line; a selection keeps the lines selected
  return e.start === e.end ? { text, start: from + block.length, end: from + block.length } : { text, start: from, end: from + block.length };
}

/** Enter on a list line: the next line gets the next marker; on an empty item the list ends. Null off a list. */
export function continueList(e: Edit): Edit | null {
  if (e.start !== e.end) return null;
  const from = e.text.lastIndexOf("\n", e.start - 1) + 1;
  const line = e.text.slice(from, e.start);
  let m: RegExpMatchArray | null;
  let next: string;
  let body: string;
  if ((m = line.match(CHECK))) {
    next = `${m[1]}- [ ] `;
    body = m[3] ?? "";
  } else if ((m = line.match(NUMBER))) {
    next = `${m[1]}${Number(m[2]) + 1}. `;
    body = m[3];
  } else if ((m = line.match(BULLET))) {
    next = `${m[1]}- `;
    body = m[2];
  } else return null;
  if (!body.trim()) {
    const text = e.text.slice(0, from) + e.text.slice(e.start);
    return { text, start: from, end: from };
  }
  const text = e.text.slice(0, e.start) + "\n" + next + e.text.slice(e.start);
  const at = e.start + 1 + next.length;
  return { text, start: at, end: at };
}
