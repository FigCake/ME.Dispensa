// The memo pad: text kept for later (OOC notes, ideas). Not QRs: no scripts, no sets.

import { extractOocNotes } from "../qr/import";
import { type Board, normalizeBoards } from "./board";
import { type SavedTheme, normalizeSavedThemes } from "./board-themes";
import { plainText } from "./markdown";
import type { ChatScope } from "../qr/scopes";
import { newId, oneLine } from "../util";

/** Where a memo shows: one chat, or the chats these characters are in. No owner: every chat. */
export type MemoOwner = { chatId: string } | { characterIds: string[] };

export type MemoPlace = "all" | "character" | "chat";

export const MEMO_PLACES: MemoPlace[] = ["all", "character", "chat"];

export interface Memo {
  id: string;
  /** Shown in lists instead of the text, when set. */
  title?: string;
  text: string;
  /** Pinned: always listed in the 📝 bubble. */
  pinned?: boolean;
  createdAt: number;
  owner?: MemoOwner;
  /** The folder it is in (the notebook view of the 📋 tab); none: only under "All memos". */
  folder?: string;
}

/** A folder of the notebook view. A memo is in one folder at most; boards are apart from folders. */
export interface MemoFolder {
  id: string;
  name: string;
}

export interface MemoState {
  version: 1;
  memos: Memo[];
  showButton: boolean;
  dockIcon: string;
  /** The "Memo" button under selected chat text (on unless turned off). */
  capture?: boolean;
  /** Where a new memo goes unless chosen (every chat unless set). */
  savePlace?: MemoPlace;
  boards?: Board[];
  /** Board looks the user saved or loaded from a file. */
  themes?: SavedTheme[];
  /** The notebook view's folders, in order. */
  folders?: MemoFolder[];
}

export const emptyMemos = (): MemoState => ({ version: 1, memos: [], showButton: true, dockIcon: "📝" });

export function newMemo(text: string, at = Date.now(), owner?: MemoOwner): Memo {
  return { id: newId("memo"), text: text.trim(), createdAt: at, ...(owner ? { owner } : {}) };
}

export function normalizeOwner(raw: unknown): MemoOwner | undefined {
  if (!raw || typeof raw !== "object") return undefined;
  const r = raw as { chatId?: unknown; characterIds?: unknown };
  if (typeof r.chatId === "string" && r.chatId) return { chatId: r.chatId };
  if (Array.isArray(r.characterIds)) {
    const ids = [...new Set(r.characterIds.filter((x): x is string => typeof x === "string" && !!x))].sort();
    if (ids.length) return { characterIds: ids };
  }
  return undefined;
}

const isPlace = (v: unknown): v is MemoPlace => MEMO_PLACES.includes(v as MemoPlace);

export function normalizeMemos(raw: unknown): MemoState {
  const base = emptyMemos();
  if (!raw || typeof raw !== "object") return base;
  const r = raw as Partial<MemoState>;
  const icon = r.dockIcon;
  const folders = normalizeFolders(r.folders);
  const folderIds = new Set(folders.map((f) => f.id));
  const memos: Memo[] = Array.isArray(r.memos)
    ? r.memos
        .filter((m) => m && typeof m.text === "string")
        .map((m) => {
          const owner = normalizeOwner(m.owner);
          return {
            id: typeof m.id === "string" ? m.id : newId("memo"),
            ...(typeof m.title === "string" && m.title.trim() ? { title: m.title.trim() } : {}),
            text: m.text,
            createdAt: Number(m.createdAt) || 0,
            ...(m.pinned ? { pinned: true } : {}),
            ...(owner ? { owner } : {}),
            // a folder deleted (on another device too) leaves its memos in no folder
            ...(typeof m.folder === "string" && folderIds.has(m.folder) ? { folder: m.folder } : {}),
          };
        })
    : [];
  const boards = normalizeBoards(r.boards, memos);
  const themes = normalizeSavedThemes(r.themes);
  return {
    version: 1,
    memos,
    showButton: r.showButton !== false,
    dockIcon: typeof icon === "string" && icon.trim() ? icon.trim() : base.dockIcon,
    ...(r.capture === false ? { capture: false } : {}),
    ...(isPlace(r.savePlace) && r.savePlace !== "all" ? { savePlace: r.savePlace } : {}),
    ...(boards.length ? { boards } : {}),
    ...(themes.length ? { themes } : {}),
    ...(folders.length ? { folders } : {}),
  };
}

function normalizeFolders(raw: unknown): MemoFolder[] {
  if (!Array.isArray(raw)) return [];
  const out: MemoFolder[] = [];
  for (const f of raw as Partial<MemoFolder>[]) {
    if (!f || typeof f.id !== "string" || !f.id || out.some((x) => x.id === f.id)) continue;
    out.push({ id: f.id, name: (typeof f.name === "string" && f.name.trim() ? f.name.trim() : "Folder").slice(0, 40) });
  }
  return out;
}

export function newFolder(name: string): MemoFolder {
  return { id: newId("folder"), name: name.trim().slice(0, 40) || "Folder" };
}

/** The memos in a folder ("all": every memo). */
export const memosInFolder = (memos: Memo[], folder: string | "all") => (folder === "all" ? memos : memos.filter((m) => m.folder === folder));

export function placeOf(owner: MemoOwner | undefined): MemoPlace {
  return !owner ? "all" : "chatId" in owner ? "chat" : "character";
}

/** "chat" and "character" fall back to every chat when no chat is open. */
export function placeHere(place: MemoPlace, scope: ChatScope): MemoPlace {
  if (place === "chat") return scope.chatId ? "chat" : "all";
  if (place === "character") return scope.characterIds.length ? "character" : "all";
  return "all";
}

/** A group chat's "character" is everyone in it. */
export function ownerFor(place: MemoPlace, scope: ChatScope): MemoOwner | undefined {
  const here = placeHere(place, scope);
  if (here === "chat") return { chatId: scope.chatId as string };
  if (here === "character") return { characterIds: [...new Set(scope.characterIds)].sort() };
  return undefined;
}

/** Every-chat memos, this chat's, and those whose characters are all in it. */
export function isVisible(m: Memo, scope: ChatScope): boolean {
  const o = m.owner;
  if (!o) return true;
  if ("chatId" in o) return o.chatId === scope.chatId;
  return o.characterIds.every((id) => scope.characterIds.includes(id));
}

export function visibleMemos(memos: Memo[], scope: ChatScope): Memo[] {
  return memos.filter((m) => isVisible(m, scope));
}

export function memosOf(memos: Memo[], scope: ChatScope, place: MemoPlace): Memo[] {
  return visibleMemos(memos, scope).filter((m) => placeOf(m.owner) === place);
}

export const RECENT_IN_DOCK = 4;

/** The 📝 bubble's lists, newest first: the latest unpinned memos, then every pinned one. */
export function dockMemos(memos: Memo[], scope: ChatScope, recent = RECENT_IN_DOCK): { recent: Memo[]; pinned: Memo[] } {
  const here = visibleMemos(memos, scope).sort((a, b) => b.createdAt - a.createdAt);
  return { recent: here.filter((m) => !m.pinned).slice(0, recent), pinned: here.filter((m) => m.pinned) };
}

/** OOC wrappers come off; several wrapped notes become several memos. */
export function memosFrom(text: string, at = Date.now(), owner?: MemoOwner): Memo[] {
  return extractOocNotes(text)
    .map((t) => t.trim())
    .filter(Boolean)
    .map((t, i) => newMemo(t, at + i, owner && structuredClone(owner)));
}

export function memoLabel(m: Memo, max?: number): string {
  return m.title?.trim() || oneLine(plainText(m.text), max);
}

const fold = (s: string) => s.normalize("NFC").toLowerCase();

/** Pinned first, then newest; `query` keeps those with every word in them. */
export function shownMemos(memos: Memo[], query = ""): Memo[] {
  const words = fold(query).split(/\s+/).filter(Boolean);
  return memos
    .filter((m) => words.every((w) => fold(`${m.title ?? ""} ${m.text}`).includes(w)))
    .sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned) || b.createdAt - a.createdAt);
}

