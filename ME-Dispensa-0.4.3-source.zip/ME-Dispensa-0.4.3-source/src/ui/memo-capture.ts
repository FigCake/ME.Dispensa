// A "Memo" button for text selected in a chat message or the input. Beside Marinara's
// "Add to lorebook" button it takes that button's look, so the two read as one row.

import { findComposer } from "../shared/composer";
import { icon } from "./dom";
import { t } from "../shared/i18n";

/** For when Marinara's button is not there (a selection in the input box). */
const OWN_LOOK = [
  "position:fixed",
  "z-index:9998",
  "transform:translateX(-50%)",
  "display:inline-flex",
  "align-items:center",
  "gap:6px",
  "min-height:36px",
  "padding:0 12px",
  "border-radius:9999px",
  "border:1px solid var(--marinara-chat-chrome-panel-border, var(--border, rgb(255 255 255 / .12)))",
  "background:var(--marinara-chat-chrome-panel-bg, var(--popover, #1d1d22))",
  "color:var(--marinara-chat-chrome-panel-text, var(--popover-foreground, var(--foreground, #e8e8ea)))",
  "box-shadow:0 25px 50px -12px rgb(0 0 0 / .4)",
  "backdrop-filter:blur(12px)",
  "font:500 12px/1 var(--font-sans, inherit)",
  "cursor:pointer",
].join(";");

export class MemoCapture {
  private readonly button: HTMLButtonElement;
  private readonly caption = document.createTextNode("");
  private text = "";
  private timer: ReturnType<typeof setTimeout> | null = null;
  private enabled = true;

  constructor(private readonly save: (text: string) => void) {
    this.button = document.createElement("button");
    this.button.type = "button";
    this.button.id = "dispensa-memo-capture";
    const glyph = icon("notebook-pen");
    glyph.setAttribute("width", "13");
    glyph.setAttribute("height", "13");
    glyph.style.flex = "none";
    this.button.append(glyph, this.caption);
    this.button.hidden = true;
    // keep the selection while pressing
    this.button.addEventListener("pointerdown", (e) => e.preventDefault());
    this.button.addEventListener("mousedown", (e) => e.preventDefault());
    this.button.addEventListener("click", () => {
      const text = this.text;
      this.hide();
      // let the selection go so the button does not come back
      const ta = findComposer()?.textarea;
      if (ta && document.activeElement === ta) ta.setSelectionRange(ta.selectionEnd, ta.selectionEnd);
      else window.getSelection()?.removeAllRanges();
      if (text) this.save(text);
    });
    document.body.append(this.button);
    document.addEventListener("selectionchange", this.schedule);
    // a selection inside the chat input does not always reach the document's selectionchange
    for (const type of ["mouseup", "keyup", "touchend", "select"]) document.addEventListener(type, this.schedule, true);
    document.addEventListener("keydown", this.onKey, true);
    window.addEventListener("scroll", this.onScroll, true);
    window.addEventListener("resize", this.hideNow);
  }

  setEnabled(on: boolean): void {
    this.enabled = on;
    if (!on) this.hide();
  }

  dispose(): void {
    document.removeEventListener("selectionchange", this.schedule);
    for (const type of ["mouseup", "keyup", "touchend", "select"]) document.removeEventListener(type, this.schedule, true);
    document.removeEventListener("keydown", this.onKey, true);
    window.removeEventListener("scroll", this.onScroll, true);
    window.removeEventListener("resize", this.hideNow);
    if (this.timer) clearTimeout(this.timer);
    this.button.remove();
  }

  private readonly schedule = (e?: Event) => {
    if (e && e.composedPath?.().includes(this.button)) return;
    if (this.timer) clearTimeout(this.timer);
    // wait for the selection to settle (dragging, the phone's handles) and for Marinara's button
    this.timer = setTimeout(() => this.update(), 200);
  };

  private readonly onKey = (e: KeyboardEvent) => {
    if (e.key === "Escape" && !this.button.hidden) this.hide();
  };

  private readonly onScroll = () => {
    if (!this.button.hidden) this.schedule();
  };

  private readonly hideNow = () => this.hide();

  private hide(): void {
    this.button.hidden = true;
    this.button.style.display = "none";
    this.text = "";
  }

  private update(): void {
    if (!this.enabled) return;
    const picked = this.picked();
    if (!picked || picked.text.length < 2) {
      this.hide();
      return;
    }
    this.text = picked.text;
    const b = this.button;
    // set on each showing, to follow the screen language
    b.title = t("Add the selected text to the Memo pad", "고른 글을 메모장에 넣기");
    this.caption.data = t("Memo", "메모하기");
    const theirs = document.querySelector<HTMLElement>("[data-selection-lorebook-button]");
    const box = theirs?.getBoundingClientRect();
    if (theirs && box?.width) {
      // Marinara's button is centered on its left with a -50% shift
      b.className = theirs.className;
      b.setAttribute("style", "");
      b.hidden = false;
      const w = b.offsetWidth;
      const gap = 6;
      // its style left/top, not its box: it slides in, so the box may still be moving
      const theirCenter = parseFloat(theirs.style.left) || box.left + box.width / 2;
      const top = parseFloat(theirs.style.top) || box.top;
      let center = theirCenter + box.width / 2 + gap + w / 2;
      if (center + w / 2 > window.innerWidth - 8) center = theirCenter - box.width / 2 - gap - w / 2;
      b.style.left = `${Math.max(8 + w / 2, center)}px`;
      b.style.top = `${top}px`;
      return;
    }
    b.className = "";
    b.setAttribute("style", OWN_LOOK);
    b.hidden = false;
    const w = b.offsetWidth || 90;
    const h = b.offsetHeight || 36;
    const center = Math.min(Math.max(8 + w / 2, picked.rect.left + picked.rect.width / 2), window.innerWidth - 8 - w / 2);
    // under the selection: the phone's own copy menu sits above it
    let y = picked.rect.bottom + 8;
    if (y + h > window.innerHeight - 8) y = Math.max(8, picked.rect.top - h - 8);
    b.style.left = `${center}px`;
    b.style.top = `${y}px`;
  }

  private picked(): { text: string; rect: DOMRect } | null {
    const ta = findComposer()?.textarea;
    if (ta && document.activeElement === ta && ta.selectionStart !== ta.selectionEnd) {
      const r = ta.getBoundingClientRect();
      return { text: ta.value.slice(ta.selectionStart, ta.selectionEnd).trim(), rect: new DOMRect(r.left, r.top - 52, r.width, 0) };
    }
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
    const inMessage = (n: Node | null) => !!(n instanceof Element ? n : n?.parentElement)?.closest("[data-message-id]");
    if (!inMessage(sel.anchorNode) && !inMessage(sel.focusNode)) return null;
    const rect = sel.getRangeAt(0).getBoundingClientRect();
    if (!rect.width && !rect.height) return null;
    return { text: sel.toString().trim(), rect };
  }
}
