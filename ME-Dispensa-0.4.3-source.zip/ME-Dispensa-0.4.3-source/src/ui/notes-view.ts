// The 📋 tab as a notebook instead of boards: folders on the left, a folder's memos, and a memo
// opened to read or write. On a phone one of the three shows at a time.
// Folders are the notebook's own (MemoState.folders); a memo is in one at most.

import { type Memo, type MemoState, memoLabel, memosInFolder, newFolder, newMemo, ownerFor, shownMemos } from "../memo/model";
import { plainText, toggleCheck } from "../memo/markdown";
import { confirmIn } from "./dialogs";
import { el, icon } from "./dom";
import { dropMenu } from "./menu";
import { memoEditor } from "./memo-editor";
import { renderMemo } from "./memo-render";
import type { BoardViewDeps } from "./board-context";
import { t } from "../shared/i18n";
import { oneLine } from "../util";

export const NOTES_VIEW_CSS = `
.notes { flex: 1; min-height: 0; display: grid; grid-template-columns: 210px minmax(0, 1fr); gap: 8px; }
.notes > section { min-height: 0; overflow: auto; display: flex; flex-direction: column; gap: 6px; padding: 8px;
  border: 1px solid var(--d-line); border-radius: var(--d-radius); background: var(--d-panel-solid); }
.notes .n-head { display: flex; align-items: center; gap: 6px; }
.notes .n-head strong { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 15px; }
.notes .n-head > button, .notes .n-head > .menu > summary { width: auto; flex: none; padding: 4px 8px; }
.notes .n-head select { width: auto; max-width: 11em; padding: 3px 6px; }
.notes .folder { display: flex; align-items: center; gap: 4px; }
.notes .folder > button.entry { flex: 1; min-width: 0; justify-content: flex-start; gap: 8px; border-color: transparent; background: none; text-align: left; }
.notes .folder > button.entry.sel { background: var(--d-hl-bg); border-color: var(--d-line); font-weight: 600; }
.notes .folder .name { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.notes .folder .count { color: var(--d-muted); font-size: 12px; font-weight: 400; }
.notes .note-row { display: flex; flex-direction: column; align-items: stretch; gap: 2px; text-align: left; padding: 8px 10px; white-space: normal; }
.notes .note-row .top { display: flex; gap: 6px; align-items: baseline; }
.notes .note-row .title { flex: 1; min-width: 0; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.notes .note-row .date { color: var(--d-muted); font-size: 11.5px; flex: none; }
.notes .note-row .preview { color: var(--d-muted); font-size: 12.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.notes .note-row .where { color: var(--d-muted); font-size: 11.5px; }
.notes .empty-note { color: var(--d-muted); text-align: center; margin: 24px auto; }
.notes .memo-body { cursor: text; min-height: 120px; }
.notes .memo-body .empty { color: var(--d-muted); }
.notes .n-title { font-size: 16px; font-weight: 600; }
@media (max-width: 600px) {
  .notes { grid-template-columns: minmax(0, 1fr); }
  .notes[data-level="list"] .n-folders, .notes[data-level="memo"] .n-folders { display: none; }
  .notes[data-level="folders"] .n-main { display: none; }
}
@media (min-width: 601px) { .notes .phone-only { display: none; } }
`;

const two = (n: number) => String(n).padStart(2, "0");
const dateOf = (at: number) => {
  // memos kept before dates were saved have none
  if (!at) return "";
  const d = new Date(at);
  return d.toDateString() === new Date().toDateString() ? `${two(d.getHours())}:${two(d.getMinutes())}` : `${two(d.getMonth() + 1)}.${two(d.getDate())}`;
};

export class NotesView {
  /** "all" or a folder id. */
  private folder = "all";
  private open: string | null = null;
  private writing = false;
  private query = "";
  /** On a phone: what shows (the folders, a folder's memos, or a memo). */
  private level: "folders" | "list" | "memo" = "list";

  constructor(private readonly deps: BoardViewDeps) {}

  private get state(): MemoState {
    return this.deps.store.value;
  }

  private update(fn: (s: MemoState) => void): void {
    this.deps.store.update(fn);
  }

  private mutate(id: string, fn: (m: Memo) => void): void {
    this.update((s) => {
      const m = s.memos.find((x) => x.id === id);
      if (m) fn(m);
    });
  }

  render(): HTMLElement {
    const folders = this.state.folders ?? [];
    if (this.folder !== "all" && !folders.some((f) => f.id === this.folder)) this.folder = "all";
    const memo = this.open ? this.state.memos.find((m) => m.id === this.open) : undefined;
    if (this.open && !memo) this.open = null;
    const level = memo ? "memo" : this.level === "memo" ? "list" : this.level;
    const folderPane = this.folderPane();
    const main = memo ? this.memoPane(memo) : this.listPane();
    this.keepScroll(folderPane, "folders");
    this.keepScroll(main, memo ? `memo:${memo.id}` : `list:${this.folder}`);
    return el("div", { class: "notes", "data-level": level }, folderPane, main);
  }

  /** Panes are drawn anew on each redraw: each keeps its scroll (per folder, per memo). */
  private readonly scrolls = new Map<string, number>();
  private keepScroll(pane: HTMLElement, key: string): void {
    const top = this.scrolls.get(key);
    if (top) requestAnimationFrame(() => pane.isConnected && (pane.scrollTop = top));
    pane.addEventListener("scroll", () => this.scrolls.set(key, pane.scrollTop), { passive: true });
  }

  private folderPane(): HTMLElement {
    const memos = this.state.memos;
    const row = (id: string, label: string, glyph: Element, count: number) =>
      el(
        "div",
        { class: "folder" },
        el(
          "button",
          {
            class: `entry${this.folder === id ? " sel" : ""}`,
            "aria-pressed": String(this.folder === id),
            onclick: () => {
              this.folder = id;
              this.open = null;
              this.query = "";
              this.level = "list";
              this.deps.rerender();
            },
          },
          glyph,
          el("span", { class: "name" }, label),
          el("span", { class: "count" }, String(count)),
        ),
      );
    const list = [row("all", t("All memos", "모든 메모"), icon("notebook-pen"), memos.length)];
    for (const f of this.state.folders ?? []) list.push(row(f.id, f.name, icon("folder"), memosInFolder(memos, f.id).length));
    return el(
      "section",
      { class: "n-folders", "aria-label": t("Folders", "폴더") },
      el("div", { class: "n-head" }, el("strong", {}, t("Folders", "폴더"))),
      ...list,
      el("button", { class: "ghost", onclick: () => void this.makeFolder() }, icon("folder-plus"), t("New folder", "새 폴더")),
    );
  }

  private folderName(id: string | undefined): string | undefined {
    return id ? this.state.folders?.find((f) => f.id === id)?.name : undefined;
  }

  private listPane(): HTMLElement {
    const all = memosInFolder(this.state.memos, this.folder);
    const shown = shownMemos(all, this.query);
    const name = this.folder === "all" ? t("All memos", "모든 메모") : (this.folderName(this.folder) ?? "");
    const rows = shown.map((m) => {
      const text = oneLine(plainText(m.text), 90);
      const where = this.folder === "all" ? this.folderName(m.folder) : undefined;
      return el(
        "button",
        {
          class: "note-row",
          "data-memo": m.id,
          onclick: () => {
            this.open = m.id;
            this.writing = !m.text.trim();
            this.level = "memo";
            this.deps.rerender();
          },
        },
        el("span", { class: "top" }, m.pinned ? el("span", {}, "📌") : null, el("span", { class: "title" }, memoLabel(m, 60) || t("(empty memo)", "(빈 메모)")), el("span", { class: "date" }, dateOf(m.createdAt))),
        m.title?.trim() && text ? el("span", { class: "preview" }, text) : null,
        where ? el("span", { class: "where" }, `📁 ${where}`) : null,
      );
    });
    return el(
      "section",
      { class: "n-main", "aria-label": name },
      el(
        "div",
        { class: "n-head" },
        el("button", { class: "phone-only", title: t("Folders", "폴더"), "aria-label": t("Folders", "폴더"), onclick: () => ((this.level = "folders"), this.deps.rerender()) }, "‹"),
        el("strong", {}, name),
        el("button", { title: t("New memo", "새 메모"), "aria-label": t("New memo", "새 메모"), onclick: () => this.newMemo() }, icon("square-pen")),
        // a folder's own menu here, where it has room (the folder pane is narrow)
        this.folder !== "all"
          ? dropMenu(icon("more"), t("Folder menu", "폴더 메뉴"), [
              { label: t("Rename folder", "폴더 이름 바꾸기"), run: () => void this.renameFolder(this.folder) },
              "-",
              { label: t("Delete folder", "폴더 지우기"), sub: t("Its memos stay, in no folder", "메모는 남아요 (폴더 없이)"), danger: true, run: () => void this.deleteFolder(this.folder) },
            ])
          : null,
      ),
      el("input", {
        type: "search",
        placeholder: t("Search memos", "메모 찾기"),
        value: this.query,
        "data-key": "notes-search",
        "aria-label": t("Search memos", "메모 찾기"),
        oninput: (e: Event) => {
          this.query = (e.target as HTMLInputElement).value;
          this.deps.rerender();
        },
      }),
      ...rows,
      !all.length ? el("div", { class: "empty-note" }, t("No memos", "메모 없음")) : !shown.length ? el("div", { class: "empty-note" }, t("No match", "찾는 메모 없음")) : null,
    );
  }

  private memoPane(memo: Memo): HTMLElement {
    const folders = this.state.folders ?? [];
    const move = el("select", { title: t("Folder", "폴더"), "aria-label": t("Folder", "폴더"), "data-key": "notes-folder" }) as HTMLSelectElement;
    move.append(el("option", { value: "", selected: !memo.folder }, t("No folder", "폴더 없음")));
    for (const f of folders) move.append(el("option", { value: f.id, selected: memo.folder === f.id }, `📁 ${f.name}`));
    move.addEventListener("change", () => this.mutate(memo.id, (m) => (move.value ? (m.folder = move.value) : delete m.folder)));
    const back = () => {
      this.open = null;
      this.writing = false;
      this.level = "list";
      this.deps.rerender();
    };
    const head = el(
      "div",
      { class: "n-head" },
      el("button", { title: t("Back to the list", "목록으로"), "aria-label": t("Back to the list", "목록으로"), onclick: back }, "‹"),
      el("strong", {}, ""),
      move,
      el(
        "button",
        {
          title: memo.pinned ? t("Unpin", "고정 풀기") : t("Pin to top", "위에 고정"),
          "aria-label": memo.pinned ? t("Unpin", "고정 풀기") : t("Pin to top", "위에 고정"),
          "aria-pressed": String(!!memo.pinned),
          onclick: () => this.mutate(memo.id, (m) => (m.pinned ? delete m.pinned : (m.pinned = true))),
        },
        icon("pin"),
      ),
      dropMenu(icon("more"), t("Memo menu", "메모 메뉴"), [
        { label: t("💬 Send as OOC", "💬 OOC로 보내기"), run: () => (this.deps.close(), void this.deps.sendOoc(memo.text)) },
        { label: t("Put in the input", "입력창에 넣기"), run: () => (this.deps.close(), this.deps.putInInput(memo.text)) },
        { label: t("Open in the 📝 tab", "📝 탭에서 열기"), run: () => this.deps.openMemo(memo.id) },
        "-",
        { label: t("Delete", "삭제"), danger: true, run: () => void this.remove(memo) },
      ]),
    );
    const title = el("input", {
      type: "text",
      class: "n-title",
      value: memo.title ?? "",
      placeholder: t("Title (optional)", "제목 (선택)"),
      "data-key": `notes-title-${memo.id}`,
      "aria-label": t("Memo title", "메모 제목"),
      oninput: (e: Event) => {
        const value = (e.target as HTMLInputElement).value;
        this.mutate(memo.id, (m) => (value.trim() ? (m.title = value) : delete m.title));
      },
    });
    return el("section", { class: "n-main" }, head, title, ...this.body(memo));
  }

  private body(memo: Memo): HTMLElement[] {
    if (this.writing) {
      return memoEditor({
        text: memo.text,
        key: `notes-${memo.id}`,
        // the window does not redraw for memo text, so typing keeps its caret
        onText: (text) => this.mutate(memo.id, (m) => (m.text = text)),
        onDone: () => {
          this.writing = false;
          this.deps.rerender();
        },
        fonts: () => this.deps.fonts(),
      });
    }
    const drawn = renderMemo(memo.text, {
      onToggle: (index) => {
        this.mutate(memo.id, (m) => (m.text = toggleCheck(m.text, index)));
        this.deps.rerender();
      },
      useFont: (family) => this.deps.useFont(family),
    });
    const write = () => {
      this.writing = true;
      this.deps.rerender();
    };
    return [
      el(
        "div",
        { class: "memo-body", role: "button", tabindex: "0", onclick: write, onkeydown: (e: Event) => (e as KeyboardEvent).key === "Enter" && e.target === e.currentTarget && write() },
        ...(drawn.length ? drawn : [el("span", { class: "empty" }, t("Empty", "빈 메모"))]),
      ),
    ];
  }

  /** A new memo in the open folder, where new memos go (the memo pad's setting). */
  private newMemo(): void {
    const memo = newMemo("", Date.now(), ownerFor(this.state.savePlace ?? "all", this.deps.scope()));
    if (this.folder !== "all") memo.folder = this.folder;
    this.update((s) => s.memos.push(memo));
    this.open = memo.id;
    this.writing = true;
    this.query = "";
    this.level = "memo";
    this.deps.rerender();
  }

  private async makeFolder(): Promise<void> {
    const name = (await this.deps.ui.input(t("Name of the new folder", "새 폴더 이름"), { okButton: t("Make", "만들기") }))?.trim();
    if (!name) return;
    const folder = newFolder(name);
    this.update((s) => (s.folders = [...(s.folders ?? []), folder]));
    this.folder = folder.id;
    this.open = null;
    this.level = "list";
    this.deps.rerender();
  }

  private async renameFolder(id: string): Promise<void> {
    const name = (await this.deps.ui.input(t("Folder name", "폴더 이름"), { defaultValue: this.folderName(id) ?? "", okButton: t("Rename", "바꾸기") }))?.trim();
    if (!name) return;
    this.update((s) => {
      const f = s.folders?.find((x) => x.id === id);
      if (f) f.name = name.slice(0, 40);
    });
  }

  private async deleteFolder(id: string): Promise<void> {
    const count = memosInFolder(this.state.memos, id).length;
    const ask = count
      ? t(`Delete the folder "${this.folderName(id)}"? Its ${count} ${count === 1 ? "memo stays" : "memos stay"}, in no folder.`, `「${this.folderName(id)}」 폴더를 지울까요? 메모 ${count}개는 폴더 없이 남아요.`)
      : t(`Delete the folder "${this.folderName(id)}"?`, `「${this.folderName(id)}」 폴더를 지울까요?`);
    if (!(await confirmIn(this.deps.ui, ask))) return;
    this.update((s) => {
      s.folders = (s.folders ?? []).filter((f) => f.id !== id);
      if (!s.folders.length) delete s.folders;
      for (const m of s.memos) if (m.folder === id) delete m.folder;
    });
    if (this.folder === id) this.folder = "all";
    this.deps.rerender();
  }

  private async remove(memo: Memo): Promise<void> {
    if (!(await confirmIn(this.deps.ui, t(`Delete "${memoLabel(memo, 30) || t("(empty memo)", "(빈 메모)")}"?`, `「${memoLabel(memo, 30) || "(빈 메모)"}」 메모를 지울까요?`)))) return;
    this.update((s) => {
      s.memos = s.memos.filter((m) => m.id !== memo.id);
      for (const b of s.boards ?? []) b.cards = b.cards.filter((c) => c.memoId !== memo.id);
    });
    this.open = null;
    this.writing = false;
    this.level = "list";
    this.deps.rerender();
  }
}
