// The 📋 tab: memo boards. The bar above the board and the boards' lifecycle;
// the board-*.ts parts draw themselves and share the open board through `BoardContext`.

import { type Board, CARD_W, boardText, newBoard, placeMemos } from "../memo/board";
import { arrangeFrame } from "../memo/board-frame";
import { themeById } from "../memo/board-themes";
import { type Memo, type MemoState, memoLabel, newMemo, ownerFor } from "../memo/model";
import { t } from "../shared/i18n";
import { BOARD_CARD_CSS, boardHead, zoomPanel } from "./board-card";
import type { BoardContext, BoardViewDeps, Slot } from "./board-context";
import { BOARD_FRAME_CSS, columnsSelect, frameView } from "./board-frame-view";
import { BOARD_PICTURES_CSS, BoardPictures } from "./board-pictures";
import { BOARD_STAGE_CSS, BoardStage } from "./board-stage";
import { BOARD_THEME_PANEL_CSS, dressBoard, themePanel } from "./board-theme-panel";
import { confirmIn } from "./dialogs";
import { el, icon } from "./dom";
import { dropMenu } from "./menu";
import { NOTES_VIEW_CSS, NotesView } from "./notes-view";

export type { BoardViewDeps } from "./board-context";

export const BOARD_VIEW_CSS = `
.board-tab { display: flex; flex-direction: column; min-height: 0; min-width: 0; height: 100%; gap: 6px; padding: 8px; position: relative; }
.board-bar { display: flex; flex-wrap: wrap; gap: 4px; align-items: center; }
.board-bar > button, .board-bar > .menu > summary { width: auto; padding: 4px 9px; font-size: 13px; }
.board-bar select { width: auto; max-width: 12em; padding: 4px 6px; }
.board-bar input[type=color] { width: 2.2em; height: 2em; padding: 1px; cursor: pointer; }
.board-bar .sep { width: 1px; align-self: stretch; margin: 2px 2px; background: var(--d-line); }
.board-bar .zoom { min-width: 3.4em; text-align: center; font-size: 12px; color: color-mix(in srgb, var(--on-paper, var(--d-text)) 65%, transparent); }
/* phone: icons only, so the bar keeps to one or two rows */
.board-bar .lbl { display: none; }
.board-bar .grow { flex: 1; }
@media (max-width: 600px) { .board-bar .zoom { min-width: 2.6em; } }
.board-empty { margin: auto; text-align: center; color: var(--d-muted); display: grid; gap: 8px; justify-items: center; padding: 24px; }
.board-over { position: absolute; inset: 8px; z-index: 5; display: flex; flex-direction: column; gap: 8px; padding: 14px; border-radius: var(--d-radius);
  background: var(--d-panel-solid); border: 1px solid var(--d-line); box-shadow: var(--d-shadow); overflow: auto; }
.board-over { color: var(--d-text); }
.board-over .over-head { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
.board-over .over-head .grow { flex: 1; }
.board-over .over-head > button, .board-over .over-head > .menu > summary { width: auto; padding: 4px 9px; }
.board-over .over-head input[type=color] { width: 2.2em; height: 2em; padding: 1px; cursor: pointer; }
${BOARD_STAGE_CSS}
${BOARD_CARD_CSS}
${BOARD_PICTURES_CSS}
${BOARD_FRAME_CSS}
${BOARD_THEME_PANEL_CSS}
${NOTES_VIEW_CSS}
`;

/** This browser's choice of the 📋 tab's look: boards, or a notebook of folders and memos. */
const MODE_KEY = "dispensa.memo-board-mode";
function savedMode(): "board" | "notes" {
  try {
    return localStorage.getItem(MODE_KEY) === "notes" ? "notes" : "board";
  } catch {
    return "board";
  }
}

export class BoardView {
  private boardId: string | null = null;
  /** The memo id of the card shown large. */
  private zoomed: string | null = null;
  private writing = false;
  private theming = false;
  private readonly ctx: BoardContext;
  private readonly stage: BoardStage;
  private readonly pictures: BoardPictures;
  private readonly notes: NotesView;
  private mode = savedMode();

  constructor(private readonly deps: BoardViewDeps) {
    this.notes = new NotesView(deps);
    this.ctx = {
      deps,
      state: () => this.state,
      boards: () => this.boards,
      board: () => this.board,
      updateBoard: (fn) => this.updateBoard(fn),
      mutateMemo: (id, fn) => this.mutateMemo(id, fn),
      grid: () => themeById(this.board?.theme?.id).grid,
      openCard: (id) => this.openCard(id),
      takeOff: (id) => this.takeOff(id),
      addMemos: (slot) => this.addMemos(slot),
      pickMagnet: (slot) => this.openPictures("magnet", slot),
    };
    this.stage = new BoardStage(this.ctx);
    this.pictures = new BoardPictures(this.ctx, () => this.stage.centerPoint());
  }

  private get state(): MemoState {
    return this.deps.store.value;
  }

  private get boards(): Board[] {
    return this.state.boards ?? [];
  }

  private get board(): Board | null {
    const list = this.boards;
    return list.find((b) => b.id === this.boardId) ?? list[0] ?? null;
  }

  private updateBoard(fn: (b: Board) => void): void {
    const id = this.board?.id;
    if (!id) return;
    this.deps.store.update((s) => {
      const b = s.boards?.find((x) => x.id === id);
      if (b) fn(b);
    });
  }

  private mutateMemo(id: string, fn: (m: Memo) => void): void {
    this.deps.store.update((s) => {
      const m = s.memos.find((x) => x.id === id);
      if (m) fn(m);
    });
  }

  show(boardId: string): void {
    this.boardId = boardId;
    this.zoomed = null;
    this.stage.putDown();
  }

  /** The button that changes the tab's look (boards ↔ notebook), kept per browser. */
  private modeButton(): HTMLElement {
    const notes = this.mode === "notes";
    return el(
      "button",
      {
        title: notes ? t("Show as boards", "보드로 보기") : t("Show as a notebook: folders and memos", "메모장으로 보기: 폴더와 메모"),
        "data-key": "board-mode",
        onclick: () => {
          this.mode = notes ? "board" : "notes";
          try {
            localStorage.setItem(MODE_KEY, this.mode);
          } catch {
            // private window: the choice lasts until the window closes
          }
          this.stage.putDown();
          this.deps.rerender();
        },
      },
      icon(notes ? "layout-dashboard" : "notebook-pen"),
      el("span", { class: "lbl" }, notes ? t("Boards", "보드") : t("Notebook", "메모장")),
    );
  }

  render(): HTMLElement {
    if (this.mode === "notes") {
      this.stage.forget();
      return el("div", { class: "board-tab notes-mode" }, el("div", { class: "board-bar" }, this.modeButton()), this.notes.render());
    }
    const board = this.board;
    if (board) this.boardId = board.id;
    const tab = el("div", { class: "board-tab" }, this.bar(board));
    if (!board) {
      tab.append(
        el(
          "div",
          { class: "board-empty" },
          el("div", {}, t("No boards", "보드 없음")),
          el("button", { onclick: () => void this.makeBoard() }, icon("plus"), t("New board", "새 보드")),
        ),
      );
      return tab;
    }
    dressBoard(tab, board, (family) => this.deps.useFont(family));
    if (board.layout === "frame") {
      this.stage.forget();
      tab.append(frameView(this.ctx, board));
    } else tab.append(boardHead(this.ctx, board), this.stage.render(board));
    if (this.theming) tab.append(themePanel(this.ctx, board, () => ((this.theming = false), this.deps.rerender())));
    else if (this.pictures.isOpen) tab.append(this.pictures.panel());
    else if (this.zoomed) {
      const card = board.cards.find((c) => c.memoId === this.zoomed);
      const memo = this.state.memos.find((m) => m.id === this.zoomed);
      if (card && memo)
        tab.append(
          zoomPanel(this.ctx, card, memo, {
            writing: this.writing,
            write: (on) => ((this.writing = on), this.deps.rerender()),
            close: () => ((this.zoomed = null), (this.writing = false), this.deps.rerender()),
          }),
        );
      else this.zoomed = null;
    }
    return tab;
  }

  // ── the bar above the board ──

  private bar(board: Board | null): HTMLElement {
    const bar = el("div", { class: "board-bar" }, this.modeButton(), el("span", { class: "sep" }));
    if (this.boards.length) {
      const select = el("select", { "aria-label": t("Board", "보드"), title: t("Board", "보드"), "data-key": "board-select" }) as HTMLSelectElement;
      for (const b of this.boards) select.append(el("option", { value: b.id, selected: b.id === board?.id }, `📋 ${b.name}`));
      select.addEventListener("change", () => {
        this.show(select.value);
        this.stage.resetView();
        this.deps.rerender();
      });
      bar.append(select);
    }
    bar.append(el("button", { title: t("New board", "새 보드"), "aria-label": t("New board", "새 보드"), onclick: () => void this.makeBoard() }, icon("plus")));
    if (!board) return bar;
    const frame = board.layout === "frame";
    bar.append(
      dropMenu(bold(icon("more")), t("Board menu", "보드 메뉴"), [
        { label: t("Rename", "이름 바꾸기"), run: () => void this.renameBoard() },
        { label: t("🖼 Background picture", "🖼 배경 그림"), run: () => this.openPictures("background") },
        { label: t("No background picture", "배경 그림 빼기"), run: () => this.updateBoard((b) => delete b.background) },
        board.numbers === false
          ? { label: t("Number the cards", "카드 번호 붙이기"), sub: t("01, 02 … in the order the board is sent", "보내는 순서대로 01, 02 …"), run: () => this.updateBoard((b) => delete b.numbers) }
          : { label: t("No card numbers", "카드 번호 빼기"), run: () => this.updateBoard((b) => (b.numbers = false)) },
        "-",
        { label: t("Delete board", "보드 지우기"), sub: t("Its memos stay", "메모는 남아요"), danger: true, run: () => void this.deleteBoard() },
      ]),
      el("button", { title: t("Theme and colors", "테마와 색"), onclick: () => this.openTheme() }, icon("palette"), el("span", { class: "lbl" }, t("Theme", "테마"))),
      el(
        "button",
        {
          title: frame ? t("Lay cards out freely", "카드를 자유롭게 놓기") : t("Cut the board into sections", "보드를 구획으로 나누기"),
          "aria-pressed": String(frame),
          onclick: () => this.toggleLayout(),
        },
        icon(frame ? "columns-3" : "layout-grid"),
        el("span", { class: "lbl" }, frame ? t("Sections", "구획 배치") : t("Free", "자유 배치")),
      ),
      ...(frame ? [columnsSelect(this.ctx, board)] : []),
      el("span", { class: "sep" }),
      el("button", { title: t("Put memos on the board", "메모를 보드에 놓기"), onclick: () => void this.addMemos() }, icon("notebook-pen"), el("span", { class: "lbl" }, t("Memos", "메모 가져오기"))),
      el("button", { title: t("Write a new memo on the board", "보드에 새 메모 쓰기"), onclick: () => this.newCard() }, icon("square-pen"), el("span", { class: "lbl" }, t("New memo", "새 메모"))),
      el("button", { title: t("Stick a picture on the board", "보드에 그림 붙이기"), onclick: () => this.openPictures("magnet") }, icon("magnet"), el("span", { class: "lbl" }, t("Magnet", "마그넷"))),
      el("span", { class: "sep" }),
      ...(frame ? [] : this.stage.zoomButtons()),
      el("span", { class: "sep" }),
      dropMenu(el("span", {}, icon("message-square"), el("span", { class: "lbl" }, t(" Send", " 보내기"))), t("Send the board", "보드 보내기"), [
        { label: t("💬 Send as OOC", "💬 OOC로 보내기"), sub: t("Every card, in reading order", "모든 카드를 읽는 순서대로"), run: () => this.sendBoard("ooc") },
        { label: t("Put in the input", "입력창에 넣기"), run: () => this.sendBoard("input") },
        { label: t("🌟 Make page", "🌟 페이지 만들기"), run: () => this.sendBoard("page") },
        { label: t("🖼 Run a QR inside the Gallery", "🖼 갤러리 내부에서 QR 실행"), run: () => this.sendBoard("gallery") },
      ]),
      el("span", { class: "grow" }),
      el("button", { title: t("The Gallery", "갤러리"), "aria-label": t("The Gallery", "갤러리"), onclick: () => this.deps.openGallery() }, icon("images")),
    );
    return bar;
  }

  // ── what opens over the board ──

  private openCard(memoId: string): void {
    this.zoomed = memoId;
    this.writing = false;
    this.stage.putDown();
    this.deps.rerender();
  }

  private openTheme(): void {
    this.theming = true;
    this.pictures.close();
    this.zoomed = null;
    this.deps.rerender();
  }

  private openPictures(kind: "background" | "magnet", slot: Slot | null = null): void {
    this.theming = false;
    this.zoomed = null;
    this.pictures.open(kind, slot);
  }

  private toggleLayout(): void {
    this.stage.putDown();
    this.updateBoard((b) => {
      if (b.layout === "frame") delete b.layout;
      else {
        b.layout = "frame";
        arrangeFrame(b);
      }
    });
  }

  // ── boards and cards ──

  async makeBoard(): Promise<void> {
    const name = (await this.deps.ui.input(t("Name of the new board", "새 보드 이름"), { okButton: t("Make", "만들기") }))?.trim();
    if (!name) return;
    const board = newBoard(name.slice(0, 60));
    this.deps.store.update((s) => (s.boards = [...(s.boards ?? []), board]));
    this.show(board.id);
    this.stage.resetView();
    this.deps.rerender();
  }

  private async renameBoard(): Promise<void> {
    const board = this.board;
    if (!board) return;
    const name = (await this.deps.ui.input(t("New name of the board", "보드의 새 이름"), { defaultValue: board.name, okButton: t("OK", "확인") }))?.trim();
    if (name) this.updateBoard((b) => (b.name = name.slice(0, 60)));
  }

  private async deleteBoard(): Promise<void> {
    const board = this.board;
    if (!board) return;
    if (!(await confirmIn(this.deps.ui, t(`Delete the board "${board.name}"? Its memos stay in the memo pad.`, `"${board.name}" 보드를 지울까요? 메모는 메모장에 그대로 남아요.`)))) return;
    this.deps.store.update((s) => {
      s.boards = (s.boards ?? []).filter((b) => b.id !== board.id);
      if (!s.boards.length) delete s.boards;
    });
    this.boardId = null;
    this.deps.rerender();
  }

  private async addMemos(slot?: Slot): Promise<void> {
    const board = this.board;
    if (!board) return;
    const on = new Set(board.cards.map((c) => c.memoId));
    const memos = this.state.memos.filter((m) => !on.has(m.id));
    if (!memos.length) {
      this.deps.ui.toast(
        this.state.memos.length ? t("Every memo is on this board already.", "모든 메모가 이미 이 보드에 있어요.") : t("No memos yet: write one with New memo.", "아직 메모가 없어요. 새 메모로 써 보세요."),
        "info",
        { title: "📋" },
      );
      return;
    }
    const labels = memos.map((m, i) => `${i + 1}. ${m.pinned ? "📌 " : ""}${memoLabel(m, 60) || t("(empty memo)", "(빈 메모)")}`);
    const picked = (await this.deps.ui.pick?.(t("Memos to put on the board", "보드에 놓을 메모"), labels, { multiple: true, placeholder: t("Search", "찾기") })) ?? [];
    const ids = picked.map((l) => memos[labels.indexOf(l)]?.id).filter((x): x is string => !!x);
    if (!ids.length) return;
    const at = this.stage.centerPoint();
    this.updateBoard((b) => {
      placeMemos(b, ids, { x: Math.max(0, at.x - 200), y: Math.max(0, at.y - 60) });
      if (b.layout !== "frame") return;
      // the first picked memo goes into the asked-for section; the rest into free ones
      const first = b.cards.find((c) => c.memoId === ids[0]);
      if (first && slot) first.cell = { ...slot, w: 1, h: 1 };
      arrangeFrame(b);
    });
  }

  private newCard(): void {
    const memo = newMemo("", Date.now(), ownerFor(this.state.savePlace ?? "all", this.deps.scope()));
    const at = this.stage.centerPoint();
    this.deps.store.update((s) => {
      s.memos.push(memo);
      const b = s.boards?.find((x) => x.id === this.board?.id);
      if (!b) return;
      placeMemos(b, [memo.id], { x: Math.max(0, at.x - CARD_W.default / 2), y: Math.max(0, at.y) });
      if (b.layout === "frame") arrangeFrame(b);
    });
    this.zoomed = memo.id;
    this.writing = true;
    this.deps.rerender();
  }

  private takeOff(memoId: string): void {
    this.stage.putDown();
    this.updateBoard((b) => (b.cards = b.cards.filter((c) => c.memoId !== memoId)));
  }

  private sendBoard(how: "ooc" | "input" | "page" | "gallery"): void {
    const board = this.board;
    if (!board) return;
    const text = boardText(board, this.state.memos);
    if (!text) {
      this.deps.ui.toast(t("The board has no memos with text.", "보드에 글이 있는 메모가 없어요."), "info", { title: "📋" });
      return;
    }
    if (how === "gallery") return this.deps.runForGallery(text, board.name);
    this.deps.close();
    if (how === "ooc") void this.deps.sendOoc(text);
    else if (how === "input") this.deps.putInInput(text);
    else void this.deps.makePage(text);
  }
}

/** Dots drawn with the usual stroke look faint next to line icons. */
function bold(svg: SVGSVGElement): SVGSVGElement {
  svg.setAttribute("stroke-width", "3");
  return svg;
}
