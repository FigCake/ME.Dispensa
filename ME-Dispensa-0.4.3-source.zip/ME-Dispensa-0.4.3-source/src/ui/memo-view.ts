// The memo tab of the Dispensa window: the memo list and editor, settings and backup.

import { type Memo, type MemoPlace, type MemoState, isVisible, memoLabel, memosFrom, newFolder, newMemo, normalizeOwner, ownerFor, placeHere, placeOf, shownMemos } from "../memo/model";
import type { ChatScope } from "../qr/scopes";
import { downloadJson, pickFiles } from "./files";
import type { MemoStore } from "../memo/store";
import type { HostUI } from "../stscript/host";
import { el, icon } from "./dom";
import type { MenuEntry } from "./menu";
import { section, segmented, setting, toggle } from "../shared/form";
import { t } from "../shared/i18n";
import { PLACE_MARK, placeLabel } from "./memo-place";
import { MEMO_EDITOR_CSS, memoEditor } from "./memo-editor";
import { MEMO_RENDER_CSS, renderMemo } from "./memo-render";
import { toggleCheck } from "../memo/markdown";
import { type Board, boardsWith, newBoard, placeMemos } from "../memo/board";
import { arrangeFrame } from "../memo/board-frame";
import { newId } from "../util";

export const MEMO_VIEW_CSS = `
.memo-list { display: flex; flex-direction: column; gap: 4px; margin-top: 6px; }
.memo-row { display: flex; align-items: center; gap: 4px; }
.memo-row > .entry { flex: 1; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.memo-row .pin.on { color: var(--d-accent); }
.memo-row .menu.place > summary { min-width: 2em; text-align: center; }
.memo-row .menu.place .away { opacity: .45; }
.memo-edit { margin: 2px 0 8px 0; display: flex; flex-direction: column; gap: 6px; }
.memo-edit textarea { font-family: var(--d-font); min-height: 90px; }
.memo-count { color: var(--d-muted); font-size: 12px; }
${MEMO_RENDER_CSS}
${MEMO_EDITOR_CSS}
`;


export interface MemoViewDeps {
  store: MemoStore;
  ui: HostUI;
  sendOoc(text: string): Promise<boolean>;
  putInInput(text: string): void;
  makePage(text: string): Promise<boolean>;
  /** Opens a new QR with the memo in its script box. */
  toQr(memo: Memo): void;
  /** The visz settings' OOC parts: how to send, the wrappers. */
  oocSettings(): HTMLElement[];
  menu(summary: Node, label: string, entries: MenuEntry[]): HTMLElement;
  close(): void;
  rerender(): void;
  scope(): ChatScope;
  fonts(): Promise<string[]>;
  useFont(family: string): void;
  openBoard(id: string): void;
}

export class MemoView {
  private query = "";
  private open: string | null = null;
  /** Every memo, not only this chat's. */
  private everywhere = false;
  private writing = false;

  constructor(private readonly deps: MemoViewDeps) {}

  private get state(): MemoState {
    return this.deps.store.value;
  }

  /** The window closes: nothing stays open for writing. */
  leave(): void {
    this.open = null;
    this.writing = false;
  }

  /** Shown even when it belongs to another chat. */
  show(id: string): void {
    this.open = id;
    this.writing = false;
    const memo = this.state.memos.find((m) => m.id === id);
    if (memo && !isVisible(memo, this.deps.scope())) this.everywhere = true;
    this.query = "";
  }

  private update(fn: (s: MemoState) => void): void {
    this.deps.store.update(fn);
  }

  render(): HTMLElement {
    return el("div", { class: "col cards" }, this.memoCard(), this.placeCard(), this.captureCard(), ...this.deps.oocSettings(), this.backupCard());
  }

  private newOwner() {
    return ownerFor(this.state.savePlace ?? "all", this.deps.scope());
  }

  private memoCard(): HTMLElement {
    const scope = this.deps.scope();
    const all = this.everywhere ? this.state.memos : this.state.memos.filter((m) => isVisible(m, scope));
    const shown = shownMemos(all, this.query);
    const list = el("div", { class: "memo-list" });
    for (const memo of shown) list.append(...this.row(memo));
    if (!all.length) list.append(el("div", { class: "note" }, this.everywhere || !this.state.memos.length ? t("No memos", "메모 없음") : t("None in this chat", "이 채팅 메모 없음")));
    else if (!shown.length) list.append(el("div", { class: "note" }, t("No match", "찾는 메모 없음")));
    return el(
      "div",
      { class: "card" },
      section(
        t("📝 Memos", "📝 메모"),
        t(
          "· Select chat text → Memo\n· Use in the 🍰 menu, [[memo]] or /memo · 📌: pin (pinned memos stay in the 📝 bubble)\n· 🌐 every chat · 👤 this character's chats · 📍 this chat only",
          "· 채팅 글 긁기 → 메모하기\n· 🍰 메뉴·[[메모]]·/memo로 꺼내 쓰기 · 📌: 고정 (고정한 메모는 📝 버블에 늘 보여요)\n· 🌐 모든 채팅 · 👤 이 캐릭터의 채팅 · 📍 이 채팅에서만",
        ),
        [
          el(
            "button",
            {
              onclick: () => {
                const memo = newMemo("", Date.now(), this.newOwner());
                this.update((s) => s.memos.push(memo));
                this.open = memo.id;
                this.writing = true;
                this.query = "";
                this.deps.rerender();
              },
            },
            icon("plus"),
            t("New memo", "새 메모"),
          ),
          el("button", { title: t("Paste many at once; OOC wrappers come off", "한꺼번에 붙여넣기. OOC 포장은 벗김"), onclick: () => void this.paste() }, icon("clipboard"), t("Add many", "여러 개 넣기")),
        ],
        segmented(
          "memo-where",
          [
            { value: "here", label: t("Shown here", "여기 보이는 메모"), title: t("Memos shown in this chat", "이 채팅에서 보이는 메모") },
            { value: "all", label: t("Every memo", "모든 메모"), title: t("Memos of every chat and character", "모든 채팅·캐릭터의 메모") },
          ],
          this.everywhere ? "all" : "here",
          (v) => {
            this.everywhere = v === "all";
            this.deps.rerender();
          },
          t("Which memos", "보여 줄 메모"),
        ),
        el("input", {
          type: "search",
          placeholder: t("Search memos", "메모 찾기"),
          value: this.query,
          "data-key": "memo-search",
          "aria-label": t("Search memos", "메모 찾기"),
          oninput: (e: Event) => {
            this.query = (e.target as HTMLInputElement).value;
            this.deps.rerender();
          },
        }),
        el("div", { class: "memo-count" }, this.query ? t(`${shown.length} / ${all.length}`, `${shown.length} / ${all.length}개`) : t(`${all.length}`, `${all.length}개`)),
        list,
      ),
    );
  }

  private row(memo: Memo): HTMLElement[] {
    const isOpen = this.open === memo.id;
    const row = el(
      "div",
      { class: "memo-row" },
      el(
        "button",
        {
          class: `entry${isOpen ? " sel" : ""}`,
          title: memo.text.slice(0, 400),
          onclick: () => {
            this.open = isOpen ? null : memo.id;
            this.writing = !isOpen && !memo.text.trim();
            this.deps.rerender();
          },
        },
        memoLabel(memo, 90) || t("(empty memo)", "(빈 메모)"),
      ),
      this.placeMenu(memo),
      el(
        "button",
        {
          class: `icon pin${memo.pinned ? " on" : ""}`,
          title: memo.pinned ? t("Unpin", "고정 풀기") : t("Pin to top", "위에 고정"),
          "aria-label": memo.pinned ? t("Unpin", "고정 풀기") : t("Pin to top", "위에 고정"),
          "aria-pressed": String(!!memo.pinned),
          onclick: () => this.mutate(memo.id, (m) => (m.pinned ? delete m.pinned : (m.pinned = true))),
        },
        icon("pin"),
      ),
      this.deps.menu(icon("more"), t("Memo menu", "메모 메뉴"), [
        { label: t("💬 Send as OOC", "💬 OOC로 보내기"), run: () => (this.deps.close(), void this.deps.sendOoc(memo.text)) },
        { label: t("Put in the input", "입력창에 넣기"), run: () => (this.deps.close(), this.deps.putInInput(memo.text)) },
        { label: t("🌟 Make page", "🌟 페이지 만들기"), run: () => (this.deps.close(), void this.deps.makePage(memo.text)) },
        { label: t("Make a QR", "QR로 만들기"), run: () => this.deps.toQr(memo) },
        { label: t("Copy", "복사"), run: async () => (await this.deps.ui.copy?.(memo.text), this.deps.ui.toast(t("Copied.", "복사했어요."), "success", { title: "📝" })) },
        { label: t("Duplicate", "복제"), run: () => this.duplicate(memo) },
        { label: t("📋 On a board…", "📋 보드에 놓기…"), sub: this.onBoards(memo), run: () => void this.putOnBoards(memo) },
        "-",
        { label: t("Delete", "삭제"), danger: true, run: () => this.remove(memo) },
      ]),
    );
    if (!isOpen) return [row];
    const title = el("input", {
      type: "text",
      value: memo.title ?? "",
      placeholder: t("Title (optional)", "제목 (선택)"),
      "data-key": `memo-title-${memo.id}`,
      "aria-label": t("Memo title", "메모 제목"),
      oninput: (e: Event) => {
        const value = (e.target as HTMLInputElement).value;
        this.mutate(memo.id, (m) => (value.trim() ? (m.title = value) : delete m.title));
      },
    });
    return [row, el("div", { class: "memo-edit" }, title, ...this.body(memo))];
  }

  private body(memo: Memo): HTMLElement[] {
    if (this.writing) {
      return memoEditor({
        text: memo.text,
        key: `memo-${memo.id}`,
        // the window does not redraw for memo text (see manager/index.ts), so typing keeps its caret
        onText: (text) => this.mutate(memo.id, (m) => (m.text = text)),
        onDone: () => {
          this.writing = false;
          this.deps.rerender();
        },
        fonts: () => this.deps.fonts(),
      });
    }
    const drawn = renderMemo(memo.text, {
      onToggle: (index) => {
        this.mutate(memo.id, (m) => (m.text = toggleCheck(m.text, index)));
        this.deps.rerender();
      },
      useFont: (family) => this.deps.useFont(family),
    });
    const box = el(
      "div",
      {
        class: "memo-body",
        role: "button",
        tabindex: "0",
        onclick: () => {
          this.writing = true;
          this.deps.rerender();
        },
        onkeydown: (e: Event) => {
          if ((e as KeyboardEvent).key !== "Enter" || e.target !== box) return;
          this.writing = true;
          this.deps.rerender();
        },
      },
      ...(drawn.length ? drawn : [el("span", { class: "empty" }, t("Empty", "빈 메모"))]),
    );
    return [box];
  }

  private onBoards(memo: Memo): string | undefined {
    const names = boardsWith(this.state.boards ?? [], memo.id).map((b) => b.name);
    return names.length ? names.join(", ") : undefined;
  }

  /** Puts the memo on picked boards, then opens the first. */
  private async putOnBoards(memo: Memo): Promise<void> {
    const boards = this.state.boards ?? [];
    const fresh = t("➕ New board…", "➕ 새 보드…");
    const labels = boards.map((b, i) => `${i + 1}. 📋 ${b.name}${b.cards.some((c) => c.memoId === memo.id) ? t(" (already on)", " (이미 있음)") : ""}`);
    const picked = (await this.deps.ui.pick?.(t("Boards to put the memo on", "메모를 놓을 보드"), [...labels, fresh], { multiple: true })) ?? [];
    const ids = picked.filter((l) => l !== fresh).map((l) => boards[labels.indexOf(l)]?.id).filter((x): x is string => !!x);
    let made: Board | null = null;
    if (picked.includes(fresh)) {
      const name = (await this.deps.ui.input(t("Name of the new board", "새 보드 이름"), { okButton: t("Make", "만들기") }))?.trim();
      if (name) made = newBoard(name.slice(0, 60));
    }
    if (!ids.length && !made) return;
    this.update((s) => {
      if (made) s.boards = [...(s.boards ?? []), made];
      for (const b of s.boards ?? []) if (ids.includes(b.id) || b.id === made?.id) {
        placeMemos(b, [memo.id]);
        if (b.layout === "frame") arrangeFrame(b);
      }
    });
    this.deps.openBoard(made?.id ?? ids[0]);
  }

  /** Not pinned, so the 📝 bubble does not list it twice. */
  private duplicate(memo: Memo): void {
    const copy: Memo = { ...structuredClone(memo), id: newId("memo"), createdAt: Date.now() };
    delete copy.pinned;
    this.update((s) => {
      const at = s.memos.findIndex((m) => m.id === memo.id);
      s.memos.splice(at < 0 ? s.memos.length : at + 1, 0, copy);
    });
    this.open = copy.id;
    this.writing = false;
    this.deps.rerender();
  }

  /** Deletes at once; the toast's Undo puts the memo back where it was. */
  private remove(memo: Memo): void {
    const at = this.state.memos.findIndex((m) => m.id === memo.id);
    if (at < 0) return;
    const kept = structuredClone(this.state.memos[at]);
    this.update((s) => (s.memos = s.memos.filter((m) => m.id !== memo.id)));
    if (this.open === memo.id) this.open = null;
    this.deps.ui.toast(t(`Deleted "${memoLabel(kept, 30) || t("(empty memo)", "(빈 메모)")}".`, `「${memoLabel(kept, 30) || "(빈 메모)"}」 메모를 지웠어요.`), "info", {
      title: "📝",
      action: {
        label: t("Undo", "되돌리기"),
        run: () => {
          if (this.state.memos.some((m) => m.id === kept.id)) return;
          this.update((s) => s.memos.splice(Math.min(at, s.memos.length), 0, kept));
          this.deps.rerender();
        },
      },
    });
  }

  private placeMenu(memo: Memo): HTMLElement {
    const scope = this.deps.scope();
    const place = placeOf(memo.owner);
    const here = isVisible(memo, scope);
    const where = place === "all" ? placeLabel("all") : here ? placeLabel(place) : place === "chat" ? t("Another chat", "다른 채팅") : t("Other characters", "다른 캐릭터");
    const move = (to: MemoPlace) => () =>
      this.mutate(memo.id, (m) => {
        const owner = ownerFor(to, scope);
        if (owner) m.owner = owner;
        else delete m.owner;
      });
    const entries = (["all", "character", "chat"] as MemoPlace[])
      .filter((p) => placeHere(p, scope) === p)
      .map((p) => ({ label: `${PLACE_MARK[p]} ${placeLabel(p)}${p === place && here ? " ✓" : ""}`, run: move(p) }));
    const summary = el("span", { class: here ? "" : "away" }, PLACE_MARK[place]);
    const menu = this.deps.menu(summary, t(`Shown in: ${where}`, `보이는 곳: ${where}`), entries);
    menu.classList.add("place");
    return menu;
  }

  private mutate(id: string, fn: (m: Memo) => void): void {
    this.update((s) => {
      const m = s.memos.find((x) => x.id === id);
      if (m) fn(m);
    });
  }

  private async paste(): Promise<void> {
    const text = await this.deps.ui.input(t("Paste the text.<br><small>OOC wrappers come off; several notes become several memos.</small>", "넣을 글을 붙여 넣으세요.<br><small>OOC 포장은 벗기고, 여러 개면 하나씩 나눠요.</small>"), { rows: 8, multiline: true, wide: true, okButton: t("Add", "넣기") });
    if (!text?.trim()) return;
    const memos = memosFrom(text, Date.now(), this.newOwner());
    this.update((s) => s.memos.push(...memos));
    this.deps.ui.toast(t(`Added ${memos.length} memos.`, `메모 ${memos.length}개를 넣었어요.`), "success", { title: "📝" });
  }

  private placeCard(): HTMLElement {
    const current = this.state.savePlace ?? "all";
    return el(
      "div",
      { class: "card" },
      section(
        t("Where new memos go", "새 메모 저장할 곳"),
        t(
          "Used unless you choose when writing (the 🌐 / 👤 / 📍 button in the 📝 bubble)\n· With no chat open, a memo goes to every chat\n· In a group chat, this character means everyone in it",
          "메모를 쓸 때 고르지 않으면 이대로 저장해요 (📝 버블의 🌐 / 👤 / 📍 단추)\n· 채팅을 안 열었으면 전체로 저장해요\n· 그룹 채팅에서 이 캐릭터는 그 채팅의 모든 캐릭터예요",
        ),
        [],
        segmented(
          "memo-save-place",
          (["all", "character", "chat"] as MemoPlace[]).map((p) => ({ value: p, label: `${PLACE_MARK[p]} ${placeLabel(p)}` })),
          current,
          (v) =>
            this.update((s) => {
              if (v === "all") delete s.savePlace;
              else s.savePlace = v as MemoPlace;
            }),
          t("Where new memos go", "새 메모 저장할 곳"),
        ),
      ),
    );
  }

  /** The 📝 bubble's row, for the window's ⚙ settings. */
  dockBubble(): HTMLElement {
    const s = this.state;
    return setting(
      t("📝 Memo bubble", "📝 메모 버블"),
      [
        el("input", { type: "text", class: "icon-input", value: s.dockIcon, maxlength: "8", "data-key": "memo-dock-icon", "aria-label": t("Bubble icon", "버블 아이콘"), oninput: (e: Event) => this.update((x) => (x.dockIcon = (e.target as HTMLInputElement).value.trim() || "📝")) }),
        toggle(s.showButton, (v) => this.update((x) => (x.showButton = v)), t("Show 📝 bubble", "📝 버블 보이기"), "memo-show"),
      ],
    );
  }

  private captureCard(): HTMLElement {
    const s = this.state;
    return el(
      "div",
      { class: "card" },
      setting(t("📝 button on selected text", "글을 긁으면 📝 버튼"), toggle(s.capture !== false, (v) => this.update((x) => (x.capture = v)), t("📝 button on selected text", "글을 긁으면 📝 버튼"), "memo-capture")),
    );
  }

  private backupCard(): HTMLElement {
    return el(
      "div",
      { class: "card" },
      section(
        t("Backup", "백업"),
        t("All memos as .memo.json; imports are added", "메모 전체를 .memo.json으로. 가져오면 더해짐"),
        [el("button", { onclick: () => this.exportJson() }, icon("upload"), t("Export", "내보내기")), el("button", { onclick: () => this.importJson() }, icon("download"), t("Import", "가져오기"))],
      ),
    );
  }

  private exportJson(): void {
    // a memo's folder goes by name, so another browser's import puts it in a folder of that name
    const folders = new Map((this.state.folders ?? []).map((f) => [f.id, f.name]));
    downloadJson({ format: "dispensa-memo", version: 1, memos: this.state.memos.map((m) => ({ title: m.title, text: m.text, pinned: m.pinned || undefined, createdAt: m.createdAt, owner: m.owner, folder: m.folder ? folders.get(m.folder) : undefined })) }, "dispensa.memo.json");
  }

  private importJson(): void {
    pickFiles(async ([file]) => {
      try {
        let json: { memos?: { title?: unknown; text?: unknown; pinned?: unknown; createdAt?: unknown; owner?: unknown; folder?: unknown }[] };
        try {
          json = JSON.parse(await file.text()) as typeof json;
        } catch {
          json = {};
        }
        if (!json || !Array.isArray(json.memos)) {
          this.deps.ui.toast(t(`${file.name} isn't a memo file (.memo.json).`, `${file.name}은(는) 메모 파일(.memo.json)이 아니에요.`), "warning", { title: "📝" });
          return;
        }
        const have = new Set(this.state.memos.map((m) => m.text));
        const list = (json.memos ?? []).filter((m) => typeof m.text === "string" && m.text.trim() && !have.has(m.text));
        // folders by name: one already here of that name, else a new one
        const folders = [...(this.state.folders ?? [])];
        const folderFor = (name: unknown): string | undefined => {
          if (typeof name !== "string" || !name.trim()) return undefined;
          const found = folders.find((f) => f.name === name.trim().slice(0, 40)) ?? newFolder(name);
          if (!folders.includes(found)) folders.push(found);
          return found.id;
        };
        const fresh = list.map((m) => {
          const folder = folderFor(m.folder);
          return { ...newMemo(String(m.text), Number(m.createdAt) || Date.now(), normalizeOwner(m.owner)), ...(typeof m.title === "string" && m.title.trim() ? { title: m.title.trim() } : {}), ...(m.pinned ? { pinned: true } : {}), ...(folder ? { folder } : {}) };
        });
        this.update((s) => {
          s.memos.push(...fresh);
          if (folders.length) s.folders = folders;
        });
        this.deps.ui.toast(fresh.length ? t(`Imported ${fresh.length} ${fresh.length === 1 ? "memo" : "memos"}.`, `메모 ${fresh.length}개를 가져왔어요.`) : t("Every memo in the file is already here.", "파일의 메모가 모두 이미 있어요."), "success", { title: "📝" });
      } catch (e) {
        this.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("📝 Import", "📝 가져오기") });
      }
    }, { json: true });
  }
}
