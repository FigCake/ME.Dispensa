// Keeps the Dock right above Marinara's chat input. React redraws throw our
// elements out (or move the input), so every page change puts them back next frame.

import { findComposer } from "../shared/composer";

export interface DockPlacementParts {
  dock: HTMLElement;
  toggle: { mount(parent: Element | null): void };
  /** Placed right above the Dock while it is open. */
  viewer(): { open: boolean; element: HTMLElement } | null;
  /** Runs each time the Dock was placed, before the viewer. */
  afterPlace?(): void;
}

export interface DockPlacement {
  /** Places everything on the next frame (several calls, one placement). */
  schedule(): void;
  dispose(): void;
}

export function keepDockPlaced(parts: DockPlacementParts): DockPlacement {
  let scheduled = false;
  const place = () => {
    scheduled = false;
    const composer = findComposer();
    if (!composer) {
      if (parts.dock.isConnected) parts.dock.remove();
      return;
    }
    const box = composer.container.querySelector(".mari-chat-input-box");
    parts.toggle.mount(box ?? composer.textarea.parentElement);
    const anchor = box ?? composer.textarea.closest("form") ?? composer.textarea.parentElement;
    const parent = anchor?.parentElement;
    if (!anchor || !parent) return;
    if (parts.dock.parentElement !== parent || parts.dock.nextElementSibling !== anchor) parent.insertBefore(parts.dock, anchor);
    parts.afterPlace?.();
    const viewer = parts.viewer();
    if (viewer?.open) {
      if (viewer.element.parentElement !== parent || viewer.element.nextElementSibling !== parts.dock) parent.insertBefore(viewer.element, parts.dock);
    } else if (viewer?.element.isConnected) viewer.element.remove();
  };
  const schedule = () => {
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(place);
    }
  };
  const observer = new MutationObserver(schedule);
  observer.observe(document.body, { childList: true, subtree: true });
  place();
  return { schedule, dispose: () => observer.disconnect() };
}
