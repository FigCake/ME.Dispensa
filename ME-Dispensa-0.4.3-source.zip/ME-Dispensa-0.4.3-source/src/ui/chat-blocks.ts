// A "View" button on HTML code blocks in chat messages: opens the page in the viewer.
// Marinara renders the HTML inside the block, so the source is read from the message, not the screen.

import { t } from "../shared/i18n";

const MARK = "dispensa-view";

const isHtmlBlock = (block: HTMLPreElement) => {
  const lang = block.querySelector(".mari-md-codeblock-lang")?.textContent?.trim().toLowerCase() ?? "";
  return lang === "html" || lang === "htm";
};

/** onView gets the message id and which HTML block of that message was clicked (0-based). */
export function addViewButtons(onView: (messageId: string, index: number) => void): void {
  document.querySelectorAll<HTMLElement>("[data-message-id]").forEach((message) => {
    const blocks = [...message.querySelectorAll<HTMLPreElement>("pre.mari-md-codeblock")].filter(isHtmlBlock);
    blocks.forEach((block, index) => {
      if (block.querySelector(`.${MARK}`)) return;
      const button = document.createElement("button");
      button.type = "button";
      button.className = `${MARK} rounded-md border border-[var(--border)] bg-[var(--card)] px-2 py-1 font-sans text-xs text-[var(--muted-foreground)] hover:bg-[var(--accent)] hover:text-[var(--foreground)]`;
      button.style.cssText = "position:absolute;bottom:6px;right:72px;min-height:2rem;cursor:pointer;";
      button.textContent = t("🌟 View", "🌟 보기");
      button.title = t("View as a page", "페이지로 보기");
      button.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const id = message.dataset.messageId;
        if (id) onView(id, index);
      });
      if (getComputedStyle(block).position === "static") block.style.position = "relative";
      block.append(button);
    });
  });
}
