// The memo pad menu that opens from the Dock. Built once and updated in place,
// so a draft survives the Dock's redraws.

import { type Memo, type MemoPlace, dockMemos, memosFrom, memoLabel, ownerFor, placeHere, placeOf, shownMemos, visibleMemos } from "../memo/model";
import type { ChatScope } from "../qr/scopes";
import type { MemoStore } from "../memo/store";
import type { HostUI } from "../stscript/host";
import { el, icon, onCtrlEnter, withIcons } from "./dom";
import { themeColors } from "../memo/board-themes";
import { liveCards } from "../memo/board";
import { helpTip, segmented } from "../shared/form";
import { t } from "../shared/i18n";
import { PLACE_MARK, placeLabel, placePrefix } from "./memo-place";

export const MEMO_STYLE = `
.memo-pop .head-line { display: flex; align-items: center; gap: 6px; }
.memo-pop .head-line strong { font-size: 13px; color: var(--d-title); white-space: nowrap; }
.memo-pop .head-line > button { width: auto; flex: none; }
.memo-pop .head-line .grow { flex: 1; }
.memo-pop input[type=search] { width: 100%; }
.memo-pop .acts .place { width: auto; flex: none; font-size: 12px; }
.memo-pop .list-head { font-size: 11px; color: var(--d-muted); margin: 6px 2px 2px; }
.memo-pop .board-line { display: flex; align-items: center; gap: 8px; }
.memo-pop .board-line > button { flex: 1; min-width: 0; display: flex; align-items: center; gap: 8px; text-align: left; }
.memo-pop .board-line .swatch { display: flex; gap: 2px; flex: none; }
.memo-pop .board-line .swatch i { width: 14px; height: 12px; border-radius: 3px; display: block; border: 1px solid rgb(0 0 0 / .15); }
.memo-pop .board-line .t { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

`;

export interface MemoPanelDeps {
  store: MemoStore;
  ui: HostUI;
  /** True once it went out. */
  sendOoc(text: string): Promise<boolean>;
  putInInput(text: string): void;
  close(): void;
  openSettings(): void;
  scope(): ChatScope;
  /** Opens a memo board (none: the boards tab; "new": a new board, asking its name) in the Dispensa window. */
  openBoard(id?: string): void;
}

/** Search shows up from this many memos. */
const SEARCH_FROM = 6;

export class MemoPanel {
  readonly element: HTMLElement;
  private readonly box: HTMLTextAreaElement;
  private readonly search: HTMLInputElement;
  private readonly list: HTMLElement;
  /** Where the memo being written is saved; null: the memo pad's setting. */
  private place: MemoPlace | null = null;
  private tab: "memo" | "boards" = "memo";

  constructor(private readonly deps: MemoPanelDeps) {
    this.box = el("textarea", { part: "memo-input", rows: "2" });
    onCtrlEnter(this.box, () => void this.sendTyped());
    this.search = el("input", { type: "search", part: "memo-search", oninput: () => this.renderList() });
    this.list = el("div", { class: "list" });
    this.element = el("div", { class: "pop visz-pop memo-pop", part: "memo-menu", role: "dialog" });
    this.render();
  }

  refresh(): void {
    this.place = null;
    this.render();
    setTimeout(() => this.box.focus(), 0);
  }

  render(): void {
    // here, not in the constructor: they follow the screen language
    this.box.placeholder = t("OOC or memo", "OOC나 메모");
    this.box.setAttribute("aria-label", t("Memo", "메모"));
    this.search.placeholder = t("Search memos", "메모 찾기");
    this.search.setAttribute("aria-label", t("Search memos", "메모 찾기"));
    this.element.setAttribute("aria-label", t("Memo pad", "메모장"));
    const tabs = withIcons(segmented(
      "memo-menu",
      [
        { value: "memo", label: "📝", title: t("Memo pad", "메모장") },
        { value: "boards", label: "📋", title: t("Memo boards", "메모 보드") },
      ],
      this.tab,
      (v) => ((this.tab = v as "memo" | "boards"), this.render()),
      t("Memo pad menu", "메모장 메뉴"),
    ), ["notebook-pen", "layout-dashboard"]);
    if (this.tab === "boards") {
      const head = el(
        "div",
        { class: "head-line" },
        tabs,
        el("span", { class: "grow" }),
        el("button", { class: "mini ghost", title: t("Open the memo boards large", "메모 보드 크게 열기"), "aria-label": t("Open the memo boards large", "메모 보드 크게 열기"), onclick: () => this.deps.openBoard() }, icon("maximize-2")),
      );
      this.element.replaceChildren(head, this.boardList());
      return;
    }
    const head = el(
      "div",
      { class: "head-line" },
      tabs,
      el("span", { class: "grow" }),
      helpTip(
        t(
          "· 🌐 / 👤 / 📍: saved for every chat, this character or this chat\n· 📌: pinned memos stay listed here",
          "· 🌐 / 👤 / 📍: 전체·이 캐릭터·이 채팅에 저장\n· 📌: 고정한 메모는 여기 늘 보여요",
        ),
        t("Memo pad", "메모장"),
      ),
      el("button", { class: "mini ghost", title: t("Memo pad and settings", "메모장 관리와 설정"), "aria-label": t("Memo pad settings", "메모장 설정"), onclick: () => this.deps.openSettings() }, icon("settings")),
    );
    const acts = el(
      "div",
      { class: "acts" },
      el("button", { part: "memo-ooc", class: "main", title: t("Send as OOC (Ctrl+Enter)", "OOC로 보내기 (Ctrl+Enter)"), onclick: () => void this.sendTyped() }, el("span", { class: "t" }, t("💬 Send OOC", "💬 OOC 보내기"))),
      el("button", { part: "memo-input-put", title: t("Put in the chat input", "채팅 입력창에 넣기"), onclick: () => this.putTyped() }, t("To input", "입력창에")),
      this.placeButton(),
      el("button", { class: "mini ghost", part: "memo-save", title: t("Save to the Memo pad", "메모장에 저장"), "aria-label": t("Save to the Memo pad", "메모장에 저장"), onclick: () => this.saveTyped() }, icon("star")),
    );
    const many = visibleMemos(this.deps.store.value.memos, this.deps.scope()).length >= SEARCH_FROM;
    this.renderList();
    this.element.replaceChildren(head, this.box, acts, ...(many ? [this.search] : []), this.list);
  }

  /** 📋: the boards, each opening in the Dispensa window. */
  private boardList(): HTMLElement {
    const state = this.deps.store.value;
    const boards = state.boards ?? [];
    const list = el("div", { class: "list" });
    if (!boards.length) {
      list.append(el("div", { class: "none" }, t("No boards", "보드 없음")), el("button", { onclick: () => this.deps.openBoard("new") }, t("＋ Make one", "＋ 보드 만들기")));
      return list;
    }
    for (const board of boards) {
      const colors = themeColors(board.theme);
      const cards = liveCards(board, state.memos).cards.length;
      const pictures = board.magnets.length;
      list.append(
        el(
          "div",
          { class: "line board-line" },
          el(
            "button",
            { part: "memo-board", title: t("Open this board", "이 보드 열기"), onclick: () => this.deps.openBoard(board.id) },
            el("span", { class: "swatch" }, ...[colors.paper, colors.card ?? colors.paper, colors.accent].map((c) => Object.assign(el("i"), { style: `background:${c}` }))),
            el("span", { class: "t" }, board.name),
            el("span", { class: "meta" }, pictures ? t(`${cards} ${cards === 1 ? "card" : "cards"} · ${pictures} ${pictures === 1 ? "picture" : "pictures"}`, `카드 ${cards} · 그림 ${pictures}`) : t(`${cards} ${cards === 1 ? "card" : "cards"}`, `카드 ${cards}`)),
          ),
        ),
      );
    }
    return list;
  }

  /** Pressing it tries the next place open here. */
  private placeButton(): HTMLButtonElement {
    const scope = this.deps.scope();
    const here = placeHere(this.place ?? this.deps.store.value.savePlace ?? "all", scope);
    const open = (["all", "character", "chat"] as MemoPlace[]).filter((p) => placeHere(p, scope) === p);
    const label = t(`Saved to: ${placeLabel(here)}`, `저장할 곳: ${placeLabel(here)}`);
    return el(
      "button",
      {
        class: "mini ghost place",
        part: "memo-place",
        title: label,
        "aria-label": label,
        onclick: () => {
          this.place = open[(open.indexOf(here) + 1) % open.length];
          this.render();
        },
      },
      `${PLACE_MARK[here]} ${placeLabel(here)}`,
    );
  }

  private renderList(): void {
    const scope = this.deps.scope();
    const all = visibleMemos(this.deps.store.value.memos, scope);
    const query = all.length >= SEARCH_FROM ? this.search.value : "";
    this.list.replaceChildren();
    if (!all.length) {
      this.list.append(el("div", { class: "none" }, t("No memos", "메모 없음")));
      return;
    }
    if (query.trim()) {
      const found = shownMemos(all, query);
      if (!found.length) this.list.append(el("div", { class: "none" }, t("No matching memos.", "찾는 메모가 없어요.")));
      for (const memo of found) this.list.append(this.line(memo));
      return;
    }
    const { recent, pinned } = dockMemos(all, scope);
    if (recent.length) this.list.append(el("div", { class: "list-head" }, t("Recent", "최근 메모")), ...recent.map((m) => this.line(m)));
    if (pinned.length) this.list.append(el("div", { class: "list-head" }, t("📌 Pinned", "📌 고정")), ...pinned.map((m) => this.line(m)));
  }

  private line(memo: Memo): HTMLElement {
    return el(
      "div",
      { class: "line" },
      el("button", { part: "memo-item", title: memo.text.slice(0, 400), onclick: () => this.load(memo.text) }, el("span", { class: "t" }, `${memo.pinned ? "📌 " : ""}${placePrefix(placeOf(memo.owner))}${memoLabel(memo, 120)}`)),
      el("button", { class: "mini", title: t("Send as OOC now", "바로 OOC로 보내기"), "aria-label": t("Send as OOC", "OOC로 보내기"), onclick: () => void this.send(memo.text) }, "💬"),
      el(
        "button",
        {
          class: `mini${memo.pinned ? " on" : ""}`,
          title: memo.pinned ? t("Unpin", "고정 풀기") : t("Pin to top", "위에 고정"),
          "aria-pressed": String(!!memo.pinned),
          onclick: () =>
            this.deps.store.update((s) => {
              const m = s.memos.find((x) => x.id === memo.id);
              if (!m) return;
              if (m.pinned) delete m.pinned;
              else m.pinned = true;
            }),
        },
        icon("pin"),
      ),
    );
  }

  private load(text: string): void {
    this.box.value = text;
    this.box.focus();
    this.box.setSelectionRange(text.length, text.length);
  }

  private async send(text: string): Promise<boolean> {
    this.deps.close();
    return this.deps.sendOoc(text);
  }

  private async sendTyped(): Promise<void> {
    const text = this.box.value;
    if (!text.trim()) {
      this.box.focus();
      return;
    }
    // keep the draft when the send was cancelled or failed
    if ((await this.send(text)) && this.box.value === text) this.box.value = "";
  }

  private putTyped(): void {
    const text = this.box.value.trim();
    if (!text) return;
    this.deps.putInInput(text);
    this.box.value = "";
    this.deps.close();
  }

  private saveTyped(): void {
    const text = this.box.value.trim();
    if (!text) return;
    const place = this.place ?? this.deps.store.value.savePlace ?? "all";
    const memos = memosFrom(text, Date.now(), ownerFor(place, this.deps.scope()));
    this.deps.store.update((s) => s.memos.push(...memos));
    this.box.value = "";
    this.place = null;
    this.deps.ui.toast(memos.length > 1 ? t(`Saved ${memos.length} memos.`, `메모 ${memos.length}개를 저장했어요.`) : t("Saved to the Memo pad.", "메모장에 저장했어요."), "success", { title: "📝" });
  }
}
