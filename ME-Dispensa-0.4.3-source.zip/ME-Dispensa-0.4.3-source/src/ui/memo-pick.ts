// Choosing memos from the memo pad (the visz request box, a [[blank]], /memo).

import type { HostUI } from "../stscript/host";
import { textForAi } from "../memo/markdown";
import { memoLabel, shownMemos, visibleMemos } from "../memo/model";
import type { ChatScope } from "../qr/scopes";
import type { MemoStore } from "../memo/store";
import { t } from "../shared/i18n";

/** The chosen memos joined by blank lines, or null. Only memos shown in `scope`'s chat are offered. */
export async function pickMemos(ui: HostUI, memos: MemoStore, scope: ChatScope, prompt = t("Pick from the Memo pad (one or more)", "메모장에서 고르기 (여러 개 가능)"), query = ""): Promise<string | null> {
  const list = shownMemos(visibleMemos(memos.value.memos, scope), query);
  if (!list.length) {
    ui.toast(query ? t(`No memo contains "${query}".`, `"${query}"이(가) 든 메모가 없어요.`) : t("The Memo pad is empty. Select text in the chat and press 📝 to add it.", "메모장이 비어 있어요. 채팅에서 글을 긁어 📝을 누르면 들어가요."), "info", { title: "📝" });
    return null;
  }
  // labels must be unique for the picker
  const labels = list.map((m, i) => `${i + 1}. ${m.pinned ? "📌 " : ""}${memoLabel(m)}`);
  const picked = (await ui.pick?.(prompt, labels, { multiple: true, placeholder: t("Search", "찾기") })) ?? [];
  const chosen = picked.map((l) => list[labels.indexOf(l)]).filter(Boolean);
  // without the look-only tags: the text goes on to a page, a [[blank]] or a script
  return chosen.length ? chosen.map((m) => textForAi(m.text)).join("\n\n") : null;
}
