// Pictures stuck on the section layout like stickers: on top of the sections, anywhere, any size,
// turned a little. A tap picks one (its handles and tools show); dragging it moves it. A picture
// can go from a section to a sticker and back (board-frame-view.ts' tools, and the sticker's own).
// While one moves only its element changes; the board is saved on let go.

import { type Board, type BoardMagnet, type BoardSticker, STICKER_W, rotationFrom, topZ } from "../memo/board";
import { arrangeFrame } from "../memo/board-frame";
import { t } from "../shared/i18n";
import type { BoardContext } from "./board-context";
import { el } from "./dom";

export const BOARD_STICKERS_CSS = `
.board-frame { position: relative; }
/* the sections' own box (inside the padding), so shares of it line up with the columns */
.frame-stickers { position: absolute; inset: var(--pad); pointer-events: none; z-index: 6; }
.board-sticker { position: absolute; pointer-events: auto; touch-action: none; cursor: grab; transform-origin: 50% 50%; filter: drop-shadow(0 3px 4px rgb(0 0 0 / .3)); }
.board-sticker img { display: block; width: 100%; height: auto; pointer-events: none; -webkit-user-drag: none; }
.board-sticker.page img { box-sizing: border-box; border: 6px solid #fff; border-bottom-width: 20px; border-radius: 2px; background: #fff; }
.board-sticker.picked { outline: 2px dashed var(--d-accent); outline-offset: 4px; z-index: 1; }
.board-sticker.dragging { cursor: grabbing; }
.board-sticker .board-handle { z-index: 2; }
/* outside the corners: a sticker can be small */
.board-sticker .board-handle.resize { right: -11px; bottom: -11px; }
.board-sticker .board-handle.turn { left: calc(50% - 11px); top: -30px; }
.board-sticker .board-handle.drop { left: -11px; top: -11px; }
.board-sticker .sticker-tools { position: absolute; left: 50%; top: calc(100% + 14px); transform: translateX(-50%); display: flex; gap: 4px; white-space: nowrap; }
.board-sticker .sticker-tools button { width: auto; padding: 3px 8px; font-size: 12px; background: var(--d-panel-solid); color: var(--d-text); border: 1px solid var(--d-line); border-radius: 6px; }
`;

/** Screen pixels a pointer may wander and still be a tap. */
const TAP_SLOP = 6;

/** The sticker picked (its handles show), by magnet id. */
let picked: string | null = null;
/** Each board's scroll in the section layout, kept across redraws (the stage is drawn anew each time). */
const scrolls = new Map<string, { top: number; left: number }>();
let lastBoard = "";

/** Section rows from the top of the sections, as the sticker layer measures them. */
function rowPitch(layer: Element | null): number {
  const frame = layer?.closest(".board-frame");
  if (!frame) return 188;
  const style = getComputedStyle(frame);
  return (parseFloat(style.gridAutoRows) || 176) + (parseFloat(style.rowGap) || 0);
}

/** Where a new sticker goes: near the top of what is in view, a little right of the middle. */
export function stickerSpot(): BoardSticker {
  const top = scrolls.get(lastBoard)?.top ?? 0;
  return { x: 0.42, y: Math.round((top / 188 + 0.2) * 100) / 100, w: STICKER_W.default };
}

/** Keeps the stage's scroll across redraws and drops the pick on a tap elsewhere. */
export function watchStage(stage: HTMLElement, boardId: string): void {
  lastBoard = boardId;
  const kept = scrolls.get(boardId);
  // put back once the window has put the new stage in place (before it is painted)
  if (kept) requestAnimationFrame(() => stage.isConnected && ((stage.scrollTop = kept.top), (stage.scrollLeft = kept.left)));
  stage.addEventListener("scroll", () => scrolls.set(boardId, { top: stage.scrollTop, left: stage.scrollLeft }), { passive: true });
  // in place, without a redraw: a redraw here would replace the button being pressed and lose its click
  stage.addEventListener(
    "pointerdown",
    (e) => {
      if (!picked || (e.target as HTMLElement).closest(".board-sticker")) return;
      picked = null;
      for (const node of stage.querySelectorAll(".board-sticker.picked")) {
        node.classList.remove("picked");
        node.querySelectorAll(".board-handle, .sticker-tools").forEach((h) => h.remove());
      }
    },
    true,
  );
}

/** The stickers' layer, drawn over the sections. */
export function stickerLayer(ctx: BoardContext, board: Board): HTMLElement {
  const layer = el("div", { class: "frame-stickers" });
  const stickers = board.magnets.filter((m) => m.sticker).sort((a, b) => a.z - b.z);
  if (picked && !stickers.some((m) => m.id === picked)) picked = null;
  for (const m of stickers) layer.append(stickerEl(ctx, m, layer));
  return layer;
}

/** As saved: to three places. */
const tidy = (s: BoardSticker): BoardSticker => ({ x: Math.round(s.x * 1000) / 1000, y: Math.round(s.y * 1000) / 1000, w: Math.round(s.w * 1000) / 1000 });

function place(node: HTMLElement, s: BoardSticker, rotate = 0): void {
  // across: a share of the sections' width; down: in section rows, so it stays over the same
  // sections on a phone (smaller rows) and a computer
  node.style.left = `${s.x * 100}%`;
  node.style.top = `calc(${s.y} * (var(--row-h) + var(--gap)))`;
  node.style.width = `${s.w * 100}%`;
  node.style.transform = rotate ? `rotate(${rotate}deg)` : "";
}

function stickerEl(ctx: BoardContext, m: BoardMagnet, layer: HTMLElement): HTMLElement {
  const isPicked = picked === m.id;
  const node = el(
    "div",
    { class: `board-sticker${m.page ? " page" : ""}${isPicked ? " picked" : ""}`, "data-sticker": m.id, ...(m.page ? { title: m.page.title } : {}) },
    el("img", { src: m.image.url, alt: "", draggable: "false" }),
  );
  place(node, m.sticker!, m.rotate);
  if (isPicked) {
    const handle = (kind: "resize" | "turn") => {
      const h = el("div", { class: `board-handle ${kind}`, "data-handle": kind, title: kind === "resize" ? t("Drag to resize", "끌어서 크기 바꾸기") : t("Drag to turn", "끌어서 돌리기") });
      h.addEventListener("pointerdown", (e) => (kind === "resize" ? resize(ctx, e, m, node, layer) : turn(ctx, e, m, node)));
      return h;
    };
    const tool = (label: string, run: () => void) => el("button", { type: "button", onpointerdown: (e: Event) => e.stopPropagation(), onclick: (e: Event) => (e.stopPropagation(), run()) }, label);
    node.append(
      handle("resize"),
      handle("turn"),
      el("div", { class: "board-handle drop", role: "button", title: t("Remove the magnet", "마그넷 떼기"), onpointerdown: (e: Event) => e.stopPropagation(), onclick: () => update(ctx, m.id, (b) => (b.magnets = b.magnets.filter((x) => x.id !== m.id))) }, "✕"),
      el(
        "div",
        { class: "sticker-tools" },
        ...(m.page ? [tool(t("Open", "열기"), () => void openPage(ctx, m))] : []),
        tool(t("Into a section", "구획에 넣기"), () => {
          picked = null;
          update(ctx, m.id, (b) => {
            const x = b.magnets.find((y) => y.id === m.id);
            if (x) delete x.sticker;
            arrangeFrame(b);
          });
        }),
      ),
    );
  }
  node.addEventListener("pointerdown", (e) => move(ctx, e, m, node, layer));
  return node;
}

async function openPage(ctx: BoardContext, m: BoardMagnet): Promise<void> {
  const ok = await ctx.deps.openPage(m.page!.archiveId);
  if (!ok) ctx.deps.ui.toast(t("This page isn't in this browser's Gallery.", "이 페이지는 이 브라우저의 갤러리에 없어요."), "info", { title: "📋" });
}

function update(ctx: BoardContext, id: string, fn: (b: Board) => void): void {
  ctx.updateBoard((b) => {
    if (b.magnets.some((m) => m.id === id)) fn(b);
  });
}

/** Follows one pointer from `e` until it lets go; `step` gets how far it went, `done` whether it moved at all. */
function follow(e: PointerEvent, step: (ev: PointerEvent, dx: number, dy: number) => void, done: (moved: boolean, ev: PointerEvent) => void): void {
  const start = { x: e.clientX, y: e.clientY };
  let moved = false;
  (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
  const onMove = (ev: PointerEvent) => {
    if (ev.pointerId !== e.pointerId) return;
    const dx = ev.clientX - start.x;
    const dy = ev.clientY - start.y;
    if (!moved && Math.hypot(dx, dy) < TAP_SLOP) return;
    moved = true;
    step(ev, dx, dy);
  };
  const onUp = (ev: PointerEvent) => {
    if (ev.pointerId !== e.pointerId) return;
    window.removeEventListener("pointermove", onMove, true);
    window.removeEventListener("pointerup", onUp, true);
    window.removeEventListener("pointercancel", onUp, true);
    done(moved && ev.type !== "pointercancel", ev);
  };
  window.addEventListener("pointermove", onMove, true);
  window.addEventListener("pointerup", onUp, true);
  window.addEventListener("pointercancel", onUp, true);
}

const width = (layer: HTMLElement) => layer.getBoundingClientRect().width || 1;

function move(ctx: BoardContext, e: PointerEvent, m: BoardMagnet, node: HTMLElement, layer: HTMLElement): void {
  if ((e.target as HTMLElement).closest(".board-handle, .sticker-tools") || e.button > 0) return;
  e.preventDefault();
  e.stopPropagation();
  const from = { ...m.sticker! };
  let now = from;
  follow(
    e,
    (_ev, dx, dy) => {
      node.classList.add("dragging");
      now = { ...from, x: Math.max(0, Math.min(1 - STICKER_W.min, from.x + dx / width(layer))), y: Math.max(0, from.y + dy / rowPitch(layer)) };
      place(node, now, m.rotate);
    },
    (moved) => {
      node.classList.remove("dragging");
      if (!moved) {
        // a tap: pick it (or put it down)
        picked = picked === m.id ? null : m.id;
        ctx.deps.rerender();
        return;
      }
      picked = m.id;
      update(ctx, m.id, (b) => {
        const x = b.magnets.find((y) => y.id === m.id)!;
        x.sticker = tidy(now);
        x.z = topZ(b);
      });
    },
  );
}

function resize(ctx: BoardContext, e: PointerEvent, m: BoardMagnet, node: HTMLElement, layer: HTMLElement): void {
  e.preventDefault();
  e.stopPropagation();
  const from = { ...m.sticker! };
  let now = from;
  follow(
    e,
    (_ev, dx) => {
      now = { ...from, w: Math.max(STICKER_W.min, Math.min(STICKER_W.max, from.w + dx / width(layer))) };
      place(node, now, m.rotate);
    },
    (moved) => moved && update(ctx, m.id, (b) => (b.magnets.find((y) => y.id === m.id)!.sticker = tidy(now))),
  );
}

function turn(ctx: BoardContext, e: PointerEvent, m: BoardMagnet, node: HTMLElement): void {
  e.preventDefault();
  e.stopPropagation();
  const r = node.getBoundingClientRect();
  const centre = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  let deg = m.rotate ?? 0;
  follow(
    e,
    (ev) => {
      deg = rotationFrom(ev.clientX - centre.x, ev.clientY - centre.y);
      place(node, m.sticker!, deg);
    },
    (moved) =>
      moved &&
      update(ctx, m.id, (b) => {
        const x = b.magnets.find((y) => y.id === m.id)!;
        if (deg) x.rotate = deg;
        else delete x.rotate;
      }),
  );
}

/** A section's picture as a sticker where it was, at most a third of the board wide. */
export function peel(ctx: BoardContext, block: HTMLElement, id: string): void {
  const layer = block.closest(".board-frame")?.querySelector(".frame-stickers");
  if (!layer) return;
  const f = layer.getBoundingClientRect();
  const r = block.getBoundingClientRect();
  const sticker: BoardSticker = tidy({ x: Math.max(0, (r.left - f.left) / f.width), y: Math.max(0, (r.top - f.top) / rowPitch(layer)), w: Math.min(r.width / f.width, 0.33) });
  picked = id;
  update(ctx, id, (b) => {
    const m = b.magnets.find((x) => x.id === id)!;
    m.sticker = sticker;
    m.z = topZ(b);
    delete m.cell;
    // straight, as it lay in its section (a turn kept from an earlier time as a sticker would surprise)
    delete m.rotate;
    arrangeFrame(b);
  });
}
