// Toasts, popups, input boxes, pickers and a loading overlay, in a shadow root so
// Marinara's styles and ours never collide; colors use Marinara's theme variables.

import type { FormField, HostUI, PickGroup, PopupOptions, Severity } from "../stscript/host";
import { getComposerText, setComposerTextIfPresent } from "./composer-text";
import { el, icon } from "./dom";
import { sanitizeHtml } from "./sanitize";
import { CONTROLS, THEME_TOKENS } from "../shared/theme";
import { t } from "../shared/i18n";

const STYLE = `
:host { all: initial; }
${THEME_TOKENS}
* { box-sizing: border-box; }
.layer { position: fixed; inset: 0; z-index: 2147483000; pointer-events: none; font: 14px/1.45 var(--d-font); color: var(--d-text); }
${CONTROLS}
.toasts { position: fixed; top: 16px; right: 16px; display: flex; flex-direction: column; gap: 8px; max-width: min(380px, calc(100vw - 32px)); pointer-events: none; }
.toast { pointer-events: auto; padding: 10px 14px; border-radius: var(--d-radius); border: 1px solid var(--d-line);
  background: var(--d-panel-solid); box-shadow: var(--d-shadow); backdrop-filter: var(--d-shell-blur); -webkit-backdrop-filter: var(--d-shell-blur);
  font-size: 14px; line-height: 1.4; white-space: pre-wrap; word-break: break-word; animation: in .15s ease-out; }
.toast .title { font-weight: 600; margin-bottom: 2px; color: var(--d-title); }
.toast .toast-action { margin-left: 10px; padding: 2px 10px; font-size: 12px; }
.toast.success { border-color: #3fb97a; } .toast.warning { border-color: #e6a23c; } .toast.error { border-color: var(--d-danger); }
.backdrop { position: fixed; inset: 0; background: rgb(0 0 0 / .5); display: flex; align-items: center; justify-content: center; padding: 16px; pointer-events: auto; animation: fade .12s ease-out; }
.dialog { width: min(440px, 100%); max-height: calc(100vh - 32px); overflow: auto; padding: 18px;
  border-radius: calc(var(--d-radius) + 0.25rem); border: 1px solid var(--d-line); background: var(--d-panel-solid);
  box-shadow: 0 16px 48px rgb(0 0 0 / .45); backdrop-filter: var(--d-shell-blur); -webkit-backdrop-filter: var(--d-shell-blur); }
.dialog.wide { width: min(760px, 100%); } .dialog.large .body { min-height: 40vh; }
.body { font-size: 14px; line-height: 1.5; margin-bottom: 12px; overflow-wrap: anywhere; }
.body img { max-width: 100%; }
textarea, input:not([type=checkbox]):not([type=radio]), select { width: 100%; padding: 8px 10px; resize: vertical; }
.row { display: flex; gap: 8px; justify-content: flex-end; margin-top: 12px; flex-wrap: wrap; }
.row button { padding: 7px 14px; }
.row button.extra { margin-right: auto; }
.choices { display: flex; flex-direction: column; gap: 6px; }
.choices button { text-align: left; width: 100%; justify-content: flex-start; padding: 8px 12px; white-space: normal; }
.pick-list { max-height: 50vh; overflow: auto; margin-top: 8px; }
.pick-list .pick-group { display: flex; align-items: center; gap: 8px; font-weight: 600; }
.pick-list svg { width: 16px; height: 16px; flex: none; }
.pick-list .pick-group .grow { flex: 1; }
.pick-list .pick-group.open { border-color: var(--d-accent); }
.pick-list .pick-count { font-weight: 400; font-size: 12px; color: var(--d-muted); }
.pick-list .pick-items { display: flex; flex-direction: column; gap: 4px; padding-left: 18px; }
.fields { display: flex; flex-direction: column; gap: 10px; }
.field { display: flex; flex-direction: column; gap: 4px; font-size: 13px; color: var(--d-muted); }
.field.check { flex-direction: row; align-items: center; gap: 8px; color: var(--d-text); }
.field.check input { width: auto; }
.loader { position: fixed; inset: 0; background: rgb(0 0 0 / .4); display: flex; align-items: center; justify-content: center; flex-direction: column; gap: 12px; pointer-events: auto; }
.spinner { width: 36px; height: 36px; border-radius: 50%; border: 3px solid var(--d-line); border-top-color: var(--d-accent); animation: spin .8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
@keyframes in { from { opacity: 0; transform: translateY(-6px); } }
@keyframes fade { from { opacity: 0; } }
@media (prefers-reduced-motion: reduce) { * { animation: none !important; } }
`;

/** A yes/no question in any HostUI (its popup with Yes and No). */
export function confirmIn(ui: HostUI, message: string): Promise<boolean> {
  return ui.popup(message, { okButton: t("Yes", "예"), cancelButton: t("No", "아니요") });
}

export class Dialogs implements HostUI {
  private host: HTMLElement | null = null;
  private root: ShadowRoot | null = null;
  private layer: HTMLElement | null = null;
  private toastBox: HTMLElement | null = null;
  private loaderEl: HTMLElement | null = null;

  private ensure(): HTMLElement {
    if (this.layer?.isConnected) return this.layer;
    this.host = el("div", { id: "dispensa-dialogs" });
    this.root = this.host.attachShadow({ mode: "open" });
    this.toastBox = el("div", { class: "toasts" });
    this.layer = el("div", { class: "layer" }, this.toastBox);
    this.root.append(el("style", {}, STYLE), this.layer);
    document.body.append(this.host);
    return this.layer;
  }

  dispose(): void {
    this.host?.remove();
    this.host = this.root = this.layer = this.toastBox = this.loaderEl = null;
  }

  toast(message: string, severity: Severity = "info", options: { title?: string; action?: { label: string; run: () => void } } = {}): void {
    this.ensure();
    const action = options.action;
    // the toast closes on any click, so the button only has to run its action
    const button = action ? el("button", { class: "toast-action", onclick: () => action.run() }, action.label) : null;
    const toast = el("div", { class: `toast ${severity}`, role: severity === "error" ? "alert" : "status", onclick: () => toast.remove() }, options.title ? el("div", { class: "title" }, options.title) : null, message, button);
    this.toastBox!.append(toast);
    setTimeout(() => toast.remove(), severity === "error" ? 8000 : 4000);
  }

  private modal(build: (dialog: HTMLElement, close: () => void) => void, options: PopupOptions = {}, onCancel?: () => void): void {
    const layer = this.ensure();
    const backdrop = el("div", { class: "backdrop" });
    const dialog = el("div", { class: `dialog${options.wide ? " wide" : ""}${options.large ? " large" : ""}`, role: "dialog", "aria-modal": "true" });
    const close = () => {
      backdrop.remove();
      document.removeEventListener("keydown", onKey, true);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        close();
        onCancel?.();
      }
    };
    document.addEventListener("keydown", onKey, true);
    backdrop.addEventListener("mousedown", (e) => {
      if (e.target === backdrop) {
        close();
        onCancel?.();
      }
    });
    build(dialog, close);
    backdrop.append(dialog);
    layer.append(backdrop);
  }

  private body(html: string): HTMLElement {
    return el("div", { class: "body" }, sanitizeHtml(html));
  }

  private button(label: string, primary: boolean, onClick: () => void): HTMLButtonElement {
    return el("button", { type: "button", class: primary ? "primary" : undefined, onclick: onClick }, label);
  }

  private row(...buttons: HTMLElement[]): HTMLElement {
    return el("div", { class: "row" }, ...buttons);
  }

  input(prompt: string, options: PopupOptions = {}): Promise<string | null> {
    return new Promise((resolve) => {
      this.modal(
        (dialog, close) => {
          const multi = options.multiline || (options.rows ?? 1) > 1 || options.large;
          const field: HTMLTextAreaElement | HTMLInputElement = multi ? el("textarea") : el("input");
          if (field instanceof HTMLTextAreaElement) field.rows = Math.max(options.rows ?? 4, 2);
          field.value = options.defaultValue ?? "";
          field.placeholder = options.placeholder ?? "";
          const ok = () => {
            close();
            resolve(field.value);
          };
          field.addEventListener("keydown", (e) => {
            const ke = e as KeyboardEvent;
            if (ke.key === "Enter" && (!multi || ke.ctrlKey || ke.metaKey)) {
              ke.preventDefault();
              ok();
            }
          });
          const row = this.row();
          const extra = options.extra;
          if (extra) {
            const b = this.button(extra.label, false, async () => {
              const text = await extra.fill();
              if (text) {
                const at = field.selectionStart ?? field.value.length;
                const gap = field.value.slice(0, at).trim() ? (multi ? "\n" : " ") : "";
                field.setRangeText(gap + text, at, field.selectionEnd ?? at, "end");
              }
              field.focus();
            });
            if (extra.title) b.title = extra.title;
            b.classList.add("extra");
            row.append(b);
          }
          row.append(
            this.button(options.cancelButton ?? t("Cancel", "취소"), false, () => {
              close();
              resolve(null);
            }),
            this.button(options.okButton ?? t("OK", "확인"), true, ok),
          );
          dialog.append(this.body(prompt), field, row);
          // a suggested one-line answer is selected, so typing replaces it
          setTimeout(() => (field.focus(), !multi && field.value && field.select()), 0);
        },
        options,
        () => resolve(null),
      );
    });
  }

  popup(html: string, options: PopupOptions = {}): Promise<boolean> {
    return new Promise((resolve) => {
      this.modal(
        (dialog, close) => {
          const row = this.row();
          if (options.cancelButton) {
            row.append(
              this.button(options.cancelButton, false, () => {
                close();
                resolve(false);
              }),
            );
          }
          const ok = this.button(options.okButton ?? t("OK", "확인"), true, () => {
            close();
            resolve(true);
          });
          row.append(ok);
          dialog.append(this.body(html), row);
          setTimeout(() => ok.focus(), 0);
        },
        options,
        () => resolve(false),
      );
    });
  }

  /** A blank with suggested answers: click one, or type your own. Null when cancelled. */
  choose(label: string, options: string[]): Promise<string | null> {
    return new Promise((resolve) => {
      this.modal(
        (dialog, close) => {
          const field = el("input", { placeholder: t("Or type it", "또는 직접 입력"), style: "margin-top:8px" });
          const done = (value: string | null) => {
            close();
            resolve(value);
          };
          const list = el("div", { class: "choices" }, ...options.map((option) => this.button(option, false, () => done(option))));
          field.addEventListener("keydown", (e) => {
            if ((e as KeyboardEvent).key === "Enter" && !(e as KeyboardEvent).isComposing) {
              e.preventDefault();
              done(field.value);
            }
          });
          const row = this.row(this.button(t("Cancel", "취소"), false, () => done(null)), this.button(t("OK", "확인"), true, () => done(field.value)));
          dialog.append(el("div", { class: "body" }, label), list, field, row);
          setTimeout(() => field.focus(), 0);
        },
        {},
        () => resolve(null),
      );
    });
  }

  buttons(html: string, labels: string[], options: { multiple?: boolean } = {}): Promise<string> {
    return new Promise((resolve) => {
      this.modal(
        (dialog, close) => {
          const list = el("div", { class: "choices" });
          const picked = new Set<string>();
          for (const label of labels) {
            const b = this.button(label, false, () => {
              if (!options.multiple) {
                close();
                resolve(label);
                return;
              }
              if (picked.has(label)) picked.delete(label);
              else picked.add(label);
              b.className = picked.has(label) ? "primary" : "";
            });
            list.append(b);
          }
          const row = this.row(
            this.button(t("Cancel", "취소"), false, () => {
              close();
              resolve("");
            }),
          );
          if (options.multiple) {
            row.append(
              this.button(t("OK", "확인"), true, () => {
                close();
                resolve(JSON.stringify([...picked]));
              }),
            );
          }
          if (html.trim()) dialog.append(this.body(html));
          dialog.append(list, row);
        },
        {},
        () => resolve(""),
      );
    });
  }

  form(title: string, fields: FormField[]): Promise<Record<string, string> | null> {
    return new Promise((resolve) => {
      this.modal(
        (dialog, close) => {
          const controls: { name: string; get: () => string }[] = [];
          const body = el("div", { class: "fields" });
          for (const f of fields) {
            const caption = el("span", {}, f.label ?? f.name);
            let control: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement;
            if (f.type === "textarea") control = el("textarea", { rows: "3" });
            else if (f.type === "select") control = el("select", {}, ...(f.options ?? []).map((o) => new Option(o, o)));
            else control = el("input", { type: f.type === "number" ? "number" : f.type === "checkbox" ? "checkbox" : "text" });
            if (control instanceof HTMLInputElement && control.type === "checkbox") control.checked = /^(true|on|1|yes)$/i.test(f.default ?? "");
            else control.value = f.default ?? "";
            if ("placeholder" in control && f.placeholder) control.placeholder = f.placeholder;
            const field = control;
            controls.push({ name: f.name, get: () => (field instanceof HTMLInputElement && field.type === "checkbox" ? String(field.checked) : field.value) });
            body.append(el("label", { class: f.type === "checkbox" ? "field check" : "field" }, ...(f.type === "checkbox" ? [control, caption] : [caption, control])));
          }
          const ok = () => {
            close();
            resolve(Object.fromEntries(controls.map((x) => [x.name, x.get()])));
          };
          body.addEventListener("keydown", (e) => {
            const ke = e as KeyboardEvent;
            if (ke.key === "Enter" && (ke.ctrlKey || ke.metaKey || (ke.target as HTMLElement).tagName === "INPUT")) {
              ke.preventDefault();
              ok();
            }
          });
          const row = this.row(
            this.button(t("Cancel", "취소"), false, () => {
              close();
              resolve(null);
            }),
            this.button(t("OK", "확인"), true, ok),
          );
          if (title.trim()) dialog.append(this.body(title));
          dialog.append(body, row);
          setTimeout(() => (body.querySelector("input, textarea, select") as HTMLElement | null)?.focus(), 0);
        },
        {},
        () => resolve(null),
      );
    });
  }

  pick(prompt: string, items: string[], options: { multiple?: boolean; placeholder?: string; groups?: PickGroup[] } = {}): Promise<string[]> {
    return new Promise((resolve) => {
      this.modal(
        (dialog, close) => {
          const search = el("input", { type: "search", placeholder: options.placeholder ?? t("Search…", "검색…") });
          const list = el("div", { class: "choices pick-list" });
          const picked = new Set<string>();
          const groups = (options.groups ?? []).filter((g) => g.items.length);
          // with groups and no search: one open at a time (the only one, when there is just one)
          let open: PickGroup | null = groups.length === 1 ? groups[0] : null;
          let active = 0;
          const grouped = () => groups.length > 0 && !search.value.trim();
          const visible = () => {
            if (grouped()) return open ? open.items : [];
            return items.filter((i) => i.toLowerCase().includes(search.value.trim().toLowerCase()));
          };
          const option = (item: string, label: string, index: number) => {
            const b = this.button(label, picked.has(item) || (!options.multiple && index === active), () => choose(item));
            b.setAttribute("role", "option");
            return b;
          };
          const draw = () => {
            const shown = visible();
            active = Math.min(active, Math.max(0, shown.length - 1));
            if (grouped()) {
              list.replaceChildren(
                ...groups.flatMap((g) => {
                  const isOpen = g === open;
                  const head = el(
                    "button",
                    { type: "button", class: `pick-group${isOpen ? " open" : ""}`, "aria-expanded": String(isOpen), onclick: () => ((open = isOpen ? null : g), (active = 0), draw()) },
                    g.icon?.trim() ? el("span", { class: "pick-icon" }, g.icon.trim()) : icon("folder"),
                    el("span", { class: "grow" }, g.label),
                    el("span", { class: "pick-count" }, String(g.items.length)),
                  );
                  return isOpen ? [head, el("div", { class: "pick-items" }, ...g.items.map((item, i) => option(item, g.names[i] ?? item, i)))] : [head];
                }),
              );
              return;
            }
            list.replaceChildren(...shown.slice(0, 300).map((item, index) => option(item, item, index)));
            if (!shown.length) list.append(el("div", { class: "body" }, t("No results.", "검색 결과가 없어요.")));
          };
          const choose = (item: string) => {
            if (!options.multiple) {
              close();
              resolve([item]);
              return;
            }
            if (picked.has(item)) picked.delete(item);
            else picked.add(item);
            draw();
          };
          search.addEventListener("input", () => {
            active = 0;
            draw();
          });
          search.addEventListener("keydown", (e) => {
            const shown = visible();
            if (e.key === "ArrowDown") active = Math.min(active + 1, shown.length - 1);
            else if (e.key === "ArrowUp") active = Math.max(active - 1, 0);
            else if (e.key === "Enter" && shown[active]) {
              e.preventDefault();
              choose(shown[active]);
              return;
            } else return;
            e.preventDefault();
            draw();
          });
          const row = this.row(
            this.button(t("Cancel", "취소"), false, () => {
              close();
              resolve([]);
            }),
          );
          if (options.multiple) {
            row.append(
              this.button(t("OK", "확인"), true, () => {
                close();
                resolve(items.filter((i) => picked.has(i)));
              }),
            );
          }
          if (prompt.trim()) dialog.append(this.body(prompt));
          dialog.append(search, list, row);
          draw();
          setTimeout(() => search.focus(), 0);
        },
        {},
        () => resolve([]),
      );
    });
  }

  async notify(title: string, body: string): Promise<void> {
    try {
      if (typeof Notification !== "undefined") {
        if (Notification.permission === "default") await Notification.requestPermission();
        if (Notification.permission === "granted") {
          new Notification(title, { body });
          return;
        }
      }
    } catch {
      // fall back to a toast
    }
    this.toast(body, "info", { title });
  }

  async copy(text: string): Promise<void> {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const area = el("textarea", { style: "position:fixed;opacity:0" });
      area.value = text;
      document.body.append(area);
      area.select();
      document.execCommand("copy");
      area.remove();
    }
  }

  async paste(): Promise<string> {
    try {
      return await navigator.clipboard.readText();
    } catch {
      return (await this.input(t("Paste here (the browser blocked the clipboard).", "여기에 붙여 넣어 주세요 (브라우저가 클립보드를 막았어요)."), { multiline: true, rows: 4 })) ?? "";
    }
  }

  confirm(message: string): Promise<boolean> {
    return confirmIn(this, message);
  }

  setInput(text: string): void {
    setComposerTextIfPresent(text);
  }

  getInput(): string {
    return getComposerText();
  }

  beep(): void {
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = 880;
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.25);
      osc.connect(gain).connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {
      // audio may be blocked; a missing beep is harmless
    }
  }

  loader(state: "show" | "hide", text = ""): void {
    if (state === "hide") {
      this.loaderEl?.remove();
      this.loaderEl = null;
      return;
    }
    const layer = this.ensure();
    this.loaderEl?.remove();
    this.loaderEl = el("div", { class: "loader" }, el("div", { class: "spinner" }), text ? el("div", {}, text) : null);
    layer.append(this.loaderEl);
  }
}
