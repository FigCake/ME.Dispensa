// A memo board's card, its title block, and the card shown large to read and write.

import { type Board, type BoardCard } from "../memo/board";
import { inkOn, themeById, themeColors } from "../memo/board-themes";
import { toggleCheck } from "../memo/markdown";
import { type Memo, memoLabel } from "../memo/model";
import { t } from "../shared/i18n";
import type { BoardContext } from "./board-context";
import { el } from "./dom";
import { memoEditor } from "./memo-editor";
import { renderMemo } from "./memo-render";
import { dropMenu } from "./menu";

export const BOARD_CARD_CSS = `
.board-card { position: absolute; transform-origin: 50% 50%; border-radius: 6px; padding: 10px 12px 12px; box-shadow: 0 3px 10px rgb(0 0 0 / .22);
  background: #fffaf0; color: #2b2b2b; cursor: pointer; max-height: 420px; overflow: hidden; touch-action: none; }
.board-card::after { content: ""; position: absolute; left: 0; right: 0; bottom: 0; height: 28px; pointer-events: none;
  background: linear-gradient(transparent, var(--paper, #fffaf0)); }
.board-card .card-title { font-weight: 700; margin-bottom: 4px; font-size: 15px; }
.board-card .memo-drawn { font-size: 14px; line-height: 1.5; word-break: break-word; }
.board-card .memo-drawn h1 { font-size: 1.3em; } .board-card .memo-drawn h2 { font-size: 1.15em; } .board-card .memo-drawn h3 { font-size: 1.05em; }
.board-card .memo-drawn p, .board-card .memo-drawn ul, .board-card .memo-drawn ol { margin: .3em 0; }
.board-card .memo-drawn ul, .board-card .memo-drawn ol { padding-left: 1.3em; }
.board-card .memo-drawn ul.checks { list-style: none; padding-left: 0; }
.board-card .memo-drawn ul.checks label { display: inline-flex; flex-direction: row; gap: 5px; align-items: baseline; font-size: inherit; color: inherit; }
.board-card .memo-drawn .done > label > span { text-decoration: line-through; opacity: .6; }
.board-card .memo-drawn code { font-family: var(--d-mono); font-size: .9em; background: rgb(0 0 0 / .07); padding: 0 3px; border-radius: 3px; }
.board-over .paper { padding: 14px 16px; border-radius: 8px; box-shadow: 0 3px 12px rgb(0 0 0 / .2); max-width: 720px; width: 100%; align-self: center; }
.board-over .paper .card-title { font-weight: 700; font-size: 18px; margin-bottom: 6px; }
.board-over .paper .memo-body { background: transparent; border: none; padding: 0; color: inherit; }
`;

const two = (n: number) => String(n).padStart(2, "0");

/** `num`: its place in what the board sends (0: none). */
export function cardEl(ctx: BoardContext, card: BoardCard, memo: Memo, num: number, moving = false): HTMLElement {
  const alt = num % 3 === 2 ? " alt1" : num % 4 === 0 ? " alt2" : "";
  const node = el("div", { class: `board-card${alt}${moving ? " moving" : ""}`, "data-card": card.memoId, role: "button", tabindex: "0", "aria-label": memoLabel(memo, 60) || t("(empty memo)", "(빈 메모)") });
  if (card.color) {
    node.style.setProperty("--card", card.color);
    node.style.setProperty("--ink", inkOn(card.color));
    node.style.background = card.color;
    node.style.color = inkOn(card.color);
  }
  const day = new Date(memo.createdAt || Date.now());
  const numbered = ctx.board()?.numbers !== false && num > 0;
  node.append(el("div", { class: "card-head" }, numbered ? el("span", { class: "num" }, two(num)) : null, el("span", { class: "meta" }, `${two(day.getMonth() + 1)}.${two(day.getDate())}`)));
  if (memo.title?.trim()) node.append(el("div", { class: "card-title" }, memo.title.trim()));
  node.append(
    el(
      "div",
      { class: "memo-drawn" },
      ...renderMemo(memo.text, {
        // redraw: the numbers change when an empty card gets text
        onToggle: (index) => {
          ctx.mutateMemo(memo.id, (m) => (m.text = toggleCheck(m.text, index)));
          ctx.deps.rerender();
        },
        useFont: (f) => ctx.deps.useFont(f),
      }),
    ),
  );
  node.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && e.target === node) ctx.openCard(card.memoId);
  });
  return node;
}

export function boardHead(ctx: BoardContext, board: Board, inFrame = false): HTMLElement {
  const n = two(ctx.boards().findIndex((b) => b.id === board.id) + 1);
  const big = inFrame && themeById(board.theme?.id).numbered;
  return el("header", { class: "board-head" }, big ? el("div", { class: "big" }, `№${n}`) : null, el("h1", {}, board.name));
}

export interface ZoomHooks {
  writing: boolean;
  write(on: boolean): void;
  close(): void;
}

/** A card shown large over the board: read, write, recolor, send. */
export function zoomPanel(ctx: BoardContext, card: BoardCard, memo: Memo, z: ZoomHooks): HTMLElement {
  const colors = themeColors(ctx.board()?.theme);
  const paper = card.color ?? colors.card ?? colors.paper;
  const setColor = (value: string | null) =>
    ctx.updateBoard((b) => {
      const c = b.cards.find((x) => x.memoId === card.memoId);
      if (!c) return;
      if (value) c.color = value;
      else delete c.color;
    });
  const color = el("input", { type: "color", value: paper, title: t("Paper color", "메모지 색"), "aria-label": t("Paper color", "메모지 색") }) as HTMLInputElement;
  color.addEventListener("change", () => setColor(color.value));
  const head = el(
    "div",
    { class: "over-head" },
    el("button", { onclick: z.close, title: t("Back to the board", "보드로 돌아가기") }, "‹ ", t("Board", "보드")),
    el("span", { class: "grow" }),
    color,
    dropMenu("⋯", t("Card menu", "카드 메뉴"), [
      { label: t("💬 Send as OOC", "💬 OOC로 보내기"), run: () => (ctx.deps.close(), void ctx.deps.sendOoc(memo.text)) },
      { label: t("Put in the input", "입력창에 넣기"), run: () => (ctx.deps.close(), ctx.deps.putInInput(memo.text)) },
      { label: t("🖼 Run a QR inside the Gallery", "🖼 갤러리 내부에서 QR 실행"), run: () => ctx.deps.runForGallery(memo.text, memoLabel(memo, 40)) },
      { label: t("Open in the 📝 tab", "📝 탭에서 열기"), run: () => ctx.deps.openMemo(memo.id) },
      { label: t("Plain paper", "기본 메모지"), run: () => setColor(null) },
      "-",
      { label: t("Off the board", "보드에서 빼기"), sub: t("The memo stays", "메모는 남아요"), danger: true, run: () => (ctx.takeOff(memo.id), z.close()) },
    ]),
  );
  const paperEl = el("div", { class: "paper" });
  paperEl.style.background = paper;
  paperEl.style.color = inkOn(paper);
  if (z.writing) {
    const title = el("input", {
      type: "text",
      value: memo.title ?? "",
      placeholder: t("Title (optional)", "제목 (선택)"),
      "data-key": `board-title-${memo.id}`,
      "aria-label": t("Memo title", "메모 제목"),
      oninput: (e: Event) => ctx.mutateMemo(memo.id, (m) => {
        const v = (e.target as HTMLInputElement).value;
        if (v.trim()) m.title = v;
        else delete m.title;
      }),
    });
    paperEl.append(
      el(
        "div",
        { class: "memo-edit" },
        title,
        ...memoEditor({
          text: memo.text,
          key: `board-memo-${memo.id}`,
          onText: (text) => ctx.mutateMemo(memo.id, (m) => (m.text = text)),
          onDone: () => z.write(false),
          fonts: () => ctx.deps.fonts(),
        }),
      ),
    );
  } else {
    if (memo.title?.trim()) paperEl.append(el("div", { class: "card-title" }, memo.title.trim()));
    const drawn = renderMemo(memo.text, {
      onToggle: (index) => {
        ctx.mutateMemo(memo.id, (m) => (m.text = toggleCheck(m.text, index)));
        ctx.deps.rerender();
      },
      useFont: (f) => ctx.deps.useFont(f),
    });
    paperEl.append(
      el(
        "div",
        { class: "memo-body", role: "button", tabindex: "0", onclick: () => z.write(true) },
        ...(drawn.length ? drawn : [el("span", { class: "empty" }, t("Empty", "빈 메모"))]),
      ),
    );
  }
  return el("div", { class: "board-over", role: "dialog", "aria-label": memoLabel(memo, 60) }, head, paperEl);
}
