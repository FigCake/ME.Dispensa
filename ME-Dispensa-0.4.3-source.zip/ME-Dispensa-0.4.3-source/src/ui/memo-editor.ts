// The memo text box with its format buttons; the editing steps are in memo/markdown.ts.

import { type Edit, type LineKind, continueList, setLines, styleSelection, wrap } from "../memo/markdown";
import { t } from "../shared/i18n";
import { el } from "./dom";

export const MEMO_EDITOR_CSS = `
.memo-tools { display: flex; flex-wrap: wrap; gap: 3px; align-items: center; }
.memo-tools > button { min-width: 2em; padding: 3px 7px; font-size: 12.5px; justify-content: center; }
.memo-tools .sep { width: 1px; align-self: stretch; margin: 2px 3px; background: var(--d-line); }
.memo-tools input[type=color] { width: 2em; height: 1.9em; padding: 1px; border-radius: var(--d-radius-sm); cursor: pointer; }
.memo-tools select { width: auto; max-width: 9em; padding: 3px 6px; font-size: 12.5px; }
.memo-edit .done-line { display: flex; justify-content: flex-end; }
`;

export interface MemoEditorDeps {
  text: string;
  /** The text box's data-key, so the window keeps its caret across redraws. */
  key: string;
  onText(text: string): void;
  onDone(): void;
  fonts(): Promise<string[]>;
}

/** Installed fonts are added after these. */
const BASIC_FONTS: [string, () => string][] = [
  ["sans-serif", () => t("Sans", "고딕")],
  ["serif", () => t("Serif", "명조")],
  ["monospace", () => t("Monospace", "고정폭")],
];
const SIZES: [string, () => string][] = [
  ["0.85em", () => t("Small", "작게")],
  ["1.25em", () => t("Large", "크게")],
  ["1.6em", () => t("Huge", "아주 크게")],
];

/** Generic names bare, the rest in quotes. */
const familyValue = (family: string) => (BASIC_FONTS.some(([f]) => f === family) ? family : `'${family.replace(/'/g, "")}'`);

export function memoEditor(deps: MemoEditorDeps): HTMLElement[] {
  const ta = el("textarea", { "data-key": deps.key, "aria-label": t("Memo text", "메모 내용"), oninput: () => deps.onText(ta.value) });
  ta.value = deps.text;
  // just opened (the button or text that opened it is gone, so nothing has focus): typing goes here
  setTimeout(() => {
    const root = ta.getRootNode() as Document | ShadowRoot;
    if (!ta.isConnected || (root.activeElement && root.activeElement !== document.body)) return;
    ta.focus();
    ta.setSelectionRange(ta.value.length, ta.value.length);
  }, 0);
  const apply = (step: (e: Edit) => Edit | null): boolean => {
    const next = step({ text: ta.value, start: ta.selectionStart, end: ta.selectionEnd });
    if (!next) return false;
    ta.value = next.text;
    ta.focus();
    ta.setSelectionRange(next.start, next.end);
    deps.onText(next.text);
    return true;
  };
  ta.addEventListener("keydown", (e) => {
    // not while an IME is composing (Korean, Japanese): Enter there ends the syllable
    if (e.key !== "Enter" || e.shiftKey || e.ctrlKey || e.metaKey || e.altKey || e.isComposing) return;
    if (apply(continueList)) e.preventDefault();
  });

  // pressing a button must not take the selection out of the text box
  const keep = (e: Event) => e.preventDefault();
  const button = (label: string, title: string, run: () => void, style = "") =>
    el("button", { type: "button", title, "aria-label": title, style, onmousedown: keep, onclick: run }, label);
  const marks = (label: string, title: string, open: string, close: string, style = "") => button(label, title, () => apply((e) => wrap(e, open, close)), style);
  const lines = (label: string, title: string, kind: LineKind) => button(label, title, () => apply((e) => setLines(e, kind)));

  const color = el("input", { type: "color", value: "#e5484d", title: t("Text color", "글자색"), "aria-label": t("Text color", "글자색") }) as HTMLInputElement;
  // "change" (not "input"): one span per pick, not one per step of the picker
  color.addEventListener("change", () => apply((e) => styleSelection(e, "color", color.value)));
  const noColor = button("⌀", t("No color", "글자색 빼기"), () => apply((e) => styleSelection(e, "color", "")));

  const choose = (label: string, options: [string, string][], run: (value: string) => void) => {
    const select = el("select", { "aria-label": label, title: label }) as HTMLSelectElement;
    const fill = (list: [string, string][]) => select.replaceChildren(el("option", { value: "" }, label), el("option", { value: "-" }, t("Default", "기본")), ...list.map(([v, l]) => el("option", { value: v }, l)));
    fill(options);
    select.addEventListener("change", () => {
      const v = select.value;
      select.value = "";
      if (v) run(v === "-" ? "" : v);
    });
    return { select, fill };
  };
  const size = choose(t("Size", "크기"), SIZES.map(([v, l]) => [v, l()]), (v) => apply((e) => styleSelection(e, "font-size", v)));
  const basic = BASIC_FONTS.map(([v, l]): [string, string] => [v, l()]);
  const font = choose(t("Font", "글꼴"), basic, (v) => apply((e) => styleSelection(e, "font-family", v && familyValue(v))));
  void deps
    .fonts()
    .then((names) => names.length && font.fill([...basic, ...names.map((n): [string, string] => [n, n])]))
    .catch(() => undefined);

  const sep = () => el("span", { class: "sep" });
  const tools = el(
    "div",
    { class: "memo-tools", role: "toolbar", "aria-label": t("Format", "서식") },
    marks("B", t("Bold", "굵게"), "**", "**", "font-weight:700"),
    marks("I", t("Italic", "기울임"), "*", "*", "font-style:italic"),
    marks("S", t("Strikethrough", "취소선"), "~~", "~~", "text-decoration:line-through"),
    marks("U", t("Underline", "밑줄"), "<u>", "</u>", "text-decoration:underline"),
    marks("</>", t("Code", "코드"), "`", "`"),
    sep(),
    lines("H1", t("Heading 1", "제목 1"), "h1"),
    lines("H2", t("Heading 2", "제목 2"), "h2"),
    lines("H3", t("Heading 3", "제목 3"), "h3"),
    sep(),
    lines("•", t("Bulleted list", "점 목록"), "bullet"),
    lines("1.", t("Numbered list", "번호 목록"), "number"),
    lines("☐", t("Checklist", "체크박스 목록"), "check"),
    sep(),
    color,
    noColor,
    size.select,
    font.select,
  );
  const done = el("div", { class: "done-line" }, el("button", { type: "button", onclick: () => deps.onDone() }, t("Done", "완료")));
  return [tools, ta, done];
}
