// A board's look on its tab, and the 🎨 panel to pick, change, save and share one.

import type { Board } from "../memo/board";
import {
  ALL_COLORS,
  BOARD_THEMES,
  type BoardLook,
  FONT_KINDS,
  MAX_CSS,
  PATTERNS,
  SHADOWS,
  type SavedTheme,
  type ThemeColor,
  type ThemeStyle,
  allColors,
  chipDefault,
  cssProblem,
  inkOn,
  lookOf,
  normalizeTheme,
  ownsChip,
  readThemeFile,
  sameLook,
  savedOf,
  themeById,
  themeColors,
  themeFile,
} from "../memo/board-themes";
import { t } from "../shared/i18n";
import { newId } from "../util";
import type { BoardContext } from "./board-context";
import { BOARD_THEME_CSS } from "./board-theme-css";
import { confirmIn } from "./dialogs";
import { el } from "./dom";
import { helpTip } from "../shared/form";
import { downloadJson, pickFiles } from "./files";

export const BOARD_THEME_PANEL_CSS = `
.theme-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; }
.theme-grid button { display: grid; gap: 6px; width: auto; padding: 6px; border-radius: 10px; text-align: left; background: transparent; border: 1px solid var(--d-line); }
.theme-grid button[aria-pressed="true"] { border-color: var(--d-accent); box-shadow: 0 0 0 2px var(--d-ring); }
.theme-grid button span { font-size: 12.5px; padding: 0 2px; }
.theme-chips { display: flex; flex-wrap: wrap; gap: 10px 18px; align-items: center; }
.theme-chips label { display: inline-flex; flex-direction: row; align-items: center; gap: 6px; font-size: 13px; color: var(--d-text); }
.theme-chips input[type=color] { width: 2.4em; height: 2em; padding: 1px; cursor: pointer; }
.theme-chips .reset, .theme-shape .reset { width: auto; padding: 2px 6px; font-size: 12px; }
.theme-chips.more { margin-top: 8px; }
.theme-grid .mine { position: relative; display: grid; }
.theme-grid .mine > button { width: 100%; min-width: 0; box-sizing: border-box; }
.theme-grid .mine > button > span { padding-right: 58px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.theme-grid .mine .acts { position: absolute; right: 6px; bottom: 4px; display: flex; gap: 3px; }
.theme-grid .mine .acts button { width: 24px; height: 24px; padding: 0; justify-content: center; font-size: 12px; border-radius: 6px; }
.theme-files { display: flex; flex-wrap: wrap; gap: 6px; }
.theme-files button { width: auto; padding: 4px 10px; }
.theme-shape { display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 8px 16px; }
.theme-shape label { display: grid; grid-template-columns: 6.5em 1fr auto; align-items: center; gap: 6px; font-size: 13px; color: var(--d-text); }
.theme-shape select, .theme-shape input[type=range] { width: 100%; min-width: 0; }
.theme-css textarea { width: 100%; min-height: 9em; font: 12px/1.45 var(--d-mono); resize: vertical; }
.theme-css .row { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 6px; }
.theme-css .row button { width: auto; padding: 4px 10px; }
${BOARD_THEME_CSS}
`;

const fontCss = (font: string) => ((FONT_KINDS as readonly string[]).includes(font) ? `var(--bt-${font})` : `"${font}", var(--bt-sans)`);

/** Puts the look on the board's tab; the user's CSS is nested under the tab so it can't reach anything else. */
export function dressBoard(tab: HTMLElement, board: Board, useFont: (family: string) => void = () => {}): void {
  const theme = themeById(board.theme?.id);
  const colors = themeColors(board.theme);
  tab.classList.add("bt", `bt-${theme.id}`);
  for (const [key, value] of Object.entries(colors)) tab.style.setProperty(`--${key}`, value);
  for (const key of Object.keys(board.theme?.colors ?? {}) as ThemeColor[]) if (!ownsChip(theme, key)) tab.classList.add(`x-${key}`);
  tab.style.setProperty("--on-accent", inkOn(colors.accent ?? "#888888"));
  // for the zoom level beside the buttons
  tab.style.setProperty("--on-paper", inkOn(colors.paper ?? "#888888"));
  tab.style.setProperty("--on-card2", inkOn(colors.card2 ?? colors.ink ?? "#888888"));
  const style = board.theme?.style;
  if (!style) return;
  for (const [cls, font] of [["s-tfont", style.titleFont], ["s-cfont", style.cardFont]] as const) {
    if (!font) continue;
    tab.classList.add(cls);
    tab.style.setProperty(`--${cls}`, fontCss(font));
    if (!(FONT_KINDS as readonly string[]).includes(font)) useFont(font);
  }
  if (style.radius !== undefined) {
    tab.classList.add("s-radius");
    tab.style.setProperty("--s-radius", `${style.radius}px`);
  }
  if (style.shadow) tab.classList.add(`s-shadow-${style.shadow}`);
  if (style.pattern) tab.classList.add("s-pattern", `s-pattern-${style.pattern}`);
  if (style.css && !cssProblem(style.css)) {
    tab.classList.add("bt-own");
    tab.append(el("style", {}, `.board-tab.bt-own {\n${style.css}\n}`));
  }
}

function miniLook(id: string, look: Record<string, string>): HTMLElement {
  const mini = el("div", { class: `bt bt-mini bt-${id}` }, el("div", { class: "mc" }, el("b", {}, "01"), el("i"), el("i")), el("div", { class: "dot" }));
  for (const [key, value] of Object.entries(look)) mini.style.setProperty(`--${key}`, value);
  return mini;
}

export function themePanel(ctx: BoardContext, board: Board, close: () => void): HTMLElement {
  const current = themeById(board.theme?.id);
  const look: BoardLook = board.theme ?? { id: current.id };
  const saved = ctx.state().themes ?? [];
  const head = el("div", { class: "over-head" }, el("button", { onclick: close }, "‹ ", t("Board", "보드")), el("strong", {}, t("Theme", "테마")), el("span", { class: "grow" }));
  const grid = el("div", { class: "theme-grid" });
  // a board showing one of "My themes" marks that one, not its base theme
  const mineShown = saved.find((s) => sameLook(board.theme, s));
  for (const theme of BOARD_THEMES) {
    const mini = miniLook(theme.id, theme.id === current.id && !mineShown ? themeColors(look) : themeColors({ id: theme.id }));
    grid.append(
      el(
        "button",
        {
          "aria-pressed": String(theme.id === current.id && !mineShown),
          onclick: () => ctx.updateBoard((b) => (b.theme = theme.id === b.theme?.id ? b.theme : { id: theme.id })),
        },
        mini,
        el("span", {}, t(theme.name[0], theme.name[1])),
      ),
    );
  }
  const lookName = mineShown?.name ?? t(current.name[0], current.name[1]);
  const files = el(
    "div",
    { class: "theme-files" },
    el("button", { onclick: () => void saveLook(ctx, look, lookName) }, "💾 ", t("Save this look", "이 모양 저장")),
    el("button", { onclick: () => downloadJson(themeFile(lookName, look), `${lookName}.board-theme.json`) }, "⬇ ", t("Save as a file", "파일로 저장")),
    el("button", { onclick: () => pickFiles((list) => void loadFiles(ctx, list), { json: true, multiple: true }) }, "⬆ ", t("Load a theme file", "테마 파일 불러오기")),
  );
  const changed = Object.keys(look.colors ?? {}).length > 0 || !!look.style;
  return el(
    "div",
    { class: "board-over", role: "dialog", "aria-label": t("Theme", "테마") },
    head,
    // the user's own first: on a phone the twelve themes run long
    files,
    saved.length ? el("strong", {}, t("My themes", "내 테마")) : null,
    saved.length ? myThemes(ctx, board, saved) : null,
    el("strong", {}, t(`Colors of ${current.name[0]}`, `${current.name[1]} 색`)),
    colorChips(ctx, look),
    el("strong", {}, t("Shape", "모양")),
    shapeControls(ctx, look),
    cssBox(ctx, look),
    changed ? el("button", { style: "width:auto;justify-self:start", onclick: () => ctx.updateBoard((b) => (b.theme = { id: current.id })) }, t(`All back to ${current.name[0]} as it comes`, `모두 ${current.name[1]} 기본으로`)) : null,
    el("strong", {}, t("Themes", "테마"), helpTip(t("Grid themes keep cards straight and lined up. A theme's fonts show when Marinara has them", "격자 테마는 카드를 반듯하게 맞춤. 테마 글꼴은 마리나라에 있을 때만"), t("Themes", "테마"))),
    grid,
  );
}

/** The theme's own chips, then the others (folded). */
function colorChips(ctx: BoardContext, look: BoardLook): HTMLElement {
  const theme = themeById(look.id);
  const colors = allColors(look);
  const changed = look.colors ?? {};
  const chip = (key: ThemeColor, label: [string, string]) => {
    const input = el("input", { type: "color", value: colors[key], "aria-label": t(label[0], label[1]) }) as HTMLInputElement;
    input.addEventListener("change", () => recolor(ctx, key, input.value));
    return el(
      "label",
      {},
      input,
      t(label[0], label[1]),
      changed[key] ? el("button", { class: "reset ghost", title: t("Theme's color", "테마 기본 색"), onclick: (e: Event) => (e.preventDefault(), recolor(ctx, key, null)) }, "↺") : null,
    );
  };
  const own = el("div", { class: "theme-chips" }, ...theme.colors.map((c) => chip(c.key, c.label)));
  const others = ALL_COLORS.filter((c) => !ownsChip(theme, c.key));
  if (!others.length) return own;
  const more = el("details", { class: "fold", ...(others.some((c) => changed[c.key]) ? { open: true } : {}) }, el("summary", {}, t("More colors", "색 더 보기")), el("div", { class: "theme-chips more" }, ...others.map((c) => chip(c.key, c.label))));
  return el("div", {}, own, more);
}

function shapeControls(ctx: BoardContext, look: BoardLook): HTMLElement {
  const style = look.style ?? {};
  const themes = t("Theme's", "테마 기본");
  const select = (key: keyof ThemeStyle, label: string, options: [string, string][], value: string | undefined) => {
    const box = el("select", { "aria-label": label }, el("option", { value: "" }, themes), ...options.map(([v, text]) => el("option", { value: v, ...(v === value ? { selected: true } : {}) }, text))) as HTMLSelectElement;
    box.addEventListener("change", () => restyle(ctx, { [key]: box.value || undefined }));
    return { box, row: el("label", {}, label, box, el("span")) };
  };
  const kinds: [string, string][] = [
    ["sans", t("Sans", "고딕")],
    ["serif", t("Serif", "명조")],
    ["italic", t("Italic serif", "이탤릭 세리프")],
    ["mono", t("Monospace", "고정폭")],
    ["display", t("Display", "디스플레이")],
  ];
  const fontRow = (key: "titleFont" | "cardFont", label: string) => {
    const current = style[key];
    const extra: [string, string][] = current && !kinds.some(([k]) => k === current) ? [[current, current]] : [];
    const { box, row } = select(key, label, [...kinds, ...extra], current);
    void ctx.deps.fonts().then((families) => {
      for (const f of families) if (f !== current) box.append(el("option", { value: f }, f));
    });
    return row;
  };
  const radius = el("input", { type: "range", min: "0", max: "40", step: "1", value: String(style.radius ?? 12), "aria-label": t("Corners", "모서리") }) as HTMLInputElement;
  radius.addEventListener("change", () => restyle(ctx, { radius: Number(radius.value) }));
  const shadowNames: Record<string, string> = { none: t("None", "없음"), soft: t("Soft", "은은하게"), strong: t("Strong", "진하게") };
  const patternNames: Record<string, string> = { none: t("None", "없음"), dots: t("Dots", "점"), grid: t("Grid", "격자"), lines: t("Lines", "줄") };
  return el(
    "div",
    { class: "theme-shape" },
    fontRow("titleFont", t("Title font", "제목 글꼴")),
    fontRow("cardFont", t("Card font", "카드 글꼴")),
    el(
      "label",
      {},
      t("Corners", "모서리"),
      radius,
      style.radius !== undefined ? el("button", { class: "reset ghost", title: themes, onclick: (e: Event) => (e.preventDefault(), restyle(ctx, { radius: undefined })) }, "↺") : el("span", { class: "note" }, themes),
    ),
    select("shadow", t("Shadow", "그림자"), SHADOWS.map((s) => [s, shadowNames[s]]), style.shadow).row,
    select("pattern", t("Background", "바탕 무늬"), PATTERNS.map((p) => [p, patternNames[p]]), style.pattern).row,
    select("tilt", t("Cards", "카드"), [["straight", t("Kept straight", "반듯하게")], ["tilted", t("Tilted as placed", "놓은 대로 기울게")]], style.tilt).row,
  );
}

function cssBox(ctx: BoardContext, look: BoardLook): HTMLElement {
  const area = el("textarea", { spellcheck: "false", maxlength: String(MAX_CSS), placeholder: ".board-card { border: 2px dashed var(--accent); }\n.board-head h1 { letter-spacing: 4px; }", "aria-label": t("Your CSS", "직접 쓰는 CSS") }) as HTMLTextAreaElement;
  area.value = look.style?.css ?? "";
  const apply = () => {
    const css = area.value.trim();
    const problem = css ? cssProblem(css) : null;
    if (problem) {
      ctx.deps.ui.toast(
        problem === "too-long"
          ? t(`The CSS is over ${MAX_CSS} characters.`, `CSS가 ${MAX_CSS}자를 넘어요.`)
          : problem === "unbalanced"
            ? t("The CSS has a { or } (or a quote) that isn't closed.", "CSS에 닫히지 않은 { } 또는 따옴표가 있어요.")
            : t("The CSS uses something a board can't: url() other than a data: picture, @import and other @ rules but @media/@supports/@container/@keyframes, position: fixed or sticky, \"<\" or a backslash.", "보드에서 쓸 수 없는 것이 있어요: data: 그림이 아닌 url(), @import 같은 @규칙(@media·@supports·@container·@keyframes는 돼요), position: fixed·sticky, \"<\", 역슬래시."),
        "warning",
      );
      return;
    }
    restyle(ctx, { css: css || undefined });
  };
  return el(
    "details",
    { class: "fold theme-css", ...(look.style?.css ? { open: true } : {}) },
    el("summary", {}, t("Advanced: your own CSS", "고급: CSS 직접 쓰기"), helpTip(t(
      "Applies only inside this board, after the theme. Parts: .board-card, .card-title, .card-head .num, .card-head .meta, .board-head h1, .board-surface; colors: var(--paper), var(--card), var(--ink), var(--accent)… It goes with the look into My themes and theme files.",
      "이 보드 안에만, 테마 다음에 적용돼요. 부분: .board-card, .card-title, .card-head .num, .card-head .meta, .board-head h1, .board-surface / 색: var(--paper), var(--card), var(--ink), var(--accent)… 내 테마와 테마 파일에도 같이 저장돼요.",
    ), "CSS")),
    area,
    el(
      "div",
      { class: "row" },
      el("button", { onclick: apply }, t("Apply", "적용")),
      look.style?.css ? el("button", { class: "ghost", onclick: () => restyle(ctx, { css: undefined }) }, t("Remove", "지우기")) : null,
    ),
  );
}

function myThemes(ctx: BoardContext, board: Board, saved: SavedTheme[]): HTMLElement {
  const grid = el("div", { class: "theme-grid" });
  for (const s of saved) {
    const look = lookOf(s);
    grid.append(
      el(
        "div",
        { class: "mine" },
        el("button", { "aria-pressed": String(sameLook(board.theme, s)), onclick: () => ctx.updateBoard((b) => (b.theme = lookOf(s))) }, miniLook(s.base, themeColors(look)), el("span", {}, s.name)),
        el(
          "div",
          { class: "acts" },
          el("button", { class: "ghost", title: t("Save as a file", "파일로 저장"), "aria-label": t("Save as a file", "파일로 저장"), onclick: () => downloadJson(themeFile(s.name, look), `${s.name}.board-theme.json`) }, "⬇"),
          el("button", { class: "ghost", title: t("Remove from My themes", "내 테마에서 지우기"), "aria-label": t("Remove from My themes", "내 테마에서 지우기"), onclick: () => void forget(ctx, s) }, "✕"),
        ),
      ),
    );
  }
  return grid;
}

async function saveLook(ctx: BoardContext, look: BoardLook, suggested: string): Promise<void> {
  const name = (await ctx.deps.ui.input(t("A name for this look", "이 모양의 이름"), { defaultValue: suggested }))?.trim();
  if (!name) return;
  ctx.deps.store.update((s) => {
    const list = s.themes ?? [];
    const same = list.find((x) => x.name === name);
    const entry = savedOf(same?.id ?? newId("theme"), name, look);
    s.themes = same ? list.map((x) => (x === same ? entry : x)) : [...list, entry];
  });
  ctx.deps.ui.toast(t(`Saved to My themes: ${name}`, `내 테마에 저장했어요: ${name}`), "success");
}

/** The board takes the last file read. */
async function loadFiles(ctx: BoardContext, files: File[]): Promise<void> {
  const added: SavedTheme[] = [];
  for (const file of files) {
    let read: ReturnType<typeof readThemeFile>;
    try {
      read = readThemeFile(JSON.parse(await file.text()));
    } catch {
      read = { error: "not-a-theme" };
    }
    if ("error" in read) {
      ctx.deps.ui.toast(read.error === "unknown-theme" ? t(`${file.name}: made from a theme this Dispensa doesn't have (update Dispensa?)`, `${file.name}: 이 Dispensa에 없는 테마로 만든 파일이에요(Dispensa를 업데이트해 보세요)`) : t(`${file.name} isn't a board theme file`, `${file.name}은(는) 보드 테마 파일이 아니에요`), "warning");
      continue;
    }
    if (read.droppedCss) ctx.deps.ui.toast(t(`${file.name}: its CSS uses something a board can't, so it was left out.`, `${file.name}: 보드에서 쓸 수 없는 CSS가 있어서 CSS는 빼고 불러왔어요.`), "warning");
    added.push(savedOf(newId("theme"), read.name, read.look));
  }
  const last = added.at(-1);
  if (!last) return;
  ctx.deps.store.update((s) => {
    // a file read twice replaces the one of its name
    const keep = (s.themes ?? []).filter((x) => !added.some((a) => a.name === x.name));
    s.themes = [...keep, ...added];
  });
  ctx.updateBoard((b) => (b.theme = lookOf(last)));
  ctx.deps.ui.toast(t(`Loaded into My themes: ${added.map((a) => a.name).join(", ")}`, `내 테마로 불러왔어요: ${added.map((a) => a.name).join(", ")}`), "success");
}

async function forget(ctx: BoardContext, s: SavedTheme): Promise<void> {
  if (!(await confirmIn(ctx.deps.ui, t(`Remove "${s.name}" from My themes? Boards using it keep their look.`, `"${s.name}"을(를) 내 테마에서 지울까요? 이 모양을 쓰는 보드는 그대로예요.`)))) return;
  ctx.deps.store.update((st) => {
    const list = (st.themes ?? []).filter((x) => x.id !== s.id);
    if (list.length) st.themes = list;
    else delete st.themes;
  });
}

/** null: back to its default. */
function recolor(ctx: BoardContext, key: ThemeColor, value: string | null): void {
  ctx.updateBoard((b) => {
    const theme = themeById(b.theme?.id);
    const colors = { ...(b.theme?.colors ?? {}), [key]: value ?? chipDefault(theme, key) };
    b.theme = normalizeTheme({ ...b.theme, id: theme.id, colors }) ?? { id: theme.id };
  });
}

/** undefined: back to the theme's. */
function restyle(ctx: BoardContext, change: Partial<ThemeStyle>): void {
  ctx.updateBoard((b) => {
    const theme = themeById(b.theme?.id);
    const style: Record<string, unknown> = { ...(b.theme?.style ?? {}) };
    for (const [k, v] of Object.entries(change)) {
      if (v === undefined) delete style[k];
      else style[k] = v;
    }
    b.theme = normalizeTheme({ ...b.theme, id: theme.id, style }) ?? { id: theme.id };
  });
}
