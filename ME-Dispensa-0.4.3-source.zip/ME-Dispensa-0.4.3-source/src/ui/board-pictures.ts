// The 📋 tab's picture list for a board's background or a magnet, kept in Marinara's Global Gallery.

import { type BoardImage, BOARD_H, BOARD_W, MAGNET_SIZE, clampTo, topZ } from "../memo/board";
import { arrangeFrame } from "../memo/board-frame";
import { stickerSpot } from "./board-stickers";
import { t } from "../shared/i18n";
import { newId } from "../util";
import type { BoardContext, Slot } from "./board-context";
import { confirmIn } from "./dialogs";
import { el, icon } from "./dom";
import { pickFiles } from "./files";
import { helpTip } from "../shared/form";

export const BOARD_PICTURES_CSS = `
.board-images { display: grid; grid-template-columns: repeat(auto-fill, minmax(96px, 1fr)); gap: 8px; }
.board-images .pic { position: relative; aspect-ratio: 1; border-radius: var(--d-radius-sm); border: 1px solid var(--d-line); overflow: hidden; background: var(--d-field); padding: 0; }
.board-images .pic img { width: 100%; height: 100%; object-fit: contain; pointer-events: none; }
.board-images .pic .del { position: absolute; right: 3px; top: 3px; width: 22px; height: 22px; padding: 0; border-radius: 50%; font-size: 12px; justify-content: center; }
`;

export class BoardPictures {
  /** null: closed. */
  private kind: "background" | "magnet" | null = null;
  private slot: Slot | null = null;
  private pictures: BoardImage[] | null = null;
  private busy = false;

  /** `centerPoint`: where a new magnet goes in the free layout. */
  constructor(private readonly ctx: BoardContext, private readonly centerPoint: () => { x: number; y: number }) {}

  get isOpen(): boolean {
    return this.kind !== null;
  }

  open(kind: "background" | "magnet", slot: Slot | null = null): void {
    this.kind = kind;
    this.slot = slot;
    this.ctx.deps.rerender();
    void this.load();
  }

  close(): void {
    this.kind = null;
  }

  panel(): HTMLElement {
    const head = el(
      "div",
      { class: "over-head" },
      el("button", { onclick: () => (this.close(), this.ctx.deps.rerender()) }, "‹ ", t("Board", "보드")),
      el("strong", {}, this.kind === "background" ? t("Background picture", "배경 그림") : t("Magnets", "마그넷")),
      helpTip(t("Pictures are kept in Marinara's Global Gallery, in the Dispensa folder, so every device sees them.", "그림은 마리나라 전역 갤러리의 Dispensa 폴더에 저장돼요. 다른 기기에서도 보여요."), t("Pictures", "그림")),
      el("span", { class: "grow" }),
      el("button", { disabled: this.busy, onclick: () => pickFiles((files) => void this.upload(files), { accept: "image/png,image/jpeg,image/gif,image/webp,image/avif", multiple: true }) }, icon("upload"), this.busy ? t("Uploading…", "올리는 중…") : t("Upload", "올리기")),
    );
    const grid = el("div", { class: "board-images" });
    if (this.pictures === null) grid.append(el("div", { class: "note" }, t("Loading…", "불러오는 중…")));
    else if (!this.pictures.length) grid.append(el("div", { class: "note" }, t("No pictures", "그림 없음")));
    for (const pic of this.pictures ?? []) {
      grid.append(
        el(
          "button",
          { class: "pic", title: t("Use this picture", "이 그림 쓰기"), onclick: () => this.use(pic) },
          el("img", { src: pic.url, alt: "", loading: "lazy" }),
          el(
            "button",
            {
              class: "del ghost",
              title: t("Delete from the Gallery", "갤러리에서 지우기"),
              "aria-label": t("Delete", "지우기"),
              onclick: (e: Event) => {
                e.stopPropagation();
                void this.remove(pic);
              },
            },
            "✕",
          ),
        ),
      );
    }
    return el("div", { class: "board-over", role: "dialog" }, head, grid);
  }

  private async load(): Promise<void> {
    try {
      this.pictures = await this.ctx.deps.images.list();
    } catch (e) {
      this.pictures = [];
      this.ctx.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("Pictures", "그림") });
    }
    this.ctx.deps.rerender();
  }

  private async upload(files: File[]): Promise<void> {
    if (!files.length) return;
    this.busy = true;
    this.ctx.deps.rerender();
    try {
      for (const f of files) await this.ctx.deps.images.upload(f);
    } catch (e) {
      this.ctx.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("Upload", "올리기") });
    } finally {
      this.busy = false;
    }
    await this.load();
  }

  private use(pic: BoardImage): void {
    if (this.kind === "background") {
      this.ctx.updateBoard((b) => (b.background = { image: pic }));
    } else {
      const at = this.centerPoint();
      const cell = this.slot;
      this.ctx.updateBoard((b) => {
        // in the section layout: into the section it was asked for, else a sticker on top
        const sticker = b.layout === "frame" && !cell ? { sticker: stickerSpot() } : {};
        b.magnets.push({ id: newId("magnet"), image: pic, x: Math.round(clampTo(at.x, 0, BOARD_W - MAGNET_SIZE.default)), y: Math.round(clampTo(at.y, 0, BOARD_H - MAGNET_SIZE.default)), size: MAGNET_SIZE.default, z: topZ(b), ...(cell ? { cell: { ...cell, w: 1, h: 1 } } : {}), ...sticker });
        if (b.layout === "frame") arrangeFrame(b);
      });
    }
    this.close();
    this.ctx.deps.rerender();
  }

  private async remove(pic: BoardImage): Promise<void> {
    const used = this.ctx.boards().filter((b) => b.background?.image?.id === pic.id || b.magnets.some((m) => m.image.id === pic.id)).length;
    const ask = used
      ? t(`Delete this picture? It is used on ${used} ${used === 1 ? "board" : "boards"} and goes from them too.`, `이 그림을 지울까요? 보드 ${used}개에서 쓰고 있어서 거기서도 사라져요.`)
      : t("Delete this picture from the Global Gallery?", "이 그림을 전역 갤러리에서 지울까요?");
    if (!(await confirmIn(this.ctx.deps.ui, ask))) return;
    try {
      await this.ctx.deps.images.remove(pic.id);
    } catch (e) {
      this.ctx.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("Pictures", "그림") });
      return;
    }
    this.ctx.deps.store.update((s) => {
      for (const b of s.boards ?? []) {
        b.magnets = b.magnets.filter((m) => m.image.id !== pic.id);
        if (b.background?.image?.id === pic.id) delete b.background;
      }
    });
    await this.load();
  }
}
