// Draws a memo's text node by node: the memo's text never becomes HTML.

import { type Block, type Inline, parseMemo } from "../memo/markdown";
import { el } from "./dom";

export const MEMO_RENDER_CSS = `
.memo-body { padding: 8px 10px; border: 1px solid var(--d-field-border); border-radius: var(--d-radius-sm); background: var(--d-field);
  cursor: text; white-space: normal; word-break: break-word; line-height: 1.55; min-height: 2.4em; }
.memo-body:hover { border-color: var(--d-btn-border-hover); }
.memo-body > :first-child { margin-top: 0; } .memo-body > :last-child { margin-bottom: 0; }
.memo-body h1, .memo-body h2, .memo-body h3 { margin: .5em 0 .3em; line-height: 1.3; color: var(--d-title); }
.memo-body h1 { font-size: 1.4em; } .memo-body h2 { font-size: 1.2em; } .memo-body h3 { font-size: 1.05em; }
.memo-body p { margin: .35em 0; }
.memo-body ul, .memo-body ol { margin: .35em 0; padding-left: 1.4em; }
.memo-body ul.checks { list-style: none; padding-left: .2em; }
.memo-body ul.checks label { display: inline-flex; flex-direction: row; gap: 6px; align-items: baseline; cursor: pointer; font-size: inherit; color: inherit; }
.memo-body ul.checks .done > label > span { text-decoration: line-through; color: var(--d-muted); }
.memo-body code { font-family: var(--d-mono); font-size: .9em; padding: 0 4px; border-radius: 4px; background: var(--d-btn-bg); }
.memo-body .empty { color: var(--d-muted); }
`;

export interface MemoRenderHooks {
  /** `index`: the checkbox's number from the top. */
  onToggle(index: number): void;
  /** A font a span uses, to load it. */
  useFont(family: string): void;
}

export function renderMemo(text: string, hooks: MemoRenderHooks): HTMLElement[] {
  return parseMemo(text).map((b) => block(b, hooks));
}

function block(b: Block, hooks: MemoRenderHooks): HTMLElement {
  if (b.kind === "heading") return el(`h${b.level}` as "h1", {}, ...inlines(b.content, hooks));
  if (b.kind === "paragraph") return el("p", {}, ...b.lines.flatMap((line, i) => [...(i ? [el("br")] : []), ...inlines(line, hooks)]));
  if (b.kind === "list") {
    const list = el(b.ordered ? "ol" : "ul", b.ordered && b.start !== 1 ? { start: String(b.start) } : {});
    for (const item of b.items) list.append(indented(el("li", {}, ...inlines(item.content, hooks)), item.indent));
    return list;
  }
  const list = el("ul", { class: "checks" });
  for (const item of b.items) {
    const box = el("input", { type: "checkbox" }) as HTMLInputElement;
    box.checked = item.checked;
    box.addEventListener("click", (e) => {
      // the body opens the editor on click; a box only ticks
      e.stopPropagation();
      hooks.onToggle(item.index);
    });
    const label = el("label", { onclick: (e: Event) => e.stopPropagation() }, box, el("span", {}, ...inlines(item.content, hooks)));
    list.append(indented(el("li", { class: item.checked ? "done" : "" }, label), item.indent));
  }
  return list;
}

function indented(li: HTMLElement, indent: number): HTMLElement {
  if (indent) li.style.marginLeft = `${indent * 1.2}em`;
  return li;
}

function inlines(list: Inline[], hooks: MemoRenderHooks): Node[] {
  return list.map((n) => inline(n, hooks));
}

function inline(n: Inline, hooks: MemoRenderHooks): Node {
  switch (n.kind) {
    case "text":
      return document.createTextNode(n.text);
    case "code":
      return el("code", {}, n.text);
    case "bold":
      return el("strong", {}, ...inlines(n.children, hooks));
    case "italic":
      return el("em", {}, ...inlines(n.children, hooks));
    case "strike":
      return el("s", {}, ...inlines(n.children, hooks));
    case "underline":
      return el("u", {}, ...inlines(n.children, hooks));
    case "span": {
      const span = el("span", {}, ...inlines(n.children, hooks));
      // set as properties, so a value can only ever be a color, a size or a font name
      if (n.style.color) span.style.color = n.style.color;
      if (n.style.size) span.style.fontSize = n.style.size;
      if (n.style.font) {
        span.style.fontFamily = n.style.font;
        hooks.useFont(n.style.font);
      }
      return span;
    }
  }
}
