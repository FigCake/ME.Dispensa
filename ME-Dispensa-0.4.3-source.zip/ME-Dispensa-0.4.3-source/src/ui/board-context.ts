// What the parts of the 📋 tab share: the window's hooks and the open board. `BoardView` makes it.

import type { Board, BoardImage } from "../memo/board";
import type { Memo, MemoState } from "../memo/model";
import type { MemoStore } from "../memo/store";
import type { ChatScope } from "../qr/scopes";
import type { HostUI } from "../stscript/host";

export interface BoardViewDeps {
  store: MemoStore;
  ui: HostUI;
  rerender(): void;
  scope(): ChatScope;
  fonts(): Promise<string[]>;
  useFont(family: string): void;
  sendOoc(text: string): Promise<boolean>;
  /** Runs a QR the user picks for the Gallery, with `text` as its memo. */
  runForGallery(text: string, title: string): void;
  /** The Gallery tab of the Dispensa window. */
  openGallery(): void;
  /** Opens a Gallery page in the viewer; false when this browser doesn't have it. */
  openPage(archiveId: string): Promise<boolean>;
  putInInput(text: string): void;
  makePage(text: string): Promise<boolean>;
  close(): void;
  openMemo(id: string): void;
  images: {
    list(): Promise<BoardImage[]>;
    upload(file: File): Promise<BoardImage>;
    remove(id: string): Promise<void>;
  };
}

export type Slot = { c: number; r: number };

export interface BoardContext {
  readonly deps: BoardViewDeps;
  state(): MemoState;
  boards(): Board[];
  /** The open board (the first one when none was chosen). */
  board(): Board | null;
  updateBoard(fn: (b: Board) => void): void;
  mutateMemo(id: string, fn: (m: Memo) => void): void;
  /** 0 when the theme lets cards lie free. */
  grid(): number;
  openCard(memoId: string): void;
  takeOff(memoId: string): void;
  addMemos(slot?: Slot): Promise<void>;
  /** Opens the picture list for a magnet (into `slot` in the section layout). */
  pickMagnet(slot?: Slot): void;
}
