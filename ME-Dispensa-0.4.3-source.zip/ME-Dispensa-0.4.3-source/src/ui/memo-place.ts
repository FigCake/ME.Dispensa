// How the memo pad names where a memo shows (every chat, this character, this chat).

import type { MemoPlace } from "../memo/model";
import { t } from "../shared/i18n";

export const PLACE_MARK: Record<MemoPlace, string> = { all: "🌐", character: "👤", chat: "📍" };

export function placeLabel(place: MemoPlace): string {
  if (place === "chat") return t("This chat", "이 채팅");
  if (place === "character") return t("This character", "이 캐릭터");
  return t("Every chat", "전체");
}

/** The mark in front of a memo in lists: none for every-chat memos. */
export const placePrefix = (place: MemoPlace): string => (place === "all" ? "" : `${PLACE_MARK[place]} `);
