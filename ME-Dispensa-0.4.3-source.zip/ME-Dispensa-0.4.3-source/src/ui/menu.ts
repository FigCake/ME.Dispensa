// A small drop-down menu of actions (a <details> with buttons); styled by details.menu in the window's CSS.

import { el } from "./dom";

/** One action, or "-" for a divider. */
export type MenuEntry = { label: string; /** Shown on hover. */ sub?: string; danger?: boolean; run: () => void | Promise<void> } | "-";

/** `summaryContent` is what the closed menu shows; `label` names it for screen readers. */
export function dropMenu(summaryContent: Node | string, label: string, entries: MenuEntry[], opensRight = false): HTMLElement {
  const menu = el("details", { class: opensRight ? "menu right" : "menu" });
  const summary = el("summary", { role: "button", "aria-label": label, title: label }, summaryContent);
  const list = el("div", { class: "menu-list" });
  for (const e of entries) {
    if (e === "-") {
      list.append(el("hr"));
      continue;
    }
    list.append(
      el(
        "button",
        {
          class: e.danger ? "danger-item" : "",
          title: e.sub,
          onclick: () => {
            menu.open = false;
            void e.run();
          },
        },
        e.label,
      ),
    );
  }
  menu.append(summary, list);
  // the list opens to the left of its button; when that would be cut off (a button near the left
  // edge), it opens to the right instead, and the other way round
  menu.addEventListener("toggle", () => {
    if (!menu.open) return;
    menu.classList.toggle("right", opensRight);
    const box = clipBox(menu);
    const r = list.getBoundingClientRect();
    const flip = () => menu.classList.toggle("right");
    if (!opensRight && r.left < box.left) flip();
    else if (opensRight && r.right > box.right) flip();
    else return;
    // neither side fits (a narrow phone): it opens the side with more room
    const after = list.getBoundingClientRect();
    if (after.left < box.left || after.right > box.right) {
      const lostNow = Math.max(0, box.left - after.left) + Math.max(0, after.right - box.right);
      const lostBefore = Math.max(0, box.left - r.left) + Math.max(0, r.right - box.right);
      if (lostBefore < lostNow) flip();
    }
  });
  menu.addEventListener("focusout", (ev) => {
    if (!menu.contains((ev as FocusEvent).relatedTarget as Node)) menu.open = false;
  });
  return menu;
}

/** The left and right edges of what `node` is drawn inside: the nearest box that cuts off what sticks out, else the window. */
function clipBox(node: Element): { left: number; right: number } {
  for (let n: Element | null = parentOf(node); n; n = parentOf(n)) {
    const style = getComputedStyle(n);
    if (style.overflowX !== "visible" || style.overflow !== "visible") {
      const r = n.getBoundingClientRect();
      return { left: Math.max(0, r.left), right: Math.min(window.innerWidth, r.right) };
    }
  }
  return { left: 0, right: window.innerWidth };
}

/** The parent element, through a shadow root to its host. */
const parentOf = (n: Element): Element | null => n.parentElement ?? ((n.getRootNode() as ShadowRoot).host || null);
