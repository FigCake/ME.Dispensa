// visz: pure helpers (no Marinara or DOM access).
// Older replies wrapped a light page in <!-- …_START --> / <!-- …_END --> markers: they are still read.

import { t as tr } from "../shared/i18n";
import { escapeHtml, escapeRegex } from "../util";

const FENCE_RE = /```[ \t]*([\w-]*)[^\n]*\n([\s\S]*?)(?:\n[ \t]*```|```)/g;
const DOC_RE = /<!doctype\s+html|<html[\s>]|<body[\s>]/i;
const TAG_RE = /<[a-z][a-z0-9-]*[\s>/]/i;
const OLD_MARKERS = /<!--\s*WAND_START\s*-->([\s\S]*?)(?:<!--\s*WAND_END\s*-->|$)/gi;

export interface HtmlBlock {
  start: number;
  end: number;
  lang: string;
  code: string;
  title: string;
  complete: boolean;
}

/** True when the code is a whole HTML document (or at least has a body). */
function looksLikeHtmlDoc(code: string): boolean {
  return DOC_RE.test(String(code ?? ""));
}

/** True when a fenced block holds HTML worth showing as a page. */
function isRenderableBlock(lang: string, code: string): boolean {
  const l = String(lang ?? "").toLowerCase();
  if (looksLikeHtmlDoc(code)) return true;
  return (l === "html" || l === "htm") && TAG_RE.test(String(code ?? ""));
}

/** False when a document was cut off before its closing tag. Fragments count as complete. */
function isCompleteHtml(code: string): boolean {
  const c = String(code ?? "").trim();
  if (/<html[\s>]/i.test(c) || /^<!doctype/i.test(c)) return /<\/html\s*>\s*$/i.test(c);
  if (/<body[\s>]/i.test(c)) return /<\/body\s*>/i.test(c);
  return true;
}

function docTitle(code: string): string {
  const m = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(String(code ?? ""));
  return m ? m[1].replace(/\s+/g, " ").trim() : "";
}

/** HTML pages in a reply, in order: fenced ```html blocks and fragments between the older markers. */
export function extractHtmlBlocks(text: string): HtmlBlock[] {
  const out: HtmlBlock[] = [];
  const src = String(text ?? "");
  FENCE_RE.lastIndex = 0;
  let m: RegExpExecArray | null;
  while ((m = FENCE_RE.exec(src))) {
    const [whole, lang, code] = m;
    if (!isRenderableBlock(lang, code)) continue;
    out.push({ start: m.index, end: m.index + whole.length, lang, code, title: docTitle(code), complete: isCompleteHtml(code) });
  }
  OLD_MARKERS.lastIndex = 0;
  while ((m = OLD_MARKERS.exec(src))) {
    if (out.some((b) => m!.index >= b.start && m!.index < b.end)) continue;
    const code = m[1].trim();
    out.push({ start: m.index, end: m.index + m[0].length, lang: "html", code, title: docTitle(code), complete: /WAND_END/i.test(m[0]) });
  }
  return out.sort((a, b) => a.start - b.start);
}

/** Keeps the block's fence. */
export function replaceHtmlBlock(text: string, index: number, code: string): string {
  const b = extractHtmlBlocks(text)[index];
  if (!b) return text;
  const fence = "```" + (b.lang || "html") + "\n" + code.replace(/\s+$/, "") + "\n```";
  return text.slice(0, b.start) + fence + text.slice(b.end);
}

export function stripReasoning(text: string, tags: string[] = ["think", "thinking"]): string {
  let t = String(text ?? "");
  for (const tag of tags) {
    const name = escapeRegex(tag);
    t = t.replace(new RegExp(`<${name}>[\\s\\S]*?</${name}>`, "gi"), "");
    // Prefilled opening tag: the reply starts inside the block.
    t = t.replace(new RegExp(`^[\\s\\S]*?</${name}>`, "i"), (m) => (new RegExp(`<${name}>`, "i").test(m) ? m : ""));
    // Unclosed block: drop from the opening tag to the end.
    t = t.replace(new RegExp(`<${name}>[\\s\\S]*$`, "i"), "");
  }
  return t;
}

/** Removes a single Markdown fence wrapped around a whole reply. */
function stripOuterFence(text: string): string {
  const t = String(text ?? "").trim();
  const m = /^```[\w-]*[^\n]*\n([\s\S]*?)(?:\n?```)?$/.exec(t);
  return m ? m[1] : t;
}

export interface NormalizedOutput {
  text: string;
  blocks: HtmlBlock[];
  truncated: boolean;
}

/** Cleans a reply: drops reasoning, closes a dangling fence, fences a bare HTML document. */
export function normalizeOutput(raw: string): NormalizedOutput {
  let t = stripReasoning(raw).trim();
  const fences = (t.match(/```/g) || []).length;
  if (fences % 2 === 1) t += "\n```";
  if (!/```/.test(t)) {
    const start = t.search(/<!doctype\s+html|<html[\s>]/i);
    if (start >= 0) {
      const tail = t.slice(start);
      const endMatch = /<\/html\s*>/i.exec(tail);
      const end = endMatch ? start + endMatch.index + endMatch[0].length : t.length;
      t = t.slice(0, start) + "```html\n" + t.slice(start, end).trim() + "\n```" + t.slice(end);
    }
  }
  const blocks = extractHtmlBlocks(t);
  return { text: t.trim(), blocks, truncated: blocks.some((b) => !b.complete) };
}

/** Joins a continuation onto cut-off code, dropping text the model repeated. */
export function mergeContinuation(code: string, more: string): string {
  let add = stripOuterFence(stripReasoning(more));
  add = add.replace(/^\s*\n/, "");
  const max = Math.min(600, code.length, add.length);
  for (let n = max; n >= 12; n--) {
    if (code.endsWith(add.slice(0, n))) {
      add = add.slice(n);
      break;
    }
  }
  return code + add;
}

/** Trims whitespace and peels wrappers such as <System>…</System>, ((…)), (OOC: …), *{OOC: …}* and "OOC:". */
export function cleanOoc(text: string): string {
  let t = String(text ?? "").trim();
  const peel = [
    /^<system>\s*([\s\S]*?)\s*<\/system>$/i,
    /^\*\s*\{\s*ooc\s*[:：]\s*([\s\S]*?)\s*\}\s*\*$/i,
    /^\(\(\s*([\s\S]*?)\s*\)\)$/,
    /^\(\s*ooc\s*[:：]\s*([\s\S]*?)\s*\)$/i,
    /^\[\s*ooc\s*[:：]\s*([\s\S]*?)\s*\]$/i,
    /^ooc\s*[:：]\s*([\s\S]*)$/i,
  ];
  let changed = true;
  while (changed) {
    changed = false;
    for (const re of peel) {
      const m = re.exec(t);
      if (m) {
        t = m[1].trim();
        changed = true;
      }
    }
  }
  return t;
}

/** Fills {{name}} placeholders for the given keys only; other macros stay for Marinara. */
export function applyVars(template: string, vars: Record<string, string>): string {
  let out = String(template ?? "");
  for (const [key, value] of Object.entries(vars)) {
    out = out.replace(new RegExp(`\\{\\{${escapeRegex(key)}\\}\\}`, "g"), () => String(value ?? ""));
  }
  return out;
}

export function wrapOoc(template: string, content: string, language: string): string {
  const tpl = String(template ?? "");
  const filled = tpl.includes("{{내용}}") ? tpl : `${tpl}\n\n{{내용}}`;
  return applyVars(filled, { 내용: cleanOoc(content), 언어: language });
}

export interface Blank {
  /** The whole text between [[ and ]], used to fill it back in. */
  key: string;
  label: string;
  options: string[];
}

const BLANK_RE = /\[\[([^[\]\n]{1,400})\]\]/g;

/** `[[label]]` asks for text; `[[label|choice A|choice B]]` offers choices (free text still allowed). */
function parseBlank(inner: string): Blank {
  const parts = String(inner).split("|").map((x) => x.trim());
  return { key: String(inner), label: parts[0] || tr("Input", "입력"), options: parts.slice(1).filter(Boolean) };
}

/** Unique blanks in order of appearance. */
export function findBlanks(text: string): Blank[] {
  const seen = new Map<string, Blank>();
  let m: RegExpExecArray | null;
  BLANK_RE.lastIndex = 0;
  while ((m = BLANK_RE.exec(String(text ?? "")))) if (!seen.has(m[1])) seen.set(m[1], parseBlank(m[1]));
  return [...seen.values()];
}

/** Fills blanks by their full inner text (the `key` from findBlanks). */
export function fillBlanks(text: string, values: Record<string, string>): string {
  return String(text ?? "").replace(BLANK_RE, (whole, inner: string) => (Object.hasOwn(values, inner) ? String(values[inner]) : whole));
}

export interface PresetChunk {
  id: string;
  name: string;
  /** "all", or only in "full" / "lite" mode. */
  mode: "all" | "full" | "lite";
  enabled: boolean;
  text: string;
  /** Only when this extension is installed too (the page commands come from Fornello). */
  needs?: "fornello";
}

export interface ViszPreset {
  id: string;
  name: string;
  wrap: boolean;
  chunks: PresetChunk[];
  /** Built-in chunk ids already offered: a built-in chunk added later joins once, a deleted one stays gone. */
  known?: string[];
}

export type ViszMode = "full" | "lite";
/** The setting: "auto" is full when Fornello runs the pages' scripts, light otherwise. */
export type ViszModeSetting = ViszMode | "auto";

export function resolveVizMode(setting: ViszModeSetting, env: ViszEnv = {}): ViszMode {
  return setting === "auto" ? (env.fornello ? "full" : "lite") : setting;
}

/** What is installed next to Dispensa (chunks that need it are left out otherwise). */
export interface ViszEnv {
  fornello?: boolean;
}

function activeChunks(preset: ViszPreset | undefined, mode: ViszMode, env: ViszEnv = {}): PresetChunk[] {
  return (preset?.chunks ?? []).filter((c) => c.enabled !== false && (!c.mode || c.mode === "all" || c.mode === mode) && (c.needs !== "fornello" || env.fornello === true));
}

export function assembleVisualizer(preset: ViszPreset | undefined, mode: ViszMode, { topic, language, env }: { topic: string; language: string; env?: ViszEnv }): string {
  let body = activeChunks(preset, mode, env)
    .map((c) => String(c.text ?? "").trim())
    .filter(Boolean)
    .join("\n\n");
  if (!body.includes("{{주제}}")) body = `[요청 주제]\n{{주제}}\n\n${body}`;
  body = applyVars(body, { 주제: cleanOoc(topic), 언어: language });
  return preset?.wrap === false ? body : `<System>\n${body}\n</System>`;
}

/** First line of the request, for titles. */
export function titleFrom(text: string, max = 40): string {
  return cleanOoc(text).split("\n")[0].replace(/\[\[|\]\]/g, "").trim().slice(0, max);
}

// ── page shown in a sandboxed frame ──

/** True when the page needs JavaScript (script tags or inline event handlers). */
export function hasScripts(code: string): boolean {
  return /<script\b|\son[a-z]+\s*=\s*["']|javascript:/i.test(String(code ?? ""));
}

/** Script put into every frame: tells the parent the page's height whenever it changes. */
function heightReporter(token: string): string {
  return `(()=>{const token=${JSON.stringify(token)};let sent=-1,queued=false;const send=()=>{queued=false;const page=document.documentElement,body=document.body;if(!page||!body)return;const px=Math.ceil(Math.max(page.scrollHeight,body.scrollHeight));if(px>0&&Math.abs(px-sent)>2){sent=px;parent.postMessage({viszHeight:px,token},"*");}};const soon=()=>{if(!queued){queued=true;requestAnimationFrame(send);}};addEventListener("load",soon);addEventListener("resize",soon);document.addEventListener("DOMContentLoaded",()=>{soon();if(window.ResizeObserver)new ResizeObserver(soon).observe(document.body);});[200,800,2000,5000].forEach((ms)=>setTimeout(send,ms));})();`;
}

export function buildSrcdoc(code: string, { token, baseUrl = "", allowExternal = true }: { token: string; baseUrl?: string; allowExternal?: boolean }): string {
  const head: string[] = [];
  if (baseUrl) head.push(`<base href="${escapeHtml(baseUrl)}">`);
  if (!allowExternal) {
    head.push(`<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data: blob:; media-src data: blob:; font-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'">`);
  }
  head.push(`<script>${heightReporter(token)}</script>`);
  const inject = head.join("");
  let doc = String(code ?? "");
  if (!looksLikeHtmlDoc(doc)) {
    doc = `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body>${doc}</body></html>`;
  }
  if (/<head[^>]*>/i.test(doc)) return doc.replace(/<head[^>]*>/i, (m) => m + inject);
  if (/<html[^>]*>/i.test(doc)) return doc.replace(/<html[^>]*>/i, (m) => `${m}<head>${inject}</head>`);
  return inject + doc;
}

/** A reply that is a bare HTML document (no ``` fence around it) gets one, so it is read as a page. */
export function fencedPage(text: string): string {
  if (extractHtmlBlocks(text).length) return text;
  const at = text.search(/<!doctype\s+html|<html[\s>]/i);
  if (at < 0) return text;
  const end = text.search(/<\/html>/i);
  const stop = end < 0 ? text.length : end + "</html>".length;
  return `${text.slice(0, at)}\`\`\`html\n${text.slice(at, stop).trim()}\n\`\`\`${text.slice(stop)}`;
}
