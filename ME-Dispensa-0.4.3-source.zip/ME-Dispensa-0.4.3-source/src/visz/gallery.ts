// Finding and filing Gallery pages. A folder is a name on its pages: it exists while a page is in it.

import type { ArchiveEntry } from "./archive";

/** Folder names are kept short and without line breaks. */
export function folderName(raw: string): string {
  return raw.replace(/\s+/g, " ").trim().slice(0, 40);
}

export function galleryFolders(entries: ArchiveEntry[]): string[] {
  return [...new Set(entries.map((e) => e.folder ?? "").filter(Boolean))].sort((a, b) => a.localeCompare(b));
}

/** Which pages to show: `folder` null for all, "" for those in no folder; `query` keeps pages with every word. */
export function shownPages(entries: ArchiveEntry[], folder: string | null, query = ""): ArchiveEntry[] {
  const fold = (s: string) => s.normalize("NFC").toLowerCase();
  const words = fold(query).split(/\s+/).filter(Boolean);
  return entries.filter((e) => (folder === null || (e.folder ?? "") === folder) && words.every((w) => fold(`${e.title} ${e.character ?? ""} ${e.chatName ?? ""}`).includes(w)));
}

/** The page filed in `folder` ("" takes it out of its folder). */
export function filed(entry: ArchiveEntry, folder: string): ArchiveEntry {
  const next = { ...entry };
  const name = folderName(folder);
  if (name) next.folder = name;
  else delete next.folder;
  return next;
}
