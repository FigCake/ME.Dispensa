// The Gallery on every device: pages are files on Marinara's server, and this browser's archive is
// their copy (it still works when the server can't be reached). A list() brings the two together:
// pages new or changed elsewhere come down, pages made here (or before there were files) go up, and a
// page deleted on another device goes here too.

import type { ArchiveBackend, ArchiveEntry } from "./archive";

/** The server's page files, by page id. */
export interface PageFiles {
  /** Every page file with when it last changed. */
  list(): Promise<Map<string, string>>;
  read(id: string): Promise<unknown>;
  write(id: string, data: unknown): Promise<void>;
  remove(id: string): Promise<void>;
}

/** What this browser knows of the files, kept between visits. */
export interface SyncMemory {
  /** The file's last change as listed when this copy matched it; SENT for one written here since. */
  seen: Record<string, string>;
  /** Changed here and not sent yet. */
  dirty: string[];
  /** Deleted here, still to go from the server. */
  gone: string[];
}

export interface SyncStore {
  read(): SyncMemory;
  write(memory: SyncMemory): void;
}

/** Files one list() fetches or sends at most (Marinara allows 600 requests a minute). */
const BATCH = 60;

const FORMAT = "dispensa-page";
/** Sent from here, its listed change not known yet. */
const SENT = "sent";

function entryOf(raw: unknown, id: string): ArchiveEntry | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  if (r.format !== FORMAT || typeof r.text !== "string") return null;
  const str = (v: unknown) => (typeof v === "string" && v ? v : undefined);
  return {
    id,
    title: str(r.title) ?? "",
    kind: r.kind === "ooc" ? "ooc" : "viz",
    text: r.text,
    createdAt: Number(r.createdAt) || Date.now(),
    ...(str(r.chatId) ? { chatId: str(r.chatId) } : {}),
    ...(str(r.chatName) ? { chatName: str(r.chatName) } : {}),
    ...(str(r.character) ? { character: str(r.character) } : {}),
    ...(str(r.folder) ? { folder: str(r.folder) } : {}),
  };
}

export class SyncedArchive implements ArchiveBackend {
  private syncing: Promise<void> | null = null;

  constructor(
    private readonly local: ArchiveBackend,
    private readonly files: PageFiles,
    private readonly memory: SyncStore,
  ) {}

  async list(): Promise<ArchiveEntry[]> {
    this.syncing ??= this.sync().finally(() => (this.syncing = null));
    await this.syncing.catch(() => undefined);
    return this.local.list();
  }

  async put(entry: ArchiveEntry): Promise<void> {
    await this.local.put(entry);
    this.change((m) => {
      if (!m.dirty.includes(entry.id)) m.dirty.push(entry.id);
      m.gone = m.gone.filter((id) => id !== entry.id);
    });
    await this.send(entry).catch(() => undefined); // sent with the next list()
  }

  async remove(id: string): Promise<void> {
    await this.local.remove(id);
    this.change((m) => {
      delete m.seen[id];
      m.dirty = m.dirty.filter((x) => x !== id);
      if (!m.gone.includes(id)) m.gone.push(id);
    });
    await this.files
      .remove(id)
      .then(() => this.change((m) => (m.gone = m.gone.filter((x) => x !== id))))
      .catch(() => undefined);
  }

  private change(fn: (m: SyncMemory) => void): void {
    const m = this.memory.read();
    fn(m);
    this.memory.write(m);
  }

  private async send(entry: ArchiveEntry): Promise<void> {
    const { id, ...rest } = entry;
    await this.files.write(id, { format: FORMAT, version: 1, ...rest });
    this.change((m) => {
      m.dirty = m.dirty.filter((x) => x !== id);
      m.seen[id] = SENT;
    });
  }

  private async sync(): Promise<void> {
    const remote = await this.files.list();
    const mem = this.memory.read();
    let budget = BATCH;
    // deleted here while the server couldn't be reached
    for (const id of mem.gone) {
      if (remote.has(id) && budget-- > 0) await this.files.remove(id);
      remote.delete(id);
      this.change((m) => (m.gone = m.gone.filter((x) => x !== id)));
    }
    const local = new Map((await this.local.list()).map((e) => [e.id, e]));
    for (const [id, modified] of remote) {
      const here = local.get(id);
      const seen = this.memory.read().seen[id];
      if (here && mem.dirty.includes(id)) continue; // ours is newer: sent below
      if (here && (seen === undefined || seen === SENT || seen === modified)) {
        if (seen !== modified) this.change((m) => (m.seen[id] = modified));
        continue;
      }
      // new here, or changed on another device
      if (budget-- <= 0) break;
      const entry = entryOf(await this.files.read(id).catch(() => null), id);
      if (!entry) continue;
      await this.local.put(entry);
      this.change((m) => (m.seen[id] = modified));
    }
    for (const [id, entry] of local) {
      const { seen, dirty } = this.memory.read();
      const changedHere = dirty.includes(id);
      if (remote.has(id) && !changedHere) continue;
      if (!remote.has(id) && seen[id] !== undefined && !changedHere) {
        // it was on the server (listed, or sent from here) and isn't any more: deleted on another device
        await this.local.remove(id);
        this.change((m) => delete m.seen[id]);
        continue;
      }
      if (budget-- <= 0) break;
      await this.send(entry).catch(() => undefined);
    }
  }
}

/** The sync memory in this browser's localStorage (empty when it can't be read). */
export function localSyncStore(key: string): SyncStore {
  const empty = (): SyncMemory => ({ seen: {}, dirty: [], gone: [] });
  return {
    read() {
      try {
        const raw = JSON.parse(localStorage.getItem(key) ?? "null") as Partial<SyncMemory> | null;
        return { seen: { ...(raw?.seen ?? {}) }, dirty: [...(raw?.dirty ?? [])], gone: [...(raw?.gone ?? [])] };
      } catch {
        return empty();
      }
    },
    write(memory) {
      try {
        localStorage.setItem(key, JSON.stringify(memory));
      } catch {
        // private window: the next visit syncs from scratch, which only costs requests
      }
    },
  };
}
