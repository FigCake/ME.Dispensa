// Same file in Dispensa and Fornello (src/shared/): after a change, run
// `npm run shared -- sync <path to the other repository>`.

// One menu in Marinara's top bar for FigCake's extensions: a slice of cake
// whose entries each extension adds (its settings, Fornello's script buttons
// when Dispensa's Dock is not there). The entries live on window
// (`__figcakeMenu`), so whichever extension starts first, every copy of this
// file, and Polyglot's own menu, read the same list. Only one button shows:
// Polyglot's when it is in the page (it lists these entries too), else the
// first extension's; when that one stops, another puts its own up.

import { t } from "./i18n";

export interface TopMenuItem {
  /** A small SVG (markup) or an emoji. */
  icon: string;
  label: string;
  title?: string;
  /** Items with the same group sit under one small heading. */
  group?: string;
  run(): void;
}

export interface TopMenuSource {
  /** "dispensa", "fornello": one source each. */
  id: string;
  /** The extension's name, for the button's tooltip. */
  name: string;
  /** Lower comes first. */
  order: number;
  /** Asked each time the menu opens. */
  items(): TopMenuItem[];
}

interface MenuRegistry {
  version: 1;
  sources: TopMenuSource[];
}

declare global {
  interface Window {
    __figcakeMenu?: MenuRegistry;
  }
}

const registry = (): MenuRegistry => (window.__figcakeMenu ??= { version: 1, sources: [] });

/** Adds an extension's entries; returns what takes them out. */
export function addMenuSource(source: TopMenuSource): () => void {
  const list = registry().sources;
  const at = list.findIndex((s) => s.id === source.id);
  if (at >= 0) list.splice(at, 1);
  list.push(source);
  list.sort((a, b) => a.order - b.order);
  return () => {
    const now = registry().sources;
    const i = now.indexOf(source);
    if (i >= 0) now.splice(i, 1);
  };
}

/** Every entry, in the sources' order (one failing source leaves the rest). */
export function menuItems(): TopMenuItem[] {
  return registry().sources.flatMap((s) => {
    try {
      return s.items();
    } catch {
      return [];
    }
  });
}

export const MENU_ICONS = {
  cake: svg('<path d="M16 13H3"/><path d="M16 17H3"/><path d="m7.2 7.9-3.388 2.5A2 2 0 0 0 3 12.01V20a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-8.654c0-2-2.44-6.026-6.44-8.026a1 1 0 0 0-1.082.057L10.4 5.6"/><circle cx="9" cy="7" r="2"/>'),
  flame: svg('<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>'),
};

function svg(paths: string): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
}

const TOPBAR = 'header[data-component="TopBar"] nav.mari-topbar-panel-nav';
const POLYGLOT = "pg-mari-launch";
const BUTTON = "figcake-menu";
const POP = "figcake-menu-pop";
const STYLE_ID = "figcake-menu-style";

// Marinara's look for its top-bar buttons and menus (as Polyglot's globe has it)
const STYLE = `
#${BUTTON} { display: inline-flex; align-items: center; justify-content: center; width: 2rem; height: 2rem; padding: 0; border: 0;
  border-radius: var(--radius, .75rem); background: none; color: var(--muted-foreground); cursor: pointer; transition: color .2s, background-color .2s; }
#${BUTTON} svg { width: .875rem; height: .875rem; }
#${BUTTON}:hover { background: var(--accent); color: var(--marinara-chat-chrome-button-text-hover, var(--foreground)); }
@media (pointer: coarse) { #${BUTTON} { width: 2.25rem; height: 2.25rem; } }
@media (max-width: 767px) { #${BUTTON} { order: 8; } }
#${BUTTON}.float { position: fixed; right: .875rem; top: .875rem; z-index: 9000; background: var(--card); box-shadow: 0 6px 20px rgb(0 0 0 / .35); }
#${POP} { position: fixed; z-index: 10001; display: grid; min-width: 11rem; max-width: min(18rem, calc(100vw - 16px)); max-height: calc(100dvh - 5rem); overflow: auto; padding: .25rem;
  border: 1px solid var(--marinara-chat-chrome-panel-border, var(--border)); border-radius: .75rem;
  background: var(--marinara-chat-chrome-panel-bg, var(--popover)); color: var(--marinara-chat-chrome-panel-text, var(--popover-foreground));
  font-size: .75rem; box-shadow: 0 25px 50px -12px rgb(0 0 0 / .4); -webkit-backdrop-filter: blur(12px); backdrop-filter: blur(12px); }
#${POP} button { display: flex; align-items: center; gap: .5rem; padding: .5rem .625rem; border: 0; border-radius: .5rem; background: none; color: inherit; font: inherit; text-align: left; cursor: pointer; }
#${POP} button:hover { background: var(--marinara-chat-chrome-highlight-bg-hover, var(--accent)); }
#${POP} button > span:last-child { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
#${POP} .icon { display: inline-flex; width: .875rem; justify-content: center; flex: none; opacity: .75; }
#${POP} .icon svg { width: .875rem; height: .875rem; }
#${POP} .group { padding: .5rem .625rem .125rem; font-size: .6875rem; opacity: .6; }
`;

/** An item's icon: markup only when it is an SVG we drew, text otherwise. */
function iconOf(icon: string): HTMLElement {
  const span = document.createElement("span");
  span.className = "icon";
  if (icon.startsWith("<svg")) span.innerHTML = icon;
  else span.textContent = icon;
  return span;
}

/** Closes the menu this copy opened, if it is open. */
let closeOpen: ((refocus: boolean) => void) | null = null;

/**
 * Opens the menu under its button (or closes it when open). Opened from the
 * keyboard, the first entry takes the focus; the arrow keys (and Home, End)
 * move between entries, and Escape closes it and gives the focus back to the button.
 */
function openMenu(btn: HTMLElement, byKeyboard = false): void {
  const old = document.getElementById(POP);
  if (closeOpen || old) {
    if (closeOpen) closeOpen(false);
    else old?.remove();
    return;
  }
  const box = document.createElement("div");
  box.id = POP;
  box.setAttribute("role", "menu");
  const entries: HTMLButtonElement[] = [];
  const close = (refocus: boolean) => {
    box.remove();
    document.removeEventListener("keydown", onKey, true);
    document.removeEventListener("click", onOutside);
    btn.setAttribute("aria-expanded", "false");
    if (closeOpen === close) closeOpen = null;
    if (refocus && btn.isConnected) btn.focus();
  };
  const onOutside = () => close(false);
  const onKey = (e: KeyboardEvent) => {
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      close(true);
      return;
    }
    if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(e.key) || !entries.length) return;
    const at = entries.indexOf(document.activeElement as HTMLButtonElement);
    // the focus is somewhere else (typing in the chat): the keys are left alone
    if (at < 0 && document.activeElement !== btn) return;
    e.preventDefault();
    const last = entries.length - 1;
    const next = e.key === "Home" ? 0 : e.key === "End" ? last : e.key === "ArrowDown" ? (at < 0 || at === last ? 0 : at + 1) : at <= 0 ? last : at - 1;
    entries[next].focus();
  };
  let group: string | undefined;
  for (const item of menuItems()) {
    if (item.group && item.group !== group) {
      const head = document.createElement("div");
      head.className = "group";
      head.textContent = item.group;
      box.append(head);
    }
    group = item.group;
    const b = document.createElement("button");
    b.type = "button";
    b.setAttribute("role", "menuitem");
    if (item.title) b.title = item.title;
    const label = document.createElement("span");
    label.textContent = item.label;
    b.append(iconOf(item.icon), label);
    b.addEventListener("click", () => {
      close(false);
      item.run();
    });
    box.append(b);
    entries.push(b);
  }
  const r = btn.getBoundingClientRect();
  box.style.top = `${Math.round(r.bottom + 6)}px`;
  box.style.right = `${Math.max(8, Math.round(innerWidth - r.right))}px`;
  document.body.append(box);
  btn.setAttribute("aria-expanded", "true");
  closeOpen = close;
  document.addEventListener("keydown", onKey, true);
  setTimeout(() => {
    if (closeOpen === close) document.addEventListener("click", onOutside, { once: true });
  });
  if (byKeyboard) entries[0]?.focus();
}

/**
 * Keeps the cake between Agents and Settings in the top bar (else in a corner)
 * while no other button is there: looked at every 1.5 s, as React may draw the
 * top bar again, and Polyglot or the other extension may come or go.
 */
export function keepTopMenu(): () => void {
  let own: HTMLButtonElement | null = null;
  const dress = (btn: HTMLElement) => {
    const title = registry().sources.map((s) => s.name).join(" · ") || t("Menu", "메뉴");
    if (btn.title !== title) {
      btn.title = title;
      btn.setAttribute("aria-label", title);
    }
  };
  const drop = () => {
    if (!own) return;
    own.remove();
    own = null;
    document.getElementById(STYLE_ID)?.remove();
  };
  const place = () => {
    const someoneElse = document.getElementById(POLYGLOT) ?? (own ? null : document.getElementById(BUTTON));
    if (someoneElse || !registry().sources.length) {
      drop();
      return;
    }
    if (!own) {
      own = document.createElement("button");
      own.type = "button";
      own.id = BUTTON;
      own.innerHTML = MENU_ICONS.cake;
      own.setAttribute("aria-haspopup", "menu");
      own.setAttribute("aria-expanded", "false");
      own.addEventListener("click", (e) => {
        e.stopPropagation();
        // Enter or Space on the button makes a click with no mouse press (detail 0)
        openMenu(e.currentTarget as HTMLElement, e.detail === 0);
      });
    }
    if (!document.getElementById(STYLE_ID)) {
      const style = document.createElement("style");
      style.id = STYLE_ID;
      style.textContent = STYLE;
      document.head.append(style);
    }
    dress(own);
    const bar = document.querySelector(TOPBAR);
    const settings = bar ? ([...bar.children].find((c) => c.getAttribute("data-topbar-hover-key") === "settings") ?? null) : null;
    if (bar) {
      own.classList.remove("float");
      if (own.parentElement !== bar || own.nextElementSibling !== settings) bar.insertBefore(own, settings);
    } else if (!own.isConnected || own.parentElement !== document.body) {
      own.classList.add("float");
      document.body.append(own);
    }
  };
  place();
  const timer = setInterval(place, 1500);
  return () => {
    clearInterval(timer);
    if (own) {
      closeOpen?.(false);
      document.getElementById(POP)?.remove();
    }
    drop();
  };
}
