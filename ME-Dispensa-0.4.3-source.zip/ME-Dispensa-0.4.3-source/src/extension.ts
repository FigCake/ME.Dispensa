// This extension's name, which src/shared/ uses to tell Dispensa and Fornello apart.

export const EXTENSION = { name: "Dispensa", id: "dispensa" } as const;
