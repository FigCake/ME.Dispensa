// State kept in Marinara's extension storage (so it follows the user to other devices): under one key, or
// split over "key" and "key:…" so two devices saving different parts don't touch each other's (Marinara
// replaces whole keys and checks nothing). Saves come a moment after update(); a store that failed to load
// never saves, so a read error can't wipe data. Another device or tab may have saved meanwhile: a save
// re-reads the keys and, if they changed, replays this tab's changes on top of what is there instead of
// writing its older copy over it, then writes only the keys that differ from what is stored.

import { getMarinara } from "../shared/marinara-global";

export interface StoreSpec<T> {
  key: string;
  /** Saved data → a complete state (missing or broken parts get defaults); normalize(undefined) is the empty state. */
  normalize(raw: unknown): T;
  /** A fresh install's state (nothing saved under `key` yet), saved right away. */
  initial?(): T;
  /**
   * Splits the state over `key` and keys starting with "key:" (null: a part gone); `join` puts what is
   * stored back together for normalize. Without them the state is the one value under `key`.
   */
  split?(state: T): Record<string, unknown>;
  join?(parts: Record<string, unknown>): unknown;
  /** For log messages. */
  label: string;
}

/** Marinara allows 1,000,000 bytes of extension storage in total. */
export const STORAGE_LIMIT = 1_000_000;
/** Past this, Dispensa warns that storage is almost full. */
export const STORAGE_SOFT_LIMIT = 900_000;
/** Past this, the Dispensa window shows how full storage is. */
export const STORAGE_SHOW_FROM = 700_000;
const SAVE_DELAY_MS = 400;

export class PersistedStore<T> {
  private state: T;
  private readonly listeners = new Set<(s: T) => void>();
  private saveTimer: ReturnType<typeof setTimeout> | null = null;
  private loadedOk = false;
  /** The stored keys as JSON when this tab last read or wrote them. */
  private base: Record<string, string> = {};
  /** Changes made here since the last save, to replay on a newer stored value. */
  private pending: ((s: T) => void)[] = [];
  /** The save in progress: a refresh waits for it, and saves run one at a time. */
  private saving: Promise<void> | null = null;

  constructor(private readonly spec: StoreSpec<T>) {
    this.state = spec.normalize(undefined);
  }

  /** Loaded from storage (writes are safe). */
  get ready(): boolean {
    return this.loadedOk;
  }

  get value(): T {
    return this.state;
  }

  async load(): Promise<void> {
    try {
      const parts = this.partsOf(await getMarinara().storage.get());
      const fresh = !Object.keys(parts).length && !!this.spec.initial;
      this.state = fresh ? this.spec.initial!() : this.spec.normalize(this.rawOf(parts));
      this.base = parts;
      this.pending = [];
      this.loadedOk = true;
      if (fresh) this.scheduleSave();
    } catch (e) {
      // Never overwrite storage we could not read.
      this.loadedOk = false;
      throw e;
    }
    this.emit();
  }

  subscribe(fn: (s: T) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  /** Like subscribe, but `fn` runs only when the slice `pick` returns has changed (compared as JSON). */
  select(pick: (s: T) => unknown, fn: (s: T) => void): () => void {
    const key = (s: T) => {
      const v = pick(s);
      return typeof v === "string" ? v : JSON.stringify(v);
    };
    let last = key(this.state);
    return this.subscribe((s) => {
      const next = key(s);
      if (next === last) return;
      last = next;
      fn(s);
    });
  }

  update(mutate: (s: T) => void): void {
    mutate(this.state);
    this.pending.push(mutate);
    this.emit();
    this.scheduleSave();
  }

  /** Takes what another device saved meanwhile (when nothing here waits to be saved). */
  async refresh(): Promise<void> {
    // a save on its way has already taken this tab's changes out of `pending`
    if (this.saving) await this.saving.catch(() => undefined);
    if (!this.loadedOk || this.pending.length || this.saveTimer || this.saving) return;
    const parts = this.partsOf(await getMarinara().storage.get());
    if (this.pending.length || this.saveTimer || this.saving) return;
    if (!Object.keys(parts).length || sameParts(parts, this.base)) return;
    this.state = this.spec.normalize(this.rawOf(parts));
    this.base = parts;
    this.emit();
  }

  /** Size of the saved data in bytes, to warn before Marinara's limit. */
  size(): number {
    return new TextEncoder().encode(JSON.stringify(this.state)).length;
  }

  async saveNow(): Promise<void> {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = null;
    if (!this.loadedOk) return;
    while (this.saving) await this.saving.catch(() => undefined);
    this.saving = this.write().finally(() => (this.saving = null));
    return this.saving;
  }

  private async write(): Promise<void> {
    // every change already in this.state; those made during the save are kept for the next one
    let taken = this.pending;
    this.pending = [];
    try {
      // always read first: a save that trusted an older read wrote over what another device saved
      const stored = this.partsOf(await getMarinara().storage.get());
      taken = [...taken, ...this.pending];
      this.pending = [];
      if (Object.keys(stored).length && !sameParts(stored, this.base)) {
        const next = this.spec.normalize(this.rawOf(stored));
        for (const op of taken) {
          try {
            op(next);
          } catch (e) {
            console.warn(`[Dispensa] ${this.spec.label}: a change could not be replayed`, e);
          }
        }
        this.state = next;
        this.emit();
      }
      // only the keys that differ from what is stored; a part gone is written as null
      const out: Record<string, string> = {};
      for (const [k, v] of Object.entries(this.spec.split ? this.spec.split(this.state) : { [this.spec.key]: this.state })) if (v != null) out[k] = JSON.stringify(v);
      const patch: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(out)) if (stored[k] !== v) patch[k] = JSON.parse(v) as unknown;
      for (const k of Object.keys(stored)) if (!(k in out)) patch[k] = null;
      if (Object.keys(patch).length) await getMarinara().storage.patch(patch);
      this.base = out;
    } catch (e) {
      this.pending = [...taken, ...this.pending];
      throw e;
    }
  }

  /** This store's keys in what storage holds, as JSON (parts written as null are gone). */
  private partsOf(stored: Record<string, unknown>): Record<string, string> {
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(stored)) {
      if (v == null || (k !== this.spec.key && !(this.spec.split && k.startsWith(`${this.spec.key}:`)))) continue;
      out[k] = JSON.stringify(v);
    }
    return out;
  }

  private rawOf(parts: Record<string, string>): unknown {
    if (!this.spec.join) return parts[this.spec.key] === undefined ? undefined : (JSON.parse(parts[this.spec.key]) as unknown);
    return this.spec.join(Object.fromEntries(Object.entries(parts).map(([k, v]) => [k, JSON.parse(v) as unknown])));
  }

  private scheduleSave(): void {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => {
      void this.saveNow().catch((e) => console.error(`[Dispensa] ${this.spec.label} save failed`, e));
    }, SAVE_DELAY_MS);
  }

  private emit(): void {
    for (const fn of this.listeners) fn(this.state);
  }
}

function sameParts(a: Record<string, string>, b: Record<string, string>): boolean {
  const keys = Object.keys(a);
  return keys.length === Object.keys(b).length && keys.every((k) => a[k] === b[k]);
}

/** Bytes all of Dispensa's stores take together (they share Marinara's one limit). */
export function storageUsed(stores: ({ size(): number } | undefined)[]): number {
  return stores.reduce((sum, s) => sum + (s?.size() ?? 0), 0);
}
