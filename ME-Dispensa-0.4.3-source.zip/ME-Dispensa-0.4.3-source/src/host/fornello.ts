import { getMarinara } from "../shared/marinara-global";

// Fornello, the extension that runs pages with their scripts: the one place that looks it up on window.

/** What Fornello puts on window.__fornello. */
export interface FornelloBridge {
  version: number;
  /** `chatId`: the page's own chat, for its picture names (older Fornello: the open chat). */
  mount(container: HTMLElement, code: string, options?: { run?: boolean; chatId?: string }): { dispose(): void };
  openSettings?(): void;
  /** A page's code with its picture names filled in from a chat's character assets (the open chat when none is given, or on an older Fornello). */
  fillAssets?(code: string, chatId?: string): Promise<string>;
}

/** Fornello's bridge when a version Dispensa knows is installed. */
export function fornello(): FornelloBridge | null {
  const bridge = (window as { __fornello?: FornelloBridge }).__fornello;
  return bridge && bridge.version === 1 && typeof bridge.mount === "function" ? bridge : null;
}

/** Any version installed: the visz prompt can tell the model about its commands. */
export function fornelloInstalled(): boolean {
  return !!(window as { __fornello?: unknown }).__fornello;
}

/** Marinara's pictures already read for a preview, by address. */
const pictures = new Map<string, Promise<string>>();

/**
 * A page with its picture names ({{raw::name}}, [img:name]) filled in by Fornello from the character
 * assets of `chatId` (the chat the page was made in; the open chat when unknown), its pictures put in as data (a sandboxed preview can't load Marinara's files).
 * The same code when Fornello isn't there or the page names none.
 */
export async function pageWithPictures(code: string, chatId?: string): Promise<string> {
  const bridge = (window as { __fornello?: FornelloBridge }).__fornello;
  if (typeof bridge?.fillAssets !== "function") return code;
  const filled = await bridge.fillAssets(code, chatId).catch(() => code);
  if (filled === code) return code;
  let out = filled;
  for (const url of new Set(filled.match(/\/api\/(?:characters\/[^"'()\s/]+\/gallery|sprites\/[^"'()\s/]+)\/file\/[^"'()\s<>]+/g) ?? [])) {
    let data = pictures.get(url);
    if (!data) {
      data = (getMarinara().fetch ?? fetch)(url, { credentials: "same-origin" })
        .then((r) => (r.ok ? r.blob() : Promise.reject(new Error(String(r.status)))))
        .then((blob) => new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result));
          reader.onerror = () => reject(reader.error ?? new Error("read"));
          reader.readAsDataURL(blob);
        }));
      pictures.set(url, data);
      const tried = data;
      data.catch(() => pictures.get(url) === tried && pictures.delete(url));
    }
    const inline = await data.catch(() => null);
    if (inline) out = out.split(url).join(inline);
  }
  return out;
}
