// The fonts installed on the Marinara server (GET /api/fonts), for the memo pad.
// A family's files are added to the page the first time a memo uses it.

import { api } from "../shared/api";

interface FontFile {
  family: string;
  url: string;
  weight?: string | number;
  style?: string;
  unicodeRange?: string;
}

let faces: Promise<Map<string, FontFile[]>> | null = null;
const added = new Set<string>();

function load(): Promise<Map<string, FontFile[]>> {
  faces ??= api<unknown>("/fonts")
    .then((list) => {
      const map = new Map<string, FontFile[]>();
      for (const f of Array.isArray(list) ? (list as FontFile[]) : []) {
        if (!f || typeof f.family !== "string" || typeof f.url !== "string") continue;
        map.set(f.family, [...(map.get(f.family) ?? []), f]);
      }
      return map;
    })
    .catch(() => {
      // asked again next time (the server may have been away)
      faces = null;
      return new Map<string, FontFile[]>();
    });
  return faces;
}

/** Family names of the installed fonts, sorted. */
export async function installedFonts(): Promise<string[]> {
  return [...(await load()).keys()].sort((a, b) => a.localeCompare(b));
}

/** Adds an installed family's files to the page (once); other names are left to the browser. */
export async function useFont(family: string): Promise<void> {
  const name = family.trim().replace(/^['"]|['"]$/g, "");
  if (!name || added.has(name) || typeof FontFace === "undefined") return;
  const files = (await load()).get(name);
  if (!files) return;
  added.add(name);
  for (const f of files) {
    const descriptors: FontFaceDescriptors = { weight: String(f.weight ?? "400"), style: f.style ?? "normal", display: "swap" };
    if (f.unicodeRange) descriptors.unicodeRange = f.unicodeRange;
    try {
      document.fonts.add(new FontFace(name, `url("${f.url}")`, descriptors));
    } catch {
      // a broken file: the browser falls back to the next font
    }
  }
}
