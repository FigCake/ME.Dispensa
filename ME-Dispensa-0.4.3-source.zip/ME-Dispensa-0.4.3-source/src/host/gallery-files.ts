// Gallery pages on Marinara's server, one JSON file each in its game assets folder
// (/api/game-assets: text files up to 10 MB), so every device sees the same Gallery.
// The files sit in "dispensa/gallery"; Marinara's game asset scan only picks up music and pictures.

import { ApiError, api } from "../shared/api";
import type { PageFiles } from "../visz/synced-archive";

const DIR = "dispensa/gallery";

interface TreeNode {
  name?: unknown;
  type?: unknown;
  modified?: unknown;
  children?: TreeNode[];
}

const child = (node: TreeNode | undefined, name: string) => node?.children?.find((c) => c.type === "folder" && c.name === name);

export const galleryFiles: PageFiles = {
  async list() {
    const root = await api<TreeNode>("/game-assets/tree");
    const folder = child(child(root, "dispensa"), "gallery");
    const out = new Map<string, string>();
    for (const f of folder?.children ?? []) {
      if (f.type !== "file" || typeof f.name !== "string" || !f.name.endsWith(".json")) continue;
      out.set(f.name.slice(0, -5), String(f.modified ?? ""));
    }
    return out;
  },
  async read(id) {
    const { content } = await api<{ content: string }>(`/game-assets/file-content/${DIR}/${encodeURIComponent(id)}.json`);
    return JSON.parse(content) as unknown;
  },
  async write(id, data) {
    await api(`/game-assets/file-content/${DIR}/${encodeURIComponent(id)}.json`, { method: "PUT", body: { content: JSON.stringify(data) } });
  },
  async remove(id) {
    try {
      await api(`/game-assets/file/${DIR}/${encodeURIComponent(id)}.json`, { method: "DELETE" });
    } catch (e) {
      // already gone
      if (!(e instanceof ApiError && e.status === 404)) throw e;
    }
  },
};
