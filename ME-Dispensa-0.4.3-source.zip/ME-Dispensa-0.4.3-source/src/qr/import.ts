// QR files: SillyTavern's and Dispensa's (.mqr.json), both ways; and OOC notes pulled out of text.

import { ParseError } from "../stscript/ast";
import { parse } from "../stscript/parser";
import type { CommandRegistry } from "../stscript/registry";
import type { Closure } from "../stscript/ast";
import { convertToMarinara } from "./convert";
import { AUTO_TRIGGERS, type QrItem, type QrSet, type QrState, newItem, newSet, withSteps } from "./model";
import type { StepQr } from "./steps";
import { emojiForIcon } from "./icons";
import { t } from "../shared/i18n";

interface StQrBase {
  label?: string;
  title?: string;
  message?: string;
  mes?: string;
  icon?: string;
  showLabel?: boolean;
  contextList?: { set?: string; isChained?: boolean }[];
  preventAutoExecute?: boolean;
  isHidden?: boolean;
  automationId?: string;
}

/** SillyTavern's executeOn… fields (one per auto-run trigger). */
type StQr = StQrBase & Partial<Record<(typeof AUTO_TRIGGERS)[number]["st"], boolean>>;

interface StSet {
  name?: string;
  qrList?: StQr[];
  quickReplySlots?: StQr[];
  disableSend?: boolean;
  placeBeforeInput?: boolean;
  injectInput?: boolean;
  color?: string;
  onlyBorderColor?: boolean;
}

/** A sub menu link waiting for its set by name (the set may come in the same file or exist already). */
export interface PendingLink {
  item: QrItem;
  setName: string;
  chained: boolean;
}

export interface ImportReport {
  sets: QrSet[];
  /** Single QRs (a file of one QR): they go into the set that is open. */
  items: QrItem[];
  links: PendingLink[];
  total: number;
  unsupported: { set: string; label: string; commands: string[] }[];
  parseErrors: { set: string; label: string; error: string }[];
  /** Rewritten to Marinara numbering on import. */
  converted: number;
  /** Kept in SillyTavern mode, with reasons. */
  keptSillyTavern: { set: string; label: string; reasons: string[] }[];
}

/** Commands used in a script that the interpreter does not know. */
export function findUnsupported(script: string, registry: CommandRegistry): string[] | { error: string } {
  if (!script.trimStart().startsWith("/")) return [];
  let closure: Closure;
  try {
    closure = parse(script, { lookup: (n) => registry.get(n) });
  } catch (e) {
    return { error: e instanceof ParseError ? e.message : String(e) };
  }
  const unknown = new Set<string>();
  const walk = (c: Closure) => {
    for (const ex of c.executors) {
      if (ex.kind === "command") {
        if (!registry.has(ex.name)) unknown.add(ex.name);
        for (const a of ex.named) if (typeof a.value !== "string") walk(a.value);
        for (const a of ex.unnamed) if (typeof a.value !== "string") walk(a.value);
      }
    }
    for (const a of c.args) if (typeof a.value !== "string") walk(a.value);
  };
  walk(closure);
  return [...unknown].sort();
}

const emptyReport = (): ImportReport => ({ sets: [], items: [], links: [], total: 0, unsupported: [], parseErrors: [], converted: 0, keptSillyTavern: [] });

/** One SillyTavern QR (a file of a single QR, from its ⋯ menu's export). */
function isStItem(json: unknown): json is StQr {
  if (!json || typeof json !== "object" || Array.isArray(json)) return false;
  const j = json as Record<string, unknown>;
  return typeof j.label === "string" && typeof j.message === "string" && !("qrList" in j);
}

export function importSillyTavern(json: unknown, registry: CommandRegistry, fallbackName = t("Imported QR", "가져온 QR")): ImportReport {
  const report = emptyReport();
  if (isStItem(json)) {
    const item = stItem(json, registry, report, "");
    if (item) report.items.push(item);
    return report;
  }
  const list: StSet[] = Array.isArray(json) ? (json as StSet[]) : [json as StSet];
  for (const raw of list) {
    if (!raw || typeof raw !== "object") continue;
    const qrs = raw.qrList ?? raw.quickReplySlots;
    if (!Array.isArray(qrs)) continue;
    const set = newSet(String(raw.name || fallbackName), "st");
    set.disableSend = !!raw.disableSend;
    set.placeBeforeInput = !!raw.placeBeforeInput;
    set.injectInput = !!raw.injectInput;
    if (raw.color && raw.color !== "rgba(0, 0, 0, 0)" && raw.color !== "transparent") set.color = raw.color;
    if (raw.onlyBorderColor) set.colorBorderOnly = true;
    for (const q of qrs) {
      const item = stItem(q, registry, report, set.name);
      if (item) set.items.push(item);
    }
    report.sets.push(set);
  }
  return report;
}

function stItem(q: StQr, registry: CommandRegistry, report: ImportReport, setName: string): QrItem | null {
  const script = String(q.message ?? q.mes ?? "");
  if (!script.trim() && !q.label && !q.contextList?.length) return null;
  const auto: QrItem["auto"] = {};
  for (const { key, st } of AUTO_TRIGGERS) if (q[st]) auto[key] = true;
  const item: QrItem = { ...newItem(String(q.label || (q.icon ? "" : "QR")), script, "st") };
  if (q.title) item.title = q.title;
  if (q.isHidden) item.hidden = true;
  if (Object.keys(auto).length) item.auto = auto;
  if (q.automationId?.trim()) item.automationId = q.automationId.trim();
  if (q.preventAutoExecute === false) item.preventAuto = false;
  const emoji = q.icon ? emojiForIcon(q.icon) : undefined;
  if (emoji) {
    item.icon = emoji;
    if (!q.showLabel && item.label) item.showLabel = false;
  }
  if (!item.label) item.label = emoji ?? "QR";
  for (const link of q.contextList ?? []) if (link?.set) report.links.push({ item, setName: link.set, chained: !!link.isChained });
  check(item, registry, report, setName);
  applyConversion(item, registry);
  if (item.dialect === "marinara") report.converted++;
  else report.keptSillyTavern.push({ set: setName, label: item.label, reasons: item.note ? item.note.split("\n") : [] });
  report.total++;
  return item;
}

function check(item: QrItem, registry: CommandRegistry, report: ImportReport, setName: string): void {
  const found = findUnsupported(item.script, registry);
  if (Array.isArray(found)) {
    if (found.length) {
      item.unsupported = found;
      report.unsupported.push({ set: setName, label: item.label, commands: found });
    }
  } else {
    item.unsupported = [t("(syntax error)", "(문법 오류)")];
    report.parseErrors.push({ set: setName, label: item.label, error: found.error });
  }
}

/** Sub menu links by set name → ids, once the imported sets are in (newest set of a name wins). */
export function resolveLinks(state: QrState, links: PendingLink[]): string[] {
  const missing = new Set<string>();
  for (const { item, setName, chained } of links) {
    const set = [...state.sets].reverse().find((s) => s.name === setName);
    if (!set) {
      missing.add(setName);
      continue;
    }
    item.contextList = [...(item.contextList ?? []), chained ? { setId: set.id, chained: true } : { setId: set.id }];
  }
  return [...missing];
}

/** Rewrite an imported QR to Marinara numbering once; if that fails it keeps SillyTavern mode and a note. */
export function applyConversion(item: QrItem, registry: CommandRegistry): boolean {
  const result = convertToMarinara(item.script, registry);
  if (result.ok) {
    item.script = result.script;
    item.dialect = "marinara";
    delete item.note;
    return true;
  }
  item.dialect = "st";
  item.note = result.reasons.join("\n");
  return false;
}

// ── Marinara (Dispensa) format: .mqr.json ────────────────────

const MQR_FORMAT = "dispensa-mqr";

/** Set id → name for sub menu links in exported files. */
export type SetNames = (setId: string) => string | undefined;

/** Dispensa's own format: Marinara numbering, QR kinds, auto triggers and Dispensa commands kept as they are. */
export function exportMarinara(set: QrSet, names?: SetNames): unknown {
  return {
    format: MQR_FORMAT,
    version: 1,
    name: set.name,
    display: set.display,
    color: set.color,
    colorBorderOnly: set.colorBorderOnly || undefined,
    icon: set.icon,
    disableSend: !!set.disableSend,
    placeBeforeInput: !!set.placeBeforeInput,
    injectInput: !!set.injectInput,
    items: set.items.map((i) => mqrItem(i, names)),
  };
}

export const MQR_ITEM_FORMAT = "dispensa-mqr-item";

/** One QR in Dispensa's format. */
export function exportMarinaraItem(item: QrItem, names?: SetNames): unknown {
  return { format: MQR_ITEM_FORMAT, version: 1, item: mqrItem(item, names) };
}

function mqrItem(i: QrItem, names?: SetNames): Record<string, unknown> {
  const links = (i.contextList ?? []).map((l) => ({ set: names?.(l.setId), chained: !!l.chained })).filter((l) => l.set);
  return {
    label: i.label,
    title: i.title,
    script: i.script,
    kind: "script",
    dialect: i.dialect,
    icon: i.icon,
    showLabel: i.showLabel === false ? false : undefined,
    hidden: !!i.hidden,
    auto: i.auto,
    automationId: i.automationId,
    preventAuto: i.preventAuto === false ? false : undefined,
    contextList: links.length ? links : undefined,
    steps: i.steps,
  };
}

export function isMarinaraQr(json: unknown): boolean {
  if (!json || typeof json !== "object") return false;
  const j = json as { format?: unknown; sets?: unknown };
  return j.format === MQR_FORMAT || j.format === MQR_ITEM_FORMAT || (Array.isArray(j.sets) && j.sets.some((s) => s && typeof s === "object" && (s as { format?: unknown }).format === MQR_FORMAT));
}

/** Read .mqr.json: no numbering conversion, the QRs are already Marinara QRs. */
export function importMarinara(json: unknown, registry: CommandRegistry, fallbackName = t("Imported QR", "가져온 QR")): ImportReport {
  const report = emptyReport();
  const j = json as { sets?: unknown[]; format?: unknown; item?: unknown };
  if (j.format === MQR_ITEM_FORMAT) {
    if (j.item && typeof j.item === "object") report.items.push(mqrToItem(j.item as Record<string, unknown>, registry, report, ""));
    return report;
  }
  const list = Array.isArray(j.sets) ? j.sets : [json];
  for (const raw of list as Record<string, unknown>[]) {
    if (!raw || raw.format !== MQR_FORMAT || !Array.isArray(raw.items)) continue;
    const set = newSet(String(raw.name || fallbackName));
    set.display = raw.display === "inline" ? "inline" : "folder";
    if (typeof raw.color === "string") set.color = raw.color;
    if (raw.colorBorderOnly) set.colorBorderOnly = true;
    if (typeof raw.icon === "string" && raw.icon.trim()) set.icon = raw.icon;
    set.disableSend = !!raw.disableSend;
    set.placeBeforeInput = !!raw.placeBeforeInput;
    set.injectInput = !!raw.injectInput;
    for (const r of raw.items as Record<string, unknown>[]) set.items.push(mqrToItem(r, registry, report, set.name));
    report.sets.push(set);
  }
  return report;
}

function mqrToItem(r: Record<string, unknown>, registry: CommandRegistry, report: ImportReport, setName: string): QrItem {
  const item: QrItem = {
    ...newItem(String(r.label ?? "QR"), String(r.script ?? ""), r.dialect === "st" ? "st" : "marinara"),
    title: typeof r.title === "string" && r.title ? r.title : undefined,
    icon: typeof r.icon === "string" ? r.icon : undefined,
    hidden: !!r.hidden,
    auto: r.auto && typeof r.auto === "object" ? (r.auto as QrItem["auto"]) : undefined,
  };
  if (r.showLabel === false) item.showLabel = false;
  if (typeof r.automationId === "string" && r.automationId.trim()) item.automationId = r.automationId.trim();
  if (r.preventAuto === false) item.preventAuto = false;
  if (Array.isArray(r.contextList)) {
    for (const l of r.contextList as { set?: unknown; chained?: unknown }[]) if (typeof l?.set === "string") report.links.push({ item, setName: l.set, chained: !!l.chained });
  }
  report.total++;
  if (r.steps) Object.assign(item, withSteps({ ...item, steps: r.steps as StepQr }));
  check(item, registry, report, setName);
  if (item.dialect === "st") report.keptSillyTavern.push({ set: setName, label: item.label, reasons: [t("Saved counting from #0", "0번부터 세는 QR로 저장됨")] });
  return item;
}

/** Either format: .mqr.json as is, anything else as a SillyTavern QR set. */
export function importAny(json: unknown, registry: CommandRegistry, fallbackName?: string): ImportReport {
  return isMarinaraQr(json) ? importMarinara(json, registry, fallbackName) : importSillyTavern(json, registry, fallbackName);
}

// ── OOC ─────────────────────────────────────────────────────

const OOC_PATTERNS: RegExp[] = [
  /\*\s*\{\s*OOC\s*[:：]\s*([\s\S]*?)\s*\}\s*\*/gi, // *{OOC: ...}*
  /\{\s*OOC\s*[:：]\s*([\s\S]*?)\s*\}/gi, // {OOC: ...}
  /\[\s*OOC\s*[:：]\s*([\s\S]*?)\s*\]/gi, // [OOC: ...]
  /\(\(\s*OOC\s*[:：]?\s*([\s\S]*?)\s*\)\)/gi, // ((OOC: ...))
  /\(\s*OOC\s*[:：]\s*([\s\S]*?)\s*\)/gi, // (OOC: ...)
  /\*\s*OOC\s*[:：]\s*([\s\S]*?)\s*\*/gi, // *OOC: ...*
  /<\s*System\s*>([\s\S]*?)<\s*\/\s*System\s*>/gi, // <System>...</System>, Dispensa's own default wrapper
];

/** The notes in a text: each OOC wrapper's text, and each paragraph outside them, in order. */
export function extractOocNotes(text: string): string[] {
  let rest = text;
  const notes: { index: number; body: string }[] = [];
  const take = (match: string, body: string, offset: number) => {
    if (body.trim()) notes.push({ index: offset + (match.length - match.trimStart().length), body: body.trim() });
    return " ".repeat(match.length);
  };
  for (const re of OOC_PATTERNS) rest = rest.replace(re, take);
  // lines like "OOC: ..." that were not wrapped
  rest = rest.replace(/^[ \t]*OOC\s*[:：][ \t]*(.+)$/gim, take);
  // no wrappers at all: the whole text is one note
  if (!notes.length) return text.trim() ? [text.trim()] : [];
  // lines with no wrapper on them are notes too (consecutive ones together); words beside a wrapper are not
  let at = 0;
  let run: { index: number; lines: string[] } | null = null;
  const end = () => {
    if (run) notes.push({ index: run.index, body: run.lines.join("\n").trim() });
    run = null;
  };
  for (const line of text.split("\n")) {
    const plain = line.trim() !== "" && rest.slice(at, at + line.length) === line;
    if (plain) (run ??= { index: at, lines: [] }).lines.push(line);
    else end();
    at += line.length + 1;
  }
  end();
  notes.sort((a, b) => a.index - b.index);
  return notes.map((n) => n.body).filter(Boolean);
}
