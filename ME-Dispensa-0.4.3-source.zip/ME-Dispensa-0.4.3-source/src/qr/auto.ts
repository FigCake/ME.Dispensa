// QRs that run by themselves (SillyTavern's AutoExecuteHandler): which QRs a
// trigger picks, and the "don't set off other auto-runs" stack.

import type { AutoTrigger, QrItem, QrSet } from "./model";

export interface AutoTarget {
  set: QrSet;
  item: QrItem;
}

/** QRs in the sets that are on here that run on this trigger. */
export function autoTargets(sets: QrSet[], trigger: AutoTrigger): AutoTarget[] {
  const out: AutoTarget[] = [];
  for (const set of sets) for (const item of set.items) if (item.auto?.[trigger]) out.push({ set, item });
  return out;
}

const key = (s: string) => s.normalize("NFC").trim().toLowerCase();

/** QRs whose automation id matches a lorebook entry that came into play (by its name or id). */
export function automationTargets(sets: QrSet[], entries: { id?: unknown; name?: unknown }[]): AutoTarget[] {
  const keys = new Set<string>();
  for (const e of entries) {
    for (const v of [e.name, e.id]) if (typeof v === "string" && v.trim()) keys.add(key(v));
  }
  if (!keys.size) return [];
  const out: AutoTarget[] = [];
  for (const set of sets) for (const item of set.items) if (item.automationId?.trim() && keys.has(key(item.automationId))) out.push({ set, item });
  return out;
}

/** Runs auto QRs one after another; while one with preventAuto (on by default) runs, the triggers it sets off run nothing. */
export class AutoExecutor {
  private readonly stack: boolean[] = [];

  constructor(private readonly run: (set: QrSet, item: QrItem) => Promise<void>) {}

  get blocked(): boolean {
    return this.stack[this.stack.length - 1] === true;
  }

  /** `blocked`: whether what set this off started while a QR was blocking; by default, whether one is now. */
  async fire(targets: AutoTarget[], blocked = this.blocked): Promise<void> {
    if (blocked || !targets.length) return;
    for (const { set, item } of targets) {
      this.stack.push(item.preventAuto !== false);
      try {
        await this.run(set, item);
      } catch (e) {
        console.warn("[Dispensa] auto-run", e);
      } finally {
        this.stack.pop();
      }
    }
  }
}
