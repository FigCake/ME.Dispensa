// Rewrites an imported SillyTavern QR once to Marinara's numbering (first message = 1) and command meanings
// (/nar → /sys, /random → /randomchar). {{lastMessageId}} already follows the running app, so only hand-written
// positions need +1: literals in /hide, at= and the like, literals stored in variables used as positions, and
// literals compared against those. Anything it cannot follow keeps SillyTavern mode, with the reason.

import type { Closure, CommandNode } from "../stscript/ast";
import { parse } from "../stscript/parser";
import type { CommandRegistry } from "../stscript/registry";
import { t } from "../shared/i18n";

export interface ConversionResult {
  ok: boolean;
  script: string;
  /** How many places were rewritten. */
  changes: number;
  /** Why the QR has to stay in SillyTavern mode. */
  reasons: string[];
}


const INDEX_COMMANDS = new Set(["hide", "unhide", "messages", "message", "cut", "goto", "jump", "scroll"]);
const AT_COMMANDS = new Set(["send", "sendas", "sys", "system", "comment", "nar"]);
const COMPARE_COMMANDS = new Set(["if", "while"]);
const BODY_COMMANDS = new Set(["if", "while", "times", "run", "loader-wrap"]);
const ASSIGN_COMMANDS = new Set(["setvar", "let", "var"]);
const MODIFY_COMMANDS = new Set(["addvar", "incvar", "decvar"]);
const OPERAND_KEYS = ["left", "right", "a", "b", "first", "second", "x", "y"];
const LAST_ID_RE = /\{\{lastMessageId\}\}/gi;
const VAR_MACRO_RE = /\{\{(?:getvar|var)::\s*([^}:]+?)\s*\}\}/gi;
const RISKY_IN_STRINGS = /\/(?:hide|unhide|messages?|cut|goto|jump|scroll|nar|random)\b|\bat=|\{\{lastMessageId\}\}/i;

interface Edit {
  start: number;
  end: number;
  text: string;
}

type Operand = { kind: "last" } | { kind: "var"; name: string } | { kind: "lit"; value: number } | { kind: "other" };

/** A QR counting messages from #0 → counting from #1. */
export function convertToMarinara(script: string, registry: CommandRegistry): ConversionResult {
  if (!script.trimStart().startsWith("/")) return { ok: true, script, changes: 0, reasons: [] };
  let root: Closure;
  try {
    root = parse(script, { lookup: (n) => registry.get(n) });
  } catch (e) {
    return { ok: false, script, changes: 0, reasons: [t(`Syntax error: ${e instanceof Error ? e.message : String(e)}`, `문법 오류: ${e instanceof Error ? e.message : String(e)}`)] };
  }

  const reasons = new Set<string>();
  const edits: Edit[] = [];
  const nodes = flatten(root, reasons);

  // ── 1. variables: how is each one assigned? ──
  interface VarInfo {
    literal: number;
    fromLast: number;
    other: boolean;
    asIndex: boolean;
  }
  const vars = new Map<string, VarInfo>();
  const info = (name: string) => {
    let v = vars.get(name);
    if (!v) vars.set(name, (v = { literal: 0, fromLast: 0, other: false, asIndex: false }));
    return v;
  };
  for (const node of nodes) {
    if (ASSIGN_COMMANDS.has(node.name)) {
      const target = assignment(node);
      if (!target) continue;
      if (node.name === "var" && target.value !== null && target.value.trim() === "") continue; // a read, not a write
      const v = info(target.name);
      if (target.value === null) v.other = true;
      else if (/^\{\{lastMessageId\}\}$/i.test(target.value.trim())) v.fromLast++;
      else if (/^-?\d+$/.test(target.value.trim())) v.literal++;
      else v.other = true;
    } else if (MODIFY_COMMANDS.has(node.name)) {
      const name = varArg(node);
      if (!name) continue;
      const amount = node.name === "addvar" ? unnamedText(node) : "1";
      if (amount === null || !/^-?\d+$/.test(amount.trim())) info(name).other = true;
      else info(name);
    }
  }

  // ── 2. which variables hold message positions? ──
  for (const node of nodes) {
    if (!INDEX_COMMANDS.has(node.name)) continue;
    const region = unnamedRegion(script, node);
    if (!region) continue;
    for (const m of region.text.matchAll(VAR_MACRO_RE)) info(m[1]).asIndex = true;
  }
  const anchored = (name: string) => {
    const v = vars.get(name);
    return !!v && !v.other && (v.fromLast > 0 || v.asIndex);
  };
  for (const [name, v] of vars) {
    if ((v.fromLast > 0 || v.asIndex) && v.other) reasons.add(t(`Variable "${name}" gets message numbers mixed with other values`, `변수 "${name}"에 메시지 번호와 다른 값이 섞여 들어가요`));
  }

  // Every {{lastMessageId}} and every macro use of an anchored variable must be accounted for.
  let lastHandled = 0;
  const varHandled = new Map<string, number>();
  const handleVar = (name: string) => varHandled.set(name, (varHandled.get(name) ?? 0) + 1);

  const bound = (text: string): string | null => {
    const t = text.trim();
    if (/^\d+$/.test(t)) return text.replace(t, String(Number(t) + 1));
    if (/^\{\{lastMessageId\}\}$/i.test(t)) {
      lastHandled++;
      return text;
    }
    const m = /^\{\{(?:getvar|var)::\s*([^}:]+?)\s*\}\}$/i.exec(t);
    if (m && anchored(m[1])) {
      handleVar(m[1]);
      return text;
    }
    return null;
  };

  // ── 3. rewrite ──
  for (const node of nodes) {
    if (node.name === "nar") edits.push({ start: node.start, end: node.start + 4, text: "/sys" });
    if (node.name === "random") edits.push({ start: node.start, end: node.start + "/random".length, text: "/randomchar" });

    if (AT_COMMANDS.has(node.name) && node.named.some((a) => a.name === "at")) {
      const arg = namedArg(script, node, "at");
      if (arg && /^\d+$/.test(arg.value)) edits.push({ start: arg.start, end: arg.start + arg.value.length, text: String(Number(arg.value) + 1) });
      else reasons.add(t(`/${node.name}: the at= value isn't a number`, `/${node.name}의 at= 값이 숫자가 아니에요`));
    }

    if (INDEX_COMMANDS.has(node.name)) {
      const region = unnamedRegion(script, node);
      if (!region) {
        if (node.name !== "messages" && node.name !== "message") reasons.add(t(`/${node.name} uses the previous command's result (pipe) as a message number`, `/${node.name}이(가) 앞 명령의 결과(파이프)를 메시지 번호로 써요`));
        continue;
      }
      const rewritten = rewriteRange(region.text, bound);
      if (rewritten === null) {
        reasons.add(t(`/${node.name}: can't follow the message number (${region.text.trim().slice(0, 40)})`, `/${node.name}의 메시지 번호를 따라갈 수 없어요 (${region.text.trim().slice(0, 40)})`));
        continue;
      }
      if (rewritten !== region.text) edits.push({ start: region.start, end: region.start + region.text.length, text: rewritten });
    }

    if (ASSIGN_COMMANDS.has(node.name)) {
      const target = assignment(node);
      if (target && target.value !== null && anchored(target.name)) {
        const value = target.value.trim();
        if (/^\{\{lastMessageId\}\}$/i.test(value)) lastHandled++;
        else if (/^-?\d+$/.test(value)) {
          const region = unnamedRegion(script, node);
          const m = region ? /(-?\d+)\s*$/.exec(region.text) : null;
          if (region && m) {
            const at = region.start + m.index;
            edits.push({ start: at, end: at + m[1].length, text: String(Number(m[1]) + 1) });
          }
        }
      }
    }

    if (COMPARE_COMMANDS.has(node.name)) {
      const ops = OPERAND_KEYS.map((k) => namedArg(script, node, k)).filter((o): o is NonNullable<typeof o> => !!o);
      if (ops.length === 0) continue;
      const kinds = ops.map((o) => classify(o.value, anchored));
      const isIndex = (k: Operand) => k.kind === "last" || (k.kind === "var" && anchored(k.name));
      const indexSides = kinds.filter(isIndex).length;
      if (indexSides === 0) continue;
      for (const k of kinds) {
        if (k.kind === "last") lastHandled++;
        if (k.kind === "var" && anchored(k.name) && /\{\{/.test(ops[kinds.indexOf(k)].value)) handleVar(k.name);
      }
      if (indexSides === 1 && ops.length === 2) {
        const otherIdx = isIndex(kinds[0]) ? 1 : 0;
        const other = kinds[otherIdx];
        if (other.kind === "lit") {
          const o = ops[otherIdx];
          const numAt = o.start + o.value.indexOf(String(other.value));
          edits.push({ start: numAt, end: numAt + String(other.value).length, text: String(other.value + 1) });
        } else {
          reasons.add(t(`/${node.name} compares a message number with a computed value`, `/${node.name}에서 메시지 번호를 계산된 값과 비교해요`));
        }
      }
    }
  }

  // ── 4. anything left unaccounted for? ──
  const totalLast = (script.match(LAST_ID_RE) ?? []).length;
  if (totalLast > lastHandled) reasons.add(t("{{lastMessageId}} is also used for things other than message numbers (text output, math, etc.)", "{{lastMessageId}}를 메시지 번호 말고 다른 곳(글자 출력, 계산 등)에도 써요"));
  const macroUses = new Map<string, number>();
  for (const m of script.matchAll(VAR_MACRO_RE)) macroUses.set(m[1], (macroUses.get(m[1]) ?? 0) + 1);
  for (const [name, count] of macroUses) {
    if (anchored(name) && count > (varHandled.get(name) ?? 0)) reasons.add(t(`Variable "${name}" holds a message number and is also used elsewhere`, `메시지 번호를 담은 변수 "${name}"를 다른 곳에도 써요`));
  }

  if (reasons.size) return { ok: false, script, changes: 0, reasons: [...reasons] };
  let out = script;
  const unique = dedupe(edits);
  for (const e of unique.sort((a, b) => b.start - a.start)) out = out.slice(0, e.start) + e.text + out.slice(e.end);
  return { ok: true, script: out, changes: unique.length, reasons: [] };
}

// ── helpers ─────────────────────────────────────────────────

function flatten(root: Closure, reasons: Set<string>): CommandNode[] {
  const out: CommandNode[] = [];
  const visit = (c: Closure) => {
    for (const a of c.args) if (typeof a.value !== "string") visit(a.value);
    for (const ex of c.executors) {
      if (ex.kind !== "command") continue;
      out.push(ex);
      for (const arg of ex.named) {
        if (typeof arg.value !== "string") visit(arg.value);
        else if (BODY_COMMANDS.has(ex.name) && arg.name === "else" && RISKY_IN_STRINGS.test(arg.value)) reasons.add(t(`/${ex.name}: a quoted command has a message number`, `/${ex.name}의 따옴표 속 명령에 메시지 번호가 있어요`));
      }
      for (const arg of ex.unnamed) {
        if (typeof arg.value !== "string") visit(arg.value);
        else if (BODY_COMMANDS.has(ex.name) && RISKY_IN_STRINGS.test(arg.value)) reasons.add(t(`/${ex.name}: a quoted command has a message number`, `/${ex.name}의 따옴표 속 명령에 메시지 번호가 있어요`));
      }
    }
  };
  visit(root);
  return out;
}

function dedupe(edits: Edit[]): Edit[] {
  const seen = new Map<string, Edit>();
  for (const e of edits) seen.set(`${e.start}:${e.end}`, e);
  return [...seen.values()];
}

function unnamedText(node: CommandNode): string | null {
  if (node.unnamed.length === 0) return "";
  if (node.unnamed.some((u) => typeof u.value !== "string")) return null;
  return node.unnamed.map((u) => u.value as string).join(" ");
}

function varArg(node: CommandNode): string | null {
  const key = node.named.find((a) => a.name === "key" || a.name === "name");
  if (key) return typeof key.value === "string" ? key.value.trim() : null;
  const t = unnamedText(node);
  return t ? t.trim() : null;
}

/** /setvar key=x V, /let x V, /var x V → { name, value } (value null when not plain text). */
function assignment(node: CommandNode): { name: string; value: string | null } | null {
  const key = node.named.find((a) => a.name === "key");
  if (node.name === "setvar" || key) {
    const name = key && typeof key.value === "string" ? key.value.trim() : "";
    if (!name) return null;
    return { name, value: unnamedText(node) };
  }
  const parts = node.unnamed;
  if (!parts.length || typeof parts[0].value !== "string") return null;
  const name = parts[0].value.trim();
  if (parts.slice(1).some((p) => typeof p.value !== "string")) return { name, value: null };
  return { name, value: parts.slice(1).map((p) => p.value as string).join(" ") };
}

function classify(raw: string, anchored: (n: string) => boolean): Operand {
  const t = raw.trim();
  if (/^\{\{lastMessageId\}\}$/i.test(t)) return { kind: "last" };
  const m = /^\{\{(?:getvar|var)::\s*([^}:]+?)\s*\}\}$/i.exec(t);
  if (m) return { kind: "var", name: m[1] };
  if (/^-?\d+$/.test(t)) return { kind: "lit", value: Number(t) };
  if (/^\w+$/.test(t) && anchored(t)) return { kind: "var", name: t }; // bare variable name operand
  return { kind: "other" };
}

/** Where a named argument's value sits in the script (quotes excluded). */
function namedArg(script: string, node: CommandNode, key: string): { start: number; value: string } | null {
  const slice = script.slice(node.start, node.end);
  const head = /^\/\S+((?:\s+\w+=(?:"(?:[^"\\]|\\.)*"|\[[^\]]*\]|\{:[\s\S]*?:\}|\S+))*)/.exec(slice);
  if (!head) return null;
  const region = slice.slice(0, head[0].length);
  const m = new RegExp(`(^|\\s)${key}=("((?:[^"\\\\]|\\\\.)*)"|(?!\\{:)\\S+)`).exec(region);
  if (!m) return null;
  const quoted = m[3] !== undefined;
  const value = quoted ? m[3] : m[2];
  const start = node.start + m.index + m[1].length + key.length + 1 + (quoted ? 1 : 0);
  return { start, value };
}

/** Where the unnamed argument sits in the script. */
function unnamedRegion(script: string, node: CommandNode): { start: number; text: string } | null {
  const slice = script.slice(node.start, node.end);
  const m = /^\/\S+((?:\s+\w+=(?:"(?:[^"\\]|\\.)*"|\[[^\]]*\]|\S+))*)\s+([\s\S]*?)\s*$/.exec(slice);
  if (!m || !m[2]) return null;
  const text = m[2];
  return { start: node.start + slice.trimEnd().length - text.length, text };
}

/** "2,5,9-12" → "3,6,10-13", each bound through `bound`; null when a bound cannot be followed. */
export function rewriteRange(text: string, bound: (b: string) => string | null = defaultBound): string | null {
  const out: string[] = [];
  for (const part of text.split(",")) {
    const m = /^(\s*)(\{\{[^}]*\}\}|[^-\s{][^-]*?)(?:(\s*-\s*)(\{\{[^}]*\}\}|\S+?))?(\s*)$/.exec(part);
    if (!m) return null;
    const a = bound(m[2]);
    if (a === null) return null;
    let piece = `${m[1]}${a}`;
    if (m[3] !== undefined) {
      const b = bound(m[4]);
      if (b === null) return null;
      piece += `${m[3]}${b}`;
    }
    out.push(piece + m[5]);
  }
  return out.join(",");
}

function defaultBound(b: string): string | null {
  if (/^\d+$/.test(b)) return String(Number(b) + 1);
  if (/^\{\{lastMessageId\}\}$/i.test(b)) return b;
  return null;
}
