// A QR run from the Gallery reads the chat but never changes it: what it would post or put in the
// input is kept for the Gallery, its AI calls use the Gallery's connection with the chat's context
// (Marinara's dry run, which doesn't wait for the chat's own reply), and chat variables stay in the run.

import { t } from "../shared/i18n";
import { type Host, LONG_REPLY_TOKENS } from "../stscript/host";
import { ScriptError } from "../stscript/scope";
import type { VariableStore } from "../stscript/variables";

/** `target` with some members replaced; the rest still run on `target` itself. */
function over<T extends object>(target: T, replaced: Record<string, unknown>): T {
  return new Proxy(target, {
    get(obj, key) {
      if (typeof key === "string" && Object.prototype.hasOwnProperty.call(replaced, key)) return replaced[key];
      const v = Reflect.get(obj, key, obj) as unknown;
      return typeof v === "function" ? (v as (...a: unknown[]) => unknown).bind(obj) : v;
    },
  });
}

/** Changes made in the run only (deleted names hide what is below). */
function inRunOnly(base: VariableStore): VariableStore {
  const mine = new Map<string, string | null>();
  return {
    get: (n) => (mine.has(n) ? (mine.get(n) ?? undefined) : base.get(n)),
    set: (n, v) => void mine.set(n, v),
    delete: (n) => void mine.set(n, null),
    has: (n) => (mine.has(n) ? mine.get(n) !== null : base.has(n)),
    entries: () => {
      const all = new Map(base.entries());
      for (const [k, v] of mine) {
        if (v === null) all.delete(k);
        else all.set(k, v);
      }
      return [...all];
    },
  };
}

export interface GalleryRun {
  host: Host;
  /** What the run would have posted or put in the input, in order. */
  outputs: string[];
  /** The visualizer made (and saved) a page itself. */
  madePages: number;
  /** The visualizer was asked for a page and said itself why there is none. */
  failedPages: number;
}

/**
 * `title`: the QR's label, for pages the visualizer saves. `input`: a memo (or a board) given to the
 * run: picking a memo ([[memo]], /memo) takes it without asking, and {{getvar::input}} reads it.
 * `runQr`: runs another QR (/qr) inside this run, on its host.
 */
export function galleryHost(base: Host, connectionId: string, title?: string, input?: string, preset?: boolean, runQr?: (name: string, host: Host) => Promise<void>): GalleryRun {
  const run: GalleryRun = { host: base, outputs: [], madePages: 0, failedPages: 0 };
  const refuse = (what: string) => async () => {
    throw new ScriptError(t(`${what}: this changes the chat, so it doesn't run from the Gallery.`, `${what}: 채팅을 바꾸는 명령이라 갤러리에서는 실행되지 않아요.`));
  };
  const chat = over(base.chat, {
    send: async (o: { text: string }) => void run.outputs.push(o.text),
    generate: (o: Parameters<Host["chat"]["generate"]>[0]) => base.chat.generate({ ...o, connectionId: o.connectionId || connectionId || undefined, memory: true, preset: o.preset ?? preset, maxTokens: LONG_REPLY_TOKENS }),
    setHidden: refuse("/hide"),
    runNativeCommand: refuse(t("Marinara's own commands", "마리나라 명령")),
    continueLast: refuse("/continue"),
    regenerate: refuse("/regenerate"),
    trigger: refuse("/trigger"),
    addSwipe: refuse("/addswipe"),
    deleteMessages: refuse("/del"),
    openRandomCharacter: refuse("/random"),
  });
  // no full-screen loader (/gen lock=on, /loader-show): the chat stays usable while a Gallery run goes on
  const ui = over(base.ui, { setInput: (text: string) => void (text && run.outputs.push(text)), loader: () => undefined });
  const marinara = base.marinara
    ? over(base.marinara, {
        patchTracker: refuse("/tracker-set"),
        retryAgents: refuse("/agents-retry"),
        createEntry: refuse(t("Adding a lorebook entry", "로어북 항목 추가")),
        patchEntry: refuse(t("Changing a lorebook entry", "로어북 항목 수정")),
        chatBook: (create: boolean) => (create ? refuse(t("Making the chat's lorebook", "채팅 로어북 만들기"))() : base.marinara!.chatBook(false)),
        updateCharacter: refuse(t("Changing a character", "캐릭터 수정")),
        setConnection: refuse("/connection"),
        renameChat: refuse(t("Renaming the chat", "채팅 이름 바꾸기")),
        newChat: refuse(t("A new chat", "새 채팅")),
        setAuthorNote: refuse(t("The author's note", "작가 노트")),
        reloadPage: refuse("/reload-page"),
      })
    : undefined;
  const visz = base.visz
    ? {
        run: async (text: string, options: Parameters<NonNullable<Host["visz"]>["run"]>[1]) => {
          const ok = await base.visz!.run(text, { ...options, gallery: { connectionId, title, input } });
          if (ok) run.madePages++;
          else run.failedPages++;
          return ok;
        },
      }
    : undefined;
  // another QR runs inside the run too, so it can't post to the chat either
  const qr = base.qr
    ? over(base.qr, {
        run: (name: string) => (runQr ? runQr(name, run.host) : refuse("/qr")()),
        runLater: () => {
          throw new ScriptError(t("/qr-later: this changes the chat, so it doesn't run from the Gallery.", "/qr-later: 채팅을 바꾸는 명령이라 갤러리에서는 실행되지 않아요."));
        },
      })
    : undefined;
  const local = inRunOnly(base.local);
  if (input !== undefined) local.set("input", input);
  const memo = base.memo && input !== undefined ? over(base.memo, { pick: async () => input }) : base.memo;
  // asking first is for changes to the chat, which a Gallery run doesn't make
  const confirm = refuse(t("Deleting or changing messages", "메시지 지우기·바꾸기"));
  run.host = over(base, { chat, ui, marinara, visz, qr, local, confirm, memo });
  return run;
}
