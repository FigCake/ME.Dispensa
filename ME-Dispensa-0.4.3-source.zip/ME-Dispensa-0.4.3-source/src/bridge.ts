// window.__dispensa: how other extensions run STscript through Dispensa.
// Its shape is in src/shared/dispensa-bridge.ts, shared with Fornello.

import type { Host } from "./stscript/host";
import { addExternalCommand } from "./stscript";
import { DISPENSA_READY, type DispensaBridge, type DockGroup } from "./shared/dispensa-bridge";
import type { CommandRegistry } from "./stscript/registry";
import { Runtime, asText } from "./stscript/interpreter";

/** A group as another extension handed it, or null when it is not one (its items without a label or a run are left out). */
export function validDockGroup(group: unknown): DockGroup | null {
  if (!group || typeof group !== "object") return null;
  const g = group as Record<string, unknown>;
  if (typeof g.name !== "string" || !Array.isArray(g.items)) return null;
  const text = (v: unknown) => (typeof v === "string" ? v : undefined);
  const items: DockGroup["items"] = [];
  for (const raw of g.items as unknown[]) {
    const item = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : null;
    if (!item || typeof item.label !== "string" || typeof item.run !== "function") continue;
    const run = item.run as () => void;
    items.push({ label: item.label, title: text(item.title), group: text(item.group), run: () => run() });
  }
  const remove = typeof g.remove === "function" ? (g.remove as () => void) : null;
  return { name: g.name, icon: text(g.icon) ?? "", items, ...(remove ? { remove: () => remove() } : {}) };
}

/** Puts the bridge on window and says "dispensa:ready"; returns what takes it off again. */
export function publishBridge(
  host: Host,
  registry: CommandRegistry,
  openSettings: () => void,
  setDockGroup: (id: string, group: DockGroup | null) => void,
  dockShown: () => boolean,
  importQrs?: (json: unknown, name: string, characterId?: string) => number,
): () => void {
  const bridge: DispensaBridge = {
    version: 1,
    runSlash: async (text) => {
      const rt = new Runtime({ host, registry, dialect: "st" });
      return asText((await rt.runScript(String(text ?? ""))).pipe);
    },
    registerCommand: (def) => addExternalCommand(registry, def),
    openSettings,
    // anything that is not a group takes the bubble out
    setDockGroup: (id, group) => setDockGroup(String(id), validDockGroup(group)),
    dockShown,
    ...(importQrs ? { importQrs: async (json: unknown, name: unknown, options?: { characterId?: unknown }) => importQrs(json, String(name ?? ""), typeof options?.characterId === "string" ? options.characterId : undefined) } : {}),
  };
  window.__dispensa = bridge;
  window.dispatchEvent(new Event(DISPENSA_READY));
  return () => {
    if (window.__dispensa === bridge) delete window.__dispensa;
  };
}
