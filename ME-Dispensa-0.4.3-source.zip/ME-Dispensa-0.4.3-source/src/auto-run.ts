// Auto-run (SillyTavern's executeOn…): wires the rules in qr/auto.ts to Marinara's events.

import type { ChatScopeWatch } from "./host/chat-scope";
import { activatedEntries, watchGeneration } from "./host/generation-watch";
import { AutoExecutor, autoTargets, automationTargets } from "./qr/auto";
import type { AutoTrigger, QrItem, QrSet, QrState } from "./qr/model";
import type { ChatScope } from "./qr/scopes";
import { activeSets } from "./qr/scopes";
import type { HostChat } from "./stscript/host";
import { sleep } from "./util";

export interface AutoRunDeps {
  state(): QrState;
  scope: ChatScopeWatch;
  chat: Pick<HostChat, "messages"> & { markStale(): void };
  run(set: QrSet, item: QrItem): Promise<void>;
  /** The open chat changed (and once when the watch starts). */
  onScope(scope: ChatScope): void;
}

/** Starts the chat watch and the triggers; returns what stops them. */
export function startAutoRun(deps: AutoRunDeps): () => void {
  const { scope, chat } = deps;
  const auto = new AutoExecutor(deps.run);
  const fire = (trigger: AutoTrigger, blocked?: boolean) => auto.fire(autoTargets(activeSets(deps.state(), scope.current), trigger), blocked);
  // new chats, and whether they were made while an auto-run was blocking others
  const newChats = new Map<string, boolean>();
  // a generation started by an auto-run QR that blocks others sets off nothing (SillyTavern's preventAutoExecute)
  const startedBlocked = new WeakMap<object, boolean>();
  let lastBlocked = false;
  const onGenerationComplete = () => void fire("ai", lastBlocked);
  window.addEventListener("marinara:generation-complete", onGenerationComplete);
  // the saved message shows up in the chat's message list a moment after the event
  const untilListed = async (id: unknown) => {
    if (typeof id !== "string") return;
    for (let i = 0; i < 20; i++) {
      chat.markStale();
      const list = await chat.messages().catch(() => []);
      if (list.some((m) => m.id === id)) return;
      await sleep(250);
    }
  };
  let beforeRunning = false;
  const entries = new WeakMap<object, { id?: unknown; name?: unknown }[]>();
  const stopWatching = watchGeneration({
    beforeGeneration: async (body) => {
      const blocked = auto.blocked;
      startedBlocked.set(body, blocked);
      lastBlocked = blocked;
      // a "before" QR that starts a generation itself does not wait on itself
      if (beforeRunning || blocked) return;
      beforeRunning = true;
      try {
        await fire("beforeGeneration");
      } finally {
        beforeRunning = false;
      }
    },
    onEvent: (event, body) => {
      const blocked = startedBlocked.get(body) ?? false;
      const role = (event.data as { role?: unknown } | null)?.role;
      if (event.type === "message_saved" && role === "user") void untilListed((event.data as { id?: unknown }).id).then(() => fire("user", blocked));
      else if (event.type === "message_saved") entries.set(body, [...(entries.get(body) ?? []), ...activatedEntries(event.data)]);
      else if (event.type === "group_turn") void fire("groupDraft", blocked);
      else if (event.type === "dispensa:end") {
        // lorebook entries that came into play run the QRs with their automation id
        const found = entries.get(body) ?? [];
        entries.delete(body);
        if (found.length) void auto.fire(automationTargets(activeSets(deps.state(), scope.current), found), blocked);
      }
    },
    onChatCreated: ({ id }) => newChats.set(id, auto.blocked),
  });
  let unsubscribeScope = () => {};
  void (async () => {
    await scope.start();
    deps.onScope(scope.current);
    unsubscribeScope = scope.onChange((now) => {
      deps.onScope(scope.current);
      void (async () => {
        await fire("chatChange");
        if (now.chatId && newChats.has(now.chatId)) {
          const blocked = newChats.get(now.chatId);
          newChats.delete(now.chatId);
          await fire("newChat", blocked);
        }
      })();
    });
    await fire("startup");
    if (scope.current.chatId) await fire("chatChange");
  })();
  return () => {
    unsubscribeScope();
    scope.stop();
    stopWatching();
    window.removeEventListener("marinara:generation-complete", onGenerationComplete);
  };
}
