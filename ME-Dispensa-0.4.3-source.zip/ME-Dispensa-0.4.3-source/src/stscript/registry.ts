import type { CommandSpec } from "./ast";
import type { CommandCall } from "./interpreter";

export interface CommandDef extends CommandSpec {
  name: string;
  aliases?: string[];
  /** Shown in the editor's command list. */
  help: string;
  /** From SillyTavern, Dispensa-only, a Marinara pass-through, or added by another extension. */
  origin?: "st" | "dispensa" | "marinara" | "extension";
  /** The extension that added it (origin "extension"). */
  from?: string;
  /** Hidden from the editor's list (another command does the same job) but still runs. */
  unlisted?: boolean;
  run(call: CommandCall): Promise<unknown> | unknown;
}

export class CommandRegistry {
  private readonly map = new Map<string, CommandDef>();

  register(...defs: CommandDef[]): this {
    for (const def of defs) {
      this.map.set(def.name, def);
      for (const alias of def.aliases ?? []) this.map.set(alias, def);
    }
    return this;
  }

  /** Removes the names and aliases that still point to this command. */
  unregister(def: CommandDef): void {
    for (const name of [def.name, ...(def.aliases ?? [])]) if (this.map.get(name) === def) this.map.delete(name);
  }

  get(name: string): CommandDef | undefined {
    return this.map.get(name);
  }

  has(name: string): boolean {
    return this.map.has(name);
  }

  list(): CommandDef[] {
    return [...new Set(this.map.values())].filter((d) => !d.unlisted).sort((a, b) => a.name.localeCompare(b.name));
  }
}
