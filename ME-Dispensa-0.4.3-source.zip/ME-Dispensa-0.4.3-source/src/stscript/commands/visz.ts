// /visz from a script (Dispensa addition); not /viz, so it never meets a command Marinara might add.

import { asText } from "../interpreter";
import type { CommandDef } from "../registry";
import { ScriptError } from "../scope";

export const viszCommands: CommandDef[] = [
  {
    name: "visz",
    help: '🌟 Make a page from the text through the visualizer ([[…]] asks first): /visz [output=viewer|chat|gallery] [prompt=last] topic (prompt=last: the text is a message, made into a new scene) → true when sent',
    origin: "dispensa",
    run: async (c) => {
      if (!c.rt.host.visz) throw new ScriptError("/visz only works inside Dispensa");
      const text = asText(c.unnamed).trim();
      if (!text) throw new ScriptError("/visz needs a topic");
      const action = c.named.action === undefined ? undefined : asText(c.named.action);
      const output = c.named.output === undefined ? undefined : asText(c.named.output);
      if (action && action !== "viz" && action !== "ooc") throw new ScriptError('/visz action= is "viz" or "ooc"');
      if (output && output !== "viewer" && output !== "chat" && output !== "gallery") throw new ScriptError('/visz output= is "viewer", "chat" or "gallery"');
      const prompt = c.named.prompt === undefined ? undefined : asText(c.named.prompt);
      if (prompt && prompt !== "superviz" && prompt !== "last") throw new ScriptError('/visz prompt= is "superviz" or "last"');
      return String(await c.rt.host.visz.run(text, { action: action as "viz" | "ooc" | undefined, output: output as "viewer" | "chat" | "gallery" | undefined, prompt: prompt as "superviz" | "last" | undefined }));
    },
  },
];
