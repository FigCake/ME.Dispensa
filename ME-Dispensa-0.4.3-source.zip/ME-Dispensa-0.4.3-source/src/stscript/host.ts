// What the interpreter needs from outside: the Marinara binding in the app, a fake in tests.

import type { MacroFacts } from "./macros";
import type { VariableStore } from "./variables";

export type Severity = "info" | "success" | "warning" | "error";

export interface PopupOptions {
  large?: boolean;
  wide?: boolean;
  okButton?: string;
  cancelButton?: string;
  rows?: number;
  placeholder?: string;
  defaultValue?: string;
  multiline?: boolean;
  /** input(): a button beside OK that fills the field. */
  extra?: { label: string; title?: string; fill(): Promise<string | null> };
}

/** A group of a pick list's items: `items` are the values (as in the list), `names` what each shows inside the group. */
export interface PickGroup {
  label: string;
  icon?: string;
  items: string[];
  names: string[];
}

export interface HostUI {
  /** `action`: a button in the toast (Undo, say); pressing it runs `run` and closes the toast. */
  toast(message: string, severity?: Severity, options?: { title?: string; action?: { label: string; run: () => void } }): void;
  /** Resolves with the typed text, or null when cancelled. */
  input(prompt: string, options?: PopupOptions): Promise<string | null>;
  popup(html: string, options?: PopupOptions): Promise<boolean>;
  /** Resolves with the clicked label, or "" when cancelled. */
  buttons(html: string, labels: string[], options?: { multiple?: boolean }): Promise<string>;
  setInput(text: string): void;
  getInput(): string;
  beep(): void;
  loader(state: "show" | "hide", text?: string): void;
  /** Resolves with name → value, or null when cancelled. */
  form?(title: string, fields: FormField[]): Promise<Record<string, string> | null>;
  /** Searchable list; resolves [] when cancelled. With `groups`, the list shows the groups first and a group opens to its items (a search still looks through all). */
  pick?(prompt: string, items: string[], options?: { multiple?: boolean; placeholder?: string; groups?: PickGroup[] }): Promise<string[]>;
  /** System notification (falls back to a toast). */
  notify?(title: string, body: string): Promise<void>;
  copy?(text: string): Promise<void>;
  paste?(): Promise<string>;
}

export interface FormField {
  name: string;
  label?: string;
  type?: "text" | "number" | "textarea" | "select" | "checkbox";
  default?: string;
  placeholder?: string;
  options?: string[];
}

export interface ChatMessageInfo {
  /** 1-based position, the way Marinara numbers messages. */
  number: number;
  id: string;
  role: "user" | "assistant" | "system" | "narrator";
  name: string;
  content: string;
  hidden: boolean;
}

/** How long a Gallery run's or the visualizer's reply may be (tokens): a page with its story is long. */
export const LONG_REPLY_TOKENS = 35_000;

export interface GenerateOptions {
  /** "chat": with the chat's context (ST /gen). "raw": only the prompt (ST /genraw). */
  mode: "chat" | "raw";
  prompt: string;
  lock?: boolean;
  stop?: string[];
  /** Raw mode: role of the prompt line. */
  as?: "system" | "char";
  /** Generate on behalf of a specific character (ST /ask, /gen in groups). */
  characterName?: string;
  /** Use this Marinara connection instead of the chat's own (chat mode). */
  connectionId?: string;
  /** Chat mode: false leaves out the chat's prompt preset (its lorebooks and the chat summary still go in). */
  preset?: boolean;
  /** Chat mode: also the chat's lorebooks and summary (Marinara's dry run leaves them out unless asked). */
  memory?: boolean;
  /** Chat mode: the reply may be this long (tokens), whatever the chat's own setting says. */
  maxTokens?: number;
}

export interface SendOptions {
  role: "user" | "assistant" | "system" | "narrator";
  text: string;
  /** Character name for assistant messages. */
  name?: string;
  /** 1-based position to insert at (best effort). */
  at?: number;
  /** Shown in the chat but kept out of the AI's context (ST /comment). */
  hidden?: boolean;
}

export interface HostChat {
  /** Throws when no chat is open. */
  requireChat(): Promise<string>;
  messages(): Promise<ChatMessageInfo[]>;
  generate(options: GenerateOptions): Promise<string>;
  send(options: SendOptions): Promise<void>;
  setHidden(numbers: number[], hidden: boolean): Promise<number>;
  /** Run one of Marinara's own slash commands through the composer. */
  runNativeCommand(commandLine: string): Promise<void>;
  continueLast(): Promise<void>;
  regenerate(): Promise<void>;
  /** Start a normal generation, optionally for one group member. */
  trigger(characterName?: string): Promise<void>;
  addSwipe(text: string): Promise<void>;
  deleteMessages(numbers: number[]): Promise<number>;
  /** Refresh chat-related caches after writes. */
  refresh(): Promise<void>;
  /** SillyTavern /random: open a random (tagged) character's latest chat, creating one if needed. Returns the name. */
  openRandomCharacter?(tag?: string): Promise<string>;
  /** Resolves true once the AI is idle, false after the timeout. */
  waitForIdle?(timeoutMs: number): Promise<boolean>;
}

export interface Host {
  local: VariableStore;
  global: VariableStore;
  ui: HostUI;
  chat: HostChat;
  facts(): MacroFacts;
  refreshFacts(): Promise<void>;
  resolveHostMacros?(text: string): Promise<string>;
  /** Called once before a script starts, to reload chat state. */
  beginRun?(): Promise<void>;
  /** Persist variable changes. */
  flush(): Promise<void>;
  /** Ask the user before something destructive. */
  confirm(message: string): Promise<boolean>;
  /** Quick Reply storage and the Dock. */
  qr?: QrControl;
  visz?: ViszControl;
  memo?: MemoControl;
  /** Marinara-only features (tracker, lorebooks, connections, ...). */
  marinara?: MarinaraExtras;
}

export interface LoreBookInfo {
  id: string;
  name: string;
  chatId?: string | null;
}

export interface MarinaraExtras {
  getTracker(): Promise<import("../shared/tracker").TrackerState | null>;
  /** Send the named top-level fields of `state` back (they replace the stored ones). */
  patchTracker(state: import("../shared/tracker").TrackerState, fields: string[]): Promise<void>;
  retryAgents(types: string[]): Promise<{ ran: string[]; errors: string[] }>;
  /** Lorebooks active in the current chat. */
  activeBooks(): Promise<LoreBookInfo[]>;
  /** The chat's own lorebook, created on request. */
  chatBook(create: boolean): Promise<LoreBookInfo | null>;
  findBook(nameOrId: string): Promise<LoreBookInfo | null>;
  entries(bookId: string): Promise<import("../marinara/lore").LoreEntry[]>;
  createEntry(bookId: string, data: Record<string, unknown>): Promise<import("../marinara/lore").LoreEntry>;
  patchEntry(bookId: string, entryId: string, patch: Record<string, unknown>): Promise<void>;
  /** The current character (or one in the chat by name), with its card data. */
  character(name?: string): Promise<{ id: string; data: Record<string, unknown> } | null>;
  updateCharacter(id: string, data: Record<string, unknown>): Promise<void>;
  persona(): Promise<Record<string, unknown> | null>;
  connections(): Promise<{ id: string; name: string; model?: string }[]>;
  currentConnection(): Promise<{ id: string; name: string } | null>;
  setConnection(id: string): Promise<void>;
  peekPrompt(): Promise<{ role: string; content: string }[]>;
  chatName(): Promise<string>;
  renameChat(name: string): Promise<void>;
  /** New chat with the current character(s), greeting included; opens it. Returns the chat name. */
  newChat(): Promise<string>;
  authorNote(): Promise<{ text: string; depth: number }>;
  setAuthorNote(text: string | undefined, depth?: number): Promise<void>;
  reloadPage(): Promise<void>;
}

export interface QrInfo {
  set: string;
  label: string;
  title: string;
  message: string;
  hidden: boolean;
  startup: boolean;
  user: boolean;
  bot: boolean;
  load: boolean;
  newChat: boolean;
  group: boolean;
  generation: boolean;
  /** An emoji or a Font Awesome class (turned into an emoji). */
  icon: string;
  showLabel: boolean;
}

/** Which QR: by set and label, or by its number in the set (id=, counted from 1). */
export interface QrRef {
  set: string;
  label?: string;
  id?: number;
}

export interface QrSetOptions {
  nosend?: boolean;
  before?: boolean;
  inject?: boolean;
  color?: string;
  onlyBorder?: boolean;
}

export interface MemoControl {
  /** Memos chosen in a list (only those with `query` in them); null when none was chosen. */
  pick(query?: string): Promise<string | null>;
  /** Keeps text as memos (OOC wrappers come off; several notes, several memos). Returns how many. */
  add(text: string): number;
  /** Memo texts shown in this chat; `only` narrows to this chat's, this character's or global memos. */
  list(only?: "chat" | "character" | "global"): string[];
}

export interface ViszControl {
  /** Run the text as a visz request (default action "viz", a page). Resolves true once it went out. */
  run(textOrTitle: string, options: { action?: "viz" | "ooc"; output?: "viewer" | "chat" | "gallery"; prompt?: "superviz" | "last"; gallery?: { connectionId: string; title?: string; input?: string } }): Promise<boolean>;
}

export interface QrControl {
  /** Set names: all, the ones on in every chat ("global"), or the ones on for this chat ("chat"). */
  setNames(where?: "all" | "global" | "chat"): string[];
  labels(set: string): string[];
  /** A QR in SillyTavern's shape (plus Dispensa's own keys). */
  get(ref: QrRef): Record<string, unknown> | undefined;
  create(info: Partial<QrInfo> & { set: string; label: string }, dialect: Dialect): void;
  update(ref: QrRef, changes: Partial<QrInfo> & { newLabel?: string }): boolean;
  remove(ref: QrRef): boolean;
  createSet(name: string, options: QrSetOptions): void;
  updateSet(name: string, options: QrSetOptions): boolean;
  removeSet(name: string): boolean;
  /** On in every chat; undefined state toggles. Returns the new state. */
  setEnabled(name: string, state?: boolean): boolean;
  /** On for the open chat; undefined state toggles. Returns the new state. */
  setForChat(name: string, state?: boolean): boolean;
  setDisplay(name: string, display: "folder" | "inline"): boolean;
  /** Sub menus: add a set (chained or not), take one off, or clear them. */
  contextAdd(ref: QrRef, setName: string, chained: boolean): void;
  contextDel(ref: QrRef, setName: string): void;
  contextClear(ref: QrRef): void;
  /** Undefined state toggles. Returns the new state. */
  dockVisible(state?: boolean): boolean;
  /** Visible QRs in Dock order, for SillyTavern's /qr index. */
  visible(): { set: string; label: string }[];
  runLater(name: string, delayMs: number): void;
  run(name: string): Promise<void>;
  /** The script of a QR found by "Label" or "Set.Label" (for /import). */
  source(name: string): ScriptSource | undefined;
}

/** A Quick Reply as the interpreter sees it (for /run and /:). */
export interface ScriptSource {
  script: string;
  dialect: Dialect;
  label: string;
  setName: string;
}

/** "st": imported from SillyTavern, messages counted from 0; "marinara": counted from 1 like Marinara. */
export type Dialect = "st" | "marinara";
