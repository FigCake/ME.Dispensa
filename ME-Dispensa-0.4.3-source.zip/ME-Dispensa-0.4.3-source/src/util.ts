// Small helpers shared across layers (no DOM, no Marinara).

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

declare global {
  interface RegExpConstructor {
    escape?(text: string): string;
  }
}

/** Text matched literally inside a RegExp (native RegExp.escape where the browser has it). */
export const escapeRegex = (text: string): string => RegExp.escape?.(text) ?? text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const HTML_ENTITIES: Record<string, string> = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };

/** Text made safe to put into HTML (popups take HTML). */
export function escapeHtml(text: string): string {
  return text.replace(/[&<>"']/g, (c) => HTML_ENTITIES[c]);
}

/** The text on one line, cut to `max` characters with "…" (lists, labels). */
export function oneLine(text: string, max = 80): string {
  const one = text.replace(/\s+/g, " ").trim();
  return one.length > max ? `${one.slice(0, max - 1)}…` : one;
}

const ID_CHARS = "0123456789abcdefghijklmnopqrstuvwxyz";

/** A random id such as "qr_k3j9x2m1p0aa" (getRandomValues also works on plain http, unlike randomUUID). */
export function newId(prefix: string): string {
  const bytes = crypto.getRandomValues(new Uint8Array(12));
  return `${prefix}_${Array.from(bytes, (b) => ID_CHARS[b % ID_CHARS.length]).join("")}`;
}
