// Wand settings, items and preset in Dispensa's Marinara storage (key "wand").

import { getMarinara } from "../host/marinara-global";
import { type WandState, defaultWandState, normalizeWandState } from "./model";

const KEY = "wand";

export class WandStore {
  private state: WandState = defaultWandState();
  private readonly listeners = new Set<(s: WandState) => void>();
  private saveTimer: ReturnType<typeof setTimeout> | null = null;
  private loadedOk = false;

  /** Loaded from storage (writes are safe). */
  get ready(): boolean {
    return this.loadedOk;
  }

  get value(): WandState {
    return this.state;
  }

  async load(): Promise<void> {
    try {
      const stored = await getMarinara().storage.get();
      this.state = normalizeWandState(stored[KEY]);
      this.loadedOk = true;
    } catch (e) {
      // Never overwrite storage we could not read.
      this.loadedOk = false;
      throw e;
    }
    this.emit();
  }

  /** For tests and first runs without storage. */
  replace(state: WandState): void {
    this.state = state;
    this.loadedOk = true;
    this.emit();
  }

  subscribe(fn: (s: WandState) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  update(mutate: (s: WandState) => void): void {
    mutate(this.state);
    this.emit();
    this.scheduleSave();
  }

  size(): number {
    return new TextEncoder().encode(JSON.stringify(this.state)).length;
  }

  async saveNow(): Promise<void> {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = null;
    if (!this.loadedOk) return;
    await getMarinara().storage.patch({ [KEY]: this.state });
  }

  private scheduleSave(): void {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => {
      void this.saveNow().catch((e) => console.error("[Dispensa] wand save failed", e));
    }, 400);
  }

  private emit(): void {
    for (const fn of this.listeners) fn(this.state);
  }
}
