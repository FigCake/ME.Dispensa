// 🌟 Wand requests: 💬 OOC (sent one of four ways) and 🌟 visualizer pages
// (shown in the viewer above the bar, or posted to the chat).

import type { HostUI } from "../stscript/host";
import type { ArchiveBackend, ArchiveEntry } from "./archive";
import { assembleVisualizer, cleanOoc, extractHtmlBlocks, fillBlanks, findBlanks, findByTitle, mergeContinuation, normalizeOutput, replaceHtmlBlock, resolveVizMode, titleFrom, wrapOoc } from "./core";
import { CONTINUE_TEMPLATE } from "./defaults";
import { type OocMode, type VizOutput, type WandAction, type WandItem, type WandState, itemOptions, newWandId } from "./model";
import { t } from "../i18n";

/** A blank named like this is filled from the 메모장. */
const MEMO_BLANK = /^(메모|memo)$/i;

export interface WandHost {
  ui: HostUI & { choose?(label: string, options: string[]): Promise<string | null> };
  /** A reply with the chat's context, without saving anything. connectionId "" = the chat's connection. */
  generate(prompt: string, connectionId: string): Promise<string>;
  postAsCharacter(text: string): Promise<void>;
  sendAsUser(text: string): Promise<void>;
  putInInput(text: string): void;
  /** Marinara /guided: no visible message, the reply comes as the character's turn. */
  guided(text: string): Promise<void>;
  chatInfo(): Promise<{ chatId?: string; chatName?: string; character?: string }>;
  /** Fornello is installed: pages get its commands, so the 🌟 prompt can tell the model about them. */
  hasFornello?(): boolean;
  /** Memos chosen from the 메모장 (null when none), for [[메모]] and the 📝 button by a blank. */
  pickMemos?(): Promise<string | null>;
}

export interface ViewerEntry {
  title: string;
  kind: "viz" | "ooc";
  text: string;
  /** Set once the result is in the archive. */
  archivedId?: string;
}

export interface WandViewer {
  show(entry: ViewerEntry): void;
}

export interface RunOptions {
  title?: string;
  item?: WandItem;
  /** Override where a 🌟 page goes. */
  vizOutput?: VizOutput;
  oocMode?: OocMode;
}

/** Automatic attempts to finish a page that came back cut off. */
const AUTO_CONTINUE = 2;

export class WandService {
  private busyLabel: string | null = null;
  private readonly listeners = new Set<(busy: string | null) => void>();

  constructor(
    private readonly host: WandHost,
    private readonly state: () => WandState,
    readonly archive: ArchiveBackend,
    private readonly viewer: () => WandViewer | null,
    /** The 🌟 QRs in the QR 보관함 (for /visz by title). */
    private readonly items: () => WandItem[] = () => [],
  ) {}

  get busy(): string | null {
    return this.busyLabel;
  }

  onBusy(fn: (busy: string | null) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private setBusy(label: string | null): void {
    this.busyLabel = label;
    for (const fn of this.listeners) fn(label);
  }

  /** Asks for every [[blank]] ([[메모]]: picks from the 메모장); null when cancelled. */
  async askBlanks(text: string): Promise<string | null> {
    const values: Record<string, string> = {};
    const pick = this.host.pickMemos;
    for (const blank of findBlanks(text)) {
      let answer: string | null;
      if (pick && !blank.options.length && MEMO_BLANK.test(blank.label.trim())) answer = await pick();
      else if (blank.options.length && this.host.ui.choose) answer = await this.host.ui.choose(blank.label, blank.options);
      else
        answer = await this.host.ui.input(blank.options.length ? `${blank.label} (${blank.options.join(" / ")})` : blank.label, {
          // a memo can be the answer
          extra: pick ? { label: t("📝 Memo pad", "📝 메모장"), title: t("Pick from the Memo pad", "메모장에서 골라 넣기"), fill: pick } : undefined,
        });
      if (answer === null) return null;
      values[blank.key] = answer;
    }
    return fillBlanks(text, values);
  }

  /** /visz: a 🌟 QR by title, or the text as a new request. */
  runTitleOrText(textOrTitle: string, options: { action?: WandAction; output?: VizOutput } = {}): Promise<boolean> {
    const item = findByTitle(this.items(), textOrTitle);
    if (item) return this.run(options.action ?? item.defaultAction, item.content, { title: item.title, item, vizOutput: options.output });
    return this.run(options.action ?? "viz", textOrTitle, { vizOutput: options.output });
  }

  /** Runs an item with its default button. */
  runItem(item: WandItem, action: WandAction = item.defaultAction): Promise<boolean> {
    return this.run(action, item.content, { title: item.title, item });
  }

  /** Resolves true once the request went out (false when cancelled, busy or failed). */
  async run(action: WandAction, content: string, opts: RunOptions = {}): Promise<boolean> {
    const ui = this.host.ui;
    if (this.busyLabel) {
      ui.toast(t("The Visualizer is already making something. Try again when it's done.", "비주얼라이저가 이미 만들고 있어요. 끝난 뒤에 다시 눌러 주세요."), "warning", { title: "🌟" });
      return false;
    }
    const filled = await this.askBlanks(content);
    if (filled === null) {
      ui.toast(t("Cancelled.", "취소했어요."), "info", { title: "🌟" });
      return false;
    }
    if (!cleanOoc(filled)) {
      ui.toast(t("Nothing to send.", "보낼 내용이 비어 있어요."), "warning", { title: "🌟" });
      return false;
    }
    const state = this.state();
    const o = itemOptions(state, opts.item);
    const title = opts.title || titleFrom(filled) || t("Visualizer", "비주얼라이저");
    if (action === "ooc") {
      const text = wrapOoc(o.wrapper.template, filled, state.settings.language);
      const mode = opts.oocMode ?? o.oocMode;
      if (mode === "input") {
        this.host.putInInput(text);
        return true;
      }
      if (mode === "user") return this.busyWhile(`💬 ${title}`, () => this.host.sendAsUser(text));
      if (mode === "guided") return this.busyWhile(`💬 ${title}`, () => this.host.guided(text));
      return this.generateAndDeliver(text, { kind: "ooc", title, connectionId: o.connectionId, output: "chat" });
    }
    const env = { fornello: this.host.hasFornello?.() === true };
    const prompt = assembleVisualizer(state.preset, resolveVizMode(state.settings.vizMode, env), { topic: filled, language: state.settings.language, env });
    return this.generateAndDeliver(prompt, { kind: "viz", title, connectionId: o.connectionId, output: opts.vizOutput ?? o.vizOutput });
  }

  private async busyWhile(label: string, fn: () => Promise<void>): Promise<boolean> {
    this.setBusy(label);
    try {
      await fn();
      return true;
    } catch (e) {
      this.host.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("🌟 Failed", "🌟 실패") });
      return false;
    } finally {
      this.setBusy(null);
    }
  }

  private generateAndDeliver(prompt: string, o: { kind: "viz" | "ooc"; title: string; connectionId: string; output: VizOutput }): Promise<boolean> {
    return this.busyWhile(`${o.kind === "viz" ? "🌟" : "💬"} ${o.title}`, async () => {
      this.host.ui.toast(t(`Making ${o.title}…`, `${o.title} 만드는 중…`), "info", { title: "🌟" });
      let text = normalizeOutput(await this.host.generate(prompt, o.connectionId)).text;
      if (!text) throw new Error(t("The reply was empty.", "응답이 비어 있어요."));
      for (let i = 0; i < AUTO_CONTINUE && normalizeOutput(text).truncated; i++) text = await this.continueText(text, o.connectionId);
      const entry: ViewerEntry = { title: o.title, kind: o.kind, text };
      if (o.output === "viewer") {
        this.viewer()?.show(entry);
        return;
      }
      await this.host.postAsCharacter(text);
      if (this.state().settings.autoArchive && (o.kind === "viz" || extractHtmlBlocks(text).length)) await this.save(entry);
    });
  }

  /** Finishes the first cut-off page in the text. */
  async continueText(text: string, connectionId = this.state().settings.connectionId): Promise<string> {
    const blocks = extractHtmlBlocks(text);
    const index = blocks.findIndex((b) => !b.complete);
    if (index < 0) return text;
    const more = await this.host.generate(CONTINUE_TEMPLATE.replace("{{앞부분}}", blocks[index].code), connectionId);
    return replaceHtmlBlock(text, index, mergeContinuation(blocks[index].code, more));
  }

  /** The viewer's "이어 쓰기" button. */
  async continueEntry(entry: ViewerEntry): Promise<ViewerEntry | null> {
    if (this.busyLabel) return null;
    let result: ViewerEntry | null = null;
    await this.busyWhile(t(`🌟 Continuing ${entry.title}`, `🌟 ${entry.title} 이어 쓰기`), async () => {
      result = { ...entry, text: await this.continueText(entry.text) };
      if (entry.archivedId) await this.save(result);
    });
    return result;
  }

  async save(entry: ViewerEntry): Promise<string> {
    const info = await this.host.chatInfo().catch(() => ({}) as Awaited<ReturnType<WandHost["chatInfo"]>>);
    const record: ArchiveEntry = {
      id: entry.archivedId ?? newWandId("page"),
      title: entry.title,
      kind: entry.kind,
      text: entry.text,
      createdAt: Date.now(),
      ...info,
    };
    await this.archive.put(record);
    entry.archivedId = record.id;
    return record.id;
  }

  /** Puts a viewer result into the chat as the character's message. */
  postToChat(entry: ViewerEntry): Promise<boolean> {
    return this.busyWhile(t(`Posting ${entry.title} to chat`, `${entry.title} 채팅에 넣기`), () => this.host.postAsCharacter(entry.text));
  }
}
