// The Visualizer set: ordinary QRs that make pages with /visz (see memo/model.ts
// for the ones it starts with). It once held "🌟 QRs", topics only; those
// moved to the memo pad.

import { t } from "../i18n";

/** The visualizer's set: its name in the screen language when it is made, and its icon. */
export const VIZ_SET = { name: () => t("Visualizer", "비주얼라이저"), icon: "🌟" };
