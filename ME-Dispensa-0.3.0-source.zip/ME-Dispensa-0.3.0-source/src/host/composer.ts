// The chat input ("composer"). Marinara's textarea is uncontrolled and its
// send handler reads textarea.value, so setting the value, firing an input
// event and clicking Send behaves exactly like the user typing.

import { t } from "../i18n";

export interface Composer {
  textarea: HTMLTextAreaElement;
  container: HTMLElement;
  sendButton: HTMLButtonElement | null;
  chatId: string | null;
}

const visible = (el: Element) => {
  const r = el.getBoundingClientRect();
  return r.width > 0 && r.height > 0;
};

export function findComposer(): Composer | null {
  const areas = [...document.querySelectorAll<HTMLTextAreaElement>("textarea[data-chat-composer]")];
  const textarea = areas.find(visible) ?? areas[0];
  if (!textarea) return null;
  const container = (textarea.closest(".mari-chat-input") as HTMLElement | null) ?? (textarea.parentElement as HTMLElement);
  return { textarea, container, sendButton: findSendButton(container), chatId: textarea.dataset.chatId || null };
}

function findSendButton(container: HTMLElement): HTMLButtonElement | null {
  const byClass = container.querySelector<HTMLButtonElement>(".mari-chat-send-btn");
  if (byClass) return byClass;
  const buttons = [...container.querySelectorAll<HTMLButtonElement>("button")];
  return (
    buttons.find((b) => /send|보내|전송/i.test(`${b.getAttribute("aria-label") ?? ""} ${b.title}`)) ??
    buttons.find((b) => b.querySelector("svg.lucide-send, svg.lucide-send-horizontal, svg.lucide-arrow-up")) ??
    null
  );
}

export function setComposerText(textarea: HTMLTextAreaElement, text: string): void {
  const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
  setter?.call(textarea, text);
  textarea.dispatchEvent(new Event("input", { bubbles: true }));
}

export function isGenerating(composer: Composer | null): boolean {
  if (!composer) return false;
  const b = composer.sendButton;
  if (!b) return false;
  return !!b.querySelector("svg.lucide-square, svg.lucide-circle-stop, svg.lucide-loader-circle, .animate-spin") || /stop|중지/i.test(b.getAttribute("aria-label") ?? "");
}

export async function waitUntil(test: () => boolean, timeoutMs: number, stepMs = 100): Promise<boolean> {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    if (test()) return true;
    await new Promise((r) => setTimeout(r, stepMs));
  }
  return test();
}

/** Type a line into the composer and press Send, keeping the user's draft. */
export async function submitThroughComposer(line: string): Promise<void> {
  const composer = findComposer();
  if (!composer) throw new Error(t("Couldn't find the chat input. Open a chat and run it again.", "채팅 입력창을 찾지 못했어요. 채팅을 연 상태에서 실행해 주세요."));
  await waitUntil(() => !isGenerating(findComposer()), 120_000);
  const draft = composer.textarea.value;
  setComposerText(composer.textarea, line);
  await new Promise((r) => setTimeout(r, 30));
  const button = findComposer()?.sendButton ?? composer.sendButton;
  if (button && !button.disabled) {
    button.click();
  } else {
    composer.textarea.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", ctrlKey: true, bubbles: true }));
  }
  if (draft) {
    // Marinara clears the box after sending; put the user's draft back.
    await waitUntil(() => composer.textarea.value === "", 2000, 50);
    setComposerText(composer.textarea, draft);
  }
}
