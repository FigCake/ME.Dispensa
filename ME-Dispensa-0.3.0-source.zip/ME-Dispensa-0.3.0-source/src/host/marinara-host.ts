import type { Host, MarinaraExtras, MemoControl, QrControl, WandControl } from "../stscript/host";
import type { MacroFacts } from "../stscript/macros";
import { Dialogs } from "../ui/dialogs";
import { api } from "./api";
import { MarinaraChat } from "./chat";
import { MarinaraExtrasImpl } from "./marinara-extras";
import { ChatVariables, GlobalVariables } from "./variables";

/** Marinara macros worth a server round trip when they are left over. */
const MARINARA_ONLY = /\{\{(?:#if\b|persona\w*|description|personality|backstory|appearance|scenario|example|charSysInfo|charPostHistory|characters|chatId|datetime|timezone|convo_display|char_about|persona_about|convo_behavior|lorebook|lore|addnumvar::|agent::|outlet::|include::|[A-Za-z0-9_-]{21}\}\})/;

export class MarinaraHost implements Host {
  readonly local = new ChatVariables();
  readonly global = new GlobalVariables();
  readonly ui = new Dialogs();
  readonly chat = new MarinaraChat();
  qr?: QrControl;
  wand?: WandControl;
  memo?: MemoControl;
  readonly marinara: MarinaraExtras = new MarinaraExtrasImpl(this.chat);
  private readonly macroCache = new Map<string, string>();

  facts(): MacroFacts {
    return this.chat.facts(this.ui.getInput());
  }

  async beginRun(): Promise<void> {
    await this.global.load();
    const detail = await this.chat.sync(true).catch(() => null);
    await this.local.load(detail?.id ?? null, detail?.metadata);
    if (detail) await this.chat.ensureFacts().catch(() => undefined);
  }

  async refreshFacts(): Promise<void> {
    const before = this.local.currentChatId;
    const detail = await this.chat.sync().catch(() => null);
    const id = detail?.id ?? null;
    if (id !== before) await this.local.load(id, detail?.metadata);
    if (detail) await this.chat.ensureFacts().catch(() => undefined);
  }

  async resolveHostMacros(text: string): Promise<string> {
    if (!MARINARA_ONLY.test(text)) return text;
    const chatId = this.chat.activeChatId();
    if (!chatId) return text;
    const cached = this.macroCache.get(text);
    if (cached !== undefined) return cached;
    try {
      await this.local.flush();
      const res = await api<{ prompt?: { messages?: { content?: unknown }[] } }>(`/generate/dryRun`, {
        method: "POST",
        body: { chatId, returnPrompt: true, presetText: text, injectLorebook: false, injectTrackers: false, injectChatSummary: false },
      });
      for (const m of res.prompt?.messages ?? []) {
        const content = typeof m.content === "string" ? m.content : "";
        const match = /<extension_preset>\s*([\s\S]*?)\s*<\/extension_preset>/.exec(content);
        if (match) {
          this.macroCache.set(text, match[1]);
          return match[1];
        }
      }
    } catch {
      // fall back to the unresolved text
    }
    return text;
  }

  async flush(): Promise<void> {
    await Promise.all([this.local.flush(), this.global.flush()]);
  }

  confirm(message: string): Promise<boolean> {
    return this.ui.confirm(message);
  }

  dispose(): void {
    this.chat.dispose();
    this.ui.dispose();
  }
}
