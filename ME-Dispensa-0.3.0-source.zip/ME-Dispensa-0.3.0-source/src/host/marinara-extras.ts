// Marinara-only features for scripts: tracker, agents, lorebooks, characters,
// connections, prompt preview, chat name and Author's Note.

import type { LoreEntry } from "../marinara/lore";
import type { TrackerState } from "../marinara/tracker";
import type { LoreBookInfo, MarinaraExtras } from "../stscript/host";
import { api } from "./api";
import type { MarinaraChat } from "./chat";
import { getMarinara } from "./marinara-global";
import { openChat, refreshQueries } from "./react-bridge";
import { parseObject } from "./variables";
import { t } from "../i18n";

const enc = encodeURIComponent;

function parseMaybeJson<T>(v: unknown, fallback: T): T {
  if (typeof v === "string") {
    try {
      return JSON.parse(v) as T;
    } catch {
      return fallback;
    }
  }
  return (v ?? fallback) as T;
}

export class MarinaraExtrasImpl implements MarinaraExtras {
  constructor(private readonly chat: MarinaraChat) {}

  private async chatId(): Promise<string> {
    return this.chat.requireChat();
  }

  // ── tracker ──

  async getTracker(): Promise<TrackerState | null> {
    const raw = await api<Record<string, unknown> | null>(`/chats/${enc(await this.chatId())}/game-state`);
    if (!raw) return null;
    // Some fields may arrive as JSON strings.
    for (const k of ["presentCharacters", "playerStats", "personaStats", "worldCustomFields", "recentEvents", "manualOverrides", "fieldLocks"]) {
      if (typeof raw[k] === "string") raw[k] = parseMaybeJson(raw[k], null);
    }
    return raw as TrackerState;
  }

  async patchTracker(state: TrackerState, fields: string[]): Promise<void> {
    const body: Record<string, unknown> = { manual: true };
    for (const f of new Set(fields)) body[f] = state[f];
    if (state.messageId) {
      body.messageId = state.messageId;
      body.swipeIndex = state.swipeIndex ?? 0;
    }
    await api(`/chats/${enc(await this.chatId())}/game-state`, { method: "PATCH", body });
  }

  async retryAgents(types: string[]): Promise<{ ran: string[]; errors: string[] }> {
    const chatId = await this.chatId();
    const doFetch = getMarinara().fetch ?? fetch;
    const res = await doFetch(`/api/generate/retry-agents`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-marinara-csrf": "1" },
      body: JSON.stringify({ chatId, agentTypes: types, streaming: true }),
      credentials: "same-origin",
    });
    const ran: string[] = [];
    const errors: string[] = [];
    if (!res.ok || !res.body) throw new Error(`Agent retry failed (${res.status})`);
    // Read the whole stream: closing it early aborts the agents.
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let nl: number;
      while ((nl = buffer.indexOf("\n")) >= 0) {
        const line = buffer.slice(0, nl).trim();
        buffer = buffer.slice(nl + 1);
        if (!line.startsWith("data:")) continue;
        try {
          const evt = JSON.parse(line.slice(5).trim()) as { type?: string; data?: Record<string, unknown>; error?: string };
          const data = (evt.data ?? evt) as Record<string, unknown>;
          if (evt.type === "agent_result" && data.success !== false) ran.push(String(data.agentName ?? data.agentType ?? ""));
          if (evt.type === "agent_error" || evt.type === "error") errors.push(String(data.error ?? evt.error ?? data.message ?? "error"));
        } catch {
          // ignore keep-alives and partial lines
        }
      }
    }
    this.chat.markStale();
    return { ran, errors };
  }

  // ── lorebooks ──

  private async allBooks(): Promise<(LoreBookInfo & { isGlobal?: boolean; characterIds?: string[] })[]> {
    const res = await api<unknown>(`/lorebooks`);
    const list = Array.isArray(res) ? res : ((res as { items?: unknown[] }).items ?? []);
    return list as (LoreBookInfo & { isGlobal?: boolean; characterIds?: string[] })[];
  }

  async activeBooks(): Promise<LoreBookInfo[]> {
    const detail = await this.chat.sync();
    if (!detail) return [];
    const meta = parseObject(detail.metadata);
    const active = new Set(Array.isArray(meta.activeLorebookIds) ? (meta.activeLorebookIds as string[]) : []);
    const excluded = new Set(Array.isArray(meta.excludedLorebookIds) ? (meta.excludedLorebookIds as string[]) : []);
    const cast = new Set(this.chat.cast.map((c) => c.id));
    return (await this.allBooks())
      .filter((b) => !excluded.has(b.id) && (b.isGlobal || active.has(b.id) || b.chatId === detail.id || (b.characterIds ?? []).some((id) => cast.has(id))))
      .map((b) => ({ id: b.id, name: b.name, chatId: b.chatId }));
  }

  async chatBook(create: boolean): Promise<LoreBookInfo | null> {
    const chatId = await this.chatId();
    const res = await api<unknown>(`/lorebooks?chatId=${enc(chatId)}`);
    const own = (Array.isArray(res) ? res : ((res as { items?: unknown[] }).items ?? [])) as LoreBookInfo[];
    if (own[0]) return { id: own[0].id, name: own[0].name, chatId };
    if (!create) return null;
    const name = `Chat Book ${(await this.chatName()) || chatId}`.slice(0, 200);
    const book = await api<LoreBookInfo>(`/lorebooks`, { method: "POST", body: { name, chatId } });
    return { id: book.id, name: book.name, chatId };
  }

  async findBook(nameOrId: string): Promise<LoreBookInfo | null> {
    const q = nameOrId.trim().toLowerCase();
    const books = await this.allBooks();
    const hit = books.find((b) => b.id === nameOrId) ?? books.find((b) => b.name?.toLowerCase() === q) ?? books.find((b) => b.name?.toLowerCase().includes(q));
    return hit ? { id: hit.id, name: hit.name, chatId: hit.chatId } : null;
  }

  async entries(bookId: string): Promise<LoreEntry[]> {
    return api<LoreEntry[]>(`/lorebooks/${enc(bookId)}/entries`);
  }

  async createEntry(bookId: string, data: Record<string, unknown>): Promise<LoreEntry> {
    return api<LoreEntry>(`/lorebooks/${enc(bookId)}/entries`, { method: "POST", body: { name: "New entry", ...data } });
  }

  async patchEntry(bookId: string, entryId: string, patch: Record<string, unknown>): Promise<void> {
    await api(`/lorebooks/${enc(bookId)}/entries/${enc(entryId)}`, { method: "PATCH", body: patch });
  }

  // ── characters and personas ──

  async character(name?: string): Promise<{ id: string; data: Record<string, unknown> } | null> {
    await this.chat.sync();
    let id: string | undefined = this.chat.cast[0]?.id;
    if (name) {
      const lower = name.trim().toLowerCase();
      id = this.chat.cast.find((c) => c.name.toLowerCase() === lower)?.id;
      if (!id) {
        const catalog = await api<{ items?: { id: string; name: string }[] }>(`/characters/catalog?limit=200&search=${enc(name)}`);
        id = (catalog.items ?? []).find((c) => c.name.toLowerCase() === lower)?.id ?? catalog.items?.[0]?.id;
      }
    }
    if (!id) return null;
    const raw = await api<{ id: string; data?: unknown }>(`/characters/${enc(id)}`);
    return { id, data: parseObject(raw.data) };
  }

  async updateCharacter(id: string, data: Record<string, unknown>): Promise<void> {
    await api(`/characters/${enc(id)}`, { method: "PATCH", body: { data } });
    this.chat.markStale();
  }

  async persona(): Promise<Record<string, unknown> | null> {
    const detail = await this.chat.sync();
    if (!detail?.personaId) return null;
    return api<Record<string, unknown>>(`/characters/personas/${enc(detail.personaId)}`);
  }

  // ── connections ──

  async connections(): Promise<{ id: string; name: string; model?: string }[]> {
    const list = await api<{ id: string; name: string; model?: string }[]>(`/connections`);
    return list.map((c) => ({ id: c.id, name: c.name, model: c.model }));
  }

  async currentConnection(): Promise<{ id: string; name: string } | null> {
    const detail = await this.chat.sync(true);
    const id = detail?.connectionId;
    if (!id) return null;
    if (id === "random") return { id, name: "random" };
    const c = (await this.connections()).find((x) => x.id === id);
    return c ? { id: c.id, name: c.name } : { id, name: id };
  }

  async setConnection(id: string): Promise<void> {
    const chatId = await this.chatId();
    await api(`/chats/${enc(chatId)}`, { method: "PATCH", body: { connectionId: id } });
    this.chat.markStale();
    refreshQueries([["chats", "detail", chatId], ["chats", "list"]]);
  }

  // ── prompt, chat, Author's Note ──

  async peekPrompt(): Promise<{ role: string; content: string }[]> {
    const res = await api<{ messages?: { role: string; content: unknown }[] }>(`/chats/${enc(await this.chatId())}/peek-prompt`, { method: "POST", body: {} });
    return (res.messages ?? []).map((m) => ({ role: m.role, content: typeof m.content === "string" ? m.content : JSON.stringify(m.content) }));
  }

  async chatName(): Promise<string> {
    const detail = await this.chat.sync();
    return detail?.name ?? "";
  }

  async renameChat(name: string): Promise<void> {
    const chatId = await this.chatId();
    await api(`/chats/${enc(chatId)}`, { method: "PATCH", body: { name } });
    this.chat.markStale();
    refreshQueries([["chats", "detail", chatId], ["chats", "list"]]);
  }

  async newChat(): Promise<string> {
    const detail = await this.chat.sync(true);
    if (!detail) throw new Error(t("No chat is open.", "열려 있는 채팅이 없어요."));
    const cast = [...this.chat.cast];
    const name = cast.map((c) => c.name).join(", ") || detail.name || "New chat";
    const created = await api<{ id: string; name: string }>(`/chats`, {
      method: "POST",
      body: { name, mode: detail.mode ?? "roleplay", characterIds: cast.map((c) => c.id), connectionId: detail.connectionId ?? null, personaId: detail.personaId ?? null },
    });
    if (cast.length === 1) {
      const g = await this.chat.greetings(cast[0].id);
      if (g.first) {
        const msg = await api<{ id?: string }>(`/chats/${enc(created.id)}/messages`, { method: "POST", body: { role: "assistant", content: g.first, characterId: cast[0].id } });
        if (msg?.id && g.alternates.length) await api(`/chats/${enc(created.id)}/messages/${enc(msg.id)}/swipes/bulk`, { method: "POST", body: { contents: g.alternates } }).catch(() => undefined);
      }
    }
    await openChat(created.id);
    this.chat.markStale();
    return created.name;
  }

  async authorNote(): Promise<{ text: string; depth: number }> {
    const detail = await this.chat.sync(true);
    const meta = parseObject(detail?.metadata);
    return { text: String(meta.authorNotes ?? ""), depth: Number(meta.authorNotesDepth ?? 4) || 4 };
  }

  async setAuthorNote(text: string | undefined, depth?: number): Promise<void> {
    const chatId = await this.chatId();
    const body: Record<string, unknown> = {};
    if (text !== undefined) body.authorNotes = text;
    if (depth !== undefined) body.authorNotesDepth = depth;
    await api(`/chats/${enc(chatId)}/metadata`, { method: "PATCH", body });
    this.chat.markStale();
    refreshQueries([["chats", "detail", chatId]]);
  }

  async reloadPage(): Promise<void> {
    location.reload();
  }
}
