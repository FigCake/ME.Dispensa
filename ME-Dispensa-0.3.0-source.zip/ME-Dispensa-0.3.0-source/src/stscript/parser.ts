// STscript parser. Follows SillyTavern's grammar: commands separated by `|`,
// `||` stops pipe injection, `{: ... :}` closures (optionally `()` to run at
// once), `//` `/#` line comments, `/* ... *|` block comments, `/:name` run
// shorthand, `/parser-flag`, and backslash escapes (loose or strict).

import {
  type ArgValue,
  type BreakNode,
  type Closure,
  type CommandLookup,
  type CommandNode,
  type Executor,
  type NamedArg,
  ParseError,
  type ParserFlags,
  type UnnamedArg,
  defaultParserFlags,
} from "./ast";

export interface ParseOptions {
  flags?: Partial<ParserFlags>;
  lookup?: CommandLookup;
}

export function parse(text: string, options: ParseOptions = {}): Closure {
  return new Parser(text, options).parseRoot();
}

class Parser {
  private index = 0;
  /** True right after skipping the backslash of an escaped symbol. */
  private jumped = false;
  private readonly flags: ParserFlags;
  private readonly lookup: CommandLookup;
  private depth = 0;
  private readonly macroDepth: Int32Array;

  constructor(
    private readonly text: string,
    options: ParseOptions,
  ) {
    this.flags = { ...defaultParserFlags(), ...options.flags };
    this.lookup = options.lookup ?? (() => undefined);
    this.macroDepth = computeMacroDepth(text);
  }

  // ── cursor ────────────────────────────────────────────────

  private get char(): string {
    return this.text[this.index] ?? "";
  }

  private get atEnd(): boolean {
    return this.index >= this.text.length;
  }

  private take(length = 1): string {
    let out = "";
    for (let i = 0; i < length; i++) {
      this.jumped = false;
      out += this.text[this.index] ?? "";
      this.index++;
    }
    return out;
  }

  private skipWhitespace(): void {
    while (/\s/.test(this.char)) {
      this.take();
      this.jumped = false;
    }
  }

  private startsAt(pos: number, seq: string | RegExp): boolean {
    const rest = this.text.slice(pos);
    return typeof seq === "string" ? rest.startsWith(seq) : new RegExp(`^(?:${seq.source})`).test(rest);
  }

  /**
   * Is the symbol at the cursor (unescaped)? When the symbol is escaped and
   * offset is 0, the escaping backslash is skipped so the caller's next
   * take() reads the symbol as a literal character.
   */
  private test(seq: string | RegExp, offset = 0): boolean {
    const escapeOffset = this.jumped ? -1 : 0;
    const base = this.index + offset + escapeOffset;
    let escapes: number;
    if (this.flags.STRICT_ESCAPING) {
      escapes = 0;
      while (this.text[base + escapes] === "\\") escapes++;
    } else {
      escapes = this.text[base] === "\\" ? 1 : 0;
    }
    if (!this.startsAt(base + escapes, seq)) return false;
    if (escapes === 0) return true;
    if (!this.jumped && offset === 0) {
      this.index++;
      this.jumped = true;
    }
    return false;
  }

  private insideMacro(): boolean {
    return this.macroDepth[Math.min(this.index, this.text.length)] > 0;
  }

  // ── structure ─────────────────────────────────────────────

  parseRoot(): Closure {
    return this.parseClosure(true);
  }

  private closureEnd(): boolean {
    if (this.depth === 0) return this.atEnd;
    if (this.atEnd) throw new ParseError(`Unclosed closure ({: without :})`, this.index);
    return this.test(":}");
  }

  private commandEnd(): boolean {
    if (this.closureEnd()) return true;
    return this.test("|") && !this.insideMacro();
  }

  private parseClosure(isRoot = false): Closure {
    if (!isRoot) {
      this.take(2);
      this.depth++;
    }
    const textStart = this.index;
    const closure: Closure = { kind: "closure", args: [], executors: [], executeNow: false, raw: "" };
    let injectPipe = true;
    this.skipWhitespace();
    while (this.testNamedArg()) {
      closure.args.push(this.parseNamedArg());
      this.skipWhitespace();
    }
    while (!this.closureEnd()) {
      if (this.test("/*")) {
        this.parseBlockComment();
      } else if (this.test(/\/[/#]/)) {
        this.parseLineComment();
      } else if (this.test("/parser-flag ")) {
        this.parseParserFlag();
      } else if (this.test("/:") && !this.test(":}", 1)) {
        const node = this.parseRunShorthand();
        node.injectPipe = injectPipe;
        closure.executors.push(node);
        injectPipe = true;
      } else if (this.test(/\/break(?:\s|\||$)/)) {
        closure.executors.push(this.parseBreak());
      } else if (this.test("/")) {
        const node = this.parseCommand();
        node.injectPipe = injectPipe;
        closure.executors.push(node);
        injectPipe = true;
      } else {
        // plain text between commands is ignored
        while (!this.commandEnd()) this.take();
      }
      this.skipWhitespace();
      if (this.test("|")) {
        this.take();
        if (this.test("|")) {
          injectPipe = false;
          this.take();
        }
      }
      this.skipWhitespace();
    }
    closure.raw = this.text.slice(textStart, this.index);
    if (!isRoot) {
      this.take(2);
      this.depth--;
      if (this.test("()")) {
        this.take(2);
        closure.executeNow = true;
      }
    }
    return closure;
  }

  private parseBlockComment(): void {
    this.take(2);
    for (;;) {
      if (this.atEnd) throw new ParseError("Unclosed block comment (/* without *|)", this.index);
      if (this.test("*|")) break;
      if (this.test("/*")) {
        this.parseBlockComment();
        continue;
      }
      this.take();
    }
    this.take(2);
  }

  private parseLineComment(): void {
    this.take(2);
    while (!this.atEnd && !this.test("|")) this.take();
  }

  private parseParserFlag(): void {
    this.take("/parser-flag ".length);
    const parts = this.parseUnnamed(true);
    const flag = typeof parts[0]?.value === "string" ? parts[0].value : "";
    const state = typeof parts[1]?.value === "string" ? parts[1].value : "on";
    if (flag === "STRICT_ESCAPING" || flag === "REPLACE_GETVAR") {
      this.flags[flag] = isTrue(state);
    }
  }

  private parseRunShorthand(): CommandNode {
    const start = this.index;
    this.take(2);
    const target = this.test('"') ? this.parseQuoted() : this.parseBareValue();
    this.skipWhitespace();
    const named: NamedArg[] = [];
    while (this.testNamedArg()) {
      named.push(this.parseNamedArg());
      this.skipWhitespace();
    }
    if (!this.commandEnd()) throw new ParseError(`Unexpected text after /:${target}`, this.index);
    return {
      kind: "command",
      name: ":",
      named,
      unnamed: [{ value: target, quoted: false }],
      injectPipe: true,
      flags: { ...this.flags },
      start,
      end: this.index,
    };
  }

  private parseBreak(): BreakNode {
    const start = this.index;
    this.take("/break".length);
    this.skipWhitespace();
    const unnamed = this.commandEnd() ? [] : this.parseUnnamed(false);
    return { kind: "break", unnamed, start, end: this.index };
  }

  private parseCommand(): CommandNode {
    const start = this.index;
    this.take();
    let name = "";
    while (!this.atEnd && !/\s/.test(this.char) && !this.commandEnd()) name += this.take();
    this.skipWhitespace();
    const spec = this.lookup(name);
    const named: NamedArg[] = [];
    while (this.testNamedArg()) {
      named.push(this.parseNamedArg());
      this.skipWhitespace();
    }
    this.skipWhitespace();
    let unnamed: UnnamedArg[] = [];
    if (!this.commandEnd()) {
      let rawQuotes = spec?.rawQuotes ?? false;
      const rawArg = named.find((a) => a.name === "raw");
      if (rawQuotes && rawArg && typeof rawArg.value === "string" && isFalse(rawArg.value)) rawQuotes = false;
      unnamed = this.parseUnnamed(spec?.split ?? false, spec?.splitCount, rawQuotes);
    }
    if (!this.commandEnd()) throw new ParseError(`Unexpected end of command /${name}`, this.index);
    return { kind: "command", name, named, unnamed, injectPipe: true, flags: { ...this.flags }, start, end: this.index };
  }

  private testNamedArg(): boolean {
    return /^\w+=/.test(this.text.slice(this.index));
  }

  private parseNamedArg(): NamedArg {
    let name = "";
    while (/\w/.test(this.char)) name += this.take();
    this.take(); // "="
    let value: ArgValue = "";
    if (this.test("{:")) value = this.parseClosure();
    else if (this.test('"')) value = this.parseQuoted();
    else if (this.test("[")) value = this.parseList();
    else if (!this.test(/\s/)) value = this.parseBareValue();
    return { name, value };
  }

  private parseUnnamed(split: boolean, splitCount?: number, rawQuotes = false): UnnamedArg[] {
    const wasSplit = split;
    let value = this.jumped ? this.take() : "";
    let isList = split;
    const list: UnnamedArg[] = [];

    if (!split && !rawQuotes && this.test('"')) {
      list.push({ value: this.parseQuoted(), quoted: true });
      isList = true;
    }
    while (!this.commandEnd()) {
      if (split && splitCount && list.length >= splitCount) {
        split = false;
        if (this.test('"')) list.push({ value: this.parseQuoted(), quoted: true });
      }
      if (this.test("{:")) {
        isList = true;
        if (value.length > 0) {
          list.push({ value, quoted: false });
          value = "";
          if (!split && this.test('"')) list.push({ value: this.parseQuoted(), quoted: true });
        }
        list.push({ value: this.parseClosure(), quoted: false });
        if (split) this.skipWhitespace();
      } else if (split) {
        if (this.test('"')) list.push({ value: this.parseQuoted(), quoted: true });
        else if (this.test("[")) list.push({ value: this.parseList(), quoted: false });
        else if (!this.test(/\s/)) list.push({ value: this.parseBareValue(), quoted: false });
        else throw new ParseError("Unexpected end of unnamed argument", this.index);
        this.skipWhitespace();
      } else {
        value += this.take();
      }
    }
    if (isList && value.length > 0) list.push({ value, quoted: false });
    if (isList) {
      const first = list[0];
      if (first && typeof first.value === "string") {
        if (!first.quoted) first.value = first.value.trimStart();
        if (first.value.length === 0) list.shift();
      }
      const last = list[list.length - 1];
      if (last && typeof last.value === "string") {
        if (!last.quoted) last.value = last.value.trimEnd();
        if (last.value.length === 0) list.pop();
      }
      if (wasSplit && splitCount && splitCount + 1 < list.length) {
        let joined = "";
        for (const part of list.slice(splitCount)) {
          joined += part.quoted ? `"${part.value as string}"` : (part.value as string);
        }
        list.splice(splitCount, list.length - splitCount, { value: joined, quoted: false });
      }
      return list;
    }
    return [{ value: value.trim(), quoted: false }];
  }

  private parseQuoted(): string {
    this.take(); // opening quote
    let value = "";
    for (;;) {
      if (this.atEnd) throw new ParseError("Unclosed quoted value", this.index);
      if (this.test('"')) break;
      if (!this.flags.STRICT_ESCAPING && this.commandEnd()) {
        throw new ParseError('Unexpected "|" inside a quoted value (escape it as \\|)', this.index);
      }
      value += this.take();
    }
    this.take(); // closing quote
    return value;
  }

  private parseList(): string {
    let value = this.take();
    for (;;) {
      if (this.atEnd) throw new ParseError("Unclosed list value ([ without ])", this.index);
      if (this.test("]")) break;
      value += this.take();
    }
    return value + this.take();
  }

  private parseBareValue(): string {
    let value = this.jumped ? this.take() : "";
    while (!this.atEnd && !this.test(/\s/) && !this.commandEnd()) value += this.take();
    return value;
  }
}

/**
 * For every position p, the `{{ }}` nesting depth of text.slice(0, p),
 * scanning pairs left to right the way SillyTavern does.
 */
function computeMacroDepth(text: string): Int32Array {
  const out = new Int32Array(text.length + 1);
  let depth = 0;
  let i = 0;
  out[0] = 0;
  while (i < text.length) {
    const isOpen = text[i] === "{" && text[i + 1] === "{";
    const isClose = text[i] === "}" && text[i + 1] === "}";
    if (isOpen || isClose) {
      out[i + 1] = depth; // prefix ends between the two braces
      depth = isOpen ? depth + 1 : Math.max(0, depth - 1);
      out[i + 2] = depth;
      i += 2;
    } else {
      out[i + 1] = depth;
      i += 1;
    }
  }
  return out;
}

export function isTrue(value: string): boolean {
  return ["on", "true", "1", "yes", "y"].includes(value.trim().toLowerCase());
}

export function isFalse(value: string): boolean {
  return ["off", "false", "0", "no", "n"].includes(value.trim().toLowerCase());
}
