// Marinara features for scripts. World Info (/getchatbook, /findentry,
// /getentryfield, /setentryfield, /createentry), /char-get, /char-update,
// /getchatname, /renamechat, /newchat, /note and /depth follow SillyTavern;
// the tracker, agent, connection and prompt commands are Dispensa additions.

import { entryPatch, findEntry, readEntryField } from "../../marinara/lore";
import { type SetOptions, TrackerPathError, getTrackerValue, setTrackerValue } from "../../marinara/tracker";
import type { MarinaraExtras } from "../host";
import { asText, type CommandCall } from "../interpreter";
import { isTrue } from "../parser";
import type { CommandDef } from "../registry";
import { ScriptError, type Val } from "../scope";
import { t } from "../../i18n";

const TRACKER_AGENTS = ["world-state", "character-tracker", "persona-stats", "quest", "custom-tracker", "inventory-tracker"];

const text = (c: CommandCall) => asText(c.unnamed).trim();
const str = (c: CommandCall, key: string): string | undefined => {
  const v = c.named[key];
  return v === undefined ? undefined : asText(v);
};
const parts = (c: CommandCall): Val[] => (Array.isArray(c.unnamed) ? c.unnamed : c.unnamed === "" ? [] : [c.unnamed]);

function m(c: CommandCall): MarinaraExtras {
  if (!c.rt.host.marinara) throw new ScriptError("This command only works inside Marinara");
  return c.rt.host.marinara;
}

/** A value that may be a variable name (SillyTavern lets file= and uid= name a variable). */
function varOr(c: CommandCall, raw: string | undefined): string {
  if (raw === undefined) return "";
  return c.rt.host.local.get(raw) ?? c.rt.host.global.get(raw) ?? raw;
}

async function book(c: CommandCall) {
  const file = varOr(c, str(c, "file"));
  const found = file ? await m(c).findBook(file) : await m(c).chatBook(false);
  if (!found) throw new ScriptError(file ? `No lorebook named "${file}"` : "This chat has no lorebook yet (use /getchatbook)");
  return found;
}

function trackerError(e: unknown): never {
  if (e instanceof TrackerPathError) throw new ScriptError(e.message);
  throw e;
}

let confirmedCharacterEdit = false;

export const marinaraCommands: CommandDef[] = [
  // ── tracker ──
  {
    name: "tracker-get",
    help: "Read the Tracker Panel: /tracker-get custom.affection | char.Ellie.mood | persona.HP | weather (no path → everything as JSON)",
    origin: "dispensa",
    run: async (c) => {
      try {
        return getTrackerValue(await m(c).getTracker(), text(c));
      } catch (e) {
        trackerError(e);
      }
    },
  },
  {
    name: "tracker-set",
    split: true,
    splitCount: 1,
    help: "Change the Tracker Panel: /tracker-set [max=100] [color=#f66] [stat=on] char.Ellie.affection 15",
    origin: "dispensa",
    run: async (c) => {
      const list = parts(c);
      const path = asText(list[0] ?? "");
      const value = list.slice(1).map((v) => asText(v)).join(" ");
      if (!path) throw new ScriptError("/tracker-set needs a path and a value");
      const opts: SetOptions = { color: str(c, "color"), asStat: isTrue(str(c, "stat") ?? "off") };
      if (str(c, "max") !== undefined) opts.max = Number(str(c, "max"));
      const state = (await m(c).getTracker()) ?? {};
      try {
        const fields = setTrackerValue(state, path, value, opts);
        await m(c).patchTracker(state, fields);
      } catch (e) {
        trackerError(e);
      }
      return value;
    },
  },
  {
    name: "tracker-add",
    split: true,
    splitCount: 1,
    help: "Add to a number in the Tracker Panel: /tracker-add char.Ellie.affection 5 (negative to subtract)",
    origin: "dispensa",
    run: async (c) => {
      const list = parts(c);
      const path = asText(list[0] ?? "");
      const amount = Number(asText(list[1] ?? "1"));
      if (!path || Number.isNaN(amount)) throw new ScriptError("/tracker-add needs a path and a number");
      const state = (await m(c).getTracker()) ?? {};
      try {
        const current = Number(getTrackerValue(state, path) || 0);
        const next = String((Number.isNaN(current) ? 0 : current) + amount);
        const opts: SetOptions = { color: str(c, "color") };
        if (str(c, "max") !== undefined) opts.max = Number(str(c, "max"));
        const fields = setTrackerValue(state, path, next, opts);
        await m(c).patchTracker(state, fields);
        return next;
      } catch (e) {
        trackerError(e);
      }
    },
  },
  {
    name: "agents-retry",
    help: `Run tracker agents again: /agents-retry [types…] (default: ${TRACKER_AGENTS.join(", ")}) → JSON list of agents that ran`,
    origin: "dispensa",
    run: async (c) => {
      const raw = text(c);
      const types = raw ? raw.split(/[\s,]+/).filter(Boolean) : TRACKER_AGENTS;
      const { ran, errors } = await m(c).retryAgents(types);
      if (errors.length) c.rt.host.ui.toast(errors.join("\n"), "warning", { title: t("Agents", "에이전트") });
      return JSON.stringify(ran);
    },
  },

  // ── lorebooks (SillyTavern World Info names) ──
  {
    name: "getchatbook",
    help: "The chat's own lorebook (created when missing). Returns its name.",
    origin: "st",
    run: async (c) => (await m(c).chatBook(true))?.name ?? "",
  },
  {
    name: "findentry",
    help: "Find a lorebook entry: /findentry file=book [field=key] text → entry id",
    origin: "st",
    run: async (c) => {
      const b = await book(c);
      return findEntry(await m(c).entries(b.id), str(c, "field") ?? "key", text(c))?.id ?? "";
    },
  },
  {
    name: "getentryfield",
    help: "Read an entry field: /getentryfield file=book [field=content] id",
    origin: "st",
    run: async (c) => {
      const b = await book(c);
      const id = varOr(c, text(c));
      const entry = (await m(c).entries(b.id)).find((e) => e.id === id);
      if (!entry) return "";
      try {
        return readEntryField(entry, str(c, "field") ?? "content");
      } catch (e) {
        throw new ScriptError(e instanceof Error ? e.message : String(e));
      }
    },
  },
  {
    name: "setentryfield",
    help: "Change an entry field: /setentryfield file=book uid=id [field=content] text",
    origin: "st",
    run: async (c) => {
      const b = await book(c);
      const id = varOr(c, str(c, "uid"));
      if (!id) throw new ScriptError("/setentryfield needs uid=");
      try {
        await m(c).patchEntry(b.id, id, entryPatch(str(c, "field") ?? "content", asText(c.unnamed)));
      } catch (e) {
        throw new ScriptError(e instanceof Error ? e.message : String(e));
      }
      return "";
    },
  },
  {
    name: "createentry",
    help: "New lorebook entry: /createentry file=book [key=a,b] content → entry id",
    origin: "st",
    run: async (c) => {
      const b = await book(c);
      const keys = (str(c, "key") ?? "").split(",").map((s) => s.trim()).filter(Boolean);
      const content = asText(c.unnamed);
      const entry = await m(c).createEntry(b.id, { name: keys[0] ?? content.slice(0, 30) ?? "New entry", keys, content });
      return entry.id;
    },
  },
  {
    name: "lore-books",
    help: "Names of the lorebooks active in this chat (JSON list).",
    origin: "dispensa",
    run: async (c) => JSON.stringify((await m(c).activeBooks()).map((b) => b.name)),
  },
  {
    name: "lore-list",
    help: "Entries of a lorebook as JSON [{id,name,keys,enabled}]: /lore-list [file=book]",
    origin: "dispensa",
    run: async (c) => {
      const b = await book(c);
      return JSON.stringify((await m(c).entries(b.id)).map((e) => ({ id: e.id, name: e.name ?? "", keys: e.keys ?? [], enabled: e.enabled !== false })));
    },
  },

  // ── characters and personas ──
  {
    name: "char-get",
    help: "Character card data: /char-get [char=name] [field=description] (no field → whole card as JSON)",
    origin: "st",
    run: async (c) => {
      const ch = await m(c).character(str(c, "char") ?? str(c, "name"));
      if (!ch) return "";
      const field = str(c, "field");
      if (!field) return JSON.stringify(ch.data);
      const v = ch.data[field];
      return v === undefined || v === null ? "" : typeof v === "object" ? JSON.stringify(v) : String(v);
    },
  },
  {
    name: "char-update",
    help: "Change the current character's card: /char-update [char=name] description=… personality=… (asks first)",
    origin: "st",
    run: async (c) => {
      const ch = await m(c).character(str(c, "char"));
      if (!ch) throw new ScriptError("No character to update");
      const data: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(c.named)) if (k !== "char") data[k] = asText(v);
      if (!Object.keys(data).length) return "";
      if (!confirmedCharacterEdit) {
        if (!(await c.rt.host.confirm(t(`Change the character card? (${Object.keys(data).join(", ")})<br><small>Won't ask again until the page reloads.</small>`, `캐릭터 카드를 바꿀까요? (${Object.keys(data).join(", ")})<br><small>이번 화면에서는 다시 묻지 않아요.</small>`)))) return "";
        confirmedCharacterEdit = true;
      }
      await m(c).updateCharacter(ch.id, data);
      return "";
    },
  },
  {
    name: "persona-get",
    help: "Your persona: /persona-get [field=description] (no field → JSON)",
    origin: "dispensa",
    run: async (c) => {
      const p = await m(c).persona();
      if (!p) return "";
      const field = str(c, "field");
      if (!field) return JSON.stringify(p);
      const v = p[field];
      return v === undefined || v === null ? "" : typeof v === "object" ? JSON.stringify(v) : String(v);
    },
  },

  // ── connections and prompt ──
  {
    name: "connection",
    help: "Show or switch this chat's AI connection: /connection [name] → connection name",
    origin: "dispensa",
    run: async (c) => {
      const wanted = text(c);
      if (!wanted) return (await m(c).currentConnection())?.name ?? "";
      const list = await m(c).connections();
      const q = wanted.toLowerCase();
      const hit = list.find((x) => x.name.toLowerCase() === q) ?? list.find((x) => x.name.toLowerCase().includes(q)) ?? list.find((x) => x.id === wanted);
      if (!hit) throw new ScriptError(`No connection named "${wanted}" (have: ${list.map((x) => x.name).join(", ")})`);
      await m(c).setConnection(hit.id);
      return hit.name;
    },
  },
  {
    name: "connections",
    help: "Names of all AI connections (JSON list).",
    origin: "dispensa",
    run: async (c) => JSON.stringify((await m(c).connections()).map((x) => x.name)),
  },
  {
    name: "peek-prompt",
    help: "The prompt the AI gets for this chat: /peek-prompt [format=text|json]",
    origin: "dispensa",
    run: async (c) => {
      const msgs = await m(c).peekPrompt();
      if (str(c, "format") === "json") return JSON.stringify(msgs);
      return msgs.map((x) => `[${x.role}]\n${x.content}`).join("\n\n");
    },
  },

  // ── chat ──
  { name: "getchatname", help: "This chat's name.", origin: "st", run: async (c) => m(c).chatName() },
  {
    name: "renamechat",
    help: "Rename this chat: /renamechat new name",
    origin: "st",
    run: async (c) => {
      if (!text(c)) throw new ScriptError("/renamechat needs a name");
      await m(c).renameChat(text(c));
      return "";
    },
  },
  { name: "newchat", help: "Start a new chat with the current character(s) and open it.", origin: "st", run: async (c) => m(c).newChat() },
  {
    name: "note",
    help: "Author's Note: /note text sets it; /note alone returns it.",
    origin: "st",
    run: async (c) => {
      if (!c.hasUnnamed || asText(c.unnamed) === "") return (await m(c).authorNote()).text;
      await m(c).setAuthorNote(asText(c.unnamed));
      return "";
    },
  },
  {
    name: "depth",
    help: "Author's Note depth: /depth 4 (alone → current depth).",
    origin: "st",
    run: async (c) => {
      if (!text(c)) return String((await m(c).authorNote()).depth);
      const n = Number(text(c));
      if (!Number.isInteger(n) || n < 0) throw new ScriptError("/depth needs a whole number");
      await m(c).setAuthorNote(undefined, n);
      return "";
    },
  },
  {
    name: "reload-page",
    help: "Reload Marinara (shows tracker and connection changes right away).",
    origin: "dispensa",
    run: async (c) => {
      await c.rt.host.flush();
      await m(c).reloadPage();
      return "";
    },
  },
];
