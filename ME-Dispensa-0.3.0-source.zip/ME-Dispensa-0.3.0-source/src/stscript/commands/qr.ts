// Quick Reply management from scripts. Names and arguments follow
// SillyTavern's Quick Reply commands; /dock, /dock-layout and /qr-later are
// Dispensa additions. /qr-set* turn a set on in every chat, /qr-chat-set* for
// the open chat.

import type { Closure } from "../ast";
import type { QrControl, QrInfo, QrRef } from "../host";
import { asText, type CommandCall } from "../interpreter";
import { isFalse, isTrue } from "../parser";
import type { CommandDef } from "../registry";
import { Scope, ScriptError } from "../scope";
import { t } from "../../i18n";

const text = (c: CommandCall) => asText(c.unnamed).trim();
const str = (c: CommandCall, key: string): string | undefined => {
  const v = c.named[key];
  return v === undefined ? undefined : asText(v);
};
const bool = (c: CommandCall, key: string): boolean | undefined => {
  const v = str(c, key);
  if (v === undefined || v === "") return undefined;
  return isTrue(v) ? true : isFalse(v) ? false : undefined;
};

function qr(c: CommandCall): QrControl {
  if (!c.rt.host.qr) throw new ScriptError("Quick Reply commands only work inside Dispensa");
  return c.rt.host.qr;
}

function infoChanges(c: CommandCall): Partial<QrInfo> {
  const changes: Partial<QrInfo> = {};
  const title = str(c, "title");
  if (title !== undefined) changes.title = title;
  const icon = str(c, "icon");
  if (icon !== undefined) changes.icon = icon;
  for (const [arg, key] of [
    ["hidden", "hidden"],
    ["startup", "startup"],
    ["user", "user"],
    ["bot", "bot"],
    ["load", "load"],
    ["new", "newChat"],
    ["group", "group"],
    ["generation", "generation"],
    ["showlabel", "showLabel"],
  ] as const) {
    const b = bool(c, arg);
    if (b !== undefined) changes[key] = b;
  }
  return changes;
}

/** set= with label= (or the unnamed text) or id= (its number in the set, from 1). */
function ref(c: CommandCall, labelFromText = false): QrRef {
  const set = str(c, "set");
  if (!set) throw new ScriptError(`/${c.node.name} needs set=`);
  const id = str(c, "id");
  if (id !== undefined && id !== "") {
    const n = Number(id);
    if (!Number.isInteger(n) || n < 1) throw new ScriptError(`id= must be a number from 1 (got "${id}")`);
    return { set, id: n };
  }
  const label = str(c, "label") ?? (labelFromText ? text(c) : undefined);
  if (!label) throw new ScriptError(`/${c.node.name} needs label= or id=`);
  return { set, label };
}

function chatToggle(state: boolean | undefined): CommandDef["run"] {
  return (c) => {
    const name = text(c);
    if (!name) throw new ScriptError("Set name is missing");
    return String(qr(c).setForChat(name, state));
  };
}

function setToggle(state: boolean | undefined): CommandDef["run"] {
  return (c) => {
    const name = text(c);
    if (!name) throw new ScriptError("Set name is missing");
    return String(qr(c).setEnabled(name, state));
  };
}

function setOptions(c: CommandCall) {
  return { nosend: bool(c, "nosend"), before: bool(c, "before"), inject: bool(c, "inject"), color: str(c, "color"), onlyBorder: bool(c, "onlyborder") };
}

/** Control errors (no such QR or set) as script errors. */
function wrap(fn: () => void): void {
  try {
    fn();
  } catch (e) {
    throw e instanceof ScriptError ? e : new ScriptError(e instanceof Error ? e.message : String(e));
  }
}

/** Top-level `/let name {: … :}` and `/var name {: … :}` closures of a script (what /import can take). */
function keptClosures(root: Closure): Map<string, Closure> {
  const out = new Map<string, Closure>();
  for (const ex of root.executors) {
    if (ex.kind !== "command" || (ex.name !== "let" && ex.name !== "var")) continue;
    const key = ex.named.find((a) => a.name === "key");
    const parts = ex.unnamed.map((u) => u.value);
    const name = key ? key.value : parts[0];
    const value = key ? parts[0] : parts[1];
    if (typeof name === "string" && value && typeof value !== "string") out.set(name.trim(), value);
  }
  return out;
}

function parseDelay(raw: string): number {
  const m = /^(\d+(?:\.\d+)?)\s*(ms|s|m|h)?$/i.exec(raw.trim());
  if (!m) throw new ScriptError(`Invalid delay "${raw}" (e.g. 30s, 5m, 1h)`);
  const n = Number(m[1]);
  const unit = (m[2] ?? "s").toLowerCase();
  return n * ({ ms: 1, s: 1000, m: 60_000, h: 3_600_000 } as Record<string, number>)[unit];
}

export const qrCommands: CommandDef[] = [
  {
    name: "qr",
    help: "Run the Nth visible Dock QR (counting from 0).",
    origin: "st",
    run: async (c) => {
      const index = Number(text(c));
      const item = qr(c).visible()[index];
      if (!item) throw new ScriptError(`No Dock QR at index ${text(c)}`);
      await qr(c).run(`${item.set}.${item.label}`);
      return "";
    },
  },
  { name: "qr-set", aliases: ["qrset"], help: "Turn a QR set on/off in every chat (toggle).", origin: "st", run: setToggle(undefined) },
  { name: "qr-set-on", help: "Turn a QR set on in every chat.", origin: "st", run: setToggle(true) },
  { name: "qr-set-off", help: "Turn a QR set off in every chat.", origin: "st", run: setToggle(false) },
  { name: "qr-chat-set", help: "Turn a QR set on/off for this chat (toggle).", origin: "st", run: chatToggle(undefined) },
  { name: "qr-chat-set-on", help: "Turn a QR set on for this chat.", origin: "st", run: chatToggle(true) },
  { name: "qr-chat-set-off", help: "Turn a QR set off for this chat.", origin: "st", run: chatToggle(false) },
  {
    name: "qr-set-list",
    help: "Names of QR sets as a JSON list: /qr-set-list [all|global|chat]",
    origin: "st",
    run: (c) => {
      const where = text(c).toLowerCase();
      return JSON.stringify(qr(c).setNames(where === "global" || where === "chat" ? where : "all"));
    },
  },
  {
    name: "qr-list",
    help: "Labels of the QRs in a set as a JSON list.",
    origin: "st",
    run: (c) => {
      const set = str(c, "set") ?? text(c);
      return JSON.stringify(qr(c).labels(set));
    },
  },
  {
    name: "qr-get",
    help: "A QR's properties as JSON: /qr-get set=… label=… (or id=)",
    origin: "st",
    run: (c) => {
      const info = qr(c).get(ref(c, true));
      return info ? JSON.stringify(info) : "";
    },
  },
  {
    name: "qr-create",
    help: "Create a QR: /qr-create set=… label=… [icon=] [showlabel=] [title=] [hidden=] [startup=] [user=] [bot=] [load=] [new=] [group=] [generation=] script",
    origin: "st",
    run: (c) => {
      const set = str(c, "set");
      const label = str(c, "label");
      if (!set || !label) throw new ScriptError("/qr-create needs set= and label=");
      qr(c).create({ set, label, message: asText(c.unnamed), ...infoChanges(c) }, c.rt.dialect);
      return "";
    },
  },
  {
    name: "qr-update",
    help: "Change a QR: /qr-update set=… label=… (or id=) [newlabel=] [icon=] [title=] [hidden=] … [new script]",
    origin: "st",
    run: (c) => {
      const target = ref(c);
      const changes: Partial<QrInfo> & { newLabel?: string } = infoChanges(c);
      const newLabel = str(c, "newlabel");
      if (newLabel) changes.newLabel = newLabel;
      if (c.hasUnnamed && asText(c.unnamed) !== "") changes.message = asText(c.unnamed);
      if (!qr(c).update(target, changes)) throw new ScriptError(`No such QR in set "${target.set}"`);
      return "";
    },
  },
  {
    name: "qr-delete",
    help: "Delete a QR: /qr-delete set=… label (or id=) (asks first).",
    origin: "st",
    run: async (c) => {
      const target = ref(c, true);
      const what = target.label ?? `#${target.id}`;
      if (!(await c.rt.host.confirm(t(`Delete QR "${what}" from set "${target.set}"?`, `"${target.set}" 세트의 QR "${what}"을(를) 삭제할까요?`)))) return "";
      qr(c).remove(target);
      return "";
    },
  },
  {
    name: "qr-contextadd",
    help: "Add a set as a QR's sub menu: /qr-contextadd set=… label=… (or id=) [chain=true] SubMenuSet",
    origin: "st",
    run: (c) => {
      const name = text(c);
      if (!name) throw new ScriptError("/qr-contextadd needs the sub menu's set name");
      wrap(() => qr(c).contextAdd(ref(c), name, bool(c, "chain") ?? false));
      return "";
    },
  },
  {
    name: "qr-contextdel",
    help: "Take a set off a QR's sub menu: /qr-contextdel set=… label=… (or id=) SubMenuSet",
    origin: "st",
    run: (c) => {
      wrap(() => qr(c).contextDel(ref(c), text(c)));
      return "";
    },
  },
  {
    name: "qr-contextclear",
    help: "Clear a QR's sub menu: /qr-contextclear set=… label (or id=)",
    origin: "st",
    run: (c) => {
      wrap(() => qr(c).contextClear(ref(c, true)));
      return "";
    },
  },
  {
    name: "qr-arg",
    help: "A fallback value for a QR argument {{arg::name}}: /qr-arg name value",
    origin: "st",
    split: true,
    splitCount: 2,
    run: (c) => {
      const [key, value] = (c.unnamed as unknown[]).map((v) => asText(v as string));
      if (!key) throw new ScriptError("/qr-arg needs a name");
      // a value passed with /run stays; a name with * always overwrites
      if (key.includes("*") || c.scope.getMacro(`arg::${key}`) === undefined) c.scope.setMacro(`arg::${key}`, value ?? "");
      return "";
    },
  },
  {
    name: "import",
    help: "Use closures a QR keeps in /let or /var: /import from=Set.Label name [name as alias] …",
    origin: "st",
    split: true,
    run: (c) => {
      const from = str(c, "from");
      if (!from) throw new ScriptError("/import requires from= to be set.");
      const names = (c.unnamed as unknown[]).map((v) => asText(v as string)).filter(Boolean);
      if (!names.length) throw new ScriptError("/import requires the names to import.");
      const source = qr(c).source(from);
      if (!source) throw new ScriptError(`No Quick Reply found for "${from}".`);
      const closures = keptClosures(c.rt.parse(source.script));
      for (let i = 0; i < names.length; i++) {
        const src = names[i];
        let dst = src;
        if (i + 2 < names.length && names[i + 1] === "as") {
          dst = names[i + 2];
          i += 2;
        }
        const closure = closures.get(src);
        if (!closure) throw new ScriptError(`No scoped closure named "${src}" found in "${from}"`);
        const value = { kind: "closure-value" as const, closure, scope: new Scope(c.scope), flags: c.node.flags };
        if (c.scope.has(dst)) c.scope.set(dst, value);
        else c.scope.let(dst, value);
      }
      return "";
    },
  },
  {
    name: "qr-set-create",
    aliases: ["qr-presetadd"],
    help: "Create a QR set: /qr-set-create [nosend=] [before=] [inject=] [color=] [onlyborder=] name",
    origin: "st",
    run: (c) => {
      const name = text(c);
      if (!name) throw new ScriptError("Set name is missing");
      qr(c).createSet(name, setOptions(c));
      return "";
    },
  },
  {
    name: "qr-set-update",
    aliases: ["qr-presetupdate"],
    help: "Change a QR set's options.",
    origin: "st",
    run: (c) => {
      if (!qr(c).updateSet(text(c), setOptions(c))) throw new ScriptError(`No QR set "${text(c)}"`);
      return "";
    },
  },
  {
    name: "qr-set-delete",
    aliases: ["qr-presetdelete"],
    help: "Delete a QR set (asks first).",
    origin: "st",
    run: async (c) => {
      if (!(await c.rt.host.confirm(t(`Delete the whole QR set "${text(c)}"?`, `QR 세트 "${text(c)}"를 통째로 삭제할까요?`)))) return "";
      qr(c).removeSet(text(c));
      return "";
    },
  },

  // ── Dispensa additions ──
  {
    name: "dock",
    aliases: ["qr-bar"],
    help: "Show, hide or toggle the Dock: /dock show|hide|toggle → true when shown",
    origin: "dispensa",
    run: (c) => {
      const arg = text(c).toLowerCase();
      const state = arg === "show" || arg === "on" ? true : arg === "hide" || arg === "off" ? false : undefined;
      return String(qr(c).barVisible(state));
    },
  },
  {
    name: "dock-layout",
    aliases: ["qr-folder"],
    help: "Lay a set on the Dock as one folder bubble or a row of bubbles: /dock-layout mode=folder|row name",
    origin: "dispensa",
    run: (c) => {
      const mode = ["row", "inline"].includes(str(c, "mode") ?? "") ? "inline" : "folder";
      if (!qr(c).setDisplay(text(c), mode)) throw new ScriptError(`No QR set "${text(c)}"`);
      return "";
    },
  },
  {
    name: "qr-later",
    help: "Run a QR after a delay: /qr-later delay=5m Set.Label (until the page is reloaded)",
    origin: "dispensa",
    run: (c) => {
      const name = text(c);
      if (!name) throw new ScriptError("/qr-later needs a QR name (Label or Set.Label)");
      const ms = parseDelay(str(c, "delay") ?? "60s");
      qr(c).runLater(name, ms);
      return "";
    },
  },
];
