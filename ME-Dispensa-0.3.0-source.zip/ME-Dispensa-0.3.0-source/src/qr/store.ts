import { getMarinara } from "../host/marinara-global";
import { type QrState, emptyState, normalizeState } from "./model";

const KEY = "qr";
/** Marinara allows 1,000,000 bytes of extension storage in total. */
const SOFT_LIMIT = 900_000;

export class QrStore {
  private state: QrState = emptyState();
  private readonly listeners = new Set<(s: QrState) => void>();
  private saveTimer: ReturnType<typeof setTimeout> | null = null;
  private loadedOk = false;

  /** Loaded from storage (writes are safe). */
  get ready(): boolean {
    return this.loadedOk;
  }

  get value(): QrState {
    return this.state;
  }

  async load(): Promise<void> {
    try {
      const stored = await getMarinara().storage.get();
      this.state = normalizeState(stored[KEY]);
      this.loadedOk = true;
    } catch (e) {
      // Never overwrite storage we could not read.
      this.loadedOk = false;
      throw e;
    }
    this.emit();
  }

  subscribe(fn: (s: QrState) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  update(mutate: (s: QrState) => void): void {
    mutate(this.state);
    this.emit();
    this.scheduleSave();
  }

  /** Size of the saved data in bytes, to warn before Marinara's limit. */
  size(): number {
    return new TextEncoder().encode(JSON.stringify(this.state)).length;
  }

  overLimit(): boolean {
    return this.size() > SOFT_LIMIT;
  }

  async saveNow(): Promise<void> {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = null;
    if (!this.loadedOk) return;
    await getMarinara().storage.patch({ [KEY]: this.state });
  }

  private scheduleSave(): void {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => {
      void this.saveNow().catch((e) => console.error("[Dispensa] save failed", e));
    }, 400);
  }

  private emit(): void {
    for (const fn of this.listeners) fn(this.state);
  }
}
