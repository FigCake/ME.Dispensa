// The Dock: its own list of bubbles (sets and single QRs), the same in
// every chat. Where a set is on (every chat, this chat, a character) decides
// only where its QRs auto-run; the bar is a row of shortcuts.

import { type BarEntry, type BarLayout, type QrItem, type QrSet, type QrState, builtinSet, newSet } from "./model";

/** The set QRs made right on the bar go to: its name in the screen language when it is made, and its icon. */
export const BAR_SET = { name: () => "Dock", icon: "⚡" };

/** A bar entry with what it points at; entries whose set or QR is gone are left out. */
export type ShownEntry = { entry: BarEntry; set: QrSet; item?: QrItem };

export function shownBar(state: QrState): ShownEntry[] {
  const out: ShownEntry[] = [];
  for (const entry of state.bar ?? []) {
    if (entry.kind === "set") {
      const set = state.sets.find((s) => s.id === entry.setId);
      if (set) out.push({ entry, set });
      continue;
    }
    // a QR moved to another set keeps its bubble (ids are unique)
    for (const set of state.sets) {
      const item = set.items.find((i) => i.id === entry.itemId);
      if (item) {
        out.push({ entry, set, item });
        break;
      }
    }
  }
  return out;
}

const same = (a: BarEntry, b: BarEntry) => a.kind === b.kind && (a.kind === "set" ? a.setId === b.setId : a.itemId === (b as typeof a).itemId);

export function onBar(state: QrState, entry: BarEntry): boolean {
  return (state.bar ?? []).some((e) => same(e, entry));
}

/** Puts an entry on the bar (at the end, or at `index`); one that is there already stays put. */
export function addToBar(state: QrState, entry: BarEntry, index?: number): void {
  const bar = (state.bar ??= []);
  if (bar.some((e) => same(e, entry))) return;
  bar.splice(index === undefined ? bar.length : Math.max(0, Math.min(index, bar.length)), 0, entry);
}

export function removeFromBar(state: QrState, entry: BarEntry): void {
  if (state.bar) state.bar = state.bar.filter((e) => !same(e, entry));
}

/** A deleted set or QR leaves no bubble behind. */
export function forgetOnBar(state: QrState, setId: string, itemId?: string): void {
  if (!state.bar) return;
  state.bar = state.bar.filter((e) => (itemId === undefined ? e.setId !== setId : !(e.kind === "qr" && e.itemId === itemId)));
}

/** The Dock set, made when missing: on in every chat, so the QRs made on the bar auto-run anywhere. */
export function barSet(state: QrState): QrSet {
  let set = builtinSet(state, "bar");
  if (!set) {
    set = { ...newSet(BAR_SET.name()), icon: BAR_SET.icon, builtin: "bar" };
    state.sets.push(set);
  }
  return set;
}

/**
 * Once, from builds where the bar showed the sets that were on: the sets on
 * in every chat (with something to show) become the bar's entries, in order.
 */
export function moveToOwnBar(state: QrState): void {
  if (state.bar) return;
  state.bar = state.sets.filter((s) => s.enabled && s.items.some((i) => !i.hidden)).map((s): BarEntry => ({ kind: "set", setId: s.id, layout: s.display === "inline" ? "row" : "folder" }));
}

const OLD_BAR_NAMES = ["퀵바", "Quick bar"];

/** The Dock set still under the name older builds gave it, if any. */
export function oldBarSet(state: QrState): QrSet | undefined {
  const set = state.sets.find((s) => s.builtin === "bar") ?? state.sets.find((s) => !s.builtin && s.name === "퀵바");
  return set && OLD_BAR_NAMES.includes(set.name) ? set : undefined;
}

/** Once: the Dock set from builds that called it 퀵바 / Quick bar takes its new name. */
export function renameOldBarSet(state: QrState): void {
  const set = oldBarSet(state);
  if (!set) return;
  set.builtin = "bar";
  set.name = BAR_SET.name();
}

/** How a set entry sits on the bar (older entries follow the set's own "펼쳐서 보이기"). */
export function layoutOf(entry: BarEntry, set: QrSet): BarLayout {
  if (entry.kind !== "set") return "folder";
  return entry.layout ?? (set.display === "inline" ? "row" : "folder");
}

export function setLayout(state: QrState, setId: string, layout: BarLayout): void {
  for (const e of state.bar ?? []) if (e.kind === "set" && e.setId === setId) e.layout = layout;
}
