import type { Dialect } from "../stscript/host";
import type { OocMode, VizOutput } from "../wand/model";
import { t } from "../i18n";

/**
 * When a QR runs by itself (SillyTavern's executeOn…): app start, after my
 * message, after an AI reply, opening a chat, a new chat, a group member's
 * turn, and right before the AI starts writing.
 */
export type AutoTrigger = "startup" | "user" | "ai" | "chatChange" | "newChat" | "groupDraft" | "beforeGeneration";

export const AUTO_TRIGGERS: AutoTrigger[] = ["startup", "user", "ai", "chatChange", "newChat", "groupDraft", "beforeGeneration"];

export interface QrItem {
  id: string;
  label: string;
  /** Tooltip. */
  title?: string;
  /** STscript, or plain text to send. */
  script: string;
  dialect: Dialect;
  /** script: STscript or text. ooc: an OOC note. viz: a 🌟 QR (its script is the visualizer request). */
  kind: "script" | "ooc" | "viz";
  /** 🌟 QRs: how the visualizer runs them. */
  viz?: VizQrOptions;
  icon?: string;
  /** With an icon: false shows only the icon in menus (SillyTavern's showLabel). */
  showLabel?: boolean;
  /** Sets opened as a sub menu of this QR (right-click / long-press); chained items run this QR first. */
  contextList?: QrContextLink[];
  /** Hidden from the bar (still runnable with /run or auto triggers). */
  hidden?: boolean;
  auto?: Partial<Record<AutoTrigger, boolean>>;
  /** Runs when a lorebook entry with this name (or id) comes into play (SillyTavern's automationId). */
  automationId?: string;
  /** While this QR runs, other QRs' auto-runs wait it out (SillyTavern's preventAutoExecute; unset = on). */
  preventAuto?: boolean;
  /** Commands the interpreter does not know (filled in on import/save). */
  unsupported?: string[];
  /** Why an imported QR still runs with SillyTavern numbering. */
  note?: string;
  /** OOC notes: the note without its wrapper, for loading into the 🌟 input. */
  ooc?: string;
}

/** A set shown as a QR's sub menu. */
export interface QrContextLink {
  setId: string;
  /** Run the parent QR's script first, then the picked item (SillyTavern's "chain"). */
  chained?: boolean;
}

/** How a 🌟 QR runs; unset choices follow the visualizer's defaults. */
export interface VizQrOptions {
  /** What a press does: make a page (🌟) or send it as OOC (💬). */
  action: "viz" | "ooc";
  /** Group name in the 🌟 menu. */
  folder?: string;
  /** Its own bubble on the bar. */
  pinned?: boolean;
  oocMode?: OocMode;
  vizOutput?: VizOutput;
  wrapperId?: string;
  /** Helper model ("" or null = the default). */
  connectionId?: string | null;
}

export interface QrSet {
  id: string;
  name: string;
  items: QrItem[];
  /** "folder": one chip that opens the items. "inline": items sit on the bar. */
  display: "folder" | "inline";
  /** On in every chat (SillyTavern's global set list). Chat and character sets live in QrState. */
  enabled: boolean;
  color?: string;
  /** Use the color for the outline only (SillyTavern's onlyBorderColor). */
  colorBorderOnly?: boolean;
  /** The bubble's icon on the bar (an emoji). */
  icon?: string;
  origin: "st" | "dispensa";
  /** One of Dispensa's own sets (found by this, whatever its name in either language). */
  builtin?: "viz" | "bar";
  /** SillyTavern set options for plain-text items. */
  disableSend?: boolean;
  placeBeforeInput?: boolean;
  injectInput?: boolean;
}

/** One bubble of the Dock: a set (a folder, or its QRs side by side) or one QR. */
export type BarEntry = { kind: "set"; setId: string; layout?: BarLayout } | { kind: "qr"; setId: string; itemId: string };

/** A set on the bar: one folder bubble, or its QRs as bubbles on a line of their own. */
export type BarLayout = "folder" | "row";

export interface QrState {
  version: 1;
  sets: QrSet[];
  barVisible: boolean;
  /** What the Dock shows, in order, in every chat (apart from where sets are on). Unset: not moved over yet. */
  bar?: BarEntry[];
  /** Sets turned on for one chat (chat id → set ids). */
  chatSets: Record<string, string[]>;
  /** Sets turned on for one character, in every chat with them (character id → set ids). */
  charSets: Record<string, string[]>;
}

/** barVisible: the switch next to the input box (off by default; on = the bar comes up on hover or touch). */
export const emptyState = (): QrState => ({ version: 1, sets: [], barVisible: false, chatSets: {}, charSets: {} });

export function newId(prefix = "q"): string {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

export function newSet(name: string, origin: QrSet["origin"] = "dispensa"): QrSet {
  return { id: newId("set"), name, items: [], display: "folder", enabled: true, origin };
}

export function newItem(label: string, script: string, dialect: Dialect = "marinara", kind: QrItem["kind"] = "script"): QrItem {
  return { id: newId("qr"), label, script, dialect, kind };
}

export function normalizeState(raw: unknown): QrState {
  const base = emptyState();
  if (!raw || typeof raw !== "object") return base;
  const r = raw as Partial<QrState>;
  return {
    version: 1,
    barVisible: r.barVisible === true,
    ...(Array.isArray(r.bar) ? { bar: barEntries(r.bar) } : {}),
    chatSets: idLists(r.chatSets),
    charSets: idLists(r.charSets),
    sets: Array.isArray(r.sets)
      ? r.sets.map((s) => ({
          ...newSet(String(s?.name ?? t("Set", "세트"))),
          ...s,
          items: Array.isArray(s?.items) ? s.items.map((i) => ({ ...newItem(String(i?.label ?? "QR"), String(i?.script ?? "")), ...i })) : [],
        }))
      : [],
  };
}

function barEntries(raw: unknown[]): BarEntry[] {
  return raw.flatMap((e): BarEntry[] => {
    const x = e as Partial<{ kind: string; setId: unknown; itemId: unknown }>;
    if (typeof x?.setId !== "string") return [];
    if (x.kind === "set") return [{ kind: "set", setId: x.setId, ...((x as { layout?: unknown }).layout === "row" || (x as { layout?: unknown }).layout === "folder" ? { layout: (x as { layout: BarLayout }).layout } : {}) }];
    if (x.kind === "qr" && typeof x.itemId === "string") return [{ kind: "qr", setId: x.setId, itemId: x.itemId }];
    return [];
  });
}

function idLists(raw: unknown): Record<string, string[]> {
  const out: Record<string, string[]> = {};
  if (!raw || typeof raw !== "object") return out;
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    const ids = Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
    if (ids.length) out[k] = [...new Set(ids)];
  }
  return out;
}

/** Names the built-in sets had before they were marked (Korean). */
const BUILTIN_NAMES: Record<NonNullable<QrSet["builtin"]>, string> = { viz: "비주얼라이저", bar: "퀵바" };

/** A built-in set: by its mark, or (from older builds) by its old name, which then gets the mark. */
export function builtinSet(state: QrState, kind: NonNullable<QrSet["builtin"]>): QrSet | undefined {
  const marked = state.sets.find((s) => s.builtin === kind);
  if (marked) return marked;
  const old = state.sets.find((s) => !s.builtin && s.name === BUILTIN_NAMES[kind]);
  if (old) old.builtin = kind;
  return old;
}

/** Find a QR for /run: "Set.Label" first as a label, then set + label. */
export function findItem(state: QrState, name: string): { set: QrSet; item: QrItem } | undefined {
  for (const set of state.sets) {
    const item = set.items.find((i) => i.label === name);
    if (item) return { set, item };
  }
  const dot = name.indexOf(".");
  if (dot > 0) {
    const setName = name.slice(0, dot);
    const label = name.slice(dot + 1);
    const set = state.sets.find((s) => s.name === setName);
    const item = set?.items.find((i) => i.label === label);
    if (set && item) return { set, item };
  }
  return undefined;
}

/** OOC notes kept in the QR sets (any set), as plain text without wrappers. */
export function oocNotes(state: QrState): { label: string; text: string }[] {
  const out: { label: string; text: string }[] = [];
  for (const set of state.sets) {
    for (const item of set.items) {
      if (item.kind !== "ooc") continue;
      const text = (item.ooc ?? item.title ?? "").trim();
      if (text) out.push({ label: item.label, text });
    }
  }
  return out;
}
