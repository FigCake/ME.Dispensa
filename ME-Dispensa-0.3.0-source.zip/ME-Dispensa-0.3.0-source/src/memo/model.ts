// The 메모장: lines of text kept for later (OOC notes, ideas for a page).
// They are not QRs: no scripts, no sets; they are found, sent as OOC, put in
// the input or the 🌟 request, or turned into a QR.

import { extractOocNotes } from "../qr/import";
import { addToBar, barSet } from "../qr/bar";
import { t } from "../i18n";
import { type QrItem, type QrSet, type QrState, builtinSet, newId, newItem, newSet } from "../qr/model";
import { forgetSet } from "../qr/scopes";
import { VIZ_SET } from "../wand/items";
import { DEFAULT_ITEMS, OLD_COMMUNITY_TEXT } from "../wand/defaults";

/** Built-in texts that were rewritten: an unedited memo with the old text gets the new one. */
const REWRITTEN = new Map([[OLD_COMMUNITY_TEXT, DEFAULT_ITEMS.find((i) => i.id === "sample-community")?.content ?? OLD_COMMUNITY_TEXT]]);

export interface Memo {
  id: string;
  text: string;
  /** Kept at the top. */
  pinned?: boolean;
  createdAt: number;
}

export interface MemoState {
  version: 1;
  memos: Memo[];
  /** The 📝 bubble on the Dock. */
  showButton: boolean;
  barIcon: string;
  /** The "📝 메모" button under selected chat text (on unless turned off). */
  capture?: boolean;
  /** OOC notes and OOC 🌟 QRs were moved here from the 보관함. */
  moved?: boolean;
  /** The topics of the old 🌟 QRs were moved here (the 비주얼라이저 set got real QRs). */
  vizMoved?: boolean;
}

export const emptyMemos = (): MemoState => ({ version: 1, memos: [], showButton: true, barIcon: "📝" });

export function newMemo(text: string, at = Date.now()): Memo {
  return { id: newId("memo"), text: text.trim(), createdAt: at };
}

export function normalizeMemos(raw: unknown): MemoState {
  const base = emptyMemos();
  if (!raw || typeof raw !== "object") return base;
  const r = raw as Partial<MemoState>;
  return {
    version: 1,
    memos: Array.isArray(r.memos)
      ? r.memos
          .filter((m) => m && typeof m.text === "string")
          .map((m) => ({ id: typeof m.id === "string" ? m.id : newId("memo"), text: REWRITTEN.get(m.text) ?? m.text, createdAt: Number(m.createdAt) || 0, ...(m.pinned ? { pinned: true } : {}) }))
      : [],
    showButton: r.showButton !== false,
    barIcon: typeof r.barIcon === "string" && r.barIcon.trim() ? r.barIcon.trim() : base.barIcon,
    ...(r.capture === false ? { capture: false } : {}),
    ...(r.moved ? { moved: true } : {}),
    ...(r.vizMoved ? { vizMoved: true } : {}),
  };
}

/** Memos made from text: OOC wrappers come off, several wrapped notes become several memos. */
export function memosFrom(text: string, at = Date.now()): Memo[] {
  return extractOocNotes(text)
    .map((t) => t.trim())
    .filter(Boolean)
    .map((t, i) => newMemo(t, at + i));
}

const fold = (s: string) => s.normalize("NFC").toLowerCase();

/** Pinned first, then newest; `query` keeps those with every word in them. */
export function shownMemos(memos: Memo[], query = ""): Memo[] {
  const words = fold(query).split(/\s+/).filter(Boolean);
  return memos
    .filter((m) => words.every((w) => fold(m.text).includes(w)))
    .sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned) || b.createdAt - a.createdAt);
}

/** One line of a memo for lists. */
export function memoLine(text: string, max = 80): string {
  const one = text.replace(/\s+/g, " ").trim();
  return one.length > max ? `${one.slice(0, max - 1)}…` : one;
}

function oocText(item: QrItem): string {
  if (item.kind === "viz") return item.script;
  return (item.ooc ?? item.title ?? item.script.replace(/^\/guided\s+/, "")).trim();
}

/**
 * Once: OOC notes and the 🌟 QRs that sent OOC leave the 보관함 for the 메모장,
 * an emptied OOC set goes, and the 비주얼라이저 set leaves the bar (its 🌟 QRs
 * are in the 🍰 menu). Returns how many memos came in.
 */
export function moveOocToMemos(qr: QrState, memo: MemoState, at = Date.now()): number {
  const moved: Memo[] = [];
  for (const set of qr.sets) {
    const keep: QrItem[] = [];
    for (const item of set.items) {
      const isOoc = item.kind === "ooc" || (item.kind === "viz" && item.viz?.action === "ooc");
      const text = isOoc ? oocText(item) : "";
      if (isOoc && text) moved.push(newMemo(text, at - moved.length));
      else if (!isOoc) keep.push(item);
    }
    set.items = keep;
  }
  for (const set of qr.sets.filter((s) => s.name === "OOC" && !s.items.length)) forgetSet(qr, set.id);
  qr.sets = qr.sets.filter((s) => !(s.name === "OOC" && !s.items.length));
  const viz = builtinSet(qr, "viz");
  if (viz) viz.enabled = false;
  // the first in the 보관함 gets the latest time, so they keep their order (newest on top)
  memo.memos.push(...moved);
  memo.moved = true;
  return moved.length;
}

/** The Visualizer set's QRs: whole QRs that run the visualizer (`[[…]]` asks at run time), named in the screen language. */
export const VIZ_QRS = (): { label: string; icon: string; title: string; script: string }[] => [
  { label: t("Superviz", "슈퍼비즈"), icon: "🌟", title: t("Ask for a topic and make a page", "주제를 물어서 페이지 만들기"), script: t("/visz [[Topic of the page]]", "/visz [[만들 페이지의 주제]]") },
  { label: t("From the last message", "마지막 메시지로"), icon: "🎬", title: t("A page of the last message's scene", "마지막 메시지의 장면을 페이지로"), script: t("/visz A page of this scene: {{lastMessage}}", "/visz 이 장면을 담은 페이지: {{lastMessage}}") },
  { label: t("From a memo", "메모로"), icon: "📝", title: t("A page from a memo picked in the memo pad", "메모장에서 고른 메모로 페이지 만들기"), script: t("/visz [[memo]]", "/visz [[메모]]") },
];

/** The Visualizer set, made with its QRs when missing. */
export function vizSetWithQrs(qr: QrState): QrSet {
  let set = builtinSet(qr, "viz");
  if (!set) {
    set = { ...newSet(VIZ_SET.name()), icon: VIZ_SET.icon, enabled: false, builtin: "viz" };
    qr.sets.push(set);
  }
  if (!set.items.length) for (const v of VIZ_QRS()) set.items.push({ ...newItem(v.label, v.script), icon: v.icon, title: v.title });
  return set;
}

/**
 * Once: the old 🌟 QRs were only topics for the visualizer, so their text goes
 * to the 메모장. One that sat on the bar becomes a QR there that makes that
 * page (`/visz 주제`), so the bubble keeps working. The 비주얼라이저 set gets
 * its real QRs. Returns how many memos came in.
 */
export function retireVizQrs(qr: QrState, memo: MemoState, at = Date.now()): number {
  const have = new Set(memo.memos.map((m) => m.text));
  let n = 0;
  for (const set of qr.sets) {
    const keep: QrItem[] = [];
    for (const item of set.items) {
      if (item.kind !== "viz") {
        keep.push(item);
        continue;
      }
      const text = item.script.trim();
      if (text && !have.has(text)) {
        memo.memos.push(newMemo(text, at - n++));
        have.add(text);
      }
      if (item.viz?.pinned) {
        const target = barSet(qr);
        const made: QrItem = { ...newItem(item.label, `/visz ${text.replace(/[|\\]/g, (c) => `\\${c}`)}`), ...(item.icon ? { icon: item.icon } : {}) };
        target.items.push(made);
        addToBar(qr, { kind: "qr", setId: target.id, itemId: made.id });
      }
    }
    set.items = keep;
  }
  vizSetWithQrs(qr);
  memo.vizMoved = true;
  return n;
}
