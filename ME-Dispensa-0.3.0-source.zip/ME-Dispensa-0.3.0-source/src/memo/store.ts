import { getMarinara } from "../host/marinara-global";
import { type MemoState, emptyMemos, normalizeMemos } from "./model";

const KEY = "memo";

/** The 메모장 in Marinara's extension storage (so it follows you to other devices). */
export class MemoStore {
  private state: MemoState = emptyMemos();
  private readonly listeners = new Set<(s: MemoState) => void>();
  private saveTimer: ReturnType<typeof setTimeout> | null = null;
  private loadedOk = false;

  get ready(): boolean {
    return this.loadedOk;
  }

  get value(): MemoState {
    return this.state;
  }

  async load(): Promise<void> {
    try {
      const stored = await getMarinara().storage.get();
      this.state = normalizeMemos(stored[KEY]);
      this.loadedOk = true;
    } catch (e) {
      // never overwrite storage we could not read
      this.loadedOk = false;
      throw e;
    }
    this.emit();
  }

  subscribe(fn: (s: MemoState) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  update(mutate: (s: MemoState) => void): void {
    mutate(this.state);
    this.emit();
    this.scheduleSave();
  }

  size(): number {
    return new TextEncoder().encode(JSON.stringify(this.state)).length;
  }

  async saveNow(): Promise<void> {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = null;
    if (!this.loadedOk) return;
    await getMarinara().storage.patch({ [KEY]: this.state });
  }

  private scheduleSave(): void {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => {
      void this.saveNow().catch((e) => console.error("[Dispensa] memo save failed", e));
    }, 400);
  }

  private emit(): void {
    for (const fn of this.listeners) fn(this.state);
  }
}
