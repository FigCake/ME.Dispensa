// QR manager: sets (folders) on the left, the selected set's QRs and the
// editor on the right. Import from SillyTavern, paste OOC notes, export.

import {
  type ImportReport,
  type SetNames,
  MQR_ITEM_FORMAT,
  applyConversion,
  exportMarinara,
  exportMarinaraItem,
  exportSillyTavern,
  findUnsupported,
  foreignCommands,
  importAny,
  importMarinara,
  nonSillyTavernCommands,
  resolveLinks,
  stExportItem,
} from "../qr/import";
import { type AutoTrigger, type QrItem, type QrSet, type QrState, newId, newItem, newSet } from "../qr/model";
import { type ChatScope, NO_CHAT, type SetZone, elsewhere, forgetSet, isOnForCharacter, isOnForChat, moveSet, setForCharacter, setForChat, zoneSets } from "../qr/scopes";
import type { Debugger } from "../stscript/interpreter";
import { DRAG_CSS, dragAcross, dragHandle, moveTo } from "./drag";
import { LANG_NAMES, type LangChoice, langChoice, setLangChoice, t } from "../i18n";
import { addToBar, barSet, layoutOf, onBar, removeFromBar, setLayout, shownBar } from "../qr/bar";
import type { BarLayout } from "../qr/model";
import { RUN_PANEL_CSS, RunPanel } from "./run-panel";
import { SCRIPT_EDITOR_CSS, ScriptEditor } from "./script-editor";
import { MEMO_VIEW_CSS, MemoView } from "./memo-view";
import type { MemoStore } from "../memo/store";
import { memoLine, newMemo } from "../memo/model";
import type { QrStore } from "../qr/store";
import type { CommandDef, CommandRegistry } from "../stscript/registry";
import type { HostUI } from "../stscript/host";
import { api } from "../host/api";
import type { WandStore } from "../wand/store";
import { el, icon } from "./dom";
import { FORM_CSS, helpTip, section, segmented, setting, toggle } from "./form";
import { CONTROLS, THEME_TOKENS } from "./theme";
import { fornello } from "./viewer";
import { VIZ_HELP, WAND_SETTINGS_STYLE, WandSettingsView } from "./wand-settings";

export interface ManagerDeps {
  store: QrStore;
  registry: CommandRegistry;
  ui: HostUI;
  run(set: QrSet, item: QrItem): void;
  /** Run from the editor (▶ / 🐞): the result comes back. */
  runInEditor(set: QrSet, item: QrItem, options: { signal: AbortSignal; debug?: Debugger }): Promise<{ pipe: string; aborted?: string }>;
  /** A character's name, for the "this character" switches. */
  characterName(id: string): Promise<string>;
  wandStore?: WandStore;
  /** The 📝 메모장 and what its memos can do. */
  memo?: {
    store: MemoStore;
    sendOoc(text: string): Promise<boolean>;
    putInInput(text: string): void;
    makePage(text: string): Promise<boolean>;
  };
}

export type ManagerTab = "qr" | "bar" | "memo" | "wand";

const STYLE = `
:host { all: initial; }
${THEME_TOKENS}
* { box-sizing: border-box; }
${CONTROLS}
.backdrop { position: fixed; inset: 0; z-index: 2147482000; background: rgb(0 0 0 / .5); display: flex; align-items: center; justify-content: center; padding: 12px;
  font: 14px/1.45 var(--d-font); color: var(--d-text); }
.win { width: min(1040px, 100%); height: min(760px, 100%); display: flex; flex-direction: column; overflow: hidden;
  border: 1px solid var(--d-line); border-radius: calc(var(--d-radius) + 0.25rem); box-shadow: 0 20px 60px rgb(0 0 0 / .45);
  background: var(--d-panel-solid); backdrop-filter: var(--d-shell-blur); -webkit-backdrop-filter: var(--d-shell-blur); }
header { display: flex; align-items: center; gap: 8px; padding: 10px 12px; border-bottom: 1px solid var(--d-divider); }
header h2 { font-size: 16px; margin: 0 6px 0 0; color: var(--d-title); }
.main { flex: 1; display: grid; grid-template-columns: 240px 1fr; min-height: 0; }
.col { min-height: 0; overflow: auto; padding: 10px; }
.col + .col { border-left: 1px solid var(--d-divider); }
.list { display: flex; flex-direction: column; gap: 4px; }
.row { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.grow { flex: 1; min-width: 0; }
button { padding: 6px 10px; }
button.icon { padding: 6px; }
.entry { justify-content: flex-start; width: 100%; text-align: left; overflow: hidden; text-overflow: ellipsis; }
.entry .meta { margin-left: auto; color: var(--d-muted); font-size: 12px; font-weight: 500; }
input[type=text], textarea, select { width: 100%; }
textarea { font-family: var(--d-mono); font-size: 13px; min-height: 220px; resize: vertical; tab-size: 2; }
label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--d-muted); }
label.inline { flex-direction: row; align-items: center; gap: 6px; color: var(--d-text); font-size: 13px; }
.section { margin: 12px 0 6px; font-size: 12px; text-transform: uppercase; letter-spacing: .04em; color: var(--d-muted); }
.note { font-size: 12px; color: var(--d-muted); }
.warn { color: #e6a23c; font-size: 12px; }
.editor { display: flex; flex-direction: column; gap: 10px; margin-top: 10px; padding: 10px; border: 1px solid var(--d-line); border-radius: var(--d-radius); background: var(--d-hl-bg); }
.empty { color: var(--d-muted); padding: 24px; text-align: center; }
.note-box { border: 1px dashed #e6a23c; border-radius: var(--d-radius-sm); padding: 8px 10px; font-size: 13px; }
.note-box ul { margin: 6px 0 8px; padding-left: 18px; }
svg { width: 15px; height: 15px; }
.badge { display: inline-block; font-size: 11px; line-height: 1; padding: 3px 6px; border-radius: 999px; border: 1px solid var(--d-line); color: var(--d-muted); white-space: nowrap; font-weight: 600; }
.badge.dispensa { border-color: #3fb97a; color: #3fb97a; }
.badge.marinara { border-color: var(--d-accent); color: var(--d-accent); }
.badge.extension { border-color: #8b7cf6; color: #8b7cf6; }
.foreign { font-size: 12px; color: var(--d-muted); display: flex; flex-wrap: wrap; gap: 4px; align-items: center; }
details.cmds summary { cursor: pointer; font-size: 13px; color: var(--d-text); }
.cmd-list { display: flex; flex-direction: column; gap: 2px; max-height: 260px; overflow: auto; margin-top: 6px; }
.cmd { justify-content: flex-start; width: 100%; text-align: left; border-color: transparent; background: none; padding: 4px 6px; white-space: normal; font-weight: 500; color: var(--d-text); }
.cmd code { font-family: var(--d-mono); font-size: 12px; min-width: 120px; color: var(--d-btn-text-active); }
.cmd .help { color: var(--d-muted); font-size: 12px; flex: 1; }
header .tab { padding: 5px 12px; }
.main.single { grid-template-columns: 1fr; }
${FORM_CSS}
${WAND_SETTINGS_STYLE}
${SCRIPT_EDITOR_CSS}
${RUN_PANEL_CSS}
${DRAG_CSS}
${MEMO_VIEW_CSS}
.qrow { display: flex; align-items: center; gap: 4px; }
.qrow > .entry { flex: 1; min-width: 0; }
.entry .marks { color: var(--d-muted); font-weight: 500; font-size: 12px; white-space: nowrap; }
.set-row { display: flex; align-items: center; gap: 2px; }
.set-row > .entry { flex: 1; min-width: 0; }
.zone-h { display: flex; align-items: center; gap: 6px; margin: 10px 0 4px; font-size: 12px; font-weight: 600; color: var(--d-muted); }
.zone-h:first-child { margin-top: 0; }
.zone-h .count { font-weight: 500; }
.zone { display: flex; flex-direction: column; gap: 4px; min-height: 32px; border-radius: var(--d-radius-sm); }
.zone.drop-into { outline: 2px dashed var(--d-accent); outline-offset: 1px; }
.zone-empty { padding: 6px 8px; font-size: 12px; color: var(--d-muted); border: 1px dashed var(--d-line); border-radius: var(--d-radius-sm); }
.links { display: flex; flex-direction: column; gap: 4px; margin: 4px 0; }
.links .link { display: flex; align-items: center; gap: 8px; padding: 4px 0; border-top: 1px solid var(--d-divider); }
.links .link:first-child { border-top: 0; }
.links .link .grow { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.links .link label.inline { font-size: 12px; color: var(--d-muted); }
.set > .ctl > input[type=color], input[type=color] { min-width: 0; width: 36px; height: 28px; padding: 2px; border-radius: var(--d-radius-sm); border: 1px solid var(--d-field-border); background: var(--d-field); cursor: pointer; }
details.box { border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); padding: 2px 10px; }
details.box > summary { cursor: pointer; list-style: none; display: flex; align-items: center; gap: 6px; padding: 7px 0; font-size: 13px; color: var(--d-text); }
details.box > summary::-webkit-details-marker { display: none; }
details.box > summary::before { content: "▸"; color: var(--d-muted); transition: transform .15s ease; }
details.box[open] > summary::before { transform: rotate(90deg); }
details.box > summary .count { color: var(--d-muted); font-size: 12px; }
details.box[open] { padding-bottom: 8px; }
.menu-list hr { border: 0; border-top: 1px solid var(--d-divider); margin: 3px 0; width: 100%; }
.menu-list button.danger-item { color: var(--d-danger); }
.field-h { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--d-muted); }
textarea.request { font-family: var(--d-font); min-height: 110px; }
.viz-mark { font-weight: 400; }
details.more > summary { cursor: pointer; color: var(--d-muted); font-size: 12px; padding: 4px 0; list-style: none; display: flex; align-items: center; gap: 6px; }
details.more > summary::before { content: "▸"; transition: transform .15s ease; }
details.more[open] > summary::before { transform: rotate(90deg); }
.col-h { display: flex; align-items: center; gap: 6px; }
.col-h strong { color: var(--d-title); }
/* switches one per line, each on the right: the names read down one column, the switches down another */
.toggles { display: flex; flex-direction: column; }
.toggles .set { min-height: 38px; padding: 4px 0; }
.toggles .set:first-child { border-top: 0; }
.actions { display: flex; justify-content: flex-end; gap: 6px; }
details.menu { position: relative; }
details.menu > summary { list-style: none; display: inline-flex; align-items: center; gap: 5px; cursor: pointer; font-weight: 600; white-space: nowrap;
  border: 1px solid var(--d-btn-border); background: var(--d-btn-bg); color: var(--d-btn-text); border-radius: var(--d-radius-sm); padding: 6px 10px; transition: background-color 150ms ease, border-color 150ms ease; }
details.menu > summary:hover, details.menu[open] > summary { border-color: var(--d-btn-border-hover); background: var(--d-btn-bg-hover); }
details.menu > summary::-webkit-details-marker { display: none; }
details.menu.right .menu-list { left: 0; right: auto; }
header select.lang { width: auto; flex: none; padding: 4px 6px; font-size: 12px; }
.bar-tab .row select { width: auto; min-width: 160px; max-width: 100%; }
.bar-tab select.layout { width: auto; flex: none; padding: 3px 6px; font-size: 12px; }
details.menu .menu-list { position: absolute; right: 0; top: calc(100% + 4px); z-index: 5; min-width: 240px; display: flex; flex-direction: column; gap: 2px; padding: 4px;
  background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); box-shadow: var(--d-shadow); animation: d-fade-in .12s ease-out; }
details.menu .menu-list button { justify-content: flex-start; flex-direction: column; align-items: flex-start; gap: 1px; border-color: transparent; background: none; white-space: normal; text-align: left; }
details.menu .menu-list button:hover { background: var(--d-hl-bg); }
details.menu .menu-list small { color: var(--d-muted); font-weight: 400; font-size: 11.5px; }
@media (max-width: 720px) { .main { grid-template-columns: 1fr; } .col + .col { border-left: none; border-top: 1px solid var(--d-divider); } }
/* phones: title and buttons on one line, the tabs on the next; header buttons show only their icons */
@media (max-width: 560px) {
  header { flex-wrap: wrap; row-gap: 8px; }
  header .tabs { order: 5; width: 100%; flex-wrap: nowrap; }
  header .tabs .seg2 { flex: 1; }
  header .label { display: none; }
  .win { height: 100%; }
  .col { padding: 10px 12px; }
}
`;

const ORIGIN_BADGE = {
  st: () => el("span", { class: "badge", title: t("Command SillyTavern also has", "실리태번에도 있는 명령") }, t("SillyTavern", "실리태번")),
  dispensa: () => el("span", { class: "badge dispensa", title: t("Dispensa-only command (not in SillyTavern)", "Dispensa 전용 명령 (실리태번에 없음)") }, "Dispensa"),
  marinara: () => el("span", { class: "badge marinara", title: t("Marinara feature command (not in SillyTavern)", "마리나라 기능 명령 (실리태번에 없음)") }, t("Marinara", "마리나라")),
  extension: (from: string) => el("span", { class: "badge extension", title: t(`Added by the ${from} extension`, `${from} 확장이 추가한 명령`) }, from),
};

/** Auto-run triggers in the editor, in SillyTavern's order. */
const TRIGGERS = (): { key: AutoTrigger; label: string; help?: string }[] => [
  { key: "startup", label: t("When Marinara starts", "마리나라를 켤 때") },
  { key: "user", label: t("After I send a message", "내 메시지를 보낸 뒤") },
  { key: "ai", label: t("After an AI reply", "AI 답변 뒤") },
  { key: "chatChange", label: t("When a chat opens", "채팅을 열 때") },
  { key: "newChat", label: t("When a new chat is made", "새 채팅을 만들 때") },
  { key: "groupDraft", label: t("On each character's turn in a group chat", "그룹 채팅에서 캐릭터 차례마다") },
  { key: "beforeGeneration", label: t("Just before the AI replies", "AI가 답을 쓰기 직전"), help: t("The reply waits until it finishes (up to 1 min)", "끝날 때까지 답 생성 대기 (최대 1분)") },
];

const HELP = () => ({
  places: t("Where auto-run works (same as the lists on the left)", "자동 실행이 도는 곳 (왼쪽 목록의 칸과 같음)"),
  plain: t(
    "When a QR with only text (no '/') is clicked\n· Don't send: only put it in the input\n· Add to input text: add it after the typed text and send\n· Put before: put it before the typed text",
    "'/' 없이 글만 쓴 QR을 누를 때\n· 보내지 않기: 입력창에 넣기만\n· 입력창 글에 붙이기: 쓰던 글 뒤에 붙여 보내기\n· 앞에 붙이기: 쓰던 글 앞에 붙이기",
  ),
  submenu: t(
    "Other sets attached as a sub menu. Opens with a right-click on the Dock (long press on phones)\n· Chain: the picked QR takes this QR's result\n· %%parent%%: becomes this QR's name",
    "다른 세트를 하위 메뉴로 달기. Dock에서 오른쪽 클릭(휴대폰은 꾹 누르기)으로 열기\n· 이어서 실행: 이 QR의 결과를 고른 QR이 이어받음\n· %%parent%%: 이 QR 이름으로 바뀜",
  ),
  auto: t("Auto-runs at the chosen times. Only where the set is on", "고른 때에 자동 실행. 세트가 켜진 곳에서만"),
  automation: t("Runs when this lorebook entry (name or id) is used in a reply (SillyTavern's Automation ID)", "이 로어북 항목(이름이나 id)이 답변에 쓰이면 실행 (실리태번의 자동화 ID)"),
  preventAuto: t("Stops this QR from auto-running other QRs", "이 QR이 다른 QR을 자동 실행하는 것을 막음"),
  showLabel: t("Shows only the icon in folders and sub menus", "폴더·하위 메뉴에서 아이콘만 표시"),
});

export class QrManager {
  private hostEl: HTMLElement | null = null;
  private root: ShadowRoot | null = null;
  private selectedSet: string | null = null;
  private selectedItem: string | null = null;
  private unsubscribe: (() => void) | null = null;
  private commandListOpen = false;
  private commandQuery = "";
  /** Folded parts kept open through redraws (by key). */
  private readonly openParts = new Set<string>();
  private tab: ManagerTab = "qr";
  private unsubscribeWand: (() => void) | null = null;
  private readonly wandView: WandSettingsView | null;
  private readonly memoView: MemoView | null;
  private unsubscribeMemo: (() => void) | null = null;
  /** The window slides in once, when it opens (not on every redraw). */
  private entering = false;
  private scope: ChatScope = NO_CHAT;
  private readonly names = new Map<string, string>();
  /** Script boxes and run panels live across redraws (caret, suggestions, a paused debugger). */
  private readonly editors = new Map<string, ScriptEditor>();
  private readonly panels = new Map<string, RunPanel>();
  private readonly breakpoints = new Map<string, Set<number>>();
  /** A change made by typing in a script box: no redraw. */
  private quiet = false;
  private scrollToEditor = false;

  constructor(private readonly deps: ManagerDeps) {
    this.wandView = deps.wandStore
      ? new WandSettingsView({
          store: deps.wandStore,
          ui: deps.ui,
          connections: async () => (await api<{ id: string; name: string }[]>("/connections")).map((c) => ({ id: c.id, name: c.name })),
          rerender: () => this.render(),
          // an old backup's items were topics: they go to the 메모장
          importItems: (items) => this.deps.memo?.store.update((m) => m.memos.push(...items.map((i) => i.content.trim()).filter(Boolean).map((t) => newMemo(t)))),
        })
      : null;
    const memo = deps.memo;
    this.memoView = memo
      ? new MemoView({
          store: memo.store,
          ui: deps.ui,
          sendOoc: memo.sendOoc,
          putInInput: memo.putInInput,
          makePage: memo.makePage,
          toQr: (text) => this.memoToQr(text),
          oocSettings: () => this.wandView?.oocCards() ?? [],
          menu: (summary, label, entries) => this.menu(summary, label, entries),
          quietly: (fn) => {
            this.quiet = true;
            try {
              fn();
            } finally {
              this.quiet = false;
            }
          },
          close: () => this.close(),
          rerender: () => this.render(),
        })
      : null;
  }

  /** A memo becomes a QR that sends it as OOC (/ooc), in a set you pick. */
  private async memoToQr(text: string): Promise<void> {
    const sets = this.state.sets;
    const NEW = t('+ New set "Memo QR"', '+ 새 세트 "메모 QR"');
    const labels = [NEW, ...sets.map((s, i) => `${s.name}${sets.filter((o) => o.name === s.name).length > 1 ? ` (${i + 1})` : ""}`)];
    const [picked] = (await this.deps.ui.pick?.(t("Pick a set for the QR.", "QR을 넣을 세트를 고르세요."), labels)) ?? [];
    if (!picked) return;
    const item = newItem(memoLine(text, 14), `/ooc ${text.replace(/[|\\]/g, (c) => `\\${c}`).replace(/\{:/g, "\\{:").replace(/:\}/g, "\\:}")}`);
    item.title = memoLine(text, 200);
    let setId = "";
    this.deps.store.update((st) => {
      let target = picked === NEW ? undefined : st.sets[labels.indexOf(picked) - 1];
      if (!target) {
        target = newSet(t("Memo QR", "메모 QR"));
        st.sets.push(target);
      }
      target.items.push(item);
      setId = target.id;
    });
    this.deps.ui.toast(t(`Made the QR "${item.label}". Clicking it sends it as OOC.`, `"${item.label}" QR을 만들었어요. 누르면 OOC로 보내요.`), "success", { title: "📝" });
    this.openItem(setId, item.id);
  }

  /** The chat on screen (its chat and character switches). */
  setScope(scope: ChatScope): void {
    this.scope = scope;
    for (const id of scope.characterIds) {
      if (this.names.has(id)) continue;
      this.names.set(id, t("Character", "캐릭터"));
      void this.deps.characterName(id).then((name) => {
        this.names.set(id, name);
        this.render();
      });
    }
    this.render();
  }

  open(tab?: ManagerTab): void {
    if (tab) this.tab = tab;
    if (this.hostEl) {
      this.render();
      return;
    }
    this.hostEl = el("div", { id: "dispensa-manager" });
    this.root = this.hostEl.attachShadow({ mode: "open" });
    document.body.append(this.hostEl);
    this.selectedSet ??= this.deps.store.value.sets[0]?.id ?? null;
    this.unsubscribe = this.deps.store.subscribe(() => {
      if (!this.quiet) this.render();
    });
    this.unsubscribeWand = this.deps.wandStore?.subscribe(() => this.render()) ?? null;
    this.unsubscribeMemo =
      this.deps.memo?.store.subscribe(() => {
        if (!this.quiet) this.render();
      }) ?? null;
    document.addEventListener("keydown", this.onKey, true);
    this.entering = true;
    this.render();
    this.entering = false;
  }

  /** Redraws when open (the screen language changed). */
  refresh(): void {
    if (this.hostEl) this.render();
  }

  /** Ctrl+click on the bar: straight to that QR's editor. */
  openItem(setId: string, itemId: string): void {
    this.selectedSet = setId;
    this.selectedItem = itemId;
    this.scrollToEditor = true;
    this.open("qr");
  }

  close(): void {
    for (const p of this.panels.values()) p.stop();
    this.unsubscribe?.();
    this.unsubscribe = null;
    this.unsubscribeWand?.();
    this.unsubscribeWand = null;
    this.unsubscribeMemo?.();
    this.unsubscribeMemo = null;
    void this.deps.wandStore?.saveNow().catch(() => undefined);
    void this.deps.memo?.store.saveNow().catch(() => undefined);
    document.removeEventListener("keydown", this.onKey, true);
    this.hostEl?.remove();
    this.hostEl = this.root = null;
    void this.deps.store.saveNow();
  }

  private readonly onKey = (e: KeyboardEvent) => {
    if (e.key === "Escape" && !e.defaultPrevented) {
      const active = this.root?.activeElement;
      if (active && active.tagName === "TEXTAREA") return;
      const menu = this.root?.querySelector<HTMLDetailsElement>("details.menu[open]");
      e.stopPropagation();
      if (menu) {
        menu.open = false;
        return;
      }
      this.close();
    }
  };

  private get set(): QrSet | undefined {
    return this.deps.store.value.sets.find((s) => s.id === this.selectedSet);
  }

  private get state(): QrState {
    return this.deps.store.value;
  }

  private readonly setName: SetNames = (id) => this.state.sets.find((s) => s.id === id)?.name;

  private render(): void {
    if (!this.root) return;
    // keep focus and caret in the editor across re-renders
    const active = this.root.activeElement as HTMLInputElement | HTMLTextAreaElement | null;
    const focusKey = active?.dataset?.key;
    const caret = active && "selectionStart" in active ? [active.selectionStart, active.selectionEnd] : null;
    const scrolls = [...this.root.querySelectorAll<HTMLElement>(".col")].map((c) => c.scrollTop);
    this.forgetGone();

    const style = el("style");
    style.textContent = STYLE;
    const win = el("div", { class: `win${this.entering ? " d-enter" : ""}`, role: "dialog", "aria-modal": "true", "aria-label": "Dispensa" });
    if (this.tab === "bar") win.append(this.header(), el("div", { class: "main single" }, this.barView()));
    else if (this.tab === "wand" && this.wandView) win.append(this.header(), el("div", { class: "main single" }, this.wandView.render()));
    else if (this.tab === "memo" && this.memoView) win.append(this.header(), el("div", { class: "main single" }, this.memoView.render()));
    else win.append(this.header(), el("div", { class: "main" }, this.setColumn(), this.itemColumn()));
    const backdrop = el("div", {
      class: `backdrop${this.entering ? " d-fade" : ""}`,
      onmousedown: (e: Event) => {
        if (e.target === backdrop) this.close();
      },
    });
    backdrop.append(win);
    this.root.replaceChildren(style, backdrop);

    [...this.root.querySelectorAll<HTMLElement>(".col")].forEach((c, i) => (c.scrollTop = scrolls[i] ?? 0));
    if (focusKey) {
      const target = this.root.querySelector<HTMLInputElement | HTMLTextAreaElement>(`[data-key="${focusKey}"]`);
      if (target) {
        target.focus({ preventScroll: true });
        if (caret && caret[0] !== null && "setSelectionRange" in target && target.type !== "checkbox" && target.type !== "color") target.setSelectionRange(caret[0], caret[1]);
      }
    }
    if (this.scrollToEditor) {
      this.scrollToEditor = false;
      requestAnimationFrame(() => this.root?.querySelector(".editor")?.scrollIntoView({ block: "start" }));
    }
  }

  /** Drop the script boxes and panels of QRs that are gone. */
  private forgetGone(): void {
    const ids = new Set(this.state.sets.flatMap((s) => s.items.map((i) => i.id)));
    for (const map of [this.editors, this.panels, this.breakpoints] as Map<string, unknown>[]) for (const id of [...map.keys()]) if (!ids.has(id)) map.delete(id);
  }

  private header(): HTMLElement {
    const size = this.deps.store.size() + (this.deps.wandStore?.size() ?? 0);
    const tabs = segmented(
      "dispensa-tab",
      [
        { value: "qr", label: t("Library", "보관함") },
        { value: "bar", label: "Dock", title: t("Sets and QRs on the Dock", "Dock에 놓을 세트·QR") },
        ...(this.memoView ? [{ value: "memo", label: "📝", title: t("Memo pad", "메모장") }] : []),
        { value: "wand", label: "🌟", title: t("Visualizer settings", "비주얼라이저 설정") },
      ],
      this.tab,
      (v) => {
        this.tab = v as ManagerTab;
        this.render();
      },
      t("Dispensa tabs", "Dispensa 탭"),
    );
    return el(
      "header",
      {},
      el("h2", {}, "Dispensa"),
      el("div", { class: "row tabs" }, tabs),
      el("span", { class: "grow" }),
      el(
        "select",
        {
          class: "lang",
          title: t("Language", "언어"),
          "aria-label": t("Language", "언어"),
          "data-key": "lang",
          onchange: (e: Event) => setLangChoice((e.target as HTMLSelectElement).value as LangChoice),
        },
        ...(["auto", "en", "ko"] as LangChoice[]).map((c) => el("option", { value: c, selected: c === langChoice() }, `🌐 ${LANG_NAMES[c]()}`)),
      ),
      // the 1 MB storage only shows once it starts filling up
      size > 700_000 ? el("span", { class: "warn", title: `${Math.round(size / 1024)} KB / 1000 KB` }, t(`Storage ${Math.round(size / 10_000)}% used`, `저장 공간 ${Math.round(size / 10_000)}% 사용`)) : el("span"),
      this.tab === "qr"
        ? el("button", { title: t("Import SillyTavern QRs (.json, .qr.json) or Marinara QRs (.mqr.json). A file with one QR goes into the open set", "실리태번 QR(.json, .qr.json)·마리나라 QR(.mqr.json) 가져오기. QR 하나짜리 파일은 열린 세트로"), "aria-label": t("Import QRs", "QR 가져오기"), onclick: () => this.importFile() }, icon("download"), el("span", { class: "label" }, t("Import QRs", "QR 가져오기")))
        : el("span"),
      // Fornello (pages with scripts, widgets) has its own settings
      typeof fornello()?.openSettings === "function"
        ? el("button", { title: t("Open Fornello settings (page scripts, JSX components)", "Fornello 설정 열기 (페이지 실행, JSX 컴포넌트)"), "aria-label": t("Fornello settings", "Fornello 설정"), onclick: () => (this.close(), fornello()?.openSettings?.()) }, "🔥", el("span", { class: "label" }, "Fornello"))
        : el("span"),
      el("button", { class: "icon", title: t("Close", "닫기"), "aria-label": t("Close", "닫기"), onclick: () => this.close() }, icon("x")),
    );
  }

  // ── the Dock ──

  /** The Dock tab: what the bar shows, in order, the same in every chat. */
  private barView(): HTMLElement {
    const { store } = this.deps;
    const st = store.value;
    const shown = shownBar(st);
    const list = el("div", { class: "list" });
    shown.forEach(({ entry, set, item }, i) => {
      const handle = el("button", { class: "drag", type: "button", title: t("Drag to reorder (or ↑↓ keys)", "끌어서 순서 바꾸기 (↑↓ 키도 가능)"), "aria-label": t(`Reorder ${item?.label ?? set.name}`, `${item?.label ?? set.name} 순서 바꾸기`), "data-key": `drag-bar-${i}` }, icon("grip"));
      const glyph = (item ? item.icon : set.icon)?.trim();
      const row = el(
        "div",
        { class: "set-row" },
        handle,
        el(
          "button",
          {
            class: "entry",
            title: item ? t("Edit", "편집") : t("Open set", "세트 열기"),
            onclick: () => (item ? this.openItem(set.id, item.id) : ((this.selectedSet = set.id), (this.selectedItem = null), this.open("qr"))),
          },
          glyph ? el("span", {}, glyph) : icon(item ? "play" : "folder"),
          el("span", { class: "grow" }, item ? item.label : set.name),
          el("span", { class: "meta" }, item ? `QR · ${set.name}` : t(`Set · ${set.items.filter((x) => !x.hidden).length}`, `세트 · ${set.items.filter((x) => !x.hidden).length}`)),
        ),
        item
          ? el("span")
          : el(
              "select",
              {
                class: "layout",
                title: t("Folder: one bubble · Row: a bubble per QR, one Dock row", "폴더: 버블 하나 · 한 줄: QR마다 버블, Dock 한 줄"),
                "aria-label": t(`${set.name} layout`, `${set.name} 놓는 모양`),
                "data-key": `bar-layout-${i}`,
                onchange: (e: Event) => store.update((x) => setLayout(x, set.id, (e.target as HTMLSelectElement).value as BarLayout)),
              },
              el("option", { value: "folder", selected: layoutOf(entry, set) === "folder" }, t("Folder", "폴더")),
              el("option", { value: "row", selected: layoutOf(entry, set) === "row" }, t("Row", "한 줄")),
            ),
        el("button", { class: "icon", title: t("Remove from the Dock", "Dock에서 빼기"), "aria-label": t(`Remove ${item?.label ?? set.name}`, `${item?.label ?? set.name} 빼기`), onclick: () => store.update((x) => removeFromBar(x, entry)) }, icon("x")),
      );
      dragHandle(handle, row, ".set-row", (from, to) =>
        store.update((x) => {
          const entries = shownBar(x).map((e) => e.entry);
          moveTo(entries, from, to);
          x.bar = entries;
        }),
      );
      list.append(row);
    });
    if (!shown.length) list.append(el("div", { class: "note" }, t("Empty", "비어 있음")));
    const freeSets = st.sets.filter((x) => !onBar(st, { kind: "set", setId: x.id }));
    const freeQrs = st.sets.flatMap((x) => x.items.filter((i) => !onBar(st, { kind: "qr", setId: x.id, itemId: i.id })).map((i) => ({ set: x, item: i })));
    const addSet = el(
      "select",
      { "aria-label": t("Add a set to the Dock", "Dock에 세트 넣기"), "data-key": "bar-add-set", onchange: (e: Event) => {
        const id = (e.target as HTMLSelectElement).value;
        if (id) store.update((x) => addToBar(x, { kind: "set", setId: id }));
      } },
      el("option", { value: "" }, t("+ Set", "+ 세트")),
      ...freeSets.map((x) => el("option", { value: x.id }, `${x.icon?.trim() ? `${x.icon.trim()} ` : ""}${x.name}`)),
    );
    const addQr = el(
      "select",
      { "aria-label": t("Add a QR to the Dock", "Dock에 QR 넣기"), "data-key": "bar-add-qr", onchange: (e: Event) => {
        const [setId, itemId] = (e.target as HTMLSelectElement).value.split("/");
        if (itemId) store.update((x) => addToBar(x, { kind: "qr", setId, itemId }));
      } },
      el("option", { value: "" }, "+ QR"),
      ...freeQrs.map(({ set, item }) => el("option", { value: `${set.id}/${item.id}` }, `${set.name} › ${item.icon?.trim() ? `${item.icon.trim()} ` : ""}${item.label}`)),
    );
    const make = this.newQrMenu((item) => {
      let target = "";
      store.update((x) => {
        const set = barSet(x);
        set.items.push(item);
        target = set.id;
        addToBar(x, { kind: "qr", setId: set.id, itemId: item.id });
      });
      this.openItem(target, item.id);
    });
    const card = section(
      "Dock",
      t(
        "The same shortcuts in every chat. Separate from where auto-run works\n· + Set: Folder (one bubble) or Row (a bubble per QR, one Dock row)\n· + QR: one QR from the Library\n· New QR: make one right here (saved in the Dock set, can auto-run)",
        "모든 채팅에서 같은 바로가기. 자동 실행 범위와 별개\n· + 세트: 폴더(버블 하나) 또는 한 줄(QR마다 버블, Dock 한 줄)\n· + QR: 보관함의 QR 하나\n· 새 QR: 여기서 바로 만들기('Dock' 세트에 저장, 자동 실행 가능)",
      ),
      [],
      list,
      el("div", { class: "row", style: "margin-top:8px;flex-wrap:wrap" }, addSet, addQr, make),
    );
    card.classList.add("card");
    return el("div", { class: "col wand-settings bar-tab" }, card);
  }

  // ── sets ──

  /**
   * The set column in SillyTavern's lists: every chat, this chat, each
   * character of the chat, then the sets on nowhere here. A set dragged to
   * another list moves there (into "꺼진 세트": off where it was).
   */
  private setColumn(): HTMLElement {
    const { store } = this.deps;
    const st = store.value;
    const chat = this.scope.chatId;
    const lists: { zone: SetZone; title: string; empty: string }[] = [
      { zone: { kind: "global" }, title: t("Global", "전체"), empty: t("Drop sets here to auto-run them in every chat", "모든 채팅에서 자동 실행할 세트를 여기로") },
      ...(chat ? [{ zone: { kind: "chat", chatId: chat } as SetZone, title: t("This chat", "이 채팅"), empty: t("Drop sets here to auto-run them in this chat", "이 채팅에서 자동 실행할 세트를 여기로") }] : []),
      ...this.scope.characterIds.map((c) => ({ zone: { kind: "char", characterId: c } as SetZone, title: t(`Character: ${this.names.get(c) ?? "…"}`, `캐릭터: ${this.names.get(c) ?? "…"}`), empty: t("Drop sets here to auto-run them in chats with this character", "이 캐릭터와의 채팅에서 자동 실행할 세트를 여기로") })),
      { zone: { kind: "all" }, title: t("All sets", "모든 세트"), empty: t("None", "없음") },
    ];
    const zoneOf = new Map<HTMLElement, SetZone>();
    const body = el("div", { class: "zones" });
    lists.forEach(({ zone, title, empty }, z) => {
      const ids = zoneSets(st, zone);
      const box = el("div", { class: "zone", "data-zone": String(z), role: "list", "aria-label": t(`${title} sets`, `${title} 세트`) });
      zoneOf.set(box, zone);
      for (const id of ids) {
        const s = st.sets.find((x) => x.id === id);
        if (!s) continue;
        const handle = el("button", { class: "drag", type: "button", title: t("Drag to reorder or move to another list (↑↓ keys to reorder)", "끌어서 순서 바꾸기·다른 칸으로 옮기기 (↑↓ 키로 순서)"), "aria-label": t(`Move ${s.name}`, `${s.name} 옮기기`), "data-key": `drag-set-${z}-${s.id}` }, icon("grip"));
        const row = el(
          "div",
          { class: "set-row", role: "listitem" },
          handle,
          el(
            "button",
            {
              class: `entry${s.id === this.selectedSet ? " sel" : ""}`,
              onclick: () => {
                this.selectedSet = s.id;
                this.selectedItem = null;
                this.render();
              },
            },
            s.icon?.trim() ? el("span", {}, s.icon.trim()) : icon("folder"),
            el("span", { class: "grow" }, s.name),
            el("span", { class: "meta" }, String(s.items.length)),
          ),
        );
        dragAcross(handle, row, ".set-row", ".zone", ".zones", (target, index) => {
          const to = zoneOf.get(target);
          if (to) store.update((x) => moveSet(x, s.id, zone, to, index));
        });
        box.append(row);
      }
      if (!ids.length) box.append(el("div", { class: "zone-empty" }, empty));
      body.append(el("div", { class: "zone-h" }, title, el("span", { class: "count" }, ids.length ? String(ids.length) : "")), box);
    });
    if (!st.sets.length) body.append(el("div", { class: "note" }, t("No sets yet.", "아직 세트가 없어요.")));
    return el(
      "div",
      { class: "col" },
      el("div", { class: "col-h" }, el("strong", {}, t("Sets", "세트")),
        helpTip(
          t(
            "Groups of QRs. The same as SillyTavern's set lists\n· Global · This chat · Character: where auto-run works\n· All sets: every set made. Drag one into a list above to add it; drag it out of a list to remove it\n· The Dock has its own tab",
            "QR 묶음. 실리태번의 세트 목록과 같음\n· 전체 · 이 채팅 · 캐릭터: 자동 실행이 도는 곳\n· 모든 세트: 만든 세트 전부. 위 칸으로 끌어 넣기, 위 칸에서 끌어 오면 빼기\n· Dock은 Dock 탭에서 따로",
          ),
          t("Sets", "세트"),
        ),),
      el(
        "div",
        { class: "row", style: "margin:8px 0" },
        el(
          "button",
          {
            onclick: () => {
              const s = newSet(t("New set", "새 세트"));
              store.update((x) => x.sets.push(s));
              this.selectedSet = s.id;
              this.selectedItem = null;
            },
          },
          icon("plus"),
          t("New set", "새 세트"),
        ),
      ),
      body,
    );
  }

  private mutateSet(set: QrSet, fn: (s: QrSet, st: QrState) => void): void {
    this.deps.store.update((st) => {
      const target = st.sets.find((x) => x.id === set.id);
      if (target) fn(target, st);
    });
  }

  private setPanel(set: QrSet): HTMLElement[] {
    const mutate = (fn: (s: QrSet, st: QrState) => void) => this.mutateSet(set, fn);
    const top = el(
      "div",
      { class: "row" },
      el("input", {
        type: "text",
        value: set.icon ?? "",
        placeholder: "📁",
        maxlength: "8",
        style: "width:3.2em;text-align:center",
        title: t("Dock bubble icon (one emoji)", "Dock 버블 아이콘 (이모지 하나)"),
        "data-key": "set-icon",
        "aria-label": t("Set icon", "세트 아이콘"),
        oninput: (e: Event) => mutate((s) => (s.icon = (e.target as HTMLInputElement).value.trim() || undefined)),
      }),
      el("input", { type: "text", class: "grow", value: set.name, "data-key": "set-name", "aria-label": t("Set name", "세트 이름"), oninput: (e: Event) => mutate((s) => (s.name = (e.target as HTMLInputElement).value)) }),
      this.exportMenu(set),
      this.setMenu(set),
    );

    // where it is on
    const chat = this.scope.chatId;
    const sw = (on: boolean, change: (v: boolean) => void, label: string, key: string, disabled = false) => {
      const box = toggle(on, change, label, key);
      if (disabled) box.querySelector("input")!.disabled = true;
      return box;
    };
    const other = elsewhere(this.state, set.id, this.scope);
    const otherNote = [other.chats ? t(`${other.chats} other chats`, `다른 채팅 ${other.chats}곳`) : "", other.characters ? t(`${other.characters} other characters`, `다른 캐릭터 ${other.characters}명`) : ""].filter(Boolean).join(", ");
    const places = section(
      t("Auto-run in", "켜는 칸"),
      HELP().places,
      [],
      setting(t("Global", "전체"), sw(set.enabled, (v) => mutate((s) => (s.enabled = v)), t("Global", "전체"), "place-all")),
      setting(
        t("This chat", "이 채팅"),
        sw(isOnForChat(this.state, set.id, chat), (v) => chat && mutate((s, st) => setForChat(st, chat, s.id, v)), t("This chat", "이 채팅"), "place-chat", !chat),
        chat ? undefined : t("Available with a chat open", "채팅을 연 상태에서 선택 가능"),
      ),
      ...this.scope.characterIds.map((c) =>
        setting(t(`Character: ${this.names.get(c) ?? "…"}`, `캐릭터: ${this.names.get(c) ?? "…"}`), sw(isOnForCharacter(this.state, set.id, c), (v) => mutate((s, st) => setForCharacter(st, c, s.id, v)), t(`Character ${this.names.get(c) ?? ""}`, `캐릭터 ${this.names.get(c) ?? ""}`), `place-char-${c}`)),
      ),
      otherNote ? el("div", { class: "note" }, t(`Also on in ${otherNote}`, `${otherNote}에서도 켜짐`)) : null,
    );

    // how it looks
    const looks = section(
      t("Look", "모양"),
      undefined,
      [],
      setting(
        t("Color", "색"),
        set.color
          ? [
              el("input", { type: "color", value: toHex(set.color) ?? "#7c6cf0", "aria-label": t("Set color", "세트 색"), "data-key": "set-color", onchange: (e: Event) => mutate((s) => (s.color = (e.target as HTMLInputElement).value)) }),
              el("button", { type: "button", onclick: () => mutate((s) => (delete s.color, delete s.colorBorderOnly)) }, t("Remove color", "색 없애기")),
            ]
          : el("button", { type: "button", "data-key": "set-color-add", onclick: () => mutate((s) => (s.color = "#7c6cf0")) }, t("Add color", "색 칠하기")),
        t("Color of the Dock bubble", "Dock 버블에 칠할 색"),
      ),
      set.color ? setting(t("Border only", "테두리만 칠하기"), toggle(!!set.colorBorderOnly, (v) => mutate((s) => (v ? (s.colorBorderOnly = true) : delete s.colorBorderOnly)), t("Border only", "테두리만 칠하기"), "set-border")) : null,
    );

    const plain = this.fold(
      `set-plain-${set.id}`,
      t("How text QRs send", "글 QR 보내는 방식"),
      [set.disableSend, set.injectInput].filter(Boolean).length,
      HELP().plain,
      setting(t("Don't send", "보내지 않기"), toggle(!!set.disableSend, (v) => mutate((s) => (s.disableSend = v)), t("Don't send", "보내지 않기"), "set-nosend"), t("Only puts it in the input, without sending", "입력창에 넣기만 하고 보내지 않음")),
      setting(t("Add to input text", "입력창 글에 붙이기"), toggle(!!set.injectInput, (v) => mutate((s) => (s.injectInput = v)), t("Add to input text", "입력창 글에 붙이기"), "set-inject")),
      set.injectInput ? setting(t("Put before", "앞에 붙이기"), toggle(!!set.placeBeforeInput, (v) => mutate((s) => (s.placeBeforeInput = v)), t("Put before", "앞에 붙이기"), "set-before")) : null,
    );
    return [top, el("div", { style: "margin-top:10px" }, places, looks), plain];
  }

  /** The set's ⋯ menu: duplicate, delete. */
  private setMenu(set: QrSet): HTMLElement {
    return this.menu(icon("more"), t("Set menu", "세트 메뉴"), [
      {
        label: t("Duplicate set", "세트 복제"),
        sub: t("Copies its QRs too", "QR까지 그대로 복제"),
        run: () => {
          const copy = duplicateSet(set, this.state);
          this.deps.store.update((st) => st.sets.splice(st.sets.findIndex((s) => s.id === set.id) + 1, 0, copy));
          this.selectedSet = copy.id;
          this.selectedItem = null;
          this.render();
          this.deps.ui.toast(t(`Made "${copy.name}".`, `"${copy.name}"을 만들었어요.`), "success");
        },
      },
      "-",
      {
        label: t("Delete set", "세트 삭제"),
        danger: true,
        run: async () => {
          if (!(await this.deps.ui.popup(t(`Delete the set "${set.name}" and its ${set.items.length} QRs?`, `"${set.name}" 세트와 QR ${set.items.length}개를 삭제할까요?`), { okButton: t("Delete", "삭제"), cancelButton: t("Cancel", "취소") }))) return;
          this.deps.store.update((st) => {
            st.sets = st.sets.filter((x) => x.id !== set.id);
            forgetSet(st, set.id);
          });
          this.selectedSet = this.state.sets[0]?.id ?? null;
          this.render();
        },
      },
    ]);
  }

  // ── QRs ──

  private itemColumn(): HTMLElement {
    const set = this.set;
    const col = el("div", { class: "col" });
    if (!set) {
      col.append(el("div", { class: "empty" }, t("Pick a set or make a new one.", "세트를 고르거나 새로 만드세요.")));
      return col;
    }
    col.append(...this.setPanel(set));
    col.append(
      el(
        "div",
        { class: "row", style: "margin:14px 0 6px" },
        el("div", { class: "section", style: "margin:0" }, t(`${set.items.length} QRs`, `QR ${set.items.length}개`)),
        el("span", { class: "grow" }),
        el("button", { type: "button", title: t("Paste a copied QR (or text)", "복사한 QR(또는 글) 붙여넣기"), onclick: () => void this.paste(set) }, icon("clipboard"), t("Paste", "붙여넣기")),
      ),
    );
    const list = el("div", { class: "list" });
    set.items.forEach((item) => {
      const handle = el("button", { class: "drag", type: "button", title: t("Drag to reorder (or ↑↓ keys)", "끌어서 순서 바꾸기 (↑↓ 키도 가능)"), "aria-label": t(`Reorder ${item.label}`, `${item.label} 순서 바꾸기`), "data-key": `drag-qr-${item.id}` }, icon("grip"));
      const marks = [
        item.auto && Object.values(item.auto).some(Boolean) ? "⚡" : "",
        item.automationId ? "📚" : "",
        item.contextList?.length ? "☰" : "",
        item.hidden ? t("Hidden", "숨김") : "",
      ].filter(Boolean);
      const row = el(
        "div",
        { class: "qrow" },
        handle,
        el(
          "button",
          {
            class: `entry${item.id === this.selectedItem ? " sel" : ""}`,
            onclick: () => {
              this.selectedItem = this.selectedItem === item.id ? null : item.id;
              this.render();
            },
          },
          item.icon?.trim() ? el("span", {}, item.icon.trim()) : item.kind === "ooc" ? icon("message-circle") : icon("play"),
          el("span", { class: "grow" }, item.label || t("(no name)", "(이름 없음)")),
          marks.length ? el("span", { class: "marks", title: t("⚡ auto-run · 📚 lorebook link · ☰ sub menu", "⚡ 자동 실행 · 📚 로어북 연결 · ☰ 하위 메뉴") }, marks.join(" ")) : null,
          item.unsupported?.length ? el("span", { class: "warn", title: item.unsupported.join(", ") }, "⚠") : null,
          item.dialect === "st" ? el("span", { class: "meta", title: item.note ?? "" }, t("SillyTavern style", "실리태번 기준")) : null,
        ),
        el("button", { class: "icon", title: t("Run", "실행"), "aria-label": t(`Run ${item.label}`, `${item.label} 실행`), onclick: () => this.deps.run(set, item) }, icon("play")),
        this.itemMenu(set, item),
      );
      dragHandle(handle, row, ".qrow", (from, to) => this.mutateSet(set, (s) => moveTo(s.items, from, to)));
      list.append(row);
      if (item.id === this.selectedItem) list.append(this.editor(set, item));
    });
    col.append(
      list,
      el(
        "div",
        { class: "row", style: "margin-top:8px" },
        this.newQrMenu((item) => {
          this.mutateSet(set, (s) => s.items.push(item));
          this.selectedItem = item.id;
          this.render();
        }),
      ),
    );
    return col;
  }

  /** A QR's ⋯ menu: copy, cut, duplicate, move or copy to another set, export, delete. */
  private itemMenu(set: QrSet, item: QrItem): HTMLElement {
    return this.menu(icon("more"), t(`${item.label} menu`, `${item.label} 메뉴`), [
      { label: t("Copy", "복사"), sub: t("Paste into another set or SillyTavern", "다른 세트나 실리태번에 붙여넣기 가능"), run: () => void this.copyItem(item, false, set) },
      { label: t("Cut", "잘라내기"), run: () => void this.copyItem(item, true, set) },
      {
        label: t("Duplicate", "복제"),
        sub: t("One more right below", "바로 아래에 하나 더"),
        run: () => {
          const copy = cloneItem(item);
          copy.label = t(`${item.label} copy`, `${item.label} 복사본`);
          this.mutateSet(set, (s) => s.items.splice(s.items.findIndex((i) => i.id === item.id) + 1, 0, copy));
          this.selectedItem = copy.id;
          this.render();
        },
      },
      { label: t("Move to another set…", "다른 세트로 옮기기…"), run: () => void this.transfer(set, item, false) },
      { label: t("Copy to another set…", "다른 세트로 복사…"), run: () => void this.transfer(set, item, true) },
      "-",
      { label: t("Export this QR: for Marinara", "이 QR만 내보내기: 마리나라용"), sub: ".mqr.json", run: () => this.download(exportMarinaraItem(item, this.setName), `${item.label || "qr"}.mqr.json`) },
      { label: t("Export this QR: for SillyTavern", "이 QR만 내보내기: 실리태번용"), sub: t(".json (first message = #0)", ".json (첫 메시지 = 0번)"), run: () => this.download(stExportItem(item, 1, this.deps.registry, this.setName), `${item.label || "qr"}.json`) },
      "-",
      { label: t("Delete QR", "QR 삭제"), danger: true, run: () => this.removeItem(set, item) },
    ]);
  }

  private removeItem(set: QrSet, item: QrItem): void {
    this.mutateSet(set, (s) => (s.items = s.items.filter((i) => i.id !== item.id)));
    if (this.selectedItem === item.id) this.selectedItem = null;
    this.render();
  }

  /** A clipboard copy that both Dispensa and SillyTavern can paste. */
  private async copyItem(item: QrItem, cut: boolean, set: QrSet): Promise<void> {
    const data = { ...stExportItem(item, 1, this.deps.registry, this.setName), dispensa: exportMarinaraItem(item, this.setName) };
    await (this.deps.ui.copy?.(JSON.stringify(data, null, 2)) ?? navigator.clipboard.writeText(JSON.stringify(data)));
    if (cut) this.removeItem(set, item);
    this.deps.ui.toast(cut ? t(`Cut "${item.label}". Click Paste in the set you want.`, `"${item.label}"을 잘라 냈어요. 원하는 세트에서 붙여넣기를 누르세요.`) : t(`Copied "${item.label}".`, `"${item.label}"을 복사했어요.`), "success");
  }

  private async paste(set: QrSet): Promise<void> {
    const text = (await (this.deps.ui.paste?.() ?? navigator.clipboard.readText())).trim();
    if (!text) return;
    let report: ImportReport | null = null;
    try {
      const json = JSON.parse(text);
      const own = json?.dispensa;
      report = own?.format === MQR_ITEM_FORMAT ? importMarinara(own, this.deps.registry) : importAny(json, this.deps.registry);
    } catch {
      // not JSON: SillyTavern makes it a QR that sends this text
    }
    if (report && report.sets.length) {
      this.addReport(report, set);
      this.deps.ui.toast(t(`Pasted ${report.sets.length} sets.`, `세트 ${report.sets.length}개를 붙여 넣었어요.`), "success");
      return;
    }
    const items = report?.items.length ? report.items : [newItem(labelOf(text), text, "marinara")];
    this.addReport(report ?? { sets: [], items, links: [], total: items.length, unsupported: [], parseErrors: [], converted: 0, keptSillyTavern: [] }, set, items);
    this.selectedItem = items[0].id;
    this.render();
    this.deps.ui.toast(t(`Pasted ${items.length} QRs.`, `QR ${items.length}개를 붙여 넣었어요.`), "success");
  }

  /** Imported sets go to the end; single QRs into `set`; sub menu links find their sets by name. */
  private addReport(report: ImportReport, set: QrSet | undefined, items = report.items): void {
    let missing: string[] = [];
    this.deps.store.update((st) => {
      st.sets.push(...report.sets);
      if (items.length) {
        let target = set ? st.sets.find((s) => s.id === set.id) : undefined;
        if (!target) {
          target = newSet(t("Imported QRs", "가져온 QR"));
          st.sets.push(target);
        }
        target.items.push(...items);
        this.selectedSet = target.id;
      }
      missing = resolveLinks(st, report.links);
    });
    if (missing.length) this.deps.ui.toast(t(`Couldn't find the sets used as sub menus: ${missing.join(", ")}`, `하위 메뉴로 쓰던 세트를 찾지 못했어요: ${missing.join(", ")}`), "warning");
  }

  private async transfer(from: QrSet, item: QrItem, copy: boolean): Promise<void> {
    const others = this.state.sets.filter((s) => s.id !== from.id);
    if (!others.length) {
      this.deps.ui.toast(t("No other set to move it to. Make another set first.", "옮길 다른 세트가 없어요. 먼저 세트를 하나 더 만드세요."), "warning");
      return;
    }
    const labels = others.map((s, i) => `${s.name}${others.filter((o) => o.name === s.name).length > 1 ? ` (${i + 1})` : ""}`);
    const [picked] = (await this.deps.ui.pick?.(t(`Pick a set to ${copy ? "copy" : "move"} "${item.label}" to.`, `"${item.label}"을 ${copy ? "복사할" : "옮길"} 세트를 고르세요.`), labels)) ?? [];
    const target = picked ? others[labels.indexOf(picked)] : undefined;
    if (!target) return;
    this.deps.store.update((st) => {
      const to = st.sets.find((s) => s.id === target.id);
      const src = st.sets.find((s) => s.id === from.id);
      if (!to || !src) return;
      if (copy) to.items.push(cloneItem(item));
      else {
        src.items = src.items.filter((i) => i.id !== item.id);
        to.items.push(item);
      }
    });
    if (!copy) {
      this.selectedSet = target.id;
      this.selectedItem = item.id;
    }
    this.render();
    this.deps.ui.toast(t(`${copy ? "Copied" : "Moved"} to the set "${target.name}".`, `"${target.name}" 세트로 ${copy ? "복사했어요" : "옮겼어요"}.`), "success");
  }

  // ── the editor ──

  private mutateItem(set: QrSet, item: QrItem, fn: (i: QrItem) => void, quiet = false): void {
    this.quiet = quiet;
    try {
      this.deps.store.update((st) => {
        const target = st.sets.find((s) => s.id === set.id)?.items.find((i) => i.id === item.id);
        if (target) fn(target);
      });
    } finally {
      this.quiet = false;
    }
  }

  private scriptBox(set: QrSet, item: QrItem): ScriptEditor {
    let editor = this.editors.get(item.id);
    if (!editor) {
      let checkTimer: ReturnType<typeof setTimeout> | null = null;
      editor = new ScriptEditor({
        value: item.script,
        key: "item-script",
        label: t("Script", "스크립트"),
        commands: () => this.deps.registry.list().map((d) => ({ name: d.name, help: d.help })),
        onChange: (value) => {
          this.mutateItem(set, item, (i) => (i.script = value), true);
          if (checkTimer) clearTimeout(checkTimer);
          checkTimer = setTimeout(() => this.recheck(set, item, value), 500);
        },
        onRun: () => void this.panelFor(set, item).start(false),
        onBreakpoints: (lines) => this.breakpoints.set(item.id, lines),
      });
      editor.setBreakpoints(this.breakpoints.get(item.id) ?? new Set());
      this.editors.set(item.id, editor);
    }
    editor.value = item.script;
    return editor;
  }

  /** Unknown commands after typing stops: only the warning lines change. */
  private recheck(set: QrSet, item: QrItem, script: string): void {
    const res = findUnsupported(script, this.deps.registry);
    this.mutateItem(set, item, (i) => (i.unsupported = Array.isArray(res) ? (res.length ? res : undefined) : [t("(syntax error)", "(문법 오류)")]), true);
    const slot = this.root?.querySelector(`[data-checks="${item.id}"]`);
    const fresh = this.state.sets.find((s) => s.id === set.id)?.items.find((i) => i.id === item.id);
    if (slot && fresh) slot.replaceChildren(...this.checks(fresh));
  }

  private checks(item: QrItem): Node[] {
    const out: Node[] = [];
    if (item.unsupported?.length) out.push(el("div", { class: "warn" }, `⚠ ${t("Not supported yet", "아직 지원하지 않는 명령")}: ${item.unsupported.map((c) => (c.startsWith("(") ? c : `/${c}`)).join(", ")}`));
    out.push(this.foreignLine(item.script));
    return out;
  }

  private panelFor(set: QrSet, item: QrItem): RunPanel {
    let panel = this.panels.get(item.id);
    if (!panel) {
      panel = new RunPanel({
        run: (signal, debug) => {
          const fresh = this.state.sets.find((s) => s.id === set.id);
          const now = fresh?.items.find((i) => i.id === item.id);
          if (!fresh || !now) throw new Error(t("Couldn't find the QR.", "QR을 찾지 못했어요."));
          return this.deps.runInEditor(fresh, now, { signal, debug });
        },
        editor: () => this.editors.get(item.id) ?? null,
        breakpoints: () => this.breakpoints.get(item.id) ?? new Set(),
        changed: () => {
          const slot = this.root?.querySelector(`[data-run="${item.id}"]`);
          if (slot) slot.replaceChildren(panel!.render());
        },
      });
      this.panels.set(item.id, panel);
    }
    return panel;
  }

  private editor(set: QrSet, item: QrItem): HTMLElement {
    const { registry } = this.deps;
    const mutate = (fn: (i: QrItem) => void) => this.mutateItem(set, item, fn);
    const box = el("div", { class: "editor" });
    const panel = this.panelFor(set, item);
    box.append(
      this.basics(set, item, mutate),
      item.dialect === "st"
        ? el(
            "div",
            { class: "note-box" },
            el("div", { class: "warn" }, t("Runs SillyTavern style (first message = #0). Why it couldn't be converted to Marinara style automatically:", "실리태번 기준(첫 메시지 = 0번)으로 실행돼요. 마리나라 기준으로 자동 변환하지 못한 이유:")),
            el("ul", {}, ...(item.note ?? t("No reason was recorded", "이유가 기록되지 않았어요")).split("\n").map((r) => el("li", {}, r))),
            el(
              "div",
              { class: "row" },
              el(
                "button",
                {
                  onclick: () => {
                    let ok = false;
                    mutate((i) => (ok = applyConversion(i, registry)));
                    this.deps.ui.toast(ok ? t("Converted to Marinara style.", "마리나라 기준으로 바꿨어요.") : t("Can't convert it automatically yet. Fix the reasons above and try again.", "아직 자동으로 바꿀 수 없어요. 위 이유를 고친 뒤 다시 눌러 주세요."), ok ? "success" : "warning");
                  },
                },
                t("Convert to Marinara style", "마리나라 기준으로 변환"),
              ),
              el(
                "button",
                {
                  title: t("Fixed the script by hand: mark it Marinara style (from #1)", "스크립트를 직접 고쳤으면 마리나라 기준(1번부터)으로 표시"),
                  onclick: () =>
                    mutate((i) => {
                      i.dialect = "marinara";
                      delete i.note;
                    }),
                },
                t("Fixed by hand (mark Marinara style)", "직접 고침 (마리나라 기준으로 표시)"),
              ),
            ),
          )
        : el("span"),
      el(
        "div",
        { class: "field-h" },
        t("Script", "스크립트"),
        helpTip(
          t(
            "STscript. Marinara commands and macros like {{char}} work too\n· Typing / or {{ shows a list\n· Ctrl+Enter runs, Tab indents\n· A clicked line number stops a debug run at that line",
            "STscript. 마리나라 명령과 {{char}} 같은 매크로도 가능\n· / 나 {{ 입력 시 목록\n· Ctrl+Enter 실행, Tab 들여쓰기\n· 줄 번호를 누르면 디버그 때 그 줄에서 멈춤",
          ),
          t("Script", "스크립트"),
        ),
      ),
      this.scriptBox(set, item).element,
      el("div", { "data-checks": item.id }, ...this.checks(item)),
      el("div", { "data-run": item.id }, panel.render()),
      this.commandList(),
      this.submenuPart(set, item),
      this.autoPart(set, item),
      this.footer(set, item, mutate),
    );
    return box;
  }

  /** Icon, name, tooltip. */
  private basics(set: QrSet, item: QrItem, mutate: (fn: (i: QrItem) => void) => void, folderField?: HTMLElement): HTMLElement {
    return el(
      "div",
      { class: "row" },
      el("label", {}, t("Icon", "아이콘"), el("input", { type: "text", value: item.icon ?? "", placeholder: item.kind === "ooc" ? "💬" : "", maxlength: "8", style: "width:3.2em;text-align:center", title: t("Dock bubble icon (empty: first letter of the name)", "Dock 버블 아이콘 (비우면 이름 첫 글자)"), "data-key": "item-icon", oninput: (e: Event) => mutate((i) => (i.icon = (e.target as HTMLInputElement).value.trim() || undefined)) })),
      el("label", { class: "grow" }, t("Name", "이름"), el("input", { type: "text", value: item.label, "data-key": "item-label", oninput: (e: Event) => mutate((i) => (i.label = (e.target as HTMLInputElement).value)) })),
      folderField ?? el("label", { class: "grow" }, el("span", { class: "field-h" }, t("Tooltip", "설명"), helpTip(t("Text shown on hover over the Dock bubble", "Dock 버블에 마우스를 올리면 보이는 글"), t("Tooltip", "설명"))), el("input", { type: "text", value: item.title ?? "", "data-key": "item-title", oninput: (e: Event) => mutate((i) => (i.title = (e.target as HTMLInputElement).value || undefined)) })),
    );
  }

  /** Hide, icon only, delete. */
  private footer(set: QrSet, item: QrItem, mutate: (fn: (i: QrItem) => void) => void, extra: Node[] = []): HTMLElement {
    return el(
      "div",
      {},
      el(
        "div",
        { class: "toggles" },
        ...extra,
        setting(t("Hide from the Dock", "Dock에서 숨기기"), toggle(!!item.hidden, (v) => mutate((i) => (i.hidden = v)), t("Hide from the Dock", "Dock에서 숨기기"), "item-hidden"), t("Hidden in the set's Dock folder. Other QRs and auto-run can still use it", "Dock의 세트 폴더에서 숨김. 다른 QR·자동 실행으로는 사용 가능")),
        item.icon?.trim() ? setting(t("Icon only", "아이콘만 보이기"), toggle(item.showLabel === false, (v) => mutate((i) => (v ? (i.showLabel = false) : delete i.showLabel)), t("Icon only", "아이콘만 보이기"), "item-icon-only"), HELP().showLabel) : null,
      ),
      el("div", { class: "actions" }, el("button", { class: "danger", onclick: () => this.removeItem(set, item) }, icon("trash"), t("Delete QR", "QR 삭제"))),
    );
  }

  /** A folded part that stays open through redraws. */
  private fold(key: string, title: string, count: number, help: string | undefined, ...kids: (Node | null)[]): HTMLElement {
    const d = el("details", { class: "box" }, el("summary", {}, title, count ? el("span", { class: "count" }, `· ${count}`) : null, help ? helpTip(help, title) : null), ...kids);
    d.open = this.openParts.has(key);
    d.addEventListener("toggle", () => (d.open ? this.openParts.add(key) : this.openParts.delete(key)));
    return d;
  }

  private submenuPart(set: QrSet, item: QrItem): HTMLElement {
    const mutate = (fn: (i: QrItem) => void) => this.mutateItem(set, item, fn);
    const links = item.contextList ?? [];
    const rows = el("div", { class: "links" });
    links.forEach((link, index) => {
      const target = this.state.sets.find((s) => s.id === link.setId);
      if (!target) return;
      rows.append(
        el(
          "div",
          { class: "link" },
          el("span", { class: "grow" }, `${target.icon?.trim() ?? "📁"} ${target.name}`, el("span", { class: "note" }, t(` · ${target.items.length} QRs`, ` · QR ${target.items.length}개`))),
          el(
            "label",
            { class: "inline" },
            toggle(!!link.chained, (v) => mutate((i) => i.contextList && (i.contextList[index] = v ? { ...link, chained: true } : { setId: link.setId })), t("Chain", "이어서 실행"), `link-chain-${index}`),
            t("Chain", "이어서 실행"),
          ),
          el(
            "button",
            {
              class: "icon",
              title: t("Remove from the sub menu", "하위 메뉴에서 빼기"),
              "aria-label": t(`Remove ${target.name}`, `${target.name} 빼기`),
              onclick: () =>
                mutate((i) => {
                  i.contextList = (i.contextList ?? []).filter((_, n) => n !== index);
                  if (!i.contextList.length) delete i.contextList;
                }),
            },
            icon("x"),
          ),
        ),
      );
    });
    const choices = this.state.sets.filter((s) => !links.some((l) => l.setId === s.id));
    const add = el(
      "select",
      {
        "aria-label": t("Set to attach as a sub menu", "하위 메뉴로 달 세트"),
        "data-key": "link-add",
        onchange: (e: Event) => {
          const id = (e.target as HTMLSelectElement).value;
          if (id) mutate((i) => (i.contextList = [...(i.contextList ?? []), { setId: id }]));
        },
      },
      el("option", { value: "" }, t("+ Attach a set…", "+ 세트 달기…")),
      ...choices.map((s) => el("option", { value: s.id }, s.id === set.id ? t(`${s.name} (this set: only hidden QRs with an icon)`, `${s.name} (이 세트: 숨긴 QR 중 아이콘 있는 것만)`) : s.name)),
    );
    return this.fold(`submenu-${item.id}`, t("Sub menu", "하위 메뉴"), links.length, HELP().submenu, rows, choices.length ? add : el("div", { class: "note" }, t("No sets to attach", "달 수 있는 세트 없음")));
  }

  private autoPart(set: QrSet, item: QrItem): HTMLElement {
    const mutate = (fn: (i: QrItem) => void) => this.mutateItem(set, item, fn);
    const on = TRIGGERS().filter((tr) => item.auto?.[tr.key]).length + (item.automationId ? 1 : 0);
    return this.fold(
      `auto-${item.id}`,
      t("Auto-run", "자동 실행"),
      on,
      HELP().auto,
      el(
        "div",
        { class: "toggles" },
        ...TRIGGERS().map((tr) =>
          setting(tr.label, toggle(!!item.auto?.[tr.key], (v) => mutate((i) => {
            const auto = { ...i.auto };
            if (v) auto[tr.key] = true;
            else delete auto[tr.key];
            i.auto = Object.keys(auto).length ? auto : undefined;
          }), tr.label, `auto-${tr.key}`), tr.help),
        ),
      ),
      setting(
        t("When a lorebook entry is used", "로어북 항목이 쓰일 때"),
        el("input", { type: "text", value: item.automationId ?? "", placeholder: t("Entry name", "항목 이름"), "data-key": "item-automation", "aria-label": t("Lorebook entry name", "로어북 항목 이름"), oninput: (e: Event) => mutate((i) => ((e.target as HTMLInputElement).value.trim() ? (i.automationId = (e.target as HTMLInputElement).value) : delete i.automationId)) }),
        HELP().automation,
      ),
      setting(t("Block auto-run chains", "자동 실행 연쇄 막기"), toggle(item.preventAuto !== false, (v) => mutate((i) => (v ? delete i.preventAuto : (i.preventAuto = false))), t("Block auto-run chains", "자동 실행 연쇄 막기"), "item-prevent"), HELP().preventAuto),
    );
  }

  /** "새 QR" with the kinds a QR can start as (each is still a plain QR to edit). */
  private newQrMenu(add: (item: QrItem) => void): HTMLElement {
    return this.menu(el("span", { class: "row", style: "gap:5px" }, icon("plus"), el("span", { class: "label" }, t("New QR", "새 QR"))), t("New QR", "새 QR"), [
      { label: t("Command / script", "명령·스크립트"), sub: t("A /command or STscript", "/명령이나 STscript"), run: () => add(newItem(t("New QR", "새 QR"), t("/echo Hello, {{user}}!", "/echo 안녕하세요, {{user}}!"))) },
      { label: "OOC", sub: t("Sends the written text as OOC", "적은 글을 OOC로 보내기"), run: () => add({ ...newItem(t("New OOC", "새 OOC"), "/ooc "), icon: "💬" }) },
      { label: t("Visualizer", "비주얼라이저"), sub: t("Makes an HTML page from a topic", "주제로 HTML 페이지 만들기"), run: () => add({ ...newItem(t("New page", "새 페이지"), t("/visz [[Topic of the page]]", "/visz [[만들 페이지의 주제]]")), icon: "🌟" }) },
    ], true);
  }

  /** A small drop-down menu (details) of actions. */
  private menu(summaryContent: Node | string, label: string, entries: ({ label: string; sub?: string; danger?: boolean; run: () => void | Promise<void> } | "-")[], opensRight = false): HTMLElement {
    const menu = el("details", { class: opensRight ? "menu right" : "menu" });
    const summary = el("summary", { role: "button", "aria-label": label, title: label }, summaryContent);
    const list = el("div", { class: "menu-list" });
    for (const e of entries) {
      if (e === "-") {
        list.append(el("hr"));
        continue;
      }
      list.append(
        el(
          "button",
          {
            class: e.danger ? "danger-item" : "",
            onclick: () => {
              menu.open = false;
              void e.run();
            },
          },
          e.label,
          e.sub ? el("small", {}, e.sub) : null,
        ),
      );
    }
    menu.append(summary, list);
    menu.addEventListener("focusout", (ev) => {
      if (!menu.contains((ev as FocusEvent).relatedTarget as Node)) menu.open = false;
    });
    return menu;
  }

  /** One "내보내기" button with the two file kinds under it. */
  private exportMenu(set: QrSet): HTMLElement {
    return this.menu(el("span", { class: "row", style: "gap:5px" }, icon("upload"), el("span", { class: "label" }, t("Export", "내보내기"))), t("Export set", "세트 내보내기"), [
      { label: t("For Marinara (.mqr.json)", "마리나라용 (.mqr.json)"), sub: t("To keep using it in Dispensa", "Dispensa에서 계속 쓸 때"), run: () => this.exportSet(set, "marinara") },
      { label: t("For SillyTavern (.qr.json)", "실리태번용 (.qr.json)"), sub: t("To use it in SillyTavern (first message = #0)", "실리태번에서 쓸 때 (첫 메시지 = 0번)"), run: () => this.exportSet(set, "st") },
    ]);
  }

  private foreignLine(script: string): HTMLElement {
    const { registry } = this.deps;
    const found = foreignCommands(script, registry);
    if (!found.length) return el("span");
    return el(
      "div",
      { class: "foreign", title: t("Commands that don't work in SillyTavern. Exporting for SillyTavern warns about them", "실리태번에서 동작하지 않는 명령. 실리태번용으로 내보낼 때 알림") },
      t("Not in SillyTavern:", "실리태번에 없는 명령:"),
      ...found.map((name) => el("span", { class: `badge ${registry.get(name)?.origin ?? ""}` }, `/${name}`)),
    );
  }

  /** Searchable list of every command; clicking one puts it into the script at the caret. */
  private commandList(): HTMLElement {
    const all = this.deps.registry.list();
    const q = this.commandQuery.trim().toLowerCase();
    const shown = q ? all.filter((d) => d.name.includes(q) || (d.aliases ?? []).some((a) => a.includes(q)) || d.help.toLowerCase().includes(q)) : all;
    const details = el(
      "details",
      { class: "cmds", ontoggle: () => (this.commandListOpen = details.open) },
      el("summary", {
        // remember right away: the toggle event comes later, and a redraw in between would lose it
        onclick: () => (this.commandListOpen = !details.open),
      }, t(`Commands (${all.length}) · `, `명령 목록 (${all.length}개) · `), ORIGIN_BADGE.st(), " ", ORIGIN_BADGE.dispensa(), " ", ORIGIN_BADGE.marinara()),
      el("input", {
        type: "text",
        placeholder: t("Find a command (name or description)", "명령 찾기 (이름이나 설명)"),
        value: this.commandQuery,
        "data-key": "command-search",
        oninput: (e: Event) => {
          this.commandQuery = (e.target as HTMLInputElement).value;
          this.render();
        },
      }),
      el("div", { class: "cmd-list" }, ...shown.map((d) => this.commandRow(d))),
    );
    details.open = this.commandListOpen;
    return details;
  }

  private commandRow(def: CommandDef): HTMLElement {
    const badge =
      def.origin === "dispensa" ? ORIGIN_BADGE.dispensa()
      : def.origin === "marinara" ? ORIGIN_BADGE.marinara()
      : def.origin === "extension" ? ORIGIN_BADGE.extension(def.from ?? "")
      : ORIGIN_BADGE.st();
    return el(
      "button",
      {
        class: "cmd",
        title: def.aliases?.length ? t(`Aliases: /${def.aliases.join(", /")}`, `다른 이름: /${def.aliases.join(", /")}`) : "",
        onclick: () => {
          const ta = this.root?.querySelector<HTMLTextAreaElement>('textarea[data-key="item-script"]');
          if (!ta) return;
          const start = ta.selectionStart ?? ta.value.length;
          const end = ta.selectionEnd ?? start;
          const before = ta.value.slice(0, start);
          const insert = `${before && !/[\s|]$/.test(before) ? " | " : ""}/${def.name} `;
          ta.value = before + insert + ta.value.slice(end);
          ta.dispatchEvent(new Event("input"));
          const caret = start + insert.length;
          ta.focus();
          ta.setSelectionRange(caret, caret);
        },
      },
      el("code", {}, `/${def.name}`),
      badge,
      el("span", { class: "help" }, def.help),
    );
  }

  private async importFile(): Promise<void> {
    const input = el("input", { type: "file", accept: ".json,application/json", multiple: true });
    input.addEventListener("change", async () => {
      let added = 0;
      let converted = 0;
      const kept: string[] = [];
      const problems: string[] = [];
      for (const file of [...(input.files ?? [])]) {
        try {
          const json = JSON.parse(await file.text());
          const report = importAny(json, this.deps.registry, file.name.replace(/\.(m?qr\.)?json$/i, ""));
          if (!report.sets.length && !report.items.length) {
            problems.push(t(`${file.name}: not a QR file.`, `${file.name}: QR 파일이 아니에요.`));
            continue;
          }
          this.addReport(report, this.set);
          if (report.sets.length) this.selectedSet = report.sets[0].id;
          added += report.total;
          converted += report.converted;
          for (const k of report.keptSillyTavern) kept.push(`${k.label}: ${k.reasons.join(" / ")}`);
          for (const u of report.unsupported) problems.push(`${u.label}: /${u.commands.join(", /")}`);
          for (const p of report.parseErrors) problems.push(t(`${p.label}: syntax error (${p.error})`, `${p.label}: 문법 오류 (${p.error})`));
        } catch (e) {
          problems.push(`${file.name}: ${e instanceof Error ? e.message : String(e)}`);
        }
      }
      this.render();
      const summary = [
        t(`Imported ${added} QRs.`, `QR ${added}개를 가져왔어요.`),
        converted ? t(`${converted} were converted to Marinara style.`, `${converted}개는 마리나라 기준으로 바꿔서 저장했어요.`) : "",
        kept.length ? t(`${kept.length} were kept SillyTavern style.`, `${kept.length}개는 실리태번 기준으로 남겼어요.`) : "",
      ].filter(Boolean).join(" ");
      this.deps.ui.toast(summary, problems.length || kept.length ? "warning" : "success");
      if (problems.length || kept.length) {
        const parts: string[] = [];
        if (kept.length) parts.push(`${t("<b>QRs kept SillyTavern style</b> (their message numbers couldn't be converted automatically)", "<b>실리태번 기준으로 남긴 QR</b> (메시지 번호를 자동으로 바꿀 수 없었어요)")}<br>${kept.map(escapeHtml).join("<br>")}`);
        if (problems.length) parts.push(`${t("<b>QRs with commands not supported yet</b>", "<b>아직 지원하지 않는 명령이 들어 있는 QR</b>")}<br>${problems.map(escapeHtml).join("<br>")}`);
        await this.deps.ui.popup(parts.join("<br><br>"), { wide: true });
      }
      if (this.deps.store.overLimit()) this.deps.ui.toast(t("Storage is almost full. Delete sets you don't use.", "저장 공간이 거의 찼어요. 쓰지 않는 세트를 지워 주세요."), "warning");
    });
    input.click();
  }

  private async exportSet(set: QrSet, format: "st" | "marinara"): Promise<void> {
    if (format === "st") {
      const foreign = nonSillyTavernCommands(set, this.deps.registry);
      if (foreign.length) {
        const list = foreign.map((f) => escapeHtml(`${f.label}: /${f.commands.join(", /")}`)).join("<br>");
        const ok = await this.deps.ui.popup(
          t(
            `<b>Some QRs have commands SillyTavern doesn't have.</b> Those parts won't work in SillyTavern.<br>${list}<br><br>Export as .qr.json anyway? (To keep using them in Marinara, .mqr.json is better)`,
            `<b>실리태번에는 없는 명령이 들어 있는 QR이 있어요.</b> 실리태번에서는 이 부분이 동작하지 않아요.<br>${list}<br><br>그래도 .qr.json으로 내보낼까요? (마리나라에서 계속 쓸 거라면 .mqr.json이 좋아요)`,
          ),
          { okButton: t("Export", "내보내기"), cancelButton: t("Cancel", "취소"), wide: true },
        );
        if (!ok) return;
      }
    }
    const data = format === "st" ? exportSillyTavern(set, this.deps.registry, this.setName) : exportMarinara(set, this.setName);
    this.download(data, `${set.name || "qr-set"}.${format === "st" ? "qr" : "mqr"}.json`);
  }

  private download(data: unknown, name: string): void {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = el("a", { href: url, download: name.replace(/[\\/:*?"<>|]/g, "_") });
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

/** A copy of a QR with a new id. */
function cloneItem(item: QrItem): QrItem {
  const copy = JSON.parse(JSON.stringify(item)) as QrItem;
  copy.id = newId(item.kind === "ooc" ? "ooc" : "qr");
  return copy;
}

/** A copy of a set: new ids, sub menus that pointed at the set itself point at the copy. */
export function duplicateSet(set: QrSet, state: QrState): QrSet {
  const copy = JSON.parse(JSON.stringify(set)) as QrSet;
  copy.id = newId("set");
  const taken = new Set(state.sets.map((s) => s.name));
  let name = t(`${set.name} copy`, `${set.name} 복사본`);
  for (let n = 2; taken.has(name); n++) name = t(`${set.name} copy ${n}`, `${set.name} 복사본 ${n}`);
  copy.name = name;
  for (const item of copy.items) {
    item.id = newId(item.kind === "ooc" ? "ooc" : "qr");
    if (item.contextList) item.contextList = item.contextList.map((l) => (l.setId === set.id ? { ...l, setId: copy.id } : l));
  }
  return copy;
}

/** "#rrggbb" for the color picker (other CSS colors pass through when they already are). */
function toHex(color: string | undefined): string | undefined {
  if (!color) return undefined;
  if (/^#[0-9a-f]{6}$/i.test(color)) return color;
  const m = /rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)/i.exec(color);
  return m ? `#${[m[1], m[2], m[3]].map((n) => Number(n).toString(16).padStart(2, "0")).join("")}` : undefined;
}

function labelOf(text: string): string {
  const one = text.replace(/\s+/g, " ").trim();
  return one.length > 14 ? `${one.slice(0, 13)}…` : one || "QR";
}
function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}
