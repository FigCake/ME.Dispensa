// Toasts, popups, input boxes, button pickers and a loading overlay, drawn in
// a shadow root so Marinara's styles and ours never collide. Colors come
// from Marinara's theme variables, so custom themes apply here too.

import type { FormField, HostUI, PopupOptions, Severity } from "../stscript/host";
import { getComposerText, setComposerTextIfPresent } from "./composer-text";
import { sanitizeHtml } from "./sanitize";
import { CONTROLS, THEME_TOKENS } from "./theme";
import { t } from "../i18n";

const STYLE = `
:host { all: initial; }
${THEME_TOKENS}
* { box-sizing: border-box; }
.layer { position: fixed; inset: 0; z-index: 2147483000; pointer-events: none; font: 14px/1.45 var(--d-font); color: var(--d-text); }
${CONTROLS}
.toasts { position: fixed; top: 16px; right: 16px; display: flex; flex-direction: column; gap: 8px; max-width: min(380px, calc(100vw - 32px)); pointer-events: none; }
.toast { pointer-events: auto; padding: 10px 14px; border-radius: var(--d-radius); border: 1px solid var(--d-line);
  background: var(--d-panel-solid); box-shadow: var(--d-shadow); backdrop-filter: var(--d-shell-blur); -webkit-backdrop-filter: var(--d-shell-blur);
  font-size: 14px; line-height: 1.4; white-space: pre-wrap; word-break: break-word; animation: in .15s ease-out; }
.toast .title { font-weight: 600; margin-bottom: 2px; color: var(--d-title); }
.toast.success { border-color: #3fb97a; } .toast.warning { border-color: #e6a23c; } .toast.error { border-color: var(--d-danger); }
.backdrop { position: fixed; inset: 0; background: rgb(0 0 0 / .5); display: flex; align-items: center; justify-content: center; padding: 16px; pointer-events: auto; animation: fade .12s ease-out; }
.dialog { width: min(440px, 100%); max-height: calc(100vh - 32px); overflow: auto; padding: 18px;
  border-radius: calc(var(--d-radius) + 0.25rem); border: 1px solid var(--d-line); background: var(--d-panel-solid);
  box-shadow: 0 16px 48px rgb(0 0 0 / .45); backdrop-filter: var(--d-shell-blur); -webkit-backdrop-filter: var(--d-shell-blur); }
.dialog.wide { width: min(760px, 100%); } .dialog.large .body { min-height: 40vh; }
.body { font-size: 14px; line-height: 1.5; margin-bottom: 12px; overflow-wrap: anywhere; }
.body img { max-width: 100%; }
textarea, input:not([type=checkbox]):not([type=radio]), select { width: 100%; padding: 8px 10px; resize: vertical; }
.row { display: flex; gap: 8px; justify-content: flex-end; margin-top: 12px; flex-wrap: wrap; }
.row button { padding: 7px 14px; }
.row button.extra { margin-right: auto; }
.choices { display: flex; flex-direction: column; gap: 6px; }
.choices button { text-align: left; width: 100%; justify-content: flex-start; padding: 8px 12px; white-space: normal; }
.pick-list { max-height: 50vh; overflow: auto; margin-top: 8px; }
.fields { display: flex; flex-direction: column; gap: 10px; }
.field { display: flex; flex-direction: column; gap: 4px; font-size: 13px; color: var(--d-muted); }
.field.check { flex-direction: row; align-items: center; gap: 8px; color: var(--d-text); }
.field.check input { width: auto; }
.loader { position: fixed; inset: 0; background: rgb(0 0 0 / .4); display: flex; align-items: center; justify-content: center; flex-direction: column; gap: 12px; pointer-events: auto; }
.spinner { width: 36px; height: 36px; border-radius: 50%; border: 3px solid var(--d-line); border-top-color: var(--d-accent); animation: spin .8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
@keyframes in { from { opacity: 0; transform: translateY(-6px); } }
@keyframes fade { from { opacity: 0; } }
@media (prefers-reduced-motion: reduce) { * { animation: none !important; } }
`;

export class Dialogs implements HostUI {
  private host: HTMLElement | null = null;
  private root: ShadowRoot | null = null;
  private layer: HTMLElement | null = null;
  private toastBox: HTMLElement | null = null;
  private loaderEl: HTMLElement | null = null;

  private ensure(): HTMLElement {
    if (this.layer?.isConnected) return this.layer;
    this.host = document.createElement("div");
    this.host.id = "dispensa-dialogs";
    this.root = this.host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = STYLE;
    this.layer = document.createElement("div");
    this.layer.className = "layer";
    this.toastBox = document.createElement("div");
    this.toastBox.className = "toasts";
    this.layer.append(this.toastBox);
    this.root.append(style, this.layer);
    document.body.append(this.host);
    return this.layer;
  }

  dispose(): void {
    this.host?.remove();
    this.host = this.root = this.layer = this.toastBox = this.loaderEl = null;
  }

  toast(message: string, severity: Severity = "info", options: { title?: string } = {}): void {
    this.ensure();
    const el = document.createElement("div");
    el.className = `toast ${severity}`;
    el.setAttribute("role", severity === "error" ? "alert" : "status");
    if (options.title) {
      const t = document.createElement("div");
      t.className = "title";
      t.textContent = options.title;
      el.append(t);
    }
    el.append(document.createTextNode(message));
    el.addEventListener("click", () => el.remove());
    this.toastBox!.append(el);
    setTimeout(() => el.remove(), severity === "error" ? 8000 : 4000);
  }

  private modal(build: (dialog: HTMLElement, close: () => void) => void, options: PopupOptions = {}, onCancel?: () => void): void {
    const layer = this.ensure();
    const backdrop = document.createElement("div");
    backdrop.className = "backdrop";
    const dialog = document.createElement("div");
    dialog.className = `dialog${options.wide ? " wide" : ""}${options.large ? " large" : ""}`;
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    const close = () => {
      backdrop.remove();
      document.removeEventListener("keydown", onKey, true);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        close();
        onCancel?.();
      }
    };
    document.addEventListener("keydown", onKey, true);
    backdrop.addEventListener("mousedown", (e) => {
      if (e.target === backdrop) {
        close();
        onCancel?.();
      }
    });
    build(dialog, close);
    backdrop.append(dialog);
    layer.append(backdrop);
  }

  private body(html: string): HTMLElement {
    const el = document.createElement("div");
    el.className = "body";
    el.append(sanitizeHtml(html));
    return el;
  }

  private button(label: string, primary: boolean, onClick: () => void): HTMLButtonElement {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = label;
    if (primary) b.className = "primary";
    b.addEventListener("click", onClick);
    return b;
  }

  input(prompt: string, options: PopupOptions = {}): Promise<string | null> {
    return new Promise((resolve) => {
      this.modal(
        (dialog, close) => {
          const multi = options.multiline || (options.rows ?? 1) > 1 || options.large;
          const field = document.createElement(multi ? "textarea" : "input") as HTMLTextAreaElement | HTMLInputElement;
          if (field instanceof HTMLTextAreaElement) field.rows = Math.max(options.rows ?? 4, 2);
          field.value = options.defaultValue ?? "";
          field.placeholder = options.placeholder ?? "";
          const ok = () => {
            close();
            resolve(field.value);
          };
          field.addEventListener("keydown", (e) => {
            const ke = e as KeyboardEvent;
            if (ke.key === "Enter" && (!multi || ke.ctrlKey || ke.metaKey)) {
              ke.preventDefault();
              ok();
            }
          });
          const row = document.createElement("div");
          row.className = "row";
          const extra = options.extra;
          if (extra) {
            const b = this.button(extra.label, false, async () => {
              const text = await extra.fill();
              if (text) {
                const at = field.selectionStart ?? field.value.length;
                const gap = field.value.slice(0, at).trim() ? (multi ? "\n" : " ") : "";
                field.setRangeText(gap + text, at, field.selectionEnd ?? at, "end");
              }
              field.focus();
            });
            if (extra.title) b.title = extra.title;
            b.classList.add("extra");
            row.append(b);
          }
          row.append(
            this.button(options.cancelButton ?? t("Cancel", "취소"), false, () => {
              close();
              resolve(null);
            }),
            this.button(options.okButton ?? t("OK", "확인"), true, ok),
          );
          dialog.append(this.body(prompt), field, row);
          setTimeout(() => field.focus(), 0);
        },
        options,
        () => resolve(null),
      );
    });
  }

  popup(html: string, options: PopupOptions = {}): Promise<boolean> {
    return new Promise((resolve) => {
      this.modal(
        (dialog, close) => {
          const row = document.createElement("div");
          row.className = "row";
          if (options.cancelButton) {
            row.append(
              this.button(options.cancelButton, false, () => {
                close();
                resolve(false);
              }),
            );
          }
          const ok = this.button(options.okButton ?? t("OK", "확인"), true, () => {
            close();
            resolve(true);
          });
          row.append(ok);
          dialog.append(this.body(html), row);
          setTimeout(() => ok.focus(), 0);
        },
        options,
        () => resolve(false),
      );
    });
  }

  /** A blank with suggested answers: click one, or type your own. Null when cancelled. */
  choose(label: string, options: string[]): Promise<string | null> {
    return new Promise((resolve) => {
      this.modal(
        (dialog, close) => {
          const field = document.createElement("input");
          field.placeholder = t("Or type it", "또는 직접 입력");
          field.style.marginTop = "8px";
          const done = (value: string | null) => {
            close();
            resolve(value);
          };
          const list = document.createElement("div");
          list.className = "choices";
          for (const option of options) list.append(this.button(option, false, () => done(option)));
          field.addEventListener("keydown", (e) => {
            if ((e as KeyboardEvent).key === "Enter" && !(e as KeyboardEvent).isComposing) {
              e.preventDefault();
              done(field.value);
            }
          });
          const row = document.createElement("div");
          row.className = "row";
          row.append(this.button(t("Cancel", "취소"), false, () => done(null)), this.button(t("OK", "확인"), true, () => done(field.value)));
          const title = document.createElement("div");
          title.className = "body";
          title.textContent = label;
          dialog.append(title, list, field, row);
          setTimeout(() => field.focus(), 0);
        },
        {},
        () => resolve(null),
      );
    });
  }

  buttons(html: string, labels: string[], options: { multiple?: boolean } = {}): Promise<string> {
    return new Promise((resolve) => {
      this.modal(
        (dialog, close) => {
          const list = document.createElement("div");
          list.className = "choices";
          const picked = new Set<string>();
          for (const label of labels) {
            const b = this.button(label, false, () => {
              if (!options.multiple) {
                close();
                resolve(label);
                return;
              }
              if (picked.has(label)) picked.delete(label);
              else picked.add(label);
              b.className = picked.has(label) ? "primary" : "";
            });
            list.append(b);
          }
          const row = document.createElement("div");
          row.className = "row";
          row.append(
            this.button(t("Cancel", "취소"), false, () => {
              close();
              resolve("");
            }),
          );
          if (options.multiple) {
            row.append(
              this.button(t("OK", "확인"), true, () => {
                close();
                resolve(JSON.stringify([...picked]));
              }),
            );
          }
          if (html.trim()) dialog.append(this.body(html));
          dialog.append(list, row);
        },
        {},
        () => resolve(""),
      );
    });
  }

  form(title: string, fields: FormField[]): Promise<Record<string, string> | null> {
    return new Promise((resolve) => {
      this.modal(
        (dialog, close) => {
          const controls: { name: string; get: () => string }[] = [];
          const body = document.createElement("div");
          body.className = "fields";
          for (const f of fields) {
            const label = document.createElement("label");
            label.className = f.type === "checkbox" ? "field check" : "field";
            const caption = document.createElement("span");
            caption.textContent = f.label ?? f.name;
            let control: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement;
            if (f.type === "textarea") {
              control = document.createElement("textarea");
              control.rows = 3;
            } else if (f.type === "select") {
              control = document.createElement("select");
              for (const o of f.options ?? []) control.append(new Option(o, o));
            } else {
              control = document.createElement("input");
              control.type = f.type === "number" ? "number" : f.type === "checkbox" ? "checkbox" : "text";
            }
            if (control instanceof HTMLInputElement && control.type === "checkbox") control.checked = /^(true|on|1|yes)$/i.test(f.default ?? "");
            else control.value = f.default ?? "";
            if ("placeholder" in control && f.placeholder) control.placeholder = f.placeholder;
            const el = control;
            controls.push({ name: f.name, get: () => (el instanceof HTMLInputElement && el.type === "checkbox" ? String(el.checked) : el.value) });
            if (f.type === "checkbox") label.append(control, caption);
            else label.append(caption, control);
            body.append(label);
          }
          const ok = () => {
            close();
            resolve(Object.fromEntries(controls.map((x) => [x.name, x.get()])));
          };
          body.addEventListener("keydown", (e) => {
            const ke = e as KeyboardEvent;
            if (ke.key === "Enter" && (ke.ctrlKey || ke.metaKey || (ke.target as HTMLElement).tagName === "INPUT")) {
              ke.preventDefault();
              ok();
            }
          });
          const row = document.createElement("div");
          row.className = "row";
          row.append(
            this.button(t("Cancel", "취소"), false, () => {
              close();
              resolve(null);
            }),
            this.button(t("OK", "확인"), true, ok),
          );
          if (title.trim()) dialog.append(this.body(title));
          dialog.append(body, row);
          setTimeout(() => (body.querySelector("input, textarea, select") as HTMLElement | null)?.focus(), 0);
        },
        {},
        () => resolve(null),
      );
    });
  }

  pick(prompt: string, items: string[], options: { multiple?: boolean; placeholder?: string } = {}): Promise<string[]> {
    return new Promise((resolve) => {
      this.modal(
        (dialog, close) => {
          const search = document.createElement("input");
          search.type = "search";
          search.placeholder = options.placeholder ?? t("Search…", "검색…");
          const list = document.createElement("div");
          list.className = "choices pick-list";
          const picked = new Set<string>();
          let active = 0;
          const visible = () => items.filter((i) => i.toLowerCase().includes(search.value.trim().toLowerCase()));
          const draw = () => {
            const shown = visible();
            active = Math.min(active, Math.max(0, shown.length - 1));
            list.replaceChildren(
              ...shown.slice(0, 300).map((item, index) => {
                const b = this.button(item, picked.has(item) || (!options.multiple && index === active), () => choose(item));
                b.setAttribute("role", "option");
                return b;
              }),
            );
            if (!shown.length) {
              const empty = document.createElement("div");
              empty.className = "body";
              empty.textContent = t("No results.", "검색 결과가 없어요.");
              list.append(empty);
            }
          };
          const choose = (item: string) => {
            if (!options.multiple) {
              close();
              resolve([item]);
              return;
            }
            if (picked.has(item)) picked.delete(item);
            else picked.add(item);
            draw();
          };
          search.addEventListener("input", () => {
            active = 0;
            draw();
          });
          search.addEventListener("keydown", (e) => {
            const shown = visible();
            if (e.key === "ArrowDown") active = Math.min(active + 1, shown.length - 1);
            else if (e.key === "ArrowUp") active = Math.max(active - 1, 0);
            else if (e.key === "Enter" && shown[active]) {
              e.preventDefault();
              choose(shown[active]);
              return;
            } else return;
            e.preventDefault();
            draw();
          });
          const row = document.createElement("div");
          row.className = "row";
          row.append(
            this.button(t("Cancel", "취소"), false, () => {
              close();
              resolve([]);
            }),
          );
          if (options.multiple) {
            row.append(
              this.button(t("OK", "확인"), true, () => {
                close();
                resolve(items.filter((i) => picked.has(i)));
              }),
            );
          }
          if (prompt.trim()) dialog.append(this.body(prompt));
          dialog.append(search, list, row);
          draw();
          setTimeout(() => search.focus(), 0);
        },
        {},
        () => resolve([]),
      );
    });
  }

  async notify(title: string, body: string): Promise<void> {
    try {
      if (typeof Notification !== "undefined") {
        if (Notification.permission === "default") await Notification.requestPermission();
        if (Notification.permission === "granted") {
          new Notification(title, { body });
          return;
        }
      }
    } catch {
      // fall back to a toast
    }
    this.toast(body, "info", { title });
  }

  async copy(text: string): Promise<void> {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const area = document.createElement("textarea");
      area.value = text;
      area.style.position = "fixed";
      area.style.opacity = "0";
      document.body.append(area);
      area.select();
      document.execCommand("copy");
      area.remove();
    }
  }

  async paste(): Promise<string> {
    try {
      return await navigator.clipboard.readText();
    } catch {
      return (await this.input(t("Paste the text here (the browser blocked reading the clipboard).", "붙여 넣을 내용을 여기에 붙여 넣어 주세요 (브라우저가 클립보드 읽기를 막았어요)."), { multiline: true, rows: 4 })) ?? "";
    }
  }

  confirm(message: string): Promise<boolean> {
    return this.popup(message, { okButton: t("Yes", "예"), cancelButton: t("No", "아니요") });
  }

  setInput(text: string): void {
    setComposerTextIfPresent(text);
  }

  getInput(): string {
    return getComposerText();
  }

  beep(): void {
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = 880;
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.25);
      osc.connect(gain).connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {
      // audio may be blocked; a missing beep is harmless
    }
  }

  loader(state: "show" | "hide", text = ""): void {
    if (state === "hide") {
      this.loaderEl?.remove();
      this.loaderEl = null;
      return;
    }
    const layer = this.ensure();
    this.loaderEl?.remove();
    const el = document.createElement("div");
    el.className = "loader";
    const spinner = document.createElement("div");
    spinner.className = "spinner";
    el.append(spinner);
    if (text) {
      const label = document.createElement("div");
      label.textContent = text;
      el.append(label);
    }
    layer.append(el);
    this.loaderEl = el;
  }
}
