// Choosing memos from the 메모장 (the 🍰 request box, a [[blank]], /memo).

import type { HostUI } from "../stscript/host";
import { memoLine, shownMemos } from "../memo/model";
import type { MemoStore } from "../memo/store";
import { t } from "../i18n";

/** The chosen memos joined by blank lines; null when none was chosen. */
export async function pickMemos(ui: HostUI, memos: MemoStore, prompt = t("Pick from the Memo pad (one or more)", "메모장에서 고르기 (여러 개 가능)"), query = ""): Promise<string | null> {
  const list = shownMemos(memos.value.memos, query);
  if (!list.length) {
    ui.toast(query ? t(`No memo contains "${query}".`, `"${query}"이(가) 든 메모가 없어요.`) : t("The Memo pad is empty. Select text in the chat and press 📝 to add it.", "메모장이 비어 있어요. 채팅에서 글을 긁어 📝을 누르면 들어가요."), "info", { title: "📝" });
    return null;
  }
  // labels must be unique for the picker
  const labels = list.map((m, i) => `${i + 1}. ${m.pinned ? "⭐ " : ""}${memoLine(m.text)}`);
  const picked = (await ui.pick?.(prompt, labels, { multiple: true, placeholder: t("Search", "찾기") })) ?? [];
  const chosen = picked.map((l) => list[labels.indexOf(l)]).filter(Boolean);
  return chosen.length ? chosen.map((m) => m.text).join("\n\n") : null;
}
