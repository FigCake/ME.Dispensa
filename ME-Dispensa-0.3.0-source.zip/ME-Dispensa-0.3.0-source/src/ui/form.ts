// Settings building blocks shared by the panels: rows (name on the left,
// control on the right), switches, and a small ? that keeps explanations out
// of the way until someone asks. The same file lives in Fornello, so both
// extensions' settings look and behave alike.

import { t } from "../i18n";

export const FORM_CSS = `
.sec { display: flex; flex-direction: column; }
.sec + .sec { margin-top: 14px; }
.sec-h { display: flex; align-items: center; gap: 6px; min-height: 24px; margin: 0 0 2px; }
.sec-h h3 { margin: 0; font-size: 12px; font-weight: 700; letter-spacing: .02em; color: var(--d-muted); }
.sec-h .spacer { flex: 1; }
.set { display: flex; align-items: center; flex-wrap: wrap; gap: 6px 12px; min-height: 42px; padding: 7px 0; border-top: 1px solid var(--d-divider); }
.sec-h + .set, .set:first-child { border-top: 0; }
.set > .lab { flex: 1 1 120px; min-width: 0; display: flex; align-items: center; gap: 6px; color: var(--d-text); font-size: 13px; }
.set > .ctl { margin-left: auto; display: flex; align-items: center; justify-content: flex-end; gap: 6px; max-width: 100%; min-width: 0; }
.set > .ctl > select, .set > .ctl > input:not([type=checkbox]):not([type=radio]) { width: auto; min-width: 130px; max-width: 100%; }
.set.stack > .ctl { flex: 1 1 100%; margin-left: 0; justify-content: flex-start; }
.set.stack > .ctl > * { flex: 1; }
.switch { position: relative; display: inline-flex; width: 36px; height: 20px; flex-shrink: 0; }
.switch input { appearance: none; -webkit-appearance: none; margin: 0; width: 100%; height: 100%; border-radius: 999px; cursor: pointer;
  background: var(--d-field); border: 1px solid var(--d-field-border); transition: background-color .18s ease, border-color .18s ease; }
.switch input:checked { background: var(--d-accent); border-color: var(--d-accent); }
.switch input:focus-visible { outline: none; box-shadow: 0 0 0 2px var(--d-ring); }
.switch input:disabled { opacity: .45; cursor: not-allowed; }
.switch .knob { position: absolute; top: 4px; left: 4px; width: 12px; height: 12px; border-radius: 50%; pointer-events: none;
  background: var(--d-muted); transition: transform .18s ease, background-color .18s ease; }
.switch input:checked + .knob { transform: translateX(16px); background: var(--d-accent-text); }
/* fixed size whatever the surrounding button rules say */
button.help { position: relative; flex-shrink: 0; width: 16px !important; height: 16px !important; min-width: 16px !important; padding: 0 !important; border-radius: 50% !important; display: inline-grid; place-items: center;
  font: 700 10px/1 var(--d-font); color: var(--d-muted); background: transparent; border: 1px solid var(--d-line); cursor: help; }
button.help::after { content: ""; position: absolute; inset: -8px; }
button.help:hover, button.help[aria-expanded="true"] { color: var(--d-hl-text); border-color: var(--d-btn-border-hover); background: var(--d-hl-bg); transform: none; }
.tip { position: fixed; z-index: 2147483000; max-width: min(300px, calc(100vw - 24px)); padding: 9px 12px; white-space: pre-line;
  font: 400 12.5px/1.55 var(--d-font); color: var(--d-text); background: var(--d-panel-solid); border: 1px solid var(--d-line);
  border-radius: var(--d-radius-sm); box-shadow: var(--d-shadow); animation: d-tip-in .12s ease-out; }
@keyframes d-tip-in { from { opacity: 0; transform: translateY(-3px); } }
.seg2 { position: relative; display: inline-flex; align-items: stretch; padding: 3px; border-radius: 999px; background: var(--d-field); border: 1px solid var(--d-field-border); max-width: 100%; }
.seg2 > button { position: relative; z-index: 1; flex: 1 1 auto; width: auto !important; min-width: 0; justify-content: center; border: 0 !important; background: transparent !important; box-shadow: none !important; transform: none !important;
  color: var(--d-muted); font-weight: 600; padding: 5px 14px; border-radius: 999px; transition: color .2s ease; }
.seg2 > button:hover { color: var(--d-text); }
.seg2 > button[aria-pressed="true"] { color: var(--d-btn-text-active); }
.seg2 > button:focus-visible { outline: none; box-shadow: 0 0 0 2px var(--d-ring) !important; }
.seg2 > .pill { position: absolute; z-index: 0; top: 3px; bottom: 3px; left: 0; width: 0; border-radius: 999px; pointer-events: none;
  background: var(--d-btn-bg-active); border: 1px solid var(--d-btn-border-active); box-shadow: 0 1px 4px rgb(0 0 0 / .18);
  transition: transform .26s cubic-bezier(.3, .7, .2, 1), width .26s cubic-bezier(.3, .7, .2, 1); }
.d-enter { animation: d-pop-in .18s ease-out; }
@keyframes d-pop-in { from { opacity: 0; transform: translateY(8px) scale(.985); } }
.d-fade { animation: d-fade-in .18s ease-out; }
@keyframes d-fade-in { from { opacity: 0; } }
@media (prefers-reduced-motion: reduce) { *, *::before, *::after { animation: none !important; transition: none !important; } }
`;

type Kid = Node | string | null | undefined | false;

function h<K extends keyof HTMLElementTagNameMap>(tag: K, cls: string, ...kids: Kid[]): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  for (const k of kids) if (k !== null && k !== undefined && k !== false) node.append(k);
  return node;
}

// ── the ? bubble ──

let open: { btn: HTMLButtonElement; tip: HTMLElement; pinned: boolean } | null = null;
let hoverTimer: ReturnType<typeof setTimeout> | null = null;
let tipCount = 0;

function closeTip(): void {
  if (!open) return;
  open.tip.remove();
  open.btn.setAttribute("aria-expanded", "false");
  open = null;
  document.removeEventListener("pointerdown", onOutside, true);
  window.removeEventListener("keydown", onKey, true);
  window.removeEventListener("scroll", closeTip, true);
  window.removeEventListener("resize", closeTip);
}

function onOutside(e: Event): void {
  if (!open) return;
  const path = e.composedPath();
  if (!path.includes(open.btn) && !path.includes(open.tip)) closeTip();
}

// window capture runs before the panels' own Esc handlers: the first Esc closes only the bubble
function onKey(e: KeyboardEvent): void {
  if (e.key !== "Escape" || !open) return;
  e.preventDefault();
  e.stopPropagation();
  open.btn.focus();
  closeTip();
}

function showTip(btn: HTMLButtonElement, text: string, pinned: boolean): void {
  if (open?.btn === btn) {
    open.pinned ||= pinned;
    return;
  }
  closeTip();
  const tip = h("div", "tip", text);
  tip.id = `d-tip-${++tipCount}`;
  tip.setAttribute("role", "tooltip");
  const root = btn.getRootNode();
  (root instanceof ShadowRoot ? root : document.body).append(tip);
  const r = btn.getBoundingClientRect();
  const w = tip.offsetWidth;
  const ht = tip.offsetHeight;
  const left = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), window.innerWidth - w - 8);
  const below = r.bottom + 8;
  tip.style.left = `${left}px`;
  tip.style.top = `${below + ht > window.innerHeight - 8 ? Math.max(8, r.top - ht - 8) : below}px`;
  btn.setAttribute("aria-expanded", "true");
  btn.setAttribute("aria-describedby", tip.id);
  open = { btn, tip, pinned };
  document.addEventListener("pointerdown", onOutside, true);
  window.addEventListener("keydown", onKey, true);
  window.addEventListener("scroll", closeTip, true);
  window.addEventListener("resize", closeTip);
}

/** A small ? whose text shows in a bubble: on hover with a mouse, or on tap/click (until tapped again or Esc). */
export function helpTip(text: string, about = ""): HTMLButtonElement {
  const btn = h("button", "help", "?");
  btn.type = "button";
  btn.setAttribute("aria-label", about ? t(`Help: ${about}`, `도움말: ${about}`) : t("Help", "도움말"));
  btn.setAttribute("aria-expanded", "false");
  btn.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (open?.btn === btn && open.pinned) closeTip();
    else showTip(btn, text, true);
  });
  btn.addEventListener("pointerenter", (e) => {
    if (e.pointerType !== "mouse") return;
    if (hoverTimer) clearTimeout(hoverTimer);
    hoverTimer = setTimeout(() => showTip(btn, text, false), 280);
  });
  btn.addEventListener("pointerleave", () => {
    if (hoverTimer) clearTimeout(hoverTimer);
    if (open?.btn === btn && !open.pinned) closeTip();
  });
  return btn;
}

// ── rows and switches ──

/** An on/off switch (a checkbox underneath, so keyboard and screen readers work as usual). */
export function toggle(checked: boolean, onChange: (on: boolean) => void, label: string, key?: string): HTMLLabelElement {
  const input = document.createElement("input");
  input.type = "checkbox";
  input.checked = checked;
  input.setAttribute("role", "switch");
  input.setAttribute("aria-label", label);
  if (key) input.dataset.key = key;
  // panels redraw on every change: let the knob finish its slide first
  const calm = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
  input.addEventListener("change", () => {
    const on = input.checked;
    if (calm) onChange(on);
    else setTimeout(() => onChange(on), 170);
  });
  return h("label", "switch", input, h("span", "knob"));
}

/** One setting: its name (and ?) on the left, the control on the right. `stack`: the control gets a line of its own. */
export function setting(label: string | Node, control: Kid | Kid[], help?: string, opts: { stack?: boolean } = {}): HTMLDivElement {
  const name = typeof label === "string" ? label : "";
  return h(
    "div",
    `set${opts.stack ? " stack" : ""}`,
    h("div", "lab", typeof label === "string" ? h("span", "", label) : label, help ? helpTip(help, name) : null),
    h("div", "ctl", ...(Array.isArray(control) ? control : [control])),
  );
}

/** A titled group of settings; `extra` goes at the right end of the title line (buttons). */
export function section(title: string, help: string | undefined, extra: Kid[], ...kids: Kid[]): HTMLElement {
  return h("section", "sec", h("div", "sec-h", h("h3", "", title), help ? helpTip(help, title) : null, h("span", "spacer"), ...extra), ...kids);
}

// ── one bar with a pill that slides to the chosen option ──

/** Per bar: the pill on screen (a bar drawn anew picks up where the old pill is). */
const livePill = new Map<string, HTMLElement>();

export interface SegOption {
  value: string;
  label: string | Node;
  /** Tooltip and accessible name (needed when the label is only an icon). */
  title?: string;
}

/**
 * Tabs or a two-/three-way choice as one bar; the pill slides to the chosen
 * option. `key` names the bar: the panels redraw on every change, and the new
 * bar's pill starts where the old one is, so the slide carries on.
 */
export function segmented(key: string, options: SegOption[], active: string, onChange: (value: string) => void, label: string): HTMLDivElement {
  const bar = h("div", "seg2");
  bar.setAttribute("role", "group");
  bar.setAttribute("aria-label", label);
  const pill = h("span", "pill");
  bar.append(pill);
  const buttons = options.map((o) => {
    const b = h("button", "", o.label);
    b.type = "button";
    b.setAttribute("aria-pressed", String(o.value === active));
    if (o.title) {
      b.title = o.title;
      b.setAttribute("aria-label", o.title);
    }
    b.addEventListener("click", () => {
      if (o.value !== active) onChange(o.value);
    });
    bar.append(b);
    return b;
  });
  const place = (value: string, animate: boolean): boolean => {
    const b = buttons[options.findIndex((o) => o.value === value)];
    if (!b || !b.offsetWidth) return false;
    pill.style.transition = animate ? "" : "none";
    pill.style.width = `${b.offsetWidth}px`;
    pill.style.transform = `translateX(${b.offsetLeft}px)`;
    return true;
  };
  // the old bar is still on screen while the new one is built: start from its pill (mid-slide included)
  const old = livePill.get(key);
  let startAt: { x: number; w: number } | null = null;
  if (old?.isConnected && old.offsetWidth) startAt = { x: new DOMMatrixReadOnly(getComputedStyle(old).transform).m41, w: old.offsetWidth };
  livePill.set(key, pill);
  let tries = 0;
  const start = () => {
    if (!bar.isConnected || !place(active, false)) {
      if (++tries < 30) requestAnimationFrame(start);
      return;
    }
    if (startAt) {
      pill.style.width = `${startAt.w}px`;
      pill.style.transform = `translateX(${startAt.x}px)`;
      void pill.offsetWidth; // apply the starting spot before sliding
      place(active, true);
    }
    watch();
  };
  const watch = () => {
    // fonts and resizes change the widths: follow them without sliding (once the slide is over)
    setTimeout(() => new ResizeObserver(() => place(active, false)).observe(bar), 320);
  };
  requestAnimationFrame(start);
  return bar;
}
