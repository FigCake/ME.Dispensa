// Reordering a list by dragging a row's handle (mouse or finger), or with
// the arrow keys while the handle has focus.

import { t } from "../i18n";

export const DRAG_CSS = `
.drag { flex: none; width: 22px; padding: 4px 0 !important; justify-content: center; cursor: grab; touch-action: none; color: var(--d-muted); background: none !important; border-color: transparent !important; }
.drag:active { cursor: grabbing; }
.drag svg { width: 14px; height: 14px; }
.dragging { position: relative; z-index: 3; opacity: .92; box-shadow: var(--d-shadow); border-radius: var(--d-radius-sm); background: var(--d-panel-solid); pointer-events: none; }
.drop-before { box-shadow: 0 -2px 0 var(--d-accent); }
.drop-after { box-shadow: 0 2px 0 var(--d-accent); }
`;

/**
 * Makes `handle` drag `row` among its sibling rows (those matching `rowSelector`
 * in the same parent). `move(from, to)` gets the indexes among those rows.
 */
export function dragHandle(handle: HTMLElement, row: HTMLElement, rowSelector: string, move: (from: number, to: number) => void): void {
  handle.setAttribute("aria-roledescription", t("Reorder", "순서 바꾸기"));
  handle.addEventListener("keydown", (e) => {
    if (e.key !== "ArrowUp" && e.key !== "ArrowDown") return;
    e.preventDefault();
    const rows = siblings(row, rowSelector);
    const from = rows.indexOf(row);
    const to = from + (e.key === "ArrowUp" ? -1 : 1);
    if (to >= 0 && to < rows.length) move(from, to);
  });
  handle.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    const rows = siblings(row, rowSelector);
    const from = rows.indexOf(row);
    const startY = e.clientY;
    let to = from;
    handle.setPointerCapture(e.pointerId);
    row.classList.add("dragging");
    const clear = () => rows.forEach((r) => r.classList.remove("drop-before", "drop-after"));
    const onMove = (ev: PointerEvent) => {
      row.style.transform = `translateY(${ev.clientY - startY}px)`;
      clear();
      to = from;
      rows.forEach((r, i) => {
        if (r === row) return;
        const rect = r.getBoundingClientRect();
        const mid = rect.top + rect.height / 2;
        if (i < from && ev.clientY < mid) to = Math.min(to, i);
        if (i > from && ev.clientY > mid) to = Math.max(to, i);
      });
      if (to !== from) rows[to].classList.add(to < from ? "drop-before" : "drop-after");
    };
    const onUp = () => {
      handle.removeEventListener("pointermove", onMove);
      handle.removeEventListener("pointerup", onUp);
      handle.removeEventListener("pointercancel", onUp);
      row.classList.remove("dragging");
      row.style.transform = "";
      clear();
      if (to !== from) move(from, to);
    };
    handle.addEventListener("pointermove", onMove);
    handle.addEventListener("pointerup", onUp);
    handle.addEventListener("pointercancel", onUp);
  });
}

function siblings(row: HTMLElement, selector: string): HTMLElement[] {
  return row.parentElement ? ([...row.parentElement.children].filter((c) => c.matches(selector)) as HTMLElement[]) : [row];
}

/** Moves one entry of a list from one index to another. */
export function moveTo<T>(list: T[], from: number, to: number): void {
  if (from === to || from < 0 || to < 0 || from >= list.length || to >= list.length) return;
  const [x] = list.splice(from, 1);
  list.splice(to, 0, x);
}

/**
 * Like dragHandle, across several lists: `row` can be dropped into any list
 * (`zoneSelector`) inside the same `rootSelector`, between its rows. `drop`
 * gets the list and the index among that list's other rows. The arrow keys
 * move it within its own list.
 */
export function dragAcross(handle: HTMLElement, row: HTMLElement, rowSelector: string, zoneSelector: string, rootSelector: string, drop: (zone: HTMLElement, index: number) => void): void {
  handle.setAttribute("aria-roledescription", t("Move", "옮기기"));
  const others = (zone: Element) => [...zone.children].filter((c) => c !== row && c.matches(rowSelector)) as HTMLElement[];
  handle.addEventListener("keydown", (e) => {
    if (e.key !== "ArrowUp" && e.key !== "ArrowDown") return;
    e.preventDefault();
    const zone = row.closest(zoneSelector);
    if (!zone) return;
    const from = siblings(row, rowSelector).indexOf(row);
    const to = from + (e.key === "ArrowUp" ? -1 : 1);
    if (to >= 0 && to <= others(zone).length) drop(zone as HTMLElement, to);
  });
  handle.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    const home = row.closest(zoneSelector) as HTMLElement | null;
    const root = row.closest(rootSelector);
    if (!home || !root) return;
    const zones = [...root.querySelectorAll<HTMLElement>(zoneSelector)];
    const from = siblings(row, rowSelector).indexOf(row);
    const start = { x: e.clientX, y: e.clientY };
    let target: { zone: HTMLElement; index: number } | null = null;
    handle.setPointerCapture(e.pointerId);
    row.classList.add("dragging");
    const clear = () => {
      for (const z of zones) {
        z.classList.remove("drop-into");
        for (const r of z.children) r.classList.remove("drop-before", "drop-after");
      }
    };
    const onMove = (ev: PointerEvent) => {
      row.style.transform = `translate(${ev.clientX - start.x}px, ${ev.clientY - start.y}px)`;
      clear();
      // the list under the pointer (the nearest one when between lists)
      let zone: HTMLElement | null = null;
      let best = Infinity;
      for (const z of zones) {
        const r = z.getBoundingClientRect();
        const d = ev.clientY < r.top ? r.top - ev.clientY : ev.clientY > r.bottom ? ev.clientY - r.bottom : 0;
        if (d < best) [best, zone] = [d, z];
      }
      if (!zone) return (target = null);
      const rows = others(zone);
      const index = rows.filter((r) => {
        const rect = r.getBoundingClientRect();
        return rect.top + rect.height / 2 < ev.clientY;
      }).length;
      target = { zone, index };
      if (zone === home && index === from) return;
      if (rows[index]) rows[index].classList.add("drop-before");
      else if (rows[index - 1]) rows[index - 1].classList.add("drop-after");
      else zone.classList.add("drop-into");
    };
    const onUp = () => {
      handle.removeEventListener("pointermove", onMove);
      handle.removeEventListener("pointerup", onUp);
      handle.removeEventListener("pointercancel", onCancel);
      row.classList.remove("dragging");
      row.style.transform = "";
      clear();
      if (target && !(target.zone === home && target.index === from)) drop(target.zone, target.index);
    };
    const onCancel = () => {
      target = null;
      onUp();
    };
    handle.addEventListener("pointermove", onMove);
    handle.addEventListener("pointerup", onUp);
    handle.addEventListener("pointercancel", onCancel);
  });
}
