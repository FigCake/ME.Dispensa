// The 📝 menu that opens from the Dock: write or pick a memo, send it as
// OOC or put it in the chat input, keep it for later. Built once and updated
// in place, so a draft survives the bar's re-renders.

import { memoLine, memosFrom, shownMemos } from "../memo/model";
import type { MemoStore } from "../memo/store";
import type { Dialogs } from "./dialogs";
import { el, icon } from "./dom";
import { helpTip } from "./form";
import { t } from "../i18n";

export const MEMO_STYLE = `
.memo-pop .head-line { display: flex; align-items: center; gap: 6px; }
.memo-pop .head-line strong { font-size: 13px; color: var(--d-title); white-space: nowrap; }
.memo-pop .head-line > button { width: auto; flex: none; }
.memo-pop .head-line .grow { flex: 1; }
.memo-pop input[type=search] { width: 100%; }

`;

export interface MemoPanelDeps {
  store: MemoStore;
  ui: Dialogs;
  /** Sends text as OOC (the 메모장's way of sending); true once it went out. */
  sendOoc(text: string): Promise<boolean>;
  putInInput(text: string): void;
  close(): void;
  openSettings(): void;
}

/** Search shows up once there are this many memos. */
const SEARCH_FROM = 6;

export class MemoPanel {
  readonly element: HTMLElement;
  private readonly box: HTMLTextAreaElement;
  private readonly search: HTMLInputElement;
  private readonly list: HTMLElement;

  constructor(private readonly deps: MemoPanelDeps) {
    this.box = el("textarea", { part: "memo-input", rows: "2" });
    this.box.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey) && !e.isComposing) {
        e.preventDefault();
        void this.sendTyped();
      }
    });
    this.search = el("input", { type: "search", part: "memo-search", oninput: () => this.renderList() });
    this.list = el("div", { class: "list" });
    this.element = el("div", { class: "pop wand-pop memo-pop", part: "memo-menu", role: "dialog" });
    this.render();
  }

  /** Called when the menu opens. */
  refresh(): void {
    this.render();
    setTimeout(() => this.box.focus(), 0);
  }

  render(): void {
    // here, not in the constructor: they follow the screen language
    this.box.placeholder = t("OOC or memo", "OOC나 메모");
    this.box.setAttribute("aria-label", t("Memo", "메모"));
    this.search.placeholder = t("Search memos", "메모 찾기");
    this.search.setAttribute("aria-label", t("Search memos", "메모 찾기"));
    this.element.setAttribute("aria-label", t("Memo pad", "메모장"));
    const head = el(
      "div",
      { class: "head-line" },
      el("strong", {}, t("📝 Memo pad", "📝 메모장")),
      el("span", { class: "grow" }),
      helpTip(
        t(
          "· 💬 Send OOC: sends the text as OOC (Ctrl+Enter). The way is set in settings\n· To input: puts it in the chat input\n· ☆: saves to the Memo pad\n· Click a memo below to load it into the box above\n· The 📝 button that shows up when you select chat text also saves",
          "· 💬 OOC 보내기: 적은 글을 OOC로 보내기 (Ctrl+Enter). 방식은 설정에서\n· 입력창에 넣기: 채팅 입력창에 넣기\n· ☆: 메모장에 저장\n· 아래 메모를 누르면 위 칸으로 불러오기\n· 채팅에서 글을 긁으면 뜨는 📝 버튼으로도 저장",
        ),
        t("Memo pad", "메모장"),
      ),
      el("button", { class: "mini ghost", title: t("Memo pad and settings", "메모장 관리와 설정"), "aria-label": t("Memo pad settings", "메모장 설정"), onclick: () => this.deps.openSettings() }, icon("settings")),
    );
    const acts = el(
      "div",
      { class: "acts" },
      el("button", { part: "memo-ooc", class: "main", title: t("Send as OOC (Ctrl+Enter)", "OOC로 보내기 (Ctrl+Enter)"), onclick: () => void this.sendTyped() }, el("span", { class: "t" }, t("💬 Send OOC", "💬 OOC 보내기"))),
      el("button", { part: "memo-input-put", title: t("Put in the chat input", "채팅 입력창에 넣기"), onclick: () => this.putTyped() }, t("To input", "입력창에")),
      el("button", { class: "mini ghost", part: "memo-save", title: t("Save to the Memo pad", "메모장에 저장"), "aria-label": t("Save to the Memo pad", "메모장에 저장"), onclick: () => this.saveTyped() }, icon("star")),
    );
    const many = this.deps.store.value.memos.length >= SEARCH_FROM;
    this.renderList();
    this.element.replaceChildren(head, this.box, acts, ...(many ? [this.search] : []), this.list);
  }

  private renderList(): void {
    const all = this.deps.store.value.memos;
    const shown = shownMemos(all, all.length >= SEARCH_FROM ? this.search.value : "");
    this.list.replaceChildren();
    if (!all.length) {
      this.list.append(el("div", { class: "none" }, t("No memos. Type above and press ☆, or select text in the chat and press 📝.", "메모가 없어요. 위에 적고 ☆을 누르거나, 채팅에서 글을 긁어 📝을 누르세요.")));
      return;
    }
    if (!shown.length) this.list.append(el("div", { class: "none" }, t("No matching memos.", "찾는 메모가 없어요.")));
    for (const memo of shown) {
      this.list.append(
        el(
          "div",
          { class: "line" },
          el("button", { part: "memo-item", title: memo.text.slice(0, 400), onclick: () => this.load(memo.text) }, el("span", { class: "t" }, `${memo.pinned ? "⭐ " : ""}${memoLine(memo.text, 120)}`)),
          el("button", { class: "mini", title: t("Send as OOC now", "바로 OOC로 보내기"), "aria-label": t("Send as OOC", "OOC로 보내기"), onclick: () => void this.send(memo.text) }, "💬"),
          el(
            "button",
            {
              class: `mini${memo.pinned ? " on" : ""}`,
              title: memo.pinned ? t("Unpin", "고정 풀기") : t("Pin to top", "위에 고정"),
              "aria-pressed": String(!!memo.pinned),
              onclick: () =>
                this.deps.store.update((s) => {
                  const m = s.memos.find((x) => x.id === memo.id);
                  if (!m) return;
                  if (m.pinned) delete m.pinned;
                  else m.pinned = true;
                }),
            },
            icon("pin"),
          ),
        ),
      );
    }
  }

  private load(text: string): void {
    this.box.value = text;
    this.box.focus();
    this.box.setSelectionRange(text.length, text.length);
  }

  private async send(text: string): Promise<boolean> {
    this.deps.close();
    return this.deps.sendOoc(text);
  }

  private async sendTyped(): Promise<void> {
    const text = this.box.value;
    if (!text.trim()) {
      this.box.focus();
      return;
    }
    // keep the draft when the send was cancelled or failed
    if ((await this.send(text)) && this.box.value === text) this.box.value = "";
  }

  private putTyped(): void {
    const text = this.box.value.trim();
    if (!text) return;
    this.deps.putInInput(text);
    this.box.value = "";
    this.deps.close();
  }

  private saveTyped(): void {
    const text = this.box.value.trim();
    if (!text) return;
    const memos = memosFrom(text);
    this.deps.store.update((s) => s.memos.push(...memos));
    this.box.value = "";
    this.deps.ui.toast(memos.length > 1 ? t(`Saved ${memos.length} memos.`, `메모 ${memos.length}개를 저장했어요.`) : t("Saved to the Memo pad.", "메모장에 저장했어요."), "success", { title: "📝" });
  }
}
