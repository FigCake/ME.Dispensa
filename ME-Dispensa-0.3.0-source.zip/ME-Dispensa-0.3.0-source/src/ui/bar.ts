// The Dock above the chat input. Lives in a shadow root; a theme extension
// (or any theme CSS) can style it through ::part(...) and Marinara's color
// variables.

import type { QrItem, QrSet, QrState } from "../qr/model";
import { type MenuEntry, type MenuGroup, contextMenu, hasMenu } from "../qr/context";
import { t } from "../i18n";
import { layoutOf, shownBar } from "../qr/bar";
import { type ChatScope, NO_CHAT } from "../qr/scopes";
import type { WandItem } from "../wand/model";
import { el, icon } from "./dom";
import { CONTROLS, THEME_TOKENS } from "./theme";
import { FORM_CSS } from "./form";
import { WAND_STYLE, type WandPanel } from "./wand-panel";
import { MEMO_STYLE, type MemoPanel } from "./memo-panel";

export interface BarHandlers {
  run(set: QrSet, item: QrItem): void;
  stop(): void;
  openManager(): void;
  /** Ctrl+click (⌘+click) on a QR: open it in the manager. */
  edit?(set: QrSet, item: QrItem): void;
  /** The 🍰 menu. */
  wand?: { panel: WandPanel };
  /** The 📝 메모장 menu. */
  memo?: { panel: MemoPanel };
}

export interface WandBarView {
  show: boolean;
  /** The wand bubble's icon (an emoji). */
  icon: string;
  busy: string | null;
}

const WAND_MENU = "\u0000wand";
const MEMO_MENU = "\u0000memo";
/** Bubbles per row. */
const PER_ROW = 8;

const EMOJI = /\p{Extended_Pictographic}/u;

function firstGrapheme(text: string): string {
  const t = text.trim();
  if (!t) return "";
  const Seg = (Intl as unknown as { Segmenter?: new (l?: string, o?: { granularity: string }) => { segment(s: string): Iterable<{ segment: string }> } }).Segmenter;
  if (Seg) for (const { segment } of new Seg(undefined, { granularity: "grapheme" }).segment(t)) return segment;
  return Array.from(t)[0] ?? "";
}

/** What a bubble shows: its own icon, else an emoji the name starts with, else the fallback or the first letter. */
export function bubbleGlyph(icon: string | undefined, name: string, fallback?: string): { text: string; emoji: boolean } {
  const own = icon?.trim();
  if (own) return { text: firstGrapheme(own), emoji: EMOJI.test(own) };
  const first = firstGrapheme(name);
  if (first && EMOJI.test(first)) return { text: first, emoji: true };
  if (fallback) return { text: fallback, emoji: EMOJI.test(fallback) };
  return { text: first.toUpperCase() || "?", emoji: false };
}

const STYLE = `
${THEME_TOKENS}
:host { display: block; position: relative; z-index: 5; }
:host([hidden]) { display: none; }
* { box-sizing: border-box; }
.wrap { position: relative; font: 13px/1.25 var(--d-font); color: var(--d-text); }
${CONTROLS}
/* icon bubbles, no bar around them; at most ${PER_ROW} on a row */
:host { --bubble: 30px; --bubble-gap: 5px; }
.bar { display: flex; flex-wrap: wrap; align-items: center; justify-content: center; gap: var(--bubble-gap); padding: 6px 4px 8px; margin: 0 auto;
  max-width: calc(${PER_ROW} * var(--bubble) + ${PER_ROW - 1} * var(--bubble-gap) + 8px); }
/* a set laid out as a line: breaks before and after it (none at the very start or end) */
.bar > .break { flex-basis: 100%; height: 0; }
.bar > .break:first-child, .bar > .break:last-child, .bar > .break + .break { display: none; }
.bubble { position: relative; width: var(--bubble); height: var(--bubble); padding: 0; justify-content: center; border-radius: 50%;
  font-size: 15px; line-height: 1; font-weight: 600;
  background: var(--d-shell-bg); border: var(--d-shell-border); color: var(--d-btn-text);
  box-shadow: var(--d-shell-shadow), 0 2px 8px rgb(0 0 0 / .18); backdrop-filter: var(--d-shell-blur); -webkit-backdrop-filter: var(--d-shell-blur); }
.bubble.busy { box-shadow: 0 0 0 2px var(--d-ring), 0 3px 10px rgb(0 0 0 / .18); }
.bubble:hover { transform: translateY(-2px); border-color: var(--d-btn-border-hover); color: var(--d-btn-text-hover); background: var(--d-shell-bg); }
.bubble:active { transform: scale(.95); }
.bubble[aria-expanded="true"], .bubble.running { border-color: var(--d-btn-border-active); box-shadow: 0 0 0 2px var(--d-ring), 0 3px 10px rgb(0 0 0 / .18); }
.bubble .letter { font-size: 12px; font-weight: 700; }
.bubble svg { width: 14px; height: 14px; }
.bubble .count { position: absolute; top: -4px; right: -4px; min-width: 14px; height: 14px; padding: 0 3px; border-radius: 7px;
  display: flex; align-items: center; justify-content: center; font-size: 9px; font-weight: 700; line-height: 1;
  background: var(--d-accent-fill); color: var(--d-accent-text); }
.bubble .warn-dot { position: absolute; bottom: -3px; right: -3px; font-size: 9px; }
.bubble.stop { background: var(--d-danger); border-color: transparent; color: #fff; }
/* hidden until the pointer is on the ⋯ handle or the bubbles (or a touch there) */
.slide { display: grid; grid-template-rows: 0fr; opacity: 0; transform: translateY(6px); pointer-events: none;
  transition: grid-template-rows 180ms ease, opacity 150ms ease, transform 180ms ease; }
.slide > .clip { min-height: 0; overflow: hidden; }
:host(.revealed) .slide { grid-template-rows: 1fr; opacity: 1; transform: none; pointer-events: auto; }
/* once up, badges and shadows may spill past the row */
:host(.revealed) .slide > .clip { overflow: visible; }
@media (prefers-reduced-motion: reduce) { .slide { transition: none; } }
/* the thin ⋯ strip right above the input box: point at it or touch it to bring the bubbles up */
.handle { position: relative; display: flex; align-items: center; justify-content: center; gap: 3px; height: 14px; margin: 0 0 2px; cursor: pointer; touch-action: manipulation; }
/* a finger-sized target around the small dots */
.handle::before { content: ""; position: absolute; inset: -10px 25%; }
.handle i { width: 4px; height: 4px; border-radius: 50%; background: var(--d-muted); opacity: .7; transition: background-color 150ms ease, opacity 150ms ease; }
.handle:hover i, :host(.revealed) .handle i { background: var(--d-accent); opacity: 1; }
.pop button.running { border-color: var(--d-btn-border-active); color: var(--d-btn-text-active); background: var(--d-btn-bg-active); }
.warn { color: #e6a23c; }
/* a QR with a sub menu: right-click or long-press opens it */
.bubble.has-menu::after { content: ""; position: absolute; bottom: 1px; left: 50%; width: 10px; height: 2px; margin-left: -5px; border-radius: 1px; background: currentColor; opacity: .55; }
.pop .entry-row { display: flex; gap: 4px; }
.pop .entry-row > button:first-child { flex: 1; min-width: 0; }
.pop .entry-row > .more { flex: none; width: auto; padding: 4px 8px; }
.pop .sub { display: flex; flex-direction: column; gap: 4px; margin-left: 12px; padding-left: 8px; border-left: 2px solid var(--d-line); }
.pop .group-h { font-size: 11.5px; color: var(--d-muted); padding: 4px 4px 0; }
.pop { position: absolute; bottom: calc(100% + 4px); min-width: 180px; max-width: min(440px, calc(100vw - 16px)); max-height: 50vh; overflow: auto;
  display: flex; flex-direction: column; gap: 4px; padding: 6px; z-index: 20; font-size: 12.5px; line-height: 1.3;
  background: var(--d-panel-solid); border: 1px solid var(--d-line); border-radius: var(--d-radius); box-shadow: var(--d-shadow);
  backdrop-filter: var(--d-shell-blur); -webkit-backdrop-filter: var(--d-shell-blur); }
.pop button { justify-content: flex-start; width: 100%; min-width: 0; padding: 5px 9px; font-size: 12.5px; }
/* one line per row, cut with … instead of wrapping */
.pop button > .t { flex: 1 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: left; }
.pop .head { font-size: 12px; color: var(--d-muted); padding: 2px 4px 4px; }
svg { width: 15px; height: 15px; flex: none; }
${WAND_STYLE}
${MEMO_STYLE}
${FORM_CSS}`;

/** A set's color: the bubble's fill, or only its outline. */
function paint(b: HTMLElement, set: QrSet): void {
  if (!set.color) return;
  b.style.borderColor = set.color;
  if (!set.colorBorderOnly) b.style.background = `color-mix(in srgb, ${set.color} 38%, var(--d-shell-bg))`;
}

export class QuickBar {
  readonly element: HTMLElement;
  private readonly root: ShadowRoot;
  private readonly container: HTMLElement;
  private openSetId: string | null = null;
  private state: QrState | null = null;
  private running: QrItem | null = null;
  private wand: WandBarView = { show: false, icon: "🍰", busy: null };
  private memo = { show: false, icon: "📝" };
  private overTarget = false;
  private overBar = false;
  private touchOpen = false;
  private hideTimer: ReturnType<typeof setTimeout> | null = null;
  private revealTarget: Element | null = null;
  private scope: ChatScope = NO_CHAT;
  /** An open sub menu (right-click / long-press on a QR). */
  private ctx: { set: QrSet; item: QrItem; key: string } | null = null;
  /** Open nested entries in the sub menu, by path. */
  private readonly expanded = new Set<string>();
  private pressTimer: ReturnType<typeof setTimeout> | null = null;
  private pressed = false;

  constructor(private readonly handlers: BarHandlers) {
    this.element = document.createElement("div");
    this.element.id = "dispensa-bar";
    this.root = this.element.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = STYLE;
    this.container = el("div", { class: "wrap" });
    this.root.append(style, this.container);
    this.root.addEventListener("keydown", (e) => {
      if ((e as KeyboardEvent).key === "Escape" && (this.openSetId || this.ctx)) {
        if (this.ctx) this.ctx = null;
        else this.openSetId = null;
        this.render();
      }
    });
    document.addEventListener("mousedown", this.onOutside, true);
    document.addEventListener("pointerdown", this.onPointerDown, true);
    this.element.addEventListener("pointerenter", (e) => {
      if (e.pointerType !== "touch") this.setHover("bar", true);
    });
    this.element.addEventListener("pointerleave", (e) => {
      if (e.pointerType !== "touch") this.setHover("bar", false);
    });
    this.element.addEventListener("focusin", () => this.updateReveal());
    this.element.addEventListener("focusout", () => setTimeout(() => this.updateReveal(), 0));
  }

  /** An extra area that brings the bar up (besides the bar's own ⋯ handle). */
  bindRevealTarget(target: Element | null): void {
    if (target === this.revealTarget) return;
    this.revealTarget?.removeEventListener("pointerenter", this.onTargetEnter as EventListener);
    this.revealTarget?.removeEventListener("pointerleave", this.onTargetLeave as EventListener);
    this.revealTarget = target;
    this.overTarget = false;
    target?.addEventListener("pointerenter", this.onTargetEnter as EventListener);
    target?.addEventListener("pointerleave", this.onTargetLeave as EventListener);
    this.updateReveal();
  }

  private readonly onTargetEnter = (e: PointerEvent) => {
    if (e.pointerType !== "touch") this.setHover("target", true);
  };

  private readonly onTargetLeave = (e: PointerEvent) => {
    if (e.pointerType !== "touch") this.setHover("target", false);
  };

  /** A touch on the bar (its ⋯ handle) shows it; a touch anywhere else hides it. */
  private readonly onPointerDown = (e: PointerEvent) => {
    if (e.pointerType !== "touch") return;
    const path = e.composedPath();
    const inside = path.includes(this.element) || (!!this.revealTarget && path.includes(this.revealTarget)) || path.some((n) => (n as HTMLElement).id === "dispensa-dialogs");
    if (inside !== this.touchOpen) {
      this.touchOpen = inside;
      this.updateReveal();
    }
  };

  private setHover(which: "target" | "bar", over: boolean): void {
    if (which === "target") this.overTarget = over;
    else this.overBar = over;
    this.updateReveal();
  }

  private get armed(): boolean {
    return !!this.state?.barVisible;
  }

  private get shouldShow(): boolean {
    if (!this.armed) return false;
    return !!this.ctx || this.overTarget || this.overBar || this.touchOpen || this.openSetId !== null || this.running !== null || !!this.wand.busy || this.element.matches(":focus-within");
  }

  private updateReveal(): void {
    if (this.shouldShow) {
      if (this.hideTimer) clearTimeout(this.hideTimer);
      this.hideTimer = null;
      this.element.classList.add("revealed");
      return;
    }
    if (!this.element.classList.contains("revealed") || this.hideTimer) return;
    // a short grace period lets the pointer travel from the input box up to the bar
    this.hideTimer = setTimeout(() => {
      this.hideTimer = null;
      if (!this.shouldShow) this.element.classList.remove("revealed");
    }, 350);
  }

  dispose(): void {
    document.removeEventListener("mousedown", this.onOutside, true);
    document.removeEventListener("pointerdown", this.onPointerDown, true);
    this.bindRevealTarget(null);
    if (this.hideTimer) clearTimeout(this.hideTimer);
    this.element.remove();
  }

  private readonly onOutside = (e: MouseEvent) => {
    const path = e.composedPath();
    // Dialogs opened from a menu (blanks, the OOC picker) keep it open.
    const inDialog = path.some((n) => (n as HTMLElement).id === "dispensa-dialogs");
    if ((this.openSetId || this.ctx) && !path.includes(this.element) && !inDialog) {
      this.openSetId = null;
      this.ctx = null;
      this.render();
    }
  };

  /** The chat on screen: its chat and character sets join the bar. */
  setScope(scope: ChatScope): void {
    this.scope = scope;
    this.render();
  }

  setState(state: QrState): void {
    this.state = state;
    this.render();
  }

  setWand(view: WandBarView): void {
    this.wand = view;
    this.render();
  }

  setMemo(view: { show: boolean; icon: string }): void {
    this.memo = view;
    this.render();
  }

  private memoButton(bar: HTMLElement): void {
    const hooks = this.handlers.memo;
    if (!hooks || !this.memo.show) return;
    const open = this.openSetId === MEMO_MENU;
    const button = this.bubble("memo", bubbleGlyph(this.memo.icon, t("Memo pad", "메모장"), "📝"), t("Memo pad", "메모장"), (e: Event) => {
      this.openSetId = open ? null : MEMO_MENU;
      this.render();
      if (!open) hooks.panel.refresh();
      e.stopPropagation();
    }, { "aria-expanded": String(open) });
    bar.append(button);
    if (open) this.placePop(hooks.panel.element, button);
  }

  /** Close the 🌟 menu (after running something from it). */
  closeMenus(): void {
    if (this.openSetId) {
      this.openSetId = null;
      this.render();
    }
  }

  private wandButtons(bar: HTMLElement): void {
    const hooks = this.handlers.wand;
    if (!hooks || !this.wand.show) return;
    const open = this.openSetId === WAND_MENU;
    const button = this.bubble("wand", bubbleGlyph(this.wand.icon, t("Visualizer", "비주얼라이저"), "🍰"), this.wand.busy ? t(`Making ${this.wand.busy}…`, `${this.wand.busy} 만드는 중…`) : t("Visualizer", "비주얼라이저"), (e: Event) => {
      this.openSetId = open ? null : WAND_MENU;
      this.render();
      if (!open) void hooks.panel.refresh();
      e.stopPropagation();
    }, { "aria-expanded": String(open), class: `wand${this.wand.busy ? " busy" : ""}` });
    bar.append(button);
    if (open) this.placePop(hooks.panel.element, button);
  }

  /** Opens a menu above the bubble, kept inside the bar's width. */
  private placePop(pop: HTMLElement, anchor: HTMLElement): void {
    requestAnimationFrame(() => {
      const barRect = this.container.getBoundingClientRect();
      const rect = anchor.getBoundingClientRect();
      // under the bubble, kept inside the screen (on a phone the menu can be wider than the bar)
      const min = 8 - barRect.left;
      const max = window.innerWidth - 8 - barRect.left - pop.offsetWidth;
      pop.style.left = `${Math.max(min, Math.min(rect.left - barRect.left, max))}px`;
    });
    this.container.append(pop);
  }

  setRunning(item: QrItem | null): void {
    this.running = item;
    this.render();
  }

  private bubble(part: string, glyph: { text: string; emoji: boolean } | SVGSVGElement, title: string, onclick: (e: Event) => void, extra: Record<string, string> = {}): HTMLButtonElement {
    const b = el("button", { class: `bubble${extra.class ? ` ${extra.class}` : ""}`, part, title, "aria-label": title, onclick, ...Object.fromEntries(Object.entries(extra).filter(([k]) => k !== "class")) });
    if (glyph instanceof SVGElement) b.append(glyph);
    else b.append(glyph.emoji ? document.createTextNode(glyph.text) : el("span", { class: "letter" }, glyph.text));
    return b;
  }

  /** Press on a QR: Ctrl/⌘ opens it in the manager, a QR with only a sub menu opens that, else it runs. */
  private press(e: Event, set: QrSet, item: QrItem, key: string): void {
    if (this.pressed) {
      // the long-press already opened the sub menu
      this.pressed = false;
      return;
    }
    const me = e as MouseEvent;
    if ((me.ctrlKey || me.metaKey) && this.handlers.edit) {
      this.openSetId = null;
      this.ctx = null;
      this.handlers.edit(set, item);
      this.render();
      return;
    }
    if (!item.script.trim() && this.state && hasMenu(this.state, item)) {
      this.openMenu(e, set, item, key);
      return;
    }
    this.openSetId = null;
    this.ctx = null;
    this.handlers.run(set, item);
  }

  private openMenu(e: Event, set: QrSet, item: QrItem, key: string): void {
    e.preventDefault();
    e.stopPropagation();
    const same = this.ctx?.key === key;
    this.ctx = same ? null : { set, item, key };
    this.expanded.clear();
    this.render();
  }

  /** Right-click, or a long press on touch, opens a QR's sub menu. */
  private bindMenu(b: HTMLElement, set: QrSet, item: QrItem, key: string): void {
    if (!this.state || !hasMenu(this.state, item)) return;
    b.classList.add("has-menu");
    b.setAttribute("aria-haspopup", "menu");
    b.addEventListener("contextmenu", (e) => this.openMenu(e, set, item, key));
    b.addEventListener("pointerdown", (e) => {
      if (e.pointerType !== "touch") return;
      this.pressed = false;
      if (this.pressTimer) clearTimeout(this.pressTimer);
      this.pressTimer = setTimeout(() => {
        this.pressTimer = null;
        this.pressed = true;
        this.openMenu(e, set, item, key);
      }, 500);
    });
    const cancel = () => {
      if (this.pressTimer) clearTimeout(this.pressTimer);
      this.pressTimer = null;
    };
    b.addEventListener("pointerup", cancel);
    b.addEventListener("pointercancel", cancel);
    b.addEventListener("pointerleave", cancel);
  }

  /** A QR laid out on the bar as a bubble. */
  private itemBubble(set: QrSet, item: QrItem): HTMLButtonElement {
    const key = `${set.id}/${item.id}`;
    const b = this.bubble("item", bubbleGlyph(item.icon, item.label, item.kind === "ooc" ? "💬" : undefined), item.title || item.label, (e) => this.press(e, set, item, key), this.running?.id === item.id ? { class: "running" } : {});
    paint(b, set);
    if (item.unsupported?.length) b.append(el("span", { class: "warn-dot", title: t(`Unsupported commands: ${item.unsupported.join(", ")}`, `지원 안 되는 명령: ${item.unsupported.join(", ")}`) }, "⚠"));
    this.bindMenu(b, set, item, key);
    if (this.ctx?.key === key) this.placePop(this.menuPop(), b);
    return b;
  }

  /** A QR in a folder's menu: icon and name. */
  private itemButton(set: QrSet, item: QrItem, onPress?: (e: Event) => void): HTMLButtonElement {
    const b = el("button", {
      part: "item",
      title: item.title || item.label,
      class: this.running?.id === item.id ? "running" : "",
      onclick: onPress ?? ((e: Event) => this.press(e, set, item, `${set.id}/${item.id}`)),
    });
    const glyph = item.icon?.trim() ? firstGrapheme(item.icon) : "";
    if (glyph) b.append(document.createTextNode(item.showLabel === false ? glyph : `${glyph} `));
    else if (item.kind === "ooc") b.append(icon("message-circle"));
    if (!glyph || item.showLabel !== false) b.append(el("span", { class: "t" }, item.label));
    if (item.unsupported?.length) b.append(el("span", { class: "warn", title: t(`Unsupported commands: ${item.unsupported.join(", ")}`, `지원 안 되는 명령: ${item.unsupported.join(", ")}`) }, " ⚠"));
    return b;
  }

  /** The open sub menu: the linked sets' QRs, nested ones folded under "›". */
  private menuPop(inFolder = false): HTMLElement {
    const ctx = this.ctx!;
    const back = inFolder
      ? el("button", { class: "more", title: t("Back", "뒤로"), "aria-label": t("Back", "뒤로"), style: "width:auto;padding:2px 8px;margin-right:6px", onclick: (e: Event) => { e.stopPropagation(); this.ctx = null; this.render(); } }, "‹")
      : null;
    const pop = el("div", { class: "pop", part: "context-menu", role: "menu" }, el("div", { class: "head" }, back, ctx.item.label));
    if (ctx.item.script.trim()) {
      pop.append(this.itemButton(ctx.set, ctx.item, () => {
        this.ctx = null;
        this.handlers.run(ctx.set, ctx.item);
        this.render();
      }));
    }
    const groups = (list: MenuGroup[], path: string, into: HTMLElement) => {
      for (const g of list) {
        into.append(el("div", { class: "group-h" }, g.set.name));
        g.entries.forEach((entry, i) => into.append(this.menuEntry(entry, `${path}/${g.set.id}:${i}`, groups)));
      }
    };
    groups(contextMenu(this.state!, ctx.set, ctx.item), "", pop);
    return pop;
  }

  private menuEntry(entry: MenuEntry, path: string, groups: (list: MenuGroup[], path: string, into: HTMLElement) => void): HTMLElement {
    const run = (e: Event) => {
      const me = e as MouseEvent;
      if ((me.ctrlKey || me.metaKey) && this.handlers.edit) {
        this.ctx = null;
        this.handlers.edit(entry.set, entry.item);
      } else {
        this.ctx = null;
        this.openSetId = null;
        this.handlers.run(entry.set, entry.run);
      }
      this.render();
    };
    const row = el("div", { class: "entry-row" }, this.itemButton(entry.set, entry.item, run));
    if (!entry.children.length) return row;
    const open = this.expanded.has(path);
    row.append(
      el("button", {
        class: "more",
        title: open ? t("Fold", "접기") : t("Sub menu", "하위 메뉴"),
        "aria-expanded": String(open),
        onclick: (e: Event) => {
          e.stopPropagation();
          if (open) this.expanded.delete(path);
          else this.expanded.add(path);
          this.render();
        },
      }, open ? "‹" : "›"),
    );
    if (!open) return row;
    const sub = el("div", { class: "sub" });
    groups(entry.children, path, sub);
    return el("div", {}, row, sub);
  }

  render(): void {
    const s = this.state;
    this.container.replaceChildren();
    if (!s) return;
    // Off: the switch next to the input box turns it on again
    this.element.hidden = !s.barVisible;
    if (!s.barVisible) {
      this.openSetId = null;
      this.updateReveal();
      return;
    }
    const bar = el("div", { class: "bar", part: "bar", role: "toolbar", "aria-label": "Quick Reply" });
    this.wandButtons(bar);
    this.memoButton(bar);
    // the bar's own list: the same in every chat
    const shown = shownBar(s);
    for (const [n, { entry, set, item: one }] of shown.entries()) {
      if (one) {
        bar.append(this.itemBubble(set, one));
        continue;
      }
      const items = set.items.filter((i) => !i.hidden);
      if (!items.length) continue;
      if (layoutOf(entry, set) === "row") {
        // a line of its own: each QR a bubble
        bar.append(el("div", { class: "break" }));
        for (const item of items) bar.append(this.itemBubble(set, item));
        // the last one keeps ⚙ (and the stop bubble) on its line
        if (n < shown.length - 1) bar.append(el("div", { class: "break" }));
        continue;
      }
      const open = this.openSetId === set.id;
      const folder = this.bubble("folder", bubbleGlyph(set.icon, set.name, "📁"), `${set.name} (${items.length})`, (e: Event) => {
        this.openSetId = open ? null : set.id;
        this.render();
        e.stopPropagation();
      }, { "aria-expanded": String(open) });
      folder.append(el("span", { class: "count" }, String(items.length)));
      paint(folder, set);
      bar.append(folder);
      if (open && this.ctx?.set.id === set.id) {
        // a folder item's sub menu takes the folder's place (Esc or ‹ goes back)
        this.placePop(this.menuPop(true), folder);
      } else if (open) {
        const pop = el("div", { class: "pop", part: "folder-menu", role: "menu" }, el("div", { class: "head" }, set.name));
        for (const item of items) {
          const b = this.itemButton(set, item);
          this.bindMenu(b, set, item, `${set.id}/${item.id}`);
          pop.append(b);
        }
        this.placePop(pop, folder);
      }
    }
    if (this.running) {
      bar.append(this.bubble("stop", icon("square"), t(`Stop "${this.running.label}"`, `"${this.running.label}" 중지`), () => this.handlers.stop(), { class: "stop" }));
    }
    bar.append(this.bubble("manage", icon("settings"), t("Manage QRs (Dispensa)", "QR 관리 (Dispensa)"), () => this.handlers.openManager()));
    this.container.prepend(
      el("div", { class: "slide" }, el("div", { class: "clip" }, bar)),
      el("div", { class: "handle", part: "handle", title: "Dock", "aria-hidden": "true" }, el("i"), el("i"), el("i")),
    );
    this.updateReveal();
  }
}
