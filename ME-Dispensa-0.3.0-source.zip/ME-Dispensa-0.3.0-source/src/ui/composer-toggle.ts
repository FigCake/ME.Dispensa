// The Dock's switch, sitting with Marinara's own buttons on the left of
// the chat input. It borrows their classes so it looks like one of them.

import { icon } from "./dom";
import { t } from "../i18n";

const MARINARA_BUTTON = "flex shrink-0 items-center justify-center rounded-lg transition-all text-foreground/40 hover:bg-foreground/10 hover:text-foreground/70";

export class ComposerToggle {
  readonly element: HTMLButtonElement;

  constructor(onToggle: () => void) {
    this.element = document.createElement("button");
    this.element.type = "button";
    this.element.id = "dispensa-toggle";
    this.element.className = MARINARA_BUTTON;
    // smaller than Marinara's 32px buttons, so it reads as a quiet extra
    this.element.style.cssText = "width:24px;height:24px;padding:0;";
    this.element.append(icon("star"));
    const svg = this.element.querySelector("svg");
    if (svg) svg.style.cssText = "width:14px;height:14px;transition:fill 150ms ease;";
    this.element.addEventListener("click", (e) => {
      e.preventDefault();
      onToggle();
    });
    this.setArmed(false);
  }

  setArmed(armed: boolean): void {
    const label = armed ? t("Turn off Dock (Dispensa)", "Dock 끄기 (Dispensa)") : t("Turn on Dock (Dispensa)", "Dock 켜기 (Dispensa)");
    this.element.title = label;
    this.element.setAttribute("aria-label", label);
    this.element.setAttribute("aria-pressed", String(armed));
    this.element.style.color = armed ? "var(--marinara-chat-chrome-accent, var(--primary))" : "";
    // on: a filled star
    const svg = this.element.querySelector("svg");
    if (svg) svg.style.fill = armed ? "currentColor" : "none";
  }

  /** Keeps the button just before the text box, through React re-renders. */
  mount(box: Element | null): void {
    if (!box) return;
    const textarea = box.querySelector("textarea");
    const parent = textarea?.parentElement;
    if (!textarea || !parent) return;
    if (this.element.parentElement !== parent || this.element.nextElementSibling !== textarea) parent.insertBefore(this.element, textarea);
  }

  dispose(): void {
    this.element.remove();
  }
}
