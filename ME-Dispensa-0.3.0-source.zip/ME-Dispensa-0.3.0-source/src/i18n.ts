// Screen language: English or Korean. "auto" follows Marinara's own language
// (it sets <html lang>). Dispensa and Fornello share the choice: one key in
// this browser's localStorage, and an event so both redraw.

export type Lang = "en" | "ko";
export type LangChoice = "auto" | Lang;

const KEY = "figcake:lang";
export const LANG_EVENT = "figcake:lang";

export function langChoice(): LangChoice {
  try {
    const v = localStorage.getItem(KEY);
    return v === "en" || v === "ko" ? v : "auto";
  } catch {
    return "auto";
  }
}

export function setLangChoice(choice: LangChoice): void {
  try {
    if (choice === "auto") localStorage.removeItem(KEY);
    else localStorage.setItem(KEY, choice);
  } catch {
    // private mode: this page only
  }
  override = choice;
  if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent(LANG_EVENT));
}

let override: LangChoice | null = null;

export function lang(): Lang {
  const choice = override ?? langChoice();
  if (choice !== "auto") return choice;
  const html = typeof document !== "undefined" ? document.documentElement.lang : "";
  return /^ko\b/i.test(html) ? "ko" : "en";
}

/** The text in the screen language: `t("Save", "저장")`. */
export function t(en: string, ko: string): string {
  return lang() === "ko" ? ko : en;
}

/** Calls `fn` when the language changes (the choice, or Marinara's own language under "auto"). */
export function onLangChange(fn: () => void): () => void {
  let last = lang();
  const check = () => {
    const now = lang();
    if (now !== last) {
      last = now;
      fn();
    }
  };
  window.addEventListener(LANG_EVENT, check);
  const watch = new MutationObserver(check);
  watch.observe(document.documentElement, { attributes: true, attributeFilter: ["lang"] });
  return () => {
    window.removeEventListener(LANG_EVENT, check);
    watch.disconnect();
  };
}

export const LANG_NAMES: Record<LangChoice, () => string> = {
  auto: () => t("Same as Marinara", "마리나라 언어 따르기"),
  en: () => "English",
  ko: () => "한국어",
};
