// A small drop-down menu of actions (a <details> with buttons); styled by details.menu in the window's CSS.

import { el } from "./dom";

/** One action, or "-" for a divider. */
export type MenuEntry = { label: string; /** Shown on hover. */ sub?: string; danger?: boolean; run: () => void | Promise<void> } | "-";

/** `summaryContent` is what the closed menu shows; `label` names it for screen readers. */
export function dropMenu(summaryContent: Node | string, label: string, entries: MenuEntry[], opensRight = false): HTMLElement {
  const menu = el("details", { class: opensRight ? "menu right" : "menu" });
  const summary = el("summary", { role: "button", "aria-label": label, title: label }, summaryContent);
  const list = el("div", { class: "menu-list" });
  for (const e of entries) {
    if (e === "-") {
      list.append(el("hr"));
      continue;
    }
    list.append(
      el(
        "button",
        {
          class: e.danger ? "danger-item" : "",
          title: e.sub,
          onclick: () => {
            menu.open = false;
            void e.run();
          },
        },
        e.label,
      ),
    );
  }
  menu.append(summary, list);
  menu.addEventListener("focusout", (ev) => {
    if (!menu.contains((ev as FocusEvent).relatedTarget as Node)) menu.open = false;
  });
  return menu;
}
