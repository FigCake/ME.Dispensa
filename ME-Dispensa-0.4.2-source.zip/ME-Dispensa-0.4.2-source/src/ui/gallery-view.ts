// The Gallery: pages and results kept in this browser, as a list or as cards with a picture of each;
// shown in the visualizer's Dock menu and, larger, as a tab of the Dispensa window.

import type { QrItem, QrSet } from "../qr/model";
import type { QrStore } from "../qr/store";
import { setting, toggle } from "../shared/form";
import { t } from "../shared/i18n";
import type { HostUI } from "../stscript/host";
import type { ArchiveEntry } from "../visz/archive";
import { extractHtmlBlocks } from "../visz/core";
import { filed, folderName, galleryFolders, shownPages } from "../visz/gallery";
import type { GalleryCollect } from "../visz/model";
import type { ViszService, ViszViewer } from "../visz/service";
import type { ViszStore } from "../visz/store";
import { escapeHtml } from "../util";
import { confirmIn } from "./dialogs";
import { pickQr } from "./gallery-actions";
import { pageWithPictures } from "../host/fornello";
import { el, icon } from "./dom";

export const GALLERY_CSS = `
.gal-board { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; padding: 6px 2px; }
.gal-card { position: relative; display: grid; gap: 4px; padding: 6px; border-radius: var(--d-radius-sm); border: 1px solid var(--d-line); background: var(--d-field); text-align: left; cursor: pointer; }
.gal-card.sel { outline: 2px solid var(--d-accent); }
.gal-card .shot { position: relative; aspect-ratio: 16 / 10; overflow: hidden; border-radius: 4px; background: #fff; }
/* a page drawn four times larger, then shrunk: it reads like a screenshot */
.gal-card .shot iframe { position: absolute; left: 0; top: 0; width: 400%; height: 400%; border: 0; transform: scale(.25); transform-origin: 0 0; pointer-events: none; }
.gal-card .shot .txt { position: absolute; inset: 0; padding: 34px 8px 6px; font-size: 10.5px; line-height: 1.4; color: #333; overflow: hidden; white-space: pre-wrap; }
.gal-card .t { font-size: 12.5px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.gal-card .meta { font-size: 11px; color: var(--d-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.gal-card .acts { position: absolute; right: 10px; top: 10px; display: flex; gap: 3px; }
.gal-card .acts button { width: 26px; height: 26px; padding: 0; justify-content: center; }
.gal-card input[type=checkbox] { position: absolute; left: 10px; top: 10px; }
.gallery .gal-tools, .gallery .gal-picked { display: flex; gap: 4px; align-items: center; }
.gallery .gal-tools select, .gallery .gal-picked select { width: auto; max-width: 9.5em; flex: none; padding: 3px 6px; font-size: 12.5px; }
.gallery .gal-tools input[type=search] { flex: 1; min-width: 0; }
.gallery .gal-tools > button, .gallery .gal-picked > button { width: auto; flex: none; padding: 3px 8px; font-size: 12.5px; }
.gallery .gal-picked { padding: 4px; border-radius: var(--d-radius-sm); background: var(--d-hl-bg); }
.gallery .gal-picked .count { flex: 1; font-size: 12px; color: var(--d-hl-text); }
.gallery .line { display: flex; gap: 3px; align-items: center; }
.gallery .line > button:first-child { flex: 1; min-width: 0; }
.gallery .line > button.mini { width: auto; flex: none; padding: 4px 6px; background: transparent; border-color: transparent; color: var(--d-muted); font-weight: 500; }
.gallery .line > button.mini:hover { background: var(--d-hl-bg); color: var(--d-hl-text); }
.gallery .line > button.mini.on { color: var(--d-accent); }
.gallery .meta { flex: none; margin-left: auto; font-size: 11px; color: var(--d-muted); font-weight: 500; }
.gallery .none { color: var(--d-muted); padding: 6px 4px; font-size: 12px; }
.gallery .line input[type=checkbox] { flex: none; margin: 0 2px 0 4px; }
.gallery .gal-tools .grow { flex: 1; }
.gallery .gal-tools > button.main { background: var(--d-accent-fill); color: var(--d-accent-text); border-color: transparent; }
.gallery .gal-settings { display: grid; gap: 2px; padding: 6px 8px; border: 1px solid var(--d-line); border-radius: var(--d-radius-sm); margin: 6px 0; }
.gallery .gal-card .t { color: var(--d-text); }
.gallery.wide .gal-board { grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 14px; }
/* inside the window: never wider than it; on a phone the tools wrap and cards get smaller */
.gallery { min-width: 0; }
.gallery .gal-tools { flex-wrap: wrap; }
.gallery .gal-tools input[type=search] { min-width: 8em; }
@media (max-width: 600px) { .gallery.wide .gal-board { grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 8px; } }
`;

export interface GalleryDeps {
  service: ViszService;
  store: ViszStore;
  qrStore: QrStore;
  viewer: () => ViszViewer | null;
  ui: HostUI;
  close(): void;
  /** Runs a QR for the Gallery only (resolves once its page is saved, or it failed and said so). */
  runInGallery(set: QrSet, item: QrItem): Promise<void>;
  /** Puts a page on a memo board (asks which one). */
  sendToBoard(entry: ArchiveEntry): Promise<void>;
  /** ↗: the Gallery tab of the Dispensa window (the Dock's menu only). */
  openWide?(): void;
}

const VIEW_KEY = "dispensa.galleryView";
const actionIcon = (kind: ArchiveEntry["kind"]) => (kind === "viz" ? "🌟" : "💬");

export class GalleryView {
  readonly element: HTMLElement;
  private archive: ArchiveEntry[] = [];
  /** QRs running for the Gallery now. */
  private making = 0;
  /** The Gallery as a list or as a board of page pictures (remembered in this browser). */
  private view: "list" | "board" = (() => {
    try {
      return localStorage.getItem(VIEW_KEY) === "board" ? "board" : "list";
    } catch {
      return "list";
    }
  })();
  private previews: IntersectionObserver | null = null;
  /** The Gallery folder shown: null for every page, "" for pages in no folder. */
  private folder: string | null = null;
  private query = "";
  private picking = false;
  private readonly picked = new Set<string>();
  private readonly search: HTMLInputElement;
  private settingsOpen = false;

  constructor(
    private readonly deps: GalleryDeps,
    wide = false,
  ) {
    this.element = el("div", { class: `gallery${wide ? " wide" : ""}` });
    // kept across redraws, so typing in it keeps the caret
    this.search = el("input", {
      type: "search",
      part: "visz-archive-search",
      oninput: () => {
        this.query = this.search.value;
        this.renderPages();
      },
    }) as HTMLInputElement;
  }

  /** Reads the Gallery and draws it. */
  load(): Promise<void> {
    return this.loadArchive();
  }

  private async loadArchive(): Promise<void> {
    try {
      this.archive = await this.deps.service.archive.list();
    } catch (e) {
      this.archive = [];
      this.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("Gallery", "갤러리") });
    }
    this.renderArchive();
  }

  /** "▶ With a QR": runs one for the Gallery only, while the chat goes on. */
  private makeButton(): HTMLElement {
    return el(
      "button",
      {
        part: "visz-archive-run",
        class: "main",
        disabled: this.deps.store.value.settings.collect === "chat",
        "aria-label": this.making ? t(`With a QR (${this.making} running)`, `QR로 만들기 (${this.making}개 진행 중)`) : t("With a QR", "QR로 만들기"),
        title: this.deps.store.value.settings.collect === "chat" ? t("The Gallery's settings keep only results from the chat (⚙)", "갤러리 설정이 채팅 결과만 저장하게 되어 있어요 (⚙)") : t("Run a QR for the Gallery only, even while the chat replies", "갤러리에만 남게 QR 실행. 채팅이 답하는 중에도 됨"),
        onclick: () => void this.makeWithQr(),
      },
      icon("play"),
      this.making ? ` ${this.making}` : null,
    );
  }

  private async makeWithQr(): Promise<void> {
    const chosen = await pickQr(this.deps.ui, this.deps.qrStore.value, t("A QR to run for the Gallery", "갤러리용으로 실행할 QR"));
    if (!chosen) return;
    this.making++;
    this.renderArchive();
    try {
      await this.deps.runInGallery(chosen.set, chosen.item);
    } finally {
      this.making--;
      await this.loadArchive();
    }
  }

  private renderArchive(): void {
    this.element.replaceChildren();
    if (!this.archive.length) {
      this.element.append(el("div", { class: "gal-tools" }, el("span", { class: "grow" }), this.makeButton(), this.settingsButton()), ...this.settingsBox(), el("div", { class: "none" }, t("Empty", "비어 있음")));
      return;
    }
    const folders = galleryFolders(this.archive);
    if (this.folder && !folders.includes(this.folder)) this.folder = null;
    this.search.placeholder = t("Search pages", "페이지 찾기");
    this.search.setAttribute("aria-label", t("Search pages", "페이지 찾기"));
    const folderSelect = this.folderSelect(folders);
    const tools = el(
      "div",
      { class: "gal-tools" },
      folderSelect,
      this.search,
      this.folder ? el("button", { class: "ghost", title: t("Rename or undo this folder", "이 폴더 이름 바꾸기·풀기"), "aria-label": t("Folder", "폴더"), onclick: () => void this.folderMenu() }, "⋯") : null,
      el(
        "button",
        {
          class: "ghost",
          part: "visz-archive-view",
          title: this.view === "board" ? t("Show as a list", "목록으로 보기") : t("Show as a board of pictures", "그림 보드로 보기"),
          "aria-label": this.view === "board" ? t("List", "목록") : t("Board", "보드"),
          onclick: () => {
            this.view = this.view === "board" ? "list" : "board";
            try {
              localStorage.setItem(VIEW_KEY, this.view);
            } catch {
              // remembered only while the page is open
            }
            this.renderArchive();
          },
        },
        icon(this.view === "board" ? "list" : "layout-grid"),
      ),
      el(
        "button",
        {
          class: this.picking ? "on" : "ghost",
          part: "visz-archive-pick",
          "aria-pressed": String(this.picking),
          title: this.picking ? t("Stop picking", "고르기 그만") : t("Pick pages to move or delete", "옮기거나 지울 페이지 고르기"),
          "aria-label": this.picking ? t("Stop picking", "고르기 그만") : t("Pick", "고르기"),
          onclick: () => {
            this.picking = !this.picking;
            this.picked.clear();
            this.renderArchive();
          },
        },
        icon(this.picking ? "x" : "square-check-big"),
      ),
      this.makeButton(),
      this.settingsButton(),
      this.deps.openWide ? el("button", { class: "ghost", part: "visz-archive-wide", title: t("Open the Gallery large", "갤러리 크게 열기"), "aria-label": t("Open the Gallery large", "갤러리 크게 열기"), onclick: () => this.deps.openWide?.() }, icon("maximize-2")) : null,
    );
    const pages = el("div", { class: "pages" });
    this.element.append(tools, ...this.settingsBox(), ...(this.picking ? [this.pickedBar(folders)] : []), pages);
    this.renderPages(pages);
  }

  private folderSelect(folders: string[]): HTMLSelectElement {
    const select = el("select", { part: "visz-archive-folder", "aria-label": t("Folder", "폴더"), title: t("Folder", "폴더") }) as HTMLSelectElement;
    const option = (value: string, label: string) => el("option", { value }, label);
    select.append(option("*", t("All pages", "모든 페이지")), option("", t("Not in a folder", "폴더 없음")), ...folders.map((f) => option(f, `📁 ${f}`)));
    select.value = this.folder === null ? "*" : this.folder;
    select.addEventListener("change", () => {
      this.folder = select.value === "*" ? null : select.value;
      this.picked.clear();
      this.renderArchive();
    });
    return select;
  }

  /** Actions on the picked pages. */
  private pickedBar(folders: string[]): HTMLElement {
    const shown = shownPages(this.archive, this.folder, this.query);
    const move = el("select", { "aria-label": t("Move to", "옮길 곳"), title: t("Move to", "옮길 곳") }) as HTMLSelectElement;
    move.append(
      el("option", { value: "*" }, t("Move to…", "옮기기…")),
      ...folders.map((f) => el("option", { value: f }, `📁 ${f}`)),
      el("option", { value: "+" }, t("➕ New folder…", "➕ 새 폴더…")),
      el("option", { value: "" }, t("Out of the folder", "폴더에서 빼기")),
    );
    move.addEventListener("change", () => {
      const to = move.value;
      move.value = "*";
      if (to !== "*") void this.movePicked(to);
    });
    const all = shown.length > 0 && shown.every((e) => this.picked.has(e.id));
    return el(
      "div",
      { class: "gal-picked" },
      el("span", { class: "count" }, t(`${this.picked.size} picked`, `${this.picked.size}개 고름`)),
      el(
        "button",
        {
          class: "ghost",
          onclick: () => {
            for (const e of shown) {
              if (all) this.picked.delete(e.id);
              else this.picked.add(e.id);
            }
            this.renderArchive();
          },
        },
        all ? t("None", "모두 풀기") : t("All", "모두 고르기"),
      ),
      move,
      el("button", { class: "ghost", title: t("Delete the picked pages", "고른 페이지 지우기"), "aria-label": t("Delete", "지우기"), onclick: () => void this.deletePicked() }, icon("trash")),
    );
  }

  private renderPages(box = this.element.querySelector<HTMLElement>(".pages")): void {
    if (!box) return;
    box.replaceChildren();
    const shown = shownPages(this.archive, this.folder, this.query);
    if (!shown.length) box.append(el("div", { class: "none" }, t("No pages here.", "여기에는 페이지가 없어요.")));
    if (this.view === "board" && shown.length) return this.renderBoard(box, shown);
    for (const entry of shown) {
      const when = new Date(entry.createdAt);
      const date = `${when.getMonth() + 1}/${when.getDate()} ${String(when.getHours()).padStart(2, "0")}:${String(when.getMinutes()).padStart(2, "0")}`;
      const pick = this.picking ? (el("input", { type: "checkbox", "aria-label": entry.title }) as HTMLInputElement) : null;
      if (pick) {
        pick.checked = this.picked.has(entry.id);
        pick.addEventListener("click", () => this.togglePick(entry.id));
      }
      box.append(
        el(
          "div",
          { class: "line" },
          pick,
          el(
            "button",
            {
              part: "visz-archive-item",
              title: [entry.character, entry.chatName].filter(Boolean).join(" · "),
              onclick: () => {
                if (this.picking) return this.togglePick(entry.id);
                this.deps.viewer()?.show({ title: entry.title, kind: entry.kind, text: entry.text, archivedId: entry.id });
                this.deps.close();
              },
            },
            el("span", { class: "t" }, `${actionIcon(entry.kind)} ${entry.title}`),
            el("span", { class: "meta" }, this.folder === null && entry.folder ? `📁 ${entry.folder} · ${date}` : date),
          ),
          this.picking ? null : el("button", { class: "mini", title: t("Put on a memo board", "메모 보드에 붙이기"), "aria-label": t("Put on a memo board", "메모 보드에 붙이기"), onclick: () => void this.deps.sendToBoard(entry) }, icon("pin")),
          this.picking
            ? null
            : el(
                "button",
                {
                  class: "mini",
                  title: t("Delete", "지우기"),
                  "aria-label": t("Delete", "지우기"),
                  onclick: async () => {
                    if (!(await confirmIn(this.deps.ui, t(`Delete "${entry.title}" from the Gallery?`, `갤러리에서 "${entry.title}"을(를) 지울까요?`)))) return;
                    await this.deps.service.archive.remove(entry.id);
                    await this.loadArchive();
                  },
                },
                icon("trash"),
              ),
        ),
      );
    }
  }

  /** The pages as cards with a small picture of each; pictures are drawn when they scroll into view. */
  private renderBoard(box: HTMLElement, shown: ArchiveEntry[]): void {
    this.previews?.disconnect();
    this.previews = typeof IntersectionObserver === "function"
      ? new IntersectionObserver((seen) => {
          for (const s of seen) {
            if (!s.isIntersecting) continue;
            const frame = s.target as HTMLIFrameElement;
            void pageWithPictures(frame.dataset.code ?? "").then((code) => (frame.srcdoc = code));
            this.previews?.unobserve(frame);
          }
        })
      : null;
    const grid = el("div", { class: "gal-board" });
    for (const entry of shown) {
      const code = extractHtmlBlocks(entry.text)[0]?.code;
      // no scripts and no same origin: a picture of the page, nothing more
      const frame = code ? (el("iframe", { sandbox: "", loading: "lazy", "aria-hidden": "true", tabindex: "-1" }) as HTMLIFrameElement) : null;
      if (frame && code) {
        // a picture runs no scripts anyway: leaving them out keeps the console quiet and the drawing light;
        // without "outside resources" it loads nothing from the web either
        const shown = code.replace(/<script\b[\s\S]*?<\/script\s*>/gi, "");
        frame.dataset.code = this.deps.store.value.settings.allowExternal ? shown : `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data: blob:; font-src data:; style-src 'unsafe-inline'">${shown}`;
        if (this.previews) this.previews.observe(frame);
        else void pageWithPictures(frame.dataset.code).then((c) => (frame.srcdoc = c));
      }
      const pick = this.picking ? (el("input", { type: "checkbox", "aria-label": entry.title }) as HTMLInputElement) : null;
      if (pick) pick.checked = this.picked.has(entry.id);
      const card = el(
        "div",
        {
          class: `gal-card${this.picked.has(entry.id) ? " sel" : ""}`,
          part: "visz-archive-card",
          role: "button",
          tabindex: "0",
          title: [entry.character, entry.chatName].filter(Boolean).join(" · "),
          onclick: (e: Event) => {
            if ((e.target as HTMLElement).closest(".acts")) return;
            if (this.picking) return this.togglePick(entry.id);
            this.deps.viewer()?.show({ title: entry.title, kind: entry.kind, text: entry.text, archivedId: entry.id });
            this.deps.close();
          },
          onkeydown: (e: Event) => {
            if ((e as KeyboardEvent).key === "Enter" && e.target === card) (card as HTMLElement).click();
          },
        },
        el("div", { class: "shot" }, frame ?? el("div", { class: "txt" }, entry.text.slice(0, 400))),
        el("span", { class: "t" }, `${actionIcon(entry.kind)} ${entry.title}`),
        el("span", { class: "meta" }, [entry.character, dateOf(entry.createdAt)].filter(Boolean).join(" · ")),
        pick,
        this.picking
          ? null
          : el(
              "div",
              { class: "acts" },
              el("button", { class: "mini", title: t("Put on a memo board", "메모 보드에 붙이기"), "aria-label": t("Put on a memo board", "메모 보드에 붙이기"), onclick: () => void this.deps.sendToBoard(entry) }, icon("pin")),
              el(
                "button",
                {
                  class: "mini",
                  title: t("Delete", "지우기"),
                  "aria-label": t("Delete", "지우기"),
                  onclick: async () => {
                    if (!(await confirmIn(this.deps.ui, t(`Delete "${entry.title}" from the Gallery?`, `갤러리에서 "${entry.title}"을(를) 지울까요?`)))) return;
                    await this.deps.service.archive.remove(entry.id);
                    await this.loadArchive();
                  },
                },
                icon("trash"),
              ),
            ),
      );
      grid.append(card);
    }
    box.append(grid);
  }

  private togglePick(id: string): void {
    if (this.picked.has(id)) this.picked.delete(id);
    else this.picked.add(id);
    this.renderArchive();
  }

  private async askFolderName(prompt: string, value = ""): Promise<string | null> {
    const name = folderName((await this.deps.ui.input(prompt, { defaultValue: value, okButton: t("OK", "확인") })) ?? "");
    return name || null;
  }

  private async movePicked(to: string): Promise<void> {
    const pages = this.archive.filter((e) => this.picked.has(e.id));
    if (!pages.length) return;
    const folder = to === "+" ? await this.askFolderName(t("Name of the new folder", "새 폴더 이름")) : to;
    if (folder === null) return;
    for (const e of pages) await this.deps.service.archive.put(filed(e, folder));
    this.picked.clear();
    this.picking = false;
    this.deps.ui.toast(folder ? t(`Moved ${pages.length} pages to ${folder}.`, `페이지 ${pages.length}개를 ${folder} 폴더로 옮겼어요.`) : t(`Took ${pages.length} pages out of their folder.`, `페이지 ${pages.length}개를 폴더에서 뺐어요.`), "success", { title: t("Gallery", "갤러리") });
    await this.loadArchive();
  }

  private async deletePicked(): Promise<void> {
    const pages = this.archive.filter((e) => this.picked.has(e.id));
    if (!pages.length) return;
    if (!(await confirmIn(this.deps.ui, t(`Delete ${pages.length} pages from the Gallery?`, `갤러리에서 페이지 ${pages.length}개를 지울까요?`)))) return;
    for (const e of pages) await this.deps.service.archive.remove(e.id);
    this.picked.clear();
    this.picking = false;
    await this.loadArchive();
  }

  /** Rename the open folder, or undo it (its pages stay, in no folder). */
  private async folderMenu(): Promise<void> {
    const folder = this.folder;
    if (!folder) return;
    const rename = t("Rename", "이름 바꾸기");
    const undo = t("Undo the folder (pages stay)", "폴더 풀기 (페이지는 남아요)");
    const choice = await this.deps.ui.buttons(`📁 ${escapeHtml(folder)}`, [rename, undo]);
    const pages = this.archive.filter((e) => e.folder === folder);
    if (choice === rename) {
      const name = await this.askFolderName(t("New name of the folder", "폴더의 새 이름"), folder);
      if (!name || name === folder) return;
      for (const e of pages) await this.deps.service.archive.put(filed(e, name));
      this.folder = name;
    } else if (choice === undo) {
      for (const e of pages) await this.deps.service.archive.put(filed(e, ""));
      this.folder = null;
    } else return;
    await this.loadArchive();
  }

  private settingsButton(): HTMLElement {
    return el("button", { class: this.settingsOpen ? "on" : "ghost", part: "visz-archive-settings", "aria-pressed": String(this.settingsOpen), title: t("What the Gallery keeps", "갤러리에 저장할 결과"), "aria-label": t("Gallery settings", "갤러리 설정"), onclick: () => ((this.settingsOpen = !this.settingsOpen), this.renderArchive()) }, icon("settings"));
  }

  /** ⚙: what is kept by itself (the AI for Gallery runs is with Dispensa's AI, in the window's header). */
  private settingsBox(): HTMLElement[] {
    if (!this.settingsOpen) return [];
    const s = this.deps.store.value.settings;
    const set = (fn: (x: typeof s) => void) => {
      this.deps.store.update((st) => fn(st.settings));
      this.renderArchive();
    };
    const choose = (key: string, entries: [string, string][], value: string, label: string, onChange: (v: string) => void) => {
      const box = el("select", { "data-key": key, "aria-label": label }, ...entries.map(([v, text]) => el("option", { value: v, ...(v === value ? { selected: true } : {}) }, text))) as HTMLSelectElement;
      box.value = value;
      box.addEventListener("change", () => onChange(box.value));
      return box;
    };
    return [
      el(
        "div",
        { class: "gal-settings" },
        setting(
          t("Keep", "저장할 결과"),
          choose("gallery-collect", [["chat", t("Results in the open chat", "현재 채팅 메시지만")], ["gallery", t("Gallery runs (▶)", "갤러리 실행만")], ["all", t("Both", "전체")]], s.collect, t("Keep", "저장할 결과"), (v) => set((x) => (x.collect = v as GalleryCollect))),
          t("From the open chat (not /guided), from ▶, or both. ☆ in the viewer always saves", "현재 채팅(/guided 제외) · ▶ 실행 · 둘 다. 보기 창 ☆는 늘 저장"),
        ),
        setting(t("HTML pages only", "HTML만 저장"), toggle(s.htmlOnly, (v) => set((x) => (x.htmlOnly = v)), t("HTML pages only", "HTML만 저장"), "gallery-html-only")),
      ),
    ];
  }
}

function dateOf(at: number): string {
  const when = new Date(at);
  return `${when.getMonth() + 1}/${when.getDate()} ${String(when.getHours()).padStart(2, "0")}:${String(when.getMinutes()).padStart(2, "0")}`;
}
