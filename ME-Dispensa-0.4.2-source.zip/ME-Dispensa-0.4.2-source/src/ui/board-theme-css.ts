// How each memo board theme looks. The board tab gets `bt bt-<id>` and the chips as variables;
// --on-<chip> is the ink that reads on that chip. Fonts fall back to ones every device has.

export const BOARD_THEME_CSS = `
.bt { --bt-sans: 'IBM Plex Sans KR', 'Pretendard', 'Noto Sans KR', system-ui, sans-serif; --bt-serif: 'Hahmlet', 'Gowun Batang', 'Nanum Myeongjo', 'Noto Serif KR', serif;
  --bt-italic: 'Instrument Serif', 'Cormorant Garamond', 'Fraunces', Georgia, serif; --bt-mono: 'IBM Plex Mono', ui-monospace, Menlo, monospace;
  --bt-display: 'Anton', 'Black Han Sans', Impact, sans-serif; --muted: color-mix(in srgb, var(--ink) 55%, var(--card, var(--paper))); }
/* the whole tab, so the title reads on the theme's ground */
.bt.board-tab { background: var(--paper); }
.bt .board-head { display: flex; align-items: baseline; gap: 12px; flex-wrap: wrap; padding: 2px 6px 4px; color: var(--pageInk, var(--ink)); }
.bt .board-head h1 { margin: 0; font: 600 26px/1.1 var(--bt-sans); letter-spacing: -1px; }
.bt .board-head .meta { font: 400 12px var(--bt-mono); opacity: .65; }
.bt .board-stage { background: var(--paper); border-color: color-mix(in srgb, var(--pageInk, var(--ink)) 14%, transparent); }
.bt .board-surface { background-color: var(--paper); box-shadow: none; }
.bt .board-card { background: var(--card); color: var(--ink); font-family: var(--bt-sans); }
.bt .board-card::after { background: linear-gradient(transparent, var(--card)); }
.bt .card-head { display: flex; justify-content: space-between; align-items: baseline; gap: 8px; margin-bottom: 6px; }
.bt .card-head .meta { font: 400 10.5px var(--bt-mono); color: var(--muted); letter-spacing: .04em; margin-left: auto; }
.bt-linen .card-head .meta { margin-left: 0; }
.bt .board-card .card-title { font-family: inherit; }
.bt .board-card .memo-drawn .red, .bt .board-card .memo-drawn ul.checks input { accent-color: var(--accent); }
.bt-mini { position: relative; height: 74px; border-radius: 8px; overflow: hidden; background: var(--paper); border: 1px solid color-mix(in srgb, var(--ink) 18%, transparent); }
.bt-mini .mc { position: absolute; left: 12px; top: 14px; width: 54%; bottom: -6px; background: var(--card, #fff); border-radius: 4px; padding: 7px 8px; box-shadow: 0 2px 6px rgb(0 0 0 / .15); }
.bt-mini .mc b { display: block; font: 700 12px var(--bt-mono); color: var(--accent); }
.bt-mini .mc i { display: block; height: 4px; margin-top: 5px; border-radius: 2px; background: color-mix(in srgb, var(--ink) 55%, transparent); }
.bt-mini .mc i + i { width: 70%; }
.bt-mini .dot { position: absolute; right: 12px; top: 14px; width: 22px; height: 22px; border-radius: 50%; background: var(--accent); }

/* warm workspace */
.bt-warm .board-surface { background-image: radial-gradient(color-mix(in srgb, var(--ink) 20%, transparent) 1px, transparent 1.2px); background-size: 18px 18px; }
.bt-warm .board-card { border-radius: 16px; background: linear-gradient(180deg, var(--card), color-mix(in srgb, var(--card) 94%, var(--ink))); box-shadow: 0 0 0 1px color-mix(in srgb, var(--ink) 12%, transparent), 0 14px 24px -18px color-mix(in srgb, var(--ink) 60%, transparent); }
.bt-warm .card-head .num { font: 600 11px var(--bt-mono); color: var(--accent); background: color-mix(in srgb, var(--accent) 14%, var(--card)); padding: 2px 7px; border-radius: 6px; }
.bt-warm .board-card .card-title { font: 600 16px var(--bt-sans); letter-spacing: -.4px; }

/* bento */
.bt-bento .board-card { border-radius: 26px; padding: 18px 20px 20px; box-shadow: none; }
.bt-bento .board-card.alt1 { background: var(--accent); color: var(--on-accent); --card: var(--accent); }
.bt-bento .board-card.alt2 { background: var(--card2); color: var(--on-card2); --card: var(--card2); --ink: var(--on-card2); }
.bt-bento .card-head .num { font: 700 32px/1 var(--bt-sans); letter-spacing: -2px; }
.bt-bento .card-head .meta { background: color-mix(in srgb, var(--ink) 8%, transparent); padding: 3px 9px; border-radius: 999px; }
.bt-bento .board-card .card-title { font: 700 18px var(--bt-sans); letter-spacing: -.6px; margin-top: 8px; }
.bt-bento .board-head h1 { font: 700 30px var(--bt-sans); letter-spacing: -1.5px; }
.bt-bento .board-head .meta { background: var(--accent); color: var(--on-accent); opacity: 1; padding: 2px 10px; border-radius: 999px; }

/* editorial serif */
.bt-editorial .board-card { background: transparent; box-shadow: none; border-left: 1px solid color-mix(in srgb, var(--ink) 22%, transparent); border-radius: 0; padding: 0 14px; font-family: var(--bt-serif); }
.bt-editorial .board-card::after { background: linear-gradient(transparent, var(--paper)); }
.bt-editorial .card-head .num { font: italic 400 40px/1 var(--bt-italic); color: var(--accent); }
.bt-editorial .card-head .meta { font: italic 400 13px var(--bt-italic); letter-spacing: 0; }
.bt-editorial .board-card .card-title { font: 600 20px var(--bt-serif); letter-spacing: -.8px; padding-bottom: 6px; border-bottom: 1px solid var(--ink); }
.bt-editorial .board-head { border-top: 1px solid var(--ink); border-bottom: 1px solid var(--ink); padding: 6px 2px 10px; }
.bt-editorial .board-head h1 { font: 800 40px/1 var(--bt-serif); letter-spacing: -2.5px; }
.bt-editorial .board-head .meta { font: italic 400 16px var(--bt-italic); }

/* dark tech */
.bt-tech .board-surface { background-image: linear-gradient(color-mix(in srgb, var(--pageInk) 5%, transparent) 1px, transparent 1px), linear-gradient(90deg, color-mix(in srgb, var(--pageInk) 5%, transparent) 1px, transparent 1px); background-size: 32px 32px; }
.bt-tech .board-card { border-radius: 12px; border: 1px solid color-mix(in srgb, var(--ink) 10%, transparent); box-shadow: 0 1px 0 color-mix(in srgb, var(--ink) 6%, transparent) inset, 0 20px 40px -20px #000; font-size: 13.5px; }
.bt-tech .card-head .num { font: 400 12px var(--bt-mono); color: var(--accent); }
.bt-tech .card-head .meta { border: 1px solid color-mix(in srgb, var(--ink) 14%, transparent); padding: 1px 6px; border-radius: 4px; }
.bt-tech .board-card .card-title { font: 600 16px var(--bt-sans); letter-spacing: -.3px; }
.bt-tech .board-head h1 { background: linear-gradient(180deg, var(--pageInk), color-mix(in srgb, var(--pageInk) 50%, var(--paper))); -webkit-background-clip: text; background-clip: text; color: transparent; font-size: 30px; }

/* guideline sheet */
.bt-spec .board-surface { background-image: linear-gradient(90deg, color-mix(in srgb, var(--ink) 7%, transparent) 1px, transparent 1px); background-size: 192px 100%; }
.bt-spec .board-card { background: var(--paper); --card: var(--paper); border-top: 2px solid var(--ink); border-radius: 0; box-shadow: none; padding: 8px 2px 4px; }
.bt-spec .card-head .num { font: 300 42px/1 var(--bt-sans); letter-spacing: -2px; }
.bt-spec .card-head .meta { text-transform: uppercase; }
.bt-spec .board-card .card-title { font: 600 16px var(--bt-sans); padding-bottom: 6px; border-bottom: 1px solid color-mix(in srgb, var(--ink) 18%, transparent); }
.bt-spec .board-head h1 { font: 700 32px var(--bt-sans); letter-spacing: -1.6px; }
.bt-spec .board-head h1::after { content: "."; color: var(--accent); }
.bt-spec .board-head .meta { color: var(--accent); opacity: 1; letter-spacing: .08em; }

/* duotone */
.bt-duotone .board-head { background: var(--accent); color: var(--pageInk); border-radius: var(--d-radius-sm); padding: 14px 16px 12px; }
.bt-duotone .board-head h1 { font: 700 34px/1 var(--bt-sans); letter-spacing: -2px; }
.bt-duotone .board-card { border-radius: 2px; box-shadow: 0 1px 0 color-mix(in srgb, var(--ink) 8%, transparent), 0 18px 30px -24px var(--ink); }
.bt-duotone .card-head .num { font: 700 13px var(--bt-sans); color: var(--accent); }
.bt-duotone .board-card .card-title { font: 700 18px var(--bt-sans); letter-spacing: -.8px; }

/* kinetic type */
.bt-kinetic .board-card { border-radius: 4px; box-shadow: none; }
.bt-kinetic .board-card.alt1 { background: var(--accent); color: var(--on-accent); --card: var(--accent); }
.bt-kinetic .card-head .num { font: 400 54px/.85 var(--bt-display); color: transparent; -webkit-text-stroke: 1.2px var(--ink); }
.bt-kinetic .board-card.alt1 .card-head .num { -webkit-text-stroke-color: var(--on-accent); }
.bt-kinetic .card-head .meta { color: inherit; opacity: .7; text-transform: uppercase; }
.bt-kinetic .board-card .card-title { font: 700 18px var(--bt-sans); letter-spacing: -.8px; margin-top: 6px; }
.bt-kinetic .board-head h1 { font: 400 40px/1 var(--bt-display); letter-spacing: 0; text-transform: uppercase; }
.bt-kinetic .board-head .meta { border-top: 1px solid color-mix(in srgb, var(--pageInk) 30%, transparent); padding-top: 4px; }

/* architect grid */
.bt-archi .board-surface { background-image: linear-gradient(color-mix(in srgb, var(--ink) 9%, transparent) 1px, transparent 1px), linear-gradient(90deg, color-mix(in srgb, var(--ink) 9%, transparent) 1px, transparent 1px); background-size: 40px 40px; }
.bt-archi .board-card { border-radius: 0; box-shadow: none; outline: 1px solid var(--ink); }
.bt-archi .card-head .num { font: 400 11px var(--bt-mono); color: var(--accent); }
.bt-archi .board-card .card-title { font: 600 16px var(--bt-sans); margin-top: 14px; }
.bt-archi .board-head h1 { font: 300 32px var(--bt-sans); letter-spacing: -1.6px; }

/* pop sticker */
.bt-pop .board-surface { background-image: radial-gradient(circle at 1020px 60px, color-mix(in srgb, var(--ink) 30%, var(--accent)) 1.6px, transparent 1.9px), radial-gradient(circle at 1020px 60px, var(--accent) 0 330px, transparent 331px);
  background-size: 12px 12px, auto; }
.bt-pop .board-surface::before { content: ""; position: absolute; left: 690px; top: -270px; width: 660px; height: 660px; border-radius: 50%; border: 3px solid var(--ink); pointer-events: none; }
.bt-pop .board-stage.frame-mode { background-image: radial-gradient(circle at 95% 0, var(--accent) 0 180px, transparent 181px); }
.bt-pop .board-card { border: 3px solid var(--ink); border-radius: 0; box-shadow: 6px 6px 0 var(--ink); }
.bt-pop .board-card::after { display: none; }
.bt-pop .card-head { border-bottom: 3px solid var(--ink); padding-bottom: 4px; margin-bottom: 8px; }
.bt-pop .card-head .num { font: 900 32px/0.9 'Black Han Sans', var(--bt-sans); }
.bt-pop .card-head .meta { font: 600 11px var(--bt-mono); color: var(--ink); background: var(--accent2); padding: 1px 6px; }
.bt-pop .board-card.alt1 .card-head .meta { background: var(--accent); color: var(--on-accent); }
.bt-pop .board-card .card-title { font: 700 18px var(--bt-sans); letter-spacing: -.6px; }
.bt-pop .board-head h1 { font: 900 40px/0.95 'Black Han Sans', var(--bt-sans); letter-spacing: -1px; }
.bt-pop .board-head .meta { font: 600 12px var(--bt-mono); opacity: 1; text-decoration: underline; text-decoration-thickness: 2px; text-underline-offset: 3px; }
.bt-pop .board-frame .board-head { background: var(--accent2); border: 3px solid var(--ink); border-radius: 0; box-shadow: 6px 6px 0 var(--ink); }

/* the title block in the section layout, per theme */
.bt .board-frame .board-head { background: var(--card, var(--paper)); color: var(--ink); }
.bt-bento .board-frame .board-head { background: var(--card2); color: var(--on-card2); border-radius: 26px; }
.bt-bento .board-frame { --frame-gap: 14px; }
.bt-editorial .board-frame .board-head, .bt-spec .board-frame .board-head, .bt-archi .board-frame .board-head { background: transparent; }
.bt-editorial .board-frame .board-head .big { font: italic 400 72px/0.85 var(--bt-italic); letter-spacing: -2px; }
.bt-spec .board-frame .board-head .big { font-weight: 300; color: var(--accent); }
.bt-archi .board-frame { --frame-gap: 0px; } .bt-archi .board-frame > * { outline: 1px solid var(--ink); }
.bt-spec .board-frame { --frame-gap: 20px; }
.bt-tech .board-frame .board-head { border: 1px solid color-mix(in srgb, var(--ink) 12%, transparent); border-radius: 12px; }
.bt-duotone .board-frame .board-head { background: var(--accent); color: var(--pageInk); border-radius: 2px; }
.bt-kinetic .board-frame .board-head { background: transparent; color: var(--pageInk); }
.bt-kinetic .board-frame .board-head .big { font: 400 92px/0.8 var(--bt-display); color: transparent; -webkit-text-stroke: 1.5px var(--accent); letter-spacing: 0; }
.bt-warm .board-frame .board-head { border-radius: 16px; box-shadow: 0 0 0 1px color-mix(in srgb, var(--ink) 12%, transparent); }
.bt-clean .board-frame .board-head { border-radius: 24px; background: var(--card2); }
.bt-linen .board-frame .board-head, .bt-cottage .board-frame .board-head { align-items: center; text-align: center; }

/* cottage scrapbook */
.bt-cottage .board-surface { background-image: radial-gradient(color-mix(in srgb, var(--ink) 12%, transparent) 1px, transparent 1.2px), radial-gradient(rgb(255 255 255 / .1) 1px, transparent 1.2px); background-size: 7px 7px, 11px 11px; }
.bt-cottage .board-card { border-radius: 2px; border-top: 3px solid var(--accent); font-family: var(--bt-serif); line-height: 24px; overflow: visible; max-height: none;
  background-image: linear-gradient(color-mix(in srgb, var(--ink) 13%, transparent) 1px, transparent 1px); background-size: 100% 24px; background-position: 0 46px; box-shadow: 0 4px 10px rgb(0 0 0 / .2); }
.bt-cottage .board-card:nth-child(3n+2) { border-top-color: var(--accent2); }
.bt-cottage .board-card::before { content: ""; position: absolute; left: 50%; top: -9px; width: 12px; height: 20px; border-radius: 3px; background: color-mix(in srgb, var(--paper) 70%, var(--ink)); transform: translateX(-50%); }
.bt-cottage .board-card::after { display: none; }
.bt-cottage .card-head .num { font: italic 400 20px var(--bt-italic); color: var(--accent); }
.bt-cottage .card-head .meta { font: italic 400 13px var(--bt-italic); }
.bt-cottage .board-card .card-title { font: 700 18px var(--bt-serif); }
.bt-cottage .board-head h1 { font: 700 30px var(--bt-serif); }
.bt-cottage .board-head .meta { font: italic 400 15px var(--bt-italic); }

/* clean neutral */
.bt-clean .board-card { border-radius: 24px; padding: 18px 18px 20px; box-shadow: 0 18px 30px -20px color-mix(in srgb, var(--ink) 50%, transparent); }
.bt-clean .board-card.alt1 { background: var(--card2); --card: var(--card2); }
.bt-clean .card-head .num { font: italic 400 24px var(--bt-italic); color: var(--accent); }
.bt-clean .card-head .meta { font: 300 10px var(--bt-sans); letter-spacing: .14em; text-transform: uppercase; }
.bt-clean .board-card .card-title { font: 600 16px var(--bt-sans); }
.bt-clean .board-head h1 { font: 300 32px var(--bt-sans); letter-spacing: -1.4px; }
.bt-clean .board-head .meta { font: italic 400 15px var(--bt-italic); }

/* linen journal */
.bt-linen .board-surface { background-image: repeating-linear-gradient(0deg, rgb(0 0 0 / .03) 0 1px, transparent 1px 3px), repeating-linear-gradient(90deg, rgb(255 255 255 / .08) 0 1px, transparent 1px 4px); }
.bt-linen .board-card { border-radius: 0; padding: 18px 18px 20px; box-shadow: 0 1px 1px rgb(0 0 0 / .06), 0 14px 24px -20px color-mix(in srgb, var(--ink) 60%, transparent); line-height: 1.7;
  clip-path: polygon(0 1%, 5% 0, 12% .8%, 20% 0, 30% .7%, 40% 0, 50% .8%, 60% .1%, 70% .8%, 80% 0, 90% .7%, 100% .2%, 99.5% 12%, 100% 30%, 99.4% 50%, 100% 70%, 99.5% 88%, 100% 99.4%, 90% 100%, 80% 99.3%, 70% 100%, 60% 99.4%, 50% 100%, 40% 99.3%, 30% 100%, 20% 99.4%, 10% 100%, 0 99.4%, .5% 85%, 0 65%, .6% 45%, 0 25%); }
.bt-linen .card-head { justify-content: center; }
.bt-linen .card-head .num { font: italic 300 22px var(--bt-italic); color: var(--accent); }
.bt-linen .card-head .meta { font: 300 10px var(--bt-sans); letter-spacing: .2em; }
.bt-linen .board-card .card-title { font: 400 18px var(--bt-serif); text-align: center; }
.bt-linen .board-card .card-title::after { content: ""; display: block; width: 26px; margin: 8px auto 4px; border-top: 1px solid var(--accent); }
.bt-linen .board-head { justify-content: center; text-align: center; }
.bt-linen .board-head h1 { font: 300 30px var(--bt-serif); }
.bt-linen .board-head .meta { font: italic 300 15px var(--bt-italic); }

/* what a look changes over its theme (classes set by board-theme-panel.ts); x-<chip>: a chip the theme doesn't name */
.bt.x-pageInk .board-head, .bt.x-pageInk .board-head h1 { color: var(--pageInk); -webkit-text-fill-color: var(--pageInk); }
.bt.x-card .board-card:not(.alt1):not(.alt2) { background: var(--card); --card: var(--card); }
.bt.x-card2 .board-card.alt2 { background: var(--card2); color: var(--on-card2); --card: var(--card2); }
.bt.x-accent2 .card-head .meta { color: var(--accent2); opacity: 1; }
.bt.s-tfont .board-head h1 { font-family: var(--s-tfont); }
.bt.s-cfont .board-card, .bt.s-cfont .board-card .card-title { font-family: var(--s-cfont); }
.bt.s-radius .board-card, .bt.s-radius .board-frame .board-head { border-radius: var(--s-radius); }
.bt.s-shadow-none .board-card { box-shadow: none; }
.bt.s-shadow-soft .board-card { box-shadow: 0 1px 2px rgb(0 0 0 / .08), 0 8px 18px -10px rgb(0 0 0 / .35); }
.bt.s-shadow-strong .board-card { box-shadow: 0 2px 4px rgb(0 0 0 / .12), 0 22px 40px -14px rgb(0 0 0 / .6); }
.bt.s-pattern .board-surface, .bt.s-pattern .board-stage.frame-mode { background-color: var(--paper); background-size: auto; background-position: 0 0; }
.bt.s-pattern .board-surface::before { display: none; }
.bt.s-pattern-none .board-surface, .bt.s-pattern-none .board-stage.frame-mode { background-image: none; }
.bt.s-pattern-dots .board-surface, .bt.s-pattern-dots .board-stage.frame-mode { background-image: radial-gradient(color-mix(in srgb, var(--on-paper, var(--ink)) 22%, transparent) 1px, transparent 1.3px); background-size: 18px 18px; }
.bt.s-pattern-grid .board-surface, .bt.s-pattern-grid .board-stage.frame-mode { background-image: linear-gradient(color-mix(in srgb, var(--on-paper, var(--ink)) 9%, transparent) 1px, transparent 1px), linear-gradient(90deg, color-mix(in srgb, var(--on-paper, var(--ink)) 9%, transparent) 1px, transparent 1px); background-size: 32px 32px; }
.bt.s-pattern-lines .board-surface, .bt.s-pattern-lines .board-stage.frame-mode { background-image: linear-gradient(color-mix(in srgb, var(--on-paper, var(--ink)) 10%, transparent) 1px, transparent 1px); background-size: 100% 28px; }
`;
