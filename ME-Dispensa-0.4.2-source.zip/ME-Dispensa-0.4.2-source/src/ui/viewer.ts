// The visz viewer above the Dock. HTML pages run in sandboxed frames (scripts allowed, no access to Marinara).

import { buildSrcdoc, extractHtmlBlocks, hasScripts, normalizeOutput } from "../visz/core";
import type { ViewerEntry, ViszService, ViszViewer } from "../visz/service";
import type { ViszStore } from "../visz/store";
import { capturePage, saveBlob } from "../shared/capture";
import { fornello } from "../host/fornello";
import type { HostUI } from "../stscript/host";
import { confirmIn } from "./dialogs";
import { el, icon } from "./dom";
import { CONTROLS, THEME_TOKENS } from "../shared/theme";
import { t } from "../shared/i18n";
import { newId } from "../util";

const STYLE = `
${THEME_TOKENS}
:host { display: block; }
* { box-sizing: border-box; }
${CONTROLS}
.panel { margin: 0 0 6px; overflow: hidden; display: flex; flex-direction: column; max-height: 70vh;
  font: 13px/1.3 var(--d-font); color: var(--d-text);
  background: var(--d-shell-bg); border: var(--d-shell-border); border-radius: var(--d-shell-radius);
  box-shadow: var(--d-shell-shadow); backdrop-filter: var(--d-shell-blur); -webkit-backdrop-filter: var(--d-shell-blur); }
.panel.full { position: fixed; inset: max(8px, env(safe-area-inset-top)) 8px max(8px, env(safe-area-inset-bottom)); z-index: 2147482500;
  width: auto; height: auto; max-width: none; max-height: none; margin: 0; padding: 0; color: var(--d-text);
  background: var(--d-panel-solid); box-shadow: 0 20px 60px rgb(0 0 0 / .45); }
.panel.full::backdrop { background: rgb(0 0 0 / .45); }
.head { display: flex; align-items: center; gap: 4px; padding: 4px 6px; border-bottom: 1px solid var(--d-divider); flex-wrap: wrap; }
.title { flex: 1; min-width: 80px; font-weight: 600; color: var(--d-title); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; padding: 0 4px; }
.head button { padding: 4px 8px; }
.head button.ghost { padding: 4px 6px; }
button.warn { border-color: #e6a23c; color: #e6a23c; }
.chip-warn { font-size: 11px; padding: 2px 7px; border-radius: 999px; border: 1px solid #e6a23c; color: #e6a23c; cursor: help; }
.pages { display: flex; gap: 4px; padding: 4px 6px 0; flex-wrap: wrap; }
.pages button { padding: 2px 8px; font-size: 12px; }
.body { overflow: auto; flex: 1; min-height: 80px; }
iframe { display: block; width: 100%; height: 360px; border: 0; background: #fff; }
.panel.full iframe { height: 100% !important; }
.panel.full .body { display: flex; flex-direction: column; }
.panel.full .body iframe { flex: 1; }
pre { margin: 0; padding: 10px 12px; white-space: pre-wrap; word-break: break-word; font: inherit; }
svg { width: 15px; height: 15px; flex: none; }
`;

/** Marinara's CSP blocks inline scripts and inline-HTML frames inherit it: check once whether scripts run. */
let scriptProbe: Promise<boolean> | null = null;
function scriptsRun(): Promise<boolean> {
  scriptProbe ??= new Promise((resolve) => {
    const token = newId("probe");
    const frame = document.createElement("iframe");
    frame.setAttribute("sandbox", "allow-scripts");
    frame.style.cssText = "position:fixed;width:1px;height:1px;left:-10px;top:-10px;border:0;opacity:0;";
    const done = (ok: boolean) => {
      window.removeEventListener("message", onMessage);
      clearTimeout(timer);
      frame.remove();
      resolve(ok);
    };
    const onMessage = (e: MessageEvent) => {
      if ((e.data as { dispensaProbe?: string } | null)?.dispensaProbe === token) done(true);
    };
    window.addEventListener("message", onMessage);
    const timer = setTimeout(() => done(false), 1500);
    frame.srcdoc = `<script>parent.postMessage({dispensaProbe:${JSON.stringify(token)}},"*")</script>`;
    document.body.append(frame);
  });
  return scriptProbe;
}

export class ViewerPanel implements ViszViewer {
  readonly element: HTMLElement;
  private readonly root: ShadowRoot;
  private entry: ViewerEntry | null = null;
  private page = 0;
  private full = false;
  private token = "";
  private frame: HTMLIFrameElement | null = null;
  private scripts: boolean | null = null;
  private resize: ResizeObserver | null = null;
  private mounted: { dispose(): void } | null = null;

  constructor(
    private readonly deps: { service: ViszService; store: ViszStore; ui: HostUI; onChange?: () => void },
  ) {
    this.element = document.createElement("div");
    this.element.id = "dispensa-viewer";
    this.root = this.element.attachShadow({ mode: "open" });
    window.addEventListener("message", this.onMessage);
    document.addEventListener("keydown", this.onKey, true);
  }

  get open(): boolean {
    return this.entry !== null;
  }

  dispose(): void {
    window.removeEventListener("message", this.onMessage);
    document.removeEventListener("keydown", this.onKey, true);
    this.element.remove();
  }

  show(entry: ViewerEntry): void {
    this.entry = { ...entry };
    this.page = 0;
    this.render();
    this.deps.onChange?.();
    if (this.scripts === null) {
      void scriptsRun().then((ok) => {
        this.scripts = ok;
        // with the page extension the answer changes nothing; redrawing would restart its page
        if (this.entry && !fornello()) this.render();
      });
    }
  }

  close(): void {
    this.mounted?.dispose();
    this.mounted = null;
    this.resize?.disconnect();
    this.resize = null;
    this.entry = null;
    this.full = false;
    this.frame = null;
    this.panel = null;
    this.sizeButton = null;
    this.root.replaceChildren();
    this.deps.onChange?.();
  }

  private readonly onKey = (e: KeyboardEvent) => {
    if (e.key === "Escape" && this.full) {
      e.stopPropagation();
      this.setFull(false);
    }
  };

  private readonly onMessage = (event: MessageEvent) => {
    const data = event.data as { viszHeight?: unknown; token?: unknown } | null;
    if (!data || typeof data.viszHeight !== "number" || data.token !== this.token || !this.frame) return;
    if (event.source !== this.frame.contentWindow || this.full) return;
    const max = Math.max(200, this.deps.store.value.settings.maxFrameHeight);
    this.frame.style.height = `${Math.min(max, Math.max(120, Math.ceil(data.viszHeight) + 4))}px`;
  };

  private render(): void {
    const entry = this.entry;
    if (!entry) return;
    const style = document.createElement("style");
    style.textContent = STYLE;
    const out = normalizeOutput(entry.text);
    const blocks = extractHtmlBlocks(out.text);
    this.page = Math.min(this.page, Math.max(0, blocks.length - 1));
    const current = blocks[this.page];
    const busy = !!this.deps.service.busy;
    const head = el(
      "div",
      { class: "head" },
      el("span", { class: "title", title: entry.title }, `${entry.kind === "viz" ? "🌟" : "💬"} ${entry.title}`),
      current && this.scripts === false && !fornello() && hasScripts(current.code)
        ? el(
            "span",
            {
              class: "chip-warn",
              title: t("Scripts are blocked; Fornello runs them", "스크립트가 막혀 있음. Fornello가 있으면 동작"),
            },
            t("Scripts off", "스크립트 꺼짐"),
          )
        : null,
      current && !current.complete
        ? el("button", { class: "warn", part: "viewer-continue", title: t("Cut off: continue writing", "끊김: 이어서 쓰기"), disabled: busy, onclick: () => void this.continue() }, icon("refresh-cw"), t("Continue", "이어 쓰기"))
        : null,
      el(
        "button",
        { class: entry.archivedId ? "ghost on" : "ghost", part: "viewer-save", title: entry.archivedId ? t("In the Gallery", "갤러리에 있음") : t("Save to Gallery", "갤러리에 저장"), "aria-label": t("Save to Gallery", "갤러리에 저장"), onclick: () => void this.save() },
        icon("star"),
      ),
      el("button", { class: "ghost", part: "viewer-post", title: t("Post to the chat as a character message", "채팅에 캐릭터 메시지로 넣기"), "aria-label": t("Post to chat", "채팅에 넣기"), disabled: busy, onclick: () => void this.postToChat() }, icon("send")),
      current ? el("button", { class: "ghost", title: t("Download as HTML file", "HTML 파일로 받기"), "aria-label": t("Download as HTML file", "HTML 파일로 받기"), onclick: () => this.download(current.code, current.title || entry.title) }, icon("download")) : null,
      current
        ? el("button", { class: "ghost", part: "viewer-image", title: t("Save as image (PNG)", "이미지(PNG)로 저장"), "aria-label": t("Save as image", "이미지로 저장"), onclick: (e: Event) => void this.saveImage(e.currentTarget as HTMLButtonElement, current.code, current.title || entry.title) }, icon("image"))
        : null,
      (this.sizeButton = el("button", { class: "ghost", title: this.full ? t("Smaller", "작게 보기") : t("Larger", "크게 보기"), "aria-label": t("Larger", "크게 보기"), onclick: () => this.setFull(!this.full) }, icon(this.full ? "minimize" : "maximize"))),
      entry.archivedId ? el("button", { class: "ghost", part: "viewer-delete", title: t("Delete from Gallery", "갤러리에서 지우기"), "aria-label": t("Delete from Gallery", "갤러리에서 지우기"), onclick: () => void this.remove() }, icon("trash")) : null,
      el("button", { class: "ghost", part: "viewer-close", title: t("Close", "닫기"), "aria-label": t("Close", "닫기"), onclick: () => this.close() }, icon("x")),
    );
    const panel = el("div", { class: `panel${this.full ? " full" : ""}`, part: "viewer", role: "region", "aria-label": t("Visualizer viewer", "비주얼라이저 보기") }, head);
    if (blocks.length > 1) {
      panel.append(
        el(
          "div",
          { class: "pages" },
          ...blocks.map((b, i) => el("button", { class: i === this.page ? "sel" : "", title: b.title, onclick: () => ((this.page = i), this.render()) }, b.title ? `${i + 1}. ${b.title.slice(0, 20)}` : String(i + 1))),
        ),
      );
    }
    const body = el("div", { class: "body" });
    this.resize?.disconnect();
    this.resize = null;
    this.mounted?.dispose();
    this.mounted = null;
    const bridge = fornello();
    if (current && bridge) {
      this.frame = null;
      const holder = el("div", { class: "fornello" });
      body.append(holder);
      this.mounted = bridge.mount(holder, current.code);
    } else if (current) {
      this.token = newId("v");
      // scripts blocked: the frame can safely share our origin, so we measure its height from here
      const noScripts = this.scripts === false;
      const frame = el("iframe", {
        sandbox: noScripts ? "allow-same-origin allow-popups allow-popups-to-escape-sandbox" : "allow-scripts allow-popups allow-modals allow-forms allow-downloads",
        title: current.title || entry.title,
        referrerpolicy: "no-referrer",
      });
      frame.srcdoc = buildSrcdoc(current.code, { token: this.token, allowExternal: this.deps.store.value.settings.allowExternal });
      if (noScripts) frame.addEventListener("load", () => this.measure(frame));
      this.frame = frame;
      body.append(frame);
    } else {
      this.frame = null;
      body.append(el("pre", {}, out.text));
    }
    panel.append(body);
    this.root.replaceChildren(style, panel);
    this.panel = panel;
    if (this.full) this.applyFull();
  }

  private panel: HTMLElement | null = null;
  private sizeButton: HTMLButtonElement | null = null;

  /**
   * Big or back above the Dock without redrawing (a running page keeps its state). Big, it is
   * a top-layer popover above Marinara's bars, so its buttons stay reachable.
   */
  private setFull(on: boolean): void {
    if (on === this.full) return;
    this.full = on;
    this.applyFull();
    if (!on && this.frame && this.scripts === false) this.measure(this.frame);
  }

  private applyFull(): void {
    const panel = this.panel;
    if (!panel) return;
    panel.classList.toggle("full", this.full);
    if (typeof panel.showPopover === "function") {
      try {
        if (this.full && !panel.matches(":popover-open")) {
          panel.popover = "manual";
          panel.showPopover();
        } else if (!this.full && panel.matches(":popover-open")) {
          panel.hidePopover();
          panel.removeAttribute("popover");
        }
      } catch {
        // not on screen: the class alone
      }
    }
    const b = this.sizeButton;
    if (b) {
      b.title = this.full ? t("Smaller", "작게 보기") : t("Larger", "크게 보기");
      b.replaceChildren(icon(this.full ? "minimize" : "maximize"));
    }
  }

  private measure(frame: HTMLIFrameElement): void {
    const doc = frame.contentDocument;
    if (!doc?.documentElement) return;
    const fit = () => {
      if (this.full) return;
      // documentElement never reports less than the frame itself, so measure the body
      const body = doc.body;
      if (!body) return;
      const cs = doc.defaultView?.getComputedStyle(body);
      const margin = cs ? parseFloat(cs.marginTop) + parseFloat(cs.marginBottom) : 0;
      const h = Math.ceil(body.scrollHeight + margin);
      const max = Math.max(200, this.deps.store.value.settings.maxFrameHeight);
      frame.style.height = `${Math.min(max, Math.max(120, h + 4))}px`;
    };
    fit();
    this.resize?.disconnect();
    this.resize = new ResizeObserver(fit);
    if (doc.body) this.resize.observe(doc.body);
  }

  private async continue(): Promise<void> {
    if (!this.entry) return;
    const next = await this.deps.service.continueEntry(this.entry);
    if (next && this.entry) {
      this.entry = next;
      this.render();
    }
  }

  private async save(): Promise<void> {
    if (!this.entry || this.entry.archivedId) return;
    try {
      await this.deps.service.save(this.entry);
      this.deps.ui.toast(t("Saved to the Gallery.", "갤러리에 저장했어요."), "success", { title: "🌟" });
    } catch (e) {
      this.deps.ui.toast(e instanceof Error ? e.message : String(e), "error", { title: t("Gallery", "갤러리") });
    }
    this.render();
  }

  private async postToChat(): Promise<void> {
    if (!this.entry) return;
    const entry = this.entry;
    if (await this.deps.service.postToChat(entry)) {
      if (this.deps.service.keeps("chat", entry.text) && !entry.archivedId) await this.deps.service.save(entry).catch(() => undefined);
      this.deps.ui.toast(t("Posted to the chat.", "채팅에 넣었어요."), "success", { title: "🌟" });
    }
    this.render();
  }

  private async remove(): Promise<void> {
    const entry = this.entry;
    if (!entry?.archivedId) return;
    if (!(await confirmIn(this.deps.ui, t(`Delete "${entry.title}" from the Gallery?`, `갤러리에서 "${entry.title}"을(를) 지울까요?`)))) return;
    await this.deps.service.archive.remove(entry.archivedId);
    this.close();
  }

  private download(code: string, title: string): void {
    saveBlob(new Blob([code], { type: "text/html;charset=utf-8" }), `${fileName(title)}.html`);
  }

  /** The page as it looks now, a running page included. */
  private async saveImage(button: HTMLButtonElement, code: string, title: string): Promise<void> {
    button.disabled = true;
    try {
      // the page extension's frame sits in its block's open shadow root
      const frame = this.frame ?? this.root.querySelector<HTMLElement>(".fornello")?.querySelector(".fornello-block")?.shadowRoot?.querySelector("iframe") ?? null;
      saveBlob(await capturePage(frame, code), `${fileName(title)}.png`);
    } catch (error) {
      this.deps.ui.toast(t(`Could not save the image: ${error instanceof Error ? error.message : String(error)}`, `이미지로 저장하지 못했어요: ${error instanceof Error ? error.message : String(error)}`), "warning", { title: "🌟" });
    } finally {
      button.disabled = false;
    }
  }
}

const fileName = (title: string) => title.replace(/[\\/:*?"<>|]+/g, " ").trim() || "page";
