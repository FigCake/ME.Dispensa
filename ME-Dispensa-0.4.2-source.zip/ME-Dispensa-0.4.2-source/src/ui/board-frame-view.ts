// The section layout drawn (memo/board-frame.ts does the layout): each block has
// ⠿ to drag and ⇥ ⇤ ⤓ ⤒ to merge or split; empty sections take a memo or a picture.

import { type Board, cardNumbers, liveCards } from "../memo/board";
import { FRAME_COLS, HEAD_KEY, type FrameItem, arrangeFrame, cardKey, frameItems, freeCells, magnetKey, moveBlock, setColumns, spanBlock } from "../memo/board-frame";
import { t } from "../shared/i18n";
import { boardHead, cardEl } from "./board-card";
import type { BoardContext } from "./board-context";
import { el, icon } from "./dom";

export const BOARD_FRAME_CSS = `
.board-stage.frame-mode { overflow: auto; cursor: default; touch-action: pan-x pan-y; user-select: text; -webkit-user-select: text; }
.board-frame { display: grid; gap: var(--frame-gap, 12px); padding: 14px; grid-auto-rows: 176px; min-width: calc(var(--cols) * 150px); }
.board-frame > * { position: relative; min-width: 0; min-height: 0; }
.board-frame .board-card { position: relative; left: auto; top: auto; width: auto !important; max-height: none; height: 100%; transform: none !important; }
.board-frame .board-magnet { position: relative; width: auto !important; height: 100%; transform: none !important; filter: none; display: grid; place-items: center; }
.board-frame .board-magnet img { width: 100%; height: 100%; object-fit: cover; border-radius: inherit; }
.board-frame .board-magnet.page { cursor: pointer; }
.board-frame .board-head { height: 100%; display: flex; flex-direction: column; justify-content: flex-end; align-items: flex-start; padding: 14px 16px; border-radius: 4px; }
.board-frame .board-head .big { font: 700 64px/0.85 var(--bt-sans, sans-serif); letter-spacing: -4px; color: var(--accent); margin-bottom: auto; }
/* bottom right: the top of a card holds its number and date */
.board-frame .block-tools { position: absolute; right: 6px; bottom: 6px; z-index: 5; display: flex; gap: 2px; opacity: 0; transition: opacity .15s; }
.board-frame > *:hover .block-tools, .board-frame > *:focus-within .block-tools, .board-frame .block-tools:focus-within { opacity: 1; }
.board-frame .block-tools button { width: 24px; height: 24px; padding: 0; justify-content: center; font-size: 12px; border-radius: 6px; background: var(--d-panel-solid); color: var(--d-text); border: 1px solid var(--d-line); }
.board-frame .block-tools button[data-drag] { cursor: grab; touch-action: none; }
.board-frame .slot { border: 1.5px dashed color-mix(in srgb, var(--ink, #888) 25%, transparent); border-radius: 8px; display: grid; place-items: center; }
.board-frame .slot button { width: auto; background: transparent; border: none; color: color-mix(in srgb, var(--ink, #888) 55%, transparent); font-size: 13px; }
.board-frame .dragging { opacity: .85; z-index: 20; box-shadow: 0 18px 40px -10px rgb(0 0 0 / .45); pointer-events: none; }
.board-frame .drop-hint { outline: 2px solid var(--accent, var(--d-accent)); outline-offset: 2px; border-radius: 8px; pointer-events: none; z-index: 4; }
@media (pointer: coarse) { .board-frame .block-tools { opacity: .85; } }
/* phone: with many columns the board scrolls sideways inside its own frame */
@media (max-width: 600px) {
  .board-frame { min-width: calc(var(--cols) * 128px); gap: 8px; padding: 8px; grid-auto-rows: 160px; }
  .board-frame .board-head .big { font-size: 40px; letter-spacing: -2px; }
}
`;

export function frameView(ctx: BoardContext, board: Board): HTMLElement {
  // shown from an arranged copy: drawing never writes the board
  const copy: Board = liveCards(board, ctx.state().memos);
  arrangeFrame(copy);
  const cols = copy.cols ?? FRAME_COLS.default;
  const items = frameItems(copy);
  const frame = el("div", { class: "board-frame" });
  frame.style.gridTemplateColumns = `repeat(${cols}, minmax(0, 1fr))`;
  frame.style.setProperty("--cols", String(cols));
  const memos = new Map(ctx.state().memos.map((m) => [m.id, m]));
  const numbers = cardNumbers(copy, ctx.state().memos);
  for (const item of items) {
    let block: HTMLElement | null = null;
    if (item.key === HEAD_KEY) block = boardHead(ctx, board, true);
    else if (item.key.startsWith("card:")) {
      const card = copy.cards.find((c) => cardKey(c.memoId) === item.key);
      const memo = card && memos.get(card.memoId);
      if (card && memo) block = cardEl(ctx, card, memo, numbers.get(card.memoId) ?? 0);
    } else {
      const m = copy.magnets.find((x) => magnetKey(x.id) === item.key);
      if (m)
        block = el(
          "div",
          {
            class: `board-magnet${m.page ? " page" : ""}`,
            "data-magnet": m.id,
            ...(m.page
              ? {
                  title: m.page.title,
                  onclick: (e: Event) => {
                    if ((e.target as HTMLElement).closest(".block-tools")) return;
                    void ctx.deps.openPage(m.page!.archiveId).then((ok) => ok || ctx.deps.ui.toast(t("This page isn't in this browser's Gallery.", "이 페이지는 이 브라우저의 갤러리에 없어요."), "info", { title: "📋" }));
                  },
                }
              : {}),
          },
          el("img", { src: m.image.url, alt: "", draggable: "false" }),
        );
    }
    if (!block) continue;
    placeInFrame(block, item);
    block.dataset.block = item.key;
    block.append(blockTools(ctx, item, cols));
    const memoId = block.dataset.card;
    if (memoId) block.addEventListener("click", (e) => {
      if (!(e.target as HTMLElement).closest(".block-tools, input, label")) ctx.openCard(memoId);
    });
    frame.append(block);
  }
  for (const free of freeCells(items, cols)) {
    const slot = el(
      "div",
      { class: "slot" },
      el("button", { title: t("Put a memo here", "여기에 메모 놓기"), onclick: () => void ctx.addMemos(free) }, "＋ ", t("Memo", "메모")),
      el("button", { title: t("Put a picture here", "여기에 그림 놓기"), onclick: () => ctx.pickMagnet(free) }, icon("magnet")),
    );
    placeInFrame(slot, { key: "", cell: { ...free, w: 1, h: 1 } });
    frame.append(slot);
  }
  const stage = el("div", { class: "board-stage frame-mode", "aria-label": board.name }, frame);
  if (board.background?.image) {
    stage.style.backgroundImage = `url("${board.background.image.url}")`;
    stage.style.backgroundSize = "cover";
  }
  return stage;
}

export function columnsSelect(ctx: BoardContext, board: Board): HTMLSelectElement {
  const select = el("select", { "aria-label": t("Columns", "칸 수"), title: t("Columns", "칸 수") }) as HTMLSelectElement;
  for (let n = FRAME_COLS.min; n <= FRAME_COLS.max; n++) select.append(el("option", { value: String(n), selected: n === (board.cols ?? FRAME_COLS.default) }, t(`${n} columns`, `${n}칸`)));
  select.addEventListener("change", () =>
    ctx.updateBoard((b) => {
      arrangeFrame(b);
      setColumns(b, Number(select.value));
    }),
  );
  return select;
}

function placeInFrame(node: HTMLElement, item: FrameItem): void {
  node.style.gridColumn = `${item.cell.c + 1} / span ${item.cell.w}`;
  node.style.gridRow = `${item.cell.r + 1} / span ${item.cell.h}`;
}

function blockTools(ctx: BoardContext, item: FrameItem, cols: number): HTMLElement {
  const { w, h } = item.cell;
  const span = (dw: number, dh: number) => () =>
    ctx.updateBoard((b) => {
      arrangeFrame(b);
      spanBlock(b, item.key, w + dw, h + dh);
    });
  const tool = (label: string, title: string, run: () => void, ok = true) => (ok ? el("button", { type: "button", title, "aria-label": title, onclick: (e: Event) => (e.stopPropagation(), run()) }, label) : null);
  const drag = el("button", { type: "button", "data-drag": "", title: t("Drag to another section", "끌어서 다른 구획으로"), "aria-label": t("Move", "옮기기") }, "⠿");
  drag.addEventListener("pointerdown", (e) => dragBlock(ctx, e, item));
  return el(
    "div",
    { class: "block-tools" },
    drag,
    tool("⇥", t("Merge with the section on the right", "오른쪽 구획과 합치기"), span(1, 0), item.cell.c + w < cols),
    tool("⇤", t("Split from the right", "오른쪽을 나누기"), span(-1, 0), w > 1),
    tool("⤓", t("Merge with the section below", "아래 구획과 합치기"), span(0, 1), h < 6),
    tool("⤒", t("Split from below", "아래를 나누기"), span(0, -1), h > 1),
  );
}

function dragBlock(ctx: BoardContext, e: PointerEvent, item: FrameItem): void {
  const handle = e.currentTarget as HTMLElement;
  const block = handle.closest<HTMLElement>("[data-block]");
  const frame = block?.parentElement;
  if (!block || !frame) return;
  e.preventDefault();
  handle.setPointerCapture?.(e.pointerId);
  const cols = Number(frame.style.getPropertyValue("--cols")) || FRAME_COLS.default;
  const start = { x: e.clientX, y: e.clientY };
  // measured once: the block moves with the pointer after this
  const grab = block.getBoundingClientRect();
  const offX = start.x - grab.left;
  const offY = start.y - grab.top;
  const hint = el("div", { class: "drop-hint" });
  const cellAt = (x: number, y: number) => {
    const r = frame.getBoundingClientRect();
    const style = getComputedStyle(frame);
    const pad = parseFloat(style.paddingLeft) || 0;
    const gap = parseFloat(style.columnGap) || 0;
    const colW = (r.width - pad * 2 - gap * (cols - 1)) / cols;
    const rowH = (parseFloat(style.gridAutoRows) || 176) + (parseFloat(style.rowGap) || gap);
    return {
      c: Math.max(0, Math.min(cols - item.cell.w, Math.round((x - offX - r.left - pad + frame.scrollLeft) / (colW + gap)))),
      r: Math.max(0, Math.round((y - offY - r.top - pad + frame.scrollTop) / rowH)),
    };
  };
  const onMove = (ev: PointerEvent) => {
    if (ev.pointerId !== e.pointerId) return;
    block.classList.add("dragging");
    // the frame's CSS holds blocks untransformed with !important
    block.style.setProperty("transform", `translate(${ev.clientX - start.x}px, ${ev.clientY - start.y}px)`, "important");
    placeInFrame(hint, { key: "", cell: { ...item.cell, ...cellAt(ev.clientX, ev.clientY) } });
    if (!hint.isConnected) frame.append(hint);
  };
  const onUp = (ev: PointerEvent) => {
    if (ev.pointerId !== e.pointerId) return;
    window.removeEventListener("pointermove", onMove, true);
    window.removeEventListener("pointerup", onUp, true);
    window.removeEventListener("pointercancel", onUp, true);
    hint.remove();
    block.classList.remove("dragging");
    block.style.removeProperty("transform");
    if (Math.hypot(ev.clientX - start.x, ev.clientY - start.y) < 6 || ev.type === "pointercancel") return;
    const at = cellAt(ev.clientX, ev.clientY);
    if (at.c === item.cell.c && at.r === item.cell.r) return;
    ctx.updateBoard((b) => {
      arrangeFrame(b);
      moveBlock(b, item.key, at.c, at.r);
    });
  };
  window.addEventListener("pointermove", onMove, true);
  window.addEventListener("pointerup", onUp, true);
  window.addEventListener("pointercancel", onUp, true);
}
