// The section layout of a memo board: a grid where the title block, cards and
// pictures each take a rectangle (`cell`). Every step leaves no overlaps.

import type { Board, BoardCell } from "./board";

export const FRAME_COLS = { min: 2, max: 6, default: 4 };
export const HEAD_KEY = "head";

export interface FrameItem {
  /** "head", "card:<memo id>" or "magnet:<id>". */
  key: string;
  cell: BoardCell;
}

const cardKey = (memoId: string) => `card:${memoId}`;
const magnetKey = (id: string) => `magnet:${id}`;

/** In saved order: the title block, then cards, then pictures. */
export function frameItems(board: Board): FrameItem[] {
  const out: FrameItem[] = [];
  out.push({ key: HEAD_KEY, cell: board.headCell ?? { c: 0, r: 0, w: 2, h: 1 } });
  for (const c of board.cards) out.push({ key: cardKey(c.memoId), cell: c.cell ?? { c: 0, r: 0, w: 1, h: 1 } });
  for (const m of board.magnets) out.push({ key: magnetKey(m.id), cell: m.cell ?? { c: 0, r: 0, w: 1, h: 1 } });
  return out;
}

const overlaps = (a: BoardCell, b: BoardCell) => a.c < b.c + b.w && b.c < a.c + a.w && a.r < b.r + b.h && b.r < a.r + a.h;

function firstFree(taken: BoardCell[], size: { w: number; h: number }, cols: number): BoardCell {
  for (let r = 0; ; r++) {
    for (let c = 0; c + size.w <= cols; c++) {
      const cell = { c, r, ...size };
      if (!taken.some((t) => overlaps(t, cell))) return cell;
    }
  }
}

function fit(cell: BoardCell, cols: number): BoardCell {
  const w = Math.max(1, Math.min(cols, Math.round(cell.w)));
  const h = Math.max(1, Math.min(6, Math.round(cell.h)));
  return { c: Math.max(0, Math.min(cols - w, Math.round(cell.c))), r: Math.max(0, Math.round(cell.r)), w, h };
}

/** `fixed` keys keep their place first (in that order); the rest keep theirs if free, else take the first free place. */
export function settle(items: FrameItem[], cols: number, fixed: string[] = []): FrameItem[] {
  const placed: FrameItem[] = [];
  const order = [...fixed.map((k) => items.find((i) => i.key === k)).filter((i): i is FrameItem => !!i), ...items.filter((i) => !fixed.includes(i.key))];
  for (const item of order) {
    const want = fit(item.cell, cols);
    const free = !placed.some((p) => overlaps(p.cell, want));
    placed.push({ key: item.key, cell: free ? want : firstFree(placed.map((p) => p.cell), { w: want.w, h: want.h }, cols) });
  }
  // back in the original order, so saving does not reshuffle the lists
  return items.map((i) => placed.find((p) => p.key === i.key)!);
}

export function applyItems(board: Board, items: FrameItem[]): void {
  const by = new Map(items.map((i) => [i.key, i.cell]));
  board.headCell = by.get(HEAD_KEY);
  for (const c of board.cards) c.cell = by.get(cardKey(c.memoId));
  for (const m of board.magnets) m.cell = by.get(magnetKey(m.id));
}

/** Gives every block a place (new cards and pictures go to the first free one). */
export function arrangeFrame(board: Board): void {
  const cols = board.cols ?? FRAME_COLS.default;
  const items = frameItems(board);
  const known = new Set([HEAD_KEY, ...board.cards.filter((c) => c.cell).map((c) => cardKey(c.memoId)), ...board.magnets.filter((m) => m.cell).map((m) => magnetKey(m.id))]);
  const kept = items.filter((i) => known.has(i.key));
  const placed = settle(kept, cols, kept.map((i) => i.key));
  for (const i of items) if (!known.has(i.key)) placed.push({ key: i.key, cell: firstFree(placed.map((p) => p.cell), { w: 1, h: 1 }, cols) });
  applyItems(board, placed);
}

/** Moves a block's top-left to (c, r); blocks it lands on swap into the place it left. */
export function moveBlock(board: Board, key: string, c: number, r: number): void {
  const cols = board.cols ?? FRAME_COLS.default;
  const items = frameItems(board);
  const me = items.find((i) => i.key === key);
  if (!me) return;
  const from = me.cell;
  const to = fit({ ...from, c, r }, cols);
  const hit = items.filter((i) => i.key !== key && overlaps(i.cell, to));
  const moved = items.map((i) => {
    if (i.key === key) return { ...i, cell: to };
    const at = hit.indexOf(i);
    if (at >= 0) return { ...i, cell: { ...i.cell, c: from.c + (i.cell.c - to.c), r: from.r + (i.cell.r - to.r) } };
    return i;
  });
  applyItems(board, settle(moved, cols, [key, ...hit.map((h) => h.key)]));
}

/** Merges a block across neighbouring sections or splits it back; blocks in the way move. */
export function spanBlock(board: Board, key: string, w: number, h: number): void {
  const cols = board.cols ?? FRAME_COLS.default;
  const items = frameItems(board).map((i) => (i.key === key ? { ...i, cell: { ...i.cell, w, h } } : i));
  applyItems(board, settle(items, cols, [key]));
}

export function setColumns(board: Board, cols: number): void {
  board.cols = Math.max(FRAME_COLS.min, Math.min(FRAME_COLS.max, Math.round(cols)));
  applyItems(board, settle(frameItems(board), board.cols, [HEAD_KEY]));
}

/** Rows used, plus one free row to drop into. */
export function frameRows(items: FrameItem[]): number {
  return Math.max(1, ...items.map((i) => i.cell.r + i.cell.h)) + 1;
}

export function freeCells(items: FrameItem[], cols: number): { c: number; r: number }[] {
  const rows = frameRows(items);
  const out: { c: number; r: number }[] = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) if (!items.some((i) => overlaps(i.cell, { c, r, w: 1, h: 1 }))) out.push({ c, r });
  return out;
}

/** Keys in reading order, for numbering and sending. */
export function frameOrder(items: FrameItem[]): string[] {
  return [...items].sort((a, b) => a.cell.r - b.cell.r || a.cell.c - b.cell.c).map((i) => i.key);
}

export { cardKey, magnetKey };
