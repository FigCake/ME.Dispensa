// QR files and the clipboard in the Library: import SillyTavern and Marinara
// QR files, export a set or one QR, copy, cut and paste QRs.

import { STORAGE_SOFT_LIMIT } from "../../host/persisted-store";
import { t } from "../../shared/i18n";
import {
  type ImportReport,
  MQR_ITEM_FORMAT,
  exportMarinara,
  exportMarinaraItem,
  importAny,
  importMarinara,
  resolveLinks,
} from "../../qr/import";
import { type QrItem, type QrSet, newItem, newSet } from "../../qr/model";
import { escapeHtml, oneLine } from "../../util";
import { downloadJson, pickFiles } from "../files";
import type { ManagerContext } from "./context";

export class QrFiles {
  constructor(private readonly ctx: ManagerContext) {}

  private get deps() {
    return this.ctx.deps;
  }

  /** Saves the set as a .mqr.json file. */
  exportSet(set: QrSet): void {
    downloadJson(exportMarinara(set, this.ctx.setName), `${set.name || "qr-set"}.mqr.json`);
  }

  /** Saves one QR as a .mqr.json file. */
  exportItem(item: QrItem): void {
    downloadJson(exportMarinaraItem(item, this.ctx.setName), `${item.label || "qr"}.mqr.json`);
  }

  async copyItem(item: QrItem, cut: boolean, set: QrSet): Promise<void> {
    const { ui } = this.deps;
    const data = JSON.stringify(exportMarinaraItem(item, this.ctx.setName), null, 2);
    await (ui.copy?.(data) ?? navigator.clipboard.writeText(data));
    if (cut) this.ctx.removeItem(set, item);
    ui.toast(cut ? t(`Cut "${item.label}". Click Paste in the set you want.`, `"${item.label}"을 잘라 냈어요. 원하는 세트에서 붙여넣기를 누르세요.`) : t(`Copied "${item.label}".`, `"${item.label}"을 복사했어요.`), "success");
  }

  async paste(set: QrSet): Promise<void> {
    const { ui, registry } = this.deps;
    const text = (await (ui.paste?.() ?? navigator.clipboard.readText())).trim();
    if (!text) return;
    let report: ImportReport | null = null;
    try {
      const json = JSON.parse(text);
      const own = json?.dispensa;
      report = own?.format === MQR_ITEM_FORMAT ? importMarinara(own, registry) : importAny(json, registry);
    } catch {
      // not JSON: SillyTavern makes it a QR that sends this text
    }
    if (report && report.sets.length) {
      this.addReport(report, set);
      ui.toast(t(`Pasted ${report.sets.length} sets.`, `세트 ${report.sets.length}개를 붙여 넣었어요.`), "success");
      return;
    }
    const items = report?.items.length ? report.items : [newItem(oneLine(text, 14) || "QR", text, "marinara")];
    this.addReport(report ?? { sets: [], items, links: [], total: items.length, unsupported: [], parseErrors: [], converted: 0, keptSillyTavern: [] }, set, items);
    this.ctx.selectedItem = items[0].id;
    this.ctx.render();
    ui.toast(t(`Pasted ${items.length} QRs.`, `QR ${items.length}개를 붙여 넣었어요.`), "success");
  }

  /** Imported sets go to the end; single QRs into `set`; sub menu links find their sets by name. */
  private addReport(report: ImportReport, set: QrSet | undefined, items = report.items): void {
    let missing: string[] = [];
    this.deps.store.update((st) => {
      st.sets.push(...report.sets);
      if (items.length) {
        let target = set ? st.sets.find((s) => s.id === set.id) : undefined;
        if (!target) {
          target = newSet(t("Imported QRs", "가져온 QR"));
          st.sets.push(target);
        }
        target.items.push(...items);
        this.ctx.selectedSet = target.id;
      }
      missing = resolveLinks(st, report.links);
    });
    if (missing.length) this.deps.ui.toast(t(`Couldn't find the sets used as sub menus: ${missing.join(", ")}`, `하위 메뉴로 쓰던 세트를 찾지 못했어요: ${missing.join(", ")}`), "warning");
  }

  /** Picks QR files and imports them; single QRs go into the open set. */
  importFile(): void {
    pickFiles((files) => void this.importFiles(files), { json: true, multiple: true });
  }

  private async importFiles(files: File[]): Promise<void> {
    const { ui, registry } = this.deps;
    let added = 0;
    let converted = 0;
    const kept: string[] = [];
    const problems: string[] = [];
    for (const file of files) {
      try {
        const json = JSON.parse(await file.text());
        const report = importAny(json, registry, file.name.replace(/\.(m?qr\.)?json$/i, ""));
        if (!report.sets.length && !report.items.length) {
          problems.push(t(`${file.name}: not a QR file.`, `${file.name}: QR 파일이 아니에요.`));
          continue;
        }
        this.addReport(report, this.ctx.state.sets.find((s) => s.id === this.ctx.selectedSet));
        if (report.sets.length) this.ctx.selectedSet = report.sets[0].id;
        added += report.total;
        converted += report.converted;
        for (const k of report.keptSillyTavern) kept.push(`${k.label}: ${k.reasons.join(" / ")}`);
        for (const u of report.unsupported) problems.push(`${u.label}: /${u.commands.join(", /")}`);
        for (const p of report.parseErrors) problems.push(t(`${p.label}: syntax error (${p.error})`, `${p.label}: 문법 오류 (${p.error})`));
      } catch (e) {
        problems.push(`${file.name}: ${e instanceof Error ? e.message : String(e)}`);
      }
    }
    this.ctx.render();
    const summary = [
      t(`Imported ${added} QRs.`, `QR ${added}개를 가져왔어요.`),
      converted ? t(`${converted} were converted to count from #1.`, `${converted}개는 1번부터 세도록 바꿨어요.`) : "",
      kept.length ? t(`${kept.length} still count messages from #0.`, `${kept.length}개는 메시지를 0번부터 세요.`) : "",
    ]
      .filter(Boolean)
      .join(" ");
    ui.toast(summary, problems.length || kept.length ? "warning" : "success");
    if (problems.length || kept.length) {
      const parts: string[] = [];
      if (kept.length) parts.push(`${t("<b>QRs counting messages from #0</b> (couldn't convert them)", "<b>메시지를 0번부터 세는 QR</b> (자동 변환 실패)")}<br>${kept.map(escapeHtml).join("<br>")}`);
      if (problems.length) parts.push(`${t("<b>QRs with commands not supported yet</b>", "<b>아직 지원하지 않는 명령이 들어 있는 QR</b>")}<br>${problems.map(escapeHtml).join("<br>")}`);
      await ui.popup(parts.join("<br><br>"), { wide: true });
    }
    if (this.ctx.storageUsed() > STORAGE_SOFT_LIMIT) ui.toast(t("Storage is almost full. Delete sets you don't use.", "저장 공간이 거의 찼어요. 쓰지 않는 세트를 지워 주세요."), "warning");
  }
}
