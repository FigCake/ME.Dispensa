// Files the user saves from Dispensa (backups, QR exports).

import { saveBlob } from "../shared/capture";

/** Saves `data` as a pretty-printed JSON file; characters file names can't hold become "_". */
export function downloadJson(data: unknown, name: string): void {
  saveBlob(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }), name.replace(/[\\/:*?"<>|]/g, "_"));
}

/** The picker kept on the page until it answers (one at a time). */
let picking: HTMLInputElement | null = null;

/**
 * Opens the file picker and hands the chosen files to `onFiles` (call it from a
 * click). On phones the picker goes to the background: the input stays in the
 * page until it answers, so the browser can't drop it meanwhile, and JSON
 * pickers show every file, since Android's picker greys out .json files it
 * doesn't know as JSON (the file's content is checked after).
 */
export function pickFiles(onFiles: (files: File[]) => void, { accept = "", multiple = false, json = false }: { accept?: string; multiple?: boolean; json?: boolean } = {}): void {
  picking?.remove();
  const input = document.createElement("input");
  input.type = "file";
  input.multiple = multiple;
  const phone = window.matchMedia?.("(pointer: coarse)").matches ?? false;
  const filter = json ? (phone ? "" : ".json,application/json") : accept;
  if (filter) input.accept = filter;
  input.style.display = "none";
  const done = () => {
    input.remove();
    if (picking === input) picking = null;
  };
  input.addEventListener("change", () => {
    const files = [...(input.files ?? [])];
    done();
    if (files.length) onFiles(files);
  });
  input.addEventListener("cancel", done);
  document.body.append(input);
  picking = input;
  input.click();
}
