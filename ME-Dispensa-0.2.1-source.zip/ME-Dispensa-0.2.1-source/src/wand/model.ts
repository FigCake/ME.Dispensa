// 🌟 Wand data: presets and settings (kept in Dispensa's
// Marinara storage), and saved results (kept in the browser, see archive.ts).

import type { PresetChunk, VizModeSetting, VizPreset } from "./core";
import { DEFAULT_ITEMS, DEFAULT_OOC_TEMPLATE, DEFAULT_WRAPPERS, OLD_OOC_TEMPLATES } from "./defaults";
import { OLD_CHUNK_TEXTS, SUPERVIZ } from "./superviz";

/** 💬 delivery. guided: Marinara /guided (no visible message, the reply is the character's turn). */
export type OocMode = "guided" | "hidden" | "user" | "input";
/** Where a 🌟 page goes: the viewer above the bar, or the chat as the character's message. */
export type VizOutput = "viewer" | "chat";
export type WandAction = "ooc" | "viz";

export const OOC_MODES: Record<OocMode, string> = {
  hidden: "결과물 받기 (캐릭터 메시지로)",
  guided: "전개에 반영하기 (다음 답에)",
  user: "직접 보내기 (내 메시지로)",
  input: "입력창에 넣기 (고친 뒤 전송)",
};

export const VIZ_OUTPUTS: Record<VizOutput, string> = {
  viewer: "보기 창",
  chat: "채팅",
};

export interface Wrapper {
  id: string;
  name: string;
  template: string;
}

export interface WandItem {
  id: string;
  emoji: string;
  title: string;
  folder: string;
  defaultAction: WandAction;
  content: string;
  /** Helper model for this item ("" or null = the setting). */
  connectionId: string | null;
  pinned: boolean;
  oocMode?: OocMode;
  vizOutput?: VizOutput;
  wrapperId?: string;
}

export interface WandSettings {
  language: string;
  vizMode: VizModeSetting;
  vizOutput: VizOutput;
  /** Pages posted to the chat also go to the archive. */
  autoArchive: boolean;
  oocMode: OocMode;
  /** The OOC default moved to "hidden" (the user's QRs' /gen → /sendas); a saved "guided" went with it once. */
  oocModeV2?: boolean;
  wrapperId: string;
  /** "" = the chat's own connection. */
  connectionId: string;
  /** Show the 🌟 button on the quick bar. */
  showButton: boolean;
  /** The wand bubble's icon on the quick bar. */
  barIcon: string;
  /** Let pages load outside resources (fonts, images, html2canvas). */
  allowExternal: boolean;
  maxFrameHeight: number;
}

export interface WandState {
  version: 1;
  settings: WandSettings;
  /**
   * Items still waiting to move into the QR 보관함 (as 🌟 QRs, see items.ts):
   * the built-in samples on a first run, or a library saved before they
   * moved. Empty once moved.
   */
  items: WandItem[];
  /** The items went to the QR 보관함 (never again, even after a set is deleted). */
  itemsMoved: boolean;
  wrappers: Wrapper[];
  /** Chunk edits on top of the built-in 슈퍼비즈 (by chunk id), plus extra chunks. */
  preset: VizPreset;
}

export const DEFAULT_SETTINGS: WandSettings = {
  language: "English",
  // Marinara's security policy stops scripts in pages: full only when Fornello runs them
  vizMode: "auto",
  vizOutput: "viewer",
  autoArchive: true,
  // like the user's SillyTavern QRs: /gen with the request, then /sendas the result as the character
  oocMode: "hidden",
  oocModeV2: true,
  wrapperId: DEFAULT_WRAPPERS[0].id,
  connectionId: "",
  showButton: true,
  barIcon: "🍰",
  allowExternal: true,
  maxFrameHeight: 1600,
};

export function defaultPreset(): VizPreset {
  return { ...structuredClone(SUPERVIZ), known: SUPERVIZ.chunks.map((c) => c.id) };
}

export function defaultWandState(): WandState {
  return {
    version: 1,
    settings: { ...DEFAULT_SETTINGS },
    items: structuredClone(DEFAULT_ITEMS),
    itemsMoved: false,
    wrappers: structuredClone(DEFAULT_WRAPPERS),
    preset: defaultPreset(),
  };
}

export function newWandId(prefix = "w"): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function newWandItem(partial: Partial<WandItem> = {}): WandItem {
  return { id: newWandId("item"), emoji: "", title: "새 항목", folder: "", defaultAction: "viz", content: "", connectionId: null, pinned: false, ...partial };
}

const str = (v: unknown, fallback = "") => (typeof v === "string" ? v : fallback);
const pick = <T extends string>(v: unknown, allowed: readonly T[], fallback: T): T => (allowed.includes(v as T) ? (v as T) : fallback);

function normalizeItem(raw: unknown): WandItem | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  const item: WandItem = {
    id: str(r.id) || newWandId("item"),
    emoji: str(r.emoji),
    title: str(r.title) || "이름 없는 항목",
    folder: str(r.folder),
    defaultAction: pick(r.defaultAction, ["ooc", "viz"] as const, "viz"),
    content: str(r.content),
    connectionId: str(r.connectionId ?? r.profileId) || null,
    pinned: r.pinned === true,
  };
  if (r.oocMode) item.oocMode = pick(r.oocMode, Object.keys(OOC_MODES) as OocMode[], "guided");
  if (r.vizOutput) item.vizOutput = pick(r.vizOutput, ["viewer", "chat"] as const, "viewer");
  if (typeof r.wrapperId === "string") item.wrapperId = r.wrapperId;
  return item;
}

function normalizeChunk(raw: unknown): PresetChunk | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  return {
    id: str(r.id) || newWandId("chunk"),
    name: str(r.name) || "조각",
    mode: pick(r.mode, ["all", "full", "lite"] as const, "all"),
    enabled: r.enabled !== false,
    text: str(r.text),
    ...(r.needs === "fornello" ? { needs: "fornello" as const } : {}),
  };
}

/** Built-in chunks that came after presets started being saved (a preset saved before keeps the others as they are). */
const LATER_BUILTINS = ["fornello"];

/** A built-in chunk left exactly as an earlier version shipped it follows the current text. */
function withNewTexts(chunks: PresetChunk[]): PresetChunk[] {
  return chunks.map((c) => {
    const current = SUPERVIZ.chunks.find((b) => b.id === c.id);
    return current && OLD_CHUNK_TEXTS[c.id]?.includes(c.text) ? { ...c, text: current.text } : c;
  });
}

/** Built-in chunks added since the preset was saved go in (before the chunk that follows them by default). */
function withNewBuiltins(chunks: PresetChunk[], known: string[] | null): { chunks: PresetChunk[]; known: string[] } {
  const builtins = defaultPreset().chunks;
  const seen = new Set(known ?? builtins.map((b) => b.id).filter((id) => !LATER_BUILTINS.includes(id)));
  const out = [...chunks];
  builtins.forEach((b, i) => {
    if (seen.has(b.id)) return;
    const next = builtins.slice(i + 1).find((x) => out.some((c) => c.id === x.id));
    const at = next ? out.findIndex((c) => c.id === next.id) : out.length;
    out.splice(at, 0, structuredClone(b));
  });
  return { chunks: out, known: builtins.map((b) => b.id) };
}

export function normalizeWandState(raw: unknown): WandState {
  const base = defaultWandState();
  if (!raw || typeof raw !== "object") return base;
  const r = raw as Record<string, unknown>;
  const s = (r.settings && typeof r.settings === "object" ? r.settings : {}) as Record<string, unknown>;
  const settings: WandSettings = {
    language: str(s.language) || DEFAULT_SETTINGS.language,
    vizMode: pick(s.vizMode, ["auto", "full", "lite"] as const, DEFAULT_SETTINGS.vizMode),
    vizOutput: pick(s.vizOutput, ["viewer", "chat"] as const, DEFAULT_SETTINGS.vizOutput),
    autoArchive: typeof s.autoArchive === "boolean" ? s.autoArchive : DEFAULT_SETTINGS.autoArchive,
    // "guided" was the default before: settings saved then follow the new default once
    oocMode: s.oocModeV2 !== true && s.oocMode === "guided" ? DEFAULT_SETTINGS.oocMode : pick(s.oocMode, Object.keys(OOC_MODES) as OocMode[], DEFAULT_SETTINGS.oocMode),
    oocModeV2: true,
    wrapperId: str(s.wrapperId) || DEFAULT_SETTINGS.wrapperId,
    connectionId: str(s.connectionId),
    showButton: typeof s.showButton === "boolean" ? s.showButton : DEFAULT_SETTINGS.showButton,
    barIcon: str(s.barIcon).trim() || DEFAULT_SETTINGS.barIcon,
    allowExternal: typeof s.allowExternal === "boolean" ? s.allowExternal : DEFAULT_SETTINGS.allowExternal,
    maxFrameHeight: Number(s.maxFrameHeight) >= 200 ? Number(s.maxFrameHeight) : DEFAULT_SETTINGS.maxFrameHeight,
  };
  const itemsMoved = r.itemsMoved === true;
  const items = itemsMoved ? [] : Array.isArray(r.items) ? r.items.map(normalizeItem).filter((i): i is WandItem => !!i) : base.items;
  const wrappers = Array.isArray(r.wrappers)
    ? r.wrappers
        .filter((w): w is Record<string, unknown> => !!w && typeof w === "object")
        .map((w) => {
          const template = str(w.template) || "{{내용}}";
          // an untouched old default follows the new one
          return { id: str(w.id) || newWandId("wrap"), name: str(w.name) || "감싸개", template: OLD_OOC_TEMPLATES.includes(template) ? DEFAULT_OOC_TEMPLATE : template };
        })
    : base.wrappers;
  let preset = base.preset;
  if (r.preset && typeof r.preset === "object") {
    const p = r.preset as Record<string, unknown>;
    const stored = Array.isArray(p.chunks) ? p.chunks.map(normalizeChunk).filter((c): c is PresetChunk => !!c) : null;
    const known = Array.isArray(p.known) ? p.known.map(String) : null;
    const { chunks, known: offered } = stored ? withNewBuiltins(withNewTexts(stored), known) : { chunks: base.preset.chunks, known: base.preset.known ?? [] };
    preset = { id: str(p.id) || base.preset.id, name: str(p.name) || base.preset.name, wrap: p.wrap !== false, chunks, known: offered };
  }
  return { version: 1, settings, items, itemsMoved, wrappers: wrappers.length ? wrappers : base.wrappers, preset };
}

/** The settings an item runs with: its own choices first, then the defaults. */
export function itemOptions(state: WandState, item?: Partial<WandItem>) {
  const s = state.settings;
  return {
    oocMode: item?.oocMode ?? s.oocMode,
    vizOutput: item?.vizOutput ?? s.vizOutput,
    wrapper: state.wrappers.find((w) => w.id === (item?.wrapperId ?? s.wrapperId)) ?? state.wrappers[0] ?? DEFAULT_WRAPPERS[0],
    connectionId: item?.connectionId || s.connectionId || "",
  };
}
