// The Library's search results, in place of the set lists.

import { t } from "../../shared/i18n";
import { addToDock } from "../../qr/dock";
import type { QrItem, QrSet } from "../../qr/model";
import { type ItemHit, type SetHit, search } from "../../qr/search";
import { el, icon } from "../dom";
import { marked } from "../search-box";
import type { ManagerContext } from "./context";
import type { QrFiles } from "./import-export";
import { MARKS_TITLE, itemMarks, itemMenu, transferItems } from "./item-list";

/** Results drawn at most. */
const LIMIT = 200;

/** Phone layout: the columns stack. */
const stacked = () => typeof window.matchMedia === "function" && window.matchMedia("(max-width: 720px)").matches;

export function searchResults(ctx: ManagerContext, files: QrFiles, redraw: () => void): HTMLElement {
  // drop ticks on deleted QRs; ticks outlive a new search
  const live = new Set(ctx.state.sets.flatMap((s) => s.items.map((i) => i.id)));
  for (const id of [...ctx.searchPicked]) if (!live.has(id)) ctx.searchPicked.delete(id);
  const { sets, items } = search(ctx.searchIndex(), ctx.searchQuery, { body: true, menus: false, limit: LIMIT });
  const box = el("div", { class: "results", role: "listbox", "aria-label": t("Search results", "찾은 결과") });
  if (!sets.length && !items.length) {
    box.append(el("div", { class: "zone-empty" }, t("Nothing found", "찾은 게 없어요")));
    if (ctx.searchPicked.size) box.append(bulkBar(ctx, files, redraw));
    return box;
  }
  if (sets.length) {
    box.append(el("div", { class: "zone-h" }, t("Sets", "세트"), el("span", { class: "count" }, String(sets.length))));
    for (const hit of sets) box.append(setRow(ctx, hit));
  }
  if (items.length) {
    box.append(el("div", { class: "zone-h" }, t("QR", "QR"), el("span", { class: "count" }, items.length >= LIMIT - sets.length ? `${items.length}+` : String(items.length))));
    for (const hit of items) box.append(itemRow(ctx, files, hit, redraw));
  }
  if (ctx.searchPicked.size) box.append(bulkBar(ctx, files, redraw));
  const rows = box.querySelectorAll<HTMLElement>(".hit");
  ctx.searchActive = Math.max(0, Math.min(ctx.searchActive, rows.length - 1));
  rows[ctx.searchActive]?.classList.add("active");
  return box;
}

function setRow(ctx: ManagerContext, hit: SetHit): HTMLElement {
  const s = hit.set;
  return el(
    "div",
    { class: "set-row hit", role: "option" },
    el(
      "button",
      {
        class: `entry${s.id === ctx.selectedSet && !ctx.viszOpen ? " sel" : ""}`,
        onclick: () => {
          ctx.selectedSet = s.id;
          ctx.selectedItem = null;
          if (ctx.viszOpen) ctx.viszOpen = false;
          ctx.render();
          if (stacked()) requestAnimationFrame(() => ctx.root?.querySelector(".main > .col + .col")?.scrollIntoView({ block: "start" }));
        },
      },
      s.icon?.trim() ? el("span", {}, s.icon.trim()) : icon("folder"),
      el("span", { class: "grow name" }, marked(s.name, hit.marks)),
      el("span", { class: "meta" }, String(s.items.length)),
    ),
  );
}

function itemRow(ctx: ManagerContext, files: QrFiles, hit: ItemHit, redraw: () => void): HTMLElement {
  const { set, item } = hit;
  const marks = itemMarks(item);
  const label = item.label || t("(no name)", "(이름 없음)");
  const open = el(
    "button",
    {
      class: `entry${item.id === ctx.selectedItem ? " sel" : ""}`,
      title: [item.title, hit.hidden ? t("Hidden from the Dock", "Dock에서 숨김") : ""].filter(Boolean).join("\n") || label,
      onclick: () => ctx.openItem(set.id, item.id),
    },
    item.icon?.trim() ? el("span", {}, item.icon.trim()) : icon("play"),
    el("span", { class: "grow name" }, item.label ? marked(item.label, hit.marks.name) : label),
    marks.length ? el("span", { class: "marks", title: MARKS_TITLE() }, marks.join(" ")) : null,
    hit.hidden ? el("span", { class: "meta" }, t("Hidden", "숨김")) : null,
    // second line: set and matched script line
    el("span", { class: "sub" }, el("span", { class: "tag", title: t("Set", "세트") }, set.name), hit.line ? el("span", { class: "line" }, marked(hit.line.text, hit.line.marks)) : null),
  );
  return el(
    "div",
    { class: `qrow hit${hit.hidden ? " dim" : ""}`, role: "option" },
    el("input", {
      type: "checkbox",
      class: "pick",
      checked: ctx.searchPicked.has(item.id),
      title: t("Pick", "고르기"),
      "aria-label": t(`Pick ${item.label}`, `${item.label} 고르기`),
      onchange: (e: Event) => {
        if ((e.target as HTMLInputElement).checked) ctx.searchPicked.add(item.id);
        else ctx.searchPicked.delete(item.id);
        redraw();
      },
    }),
    open,
    el("button", { class: "icon", title: t("Run", "실행"), "aria-label": t(`Run ${item.label}`, `${item.label} 실행`), onclick: () => ctx.deps.run(set, item) }, icon("play")),
    itemMenu(ctx, files, set, item),
  );
}

/** Ticked QRs, Library order. */
function pickedItems(ctx: ManagerContext): { set: QrSet; item: QrItem }[] {
  return ctx.state.sets.flatMap((set) => set.items.filter((i) => ctx.searchPicked.has(i.id)).map((item) => ({ set, item })));
}

/** Actions on the ticked QRs. */
function bulkBar(ctx: ManagerContext, files: QrFiles, redraw: () => void): HTMLElement {
  const { store, ui } = ctx.deps;
  const picked = pickedItems(ctx);
  const n = picked.length;
  const done = () => {
    ctx.searchPicked.clear();
    ctx.render();
  };
  const transfer = async (copy: boolean) => {
    if (await transferItems(ctx, picked, copy)) done();
  };
  return el(
    "div",
    { class: "bulk", role: "toolbar", "aria-label": t("Picked QRs", "고른 QR") },
    el("span", { class: "grow" }, t(`${n} picked`, `${n}개 고름`)),
    el("button", { type: "button", onclick: () => void transfer(false) }, t("Move to set…", "세트로 옮기기…")),
    el("button", { type: "button", onclick: () => void transfer(true) }, t("Copy to set…", "세트로 복사…")),
    el("button", { type: "button", title: ".mqr.json", onclick: () => files.exportItems(picked.map((p) => p.item)) }, t("Export", "내보내기")),
    el(
      "button",
      {
        type: "button",
        onclick: () => {
          store.update((st) => picked.forEach(({ set, item }) => addToDock(st, { kind: "qr", setId: set.id, itemId: item.id })));
          ui.toast(t(`Put ${n} QRs on the Dock.`, `QR ${n}개를 Dock에 놓았어요.`), "success");
          done();
        },
      },
      t("Put on the Dock", "Dock에 놓기"),
    ),
    el(
      "button",
      {
        type: "button",
        class: "danger",
        onclick: async () => {
          if (!(await ui.popup(t(`Delete ${n} QRs?`, `QR ${n}개를 삭제할까요?`), { okButton: t("Delete", "삭제"), cancelButton: t("Cancel", "취소") }))) return;
          const ids = new Set(picked.map((p) => p.item.id));
          store.update((st) => st.sets.forEach((s) => (s.items = s.items.filter((i) => !ids.has(i.id)))));
          if (ctx.selectedItem && ids.has(ctx.selectedItem)) ctx.selectedItem = null;
          done();
        },
      },
      t("Delete", "삭제"),
    ),
    el(
      "button",
      {
        type: "button",
        class: "icon",
        title: t("Unpick all", "모두 풀기"),
        "aria-label": t("Unpick all", "모두 풀기"),
        onclick: () => {
          ctx.searchPicked.clear();
          redraw();
        },
      },
      icon("x"),
    ),
  );
}

export const SEARCH_RESULTS_CSS = `
.results { display: flex; flex-direction: column; gap: 4px; }
.results .zone-h { margin-top: 10px; }
.results .zone-h:first-child { margin-top: 0; }
.results .hit.active > .entry { border-color: var(--d-btn-border-hover); background: var(--d-hl-bg); }
.results .entry { flex-wrap: wrap; row-gap: 2px; }
.results .entry .name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.results .entry .sub { flex-basis: 100%; display: flex; align-items: baseline; gap: 6px; min-width: 0; font-weight: 400; }
.results .entry .tag { flex: none; max-width: 50%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; padding: 0 6px; border-radius: 999px; border: 1px solid var(--d-line); color: var(--d-muted); font-size: 11px; }
.results .entry .line { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font: 11.5px/1.35 var(--d-mono); color: var(--d-muted); }
.results .hit.dim > .entry { opacity: .6; }
.col-search { margin: 8px 0 0; }
.results .qrow { gap: 2px; }
.results .qrow > input.pick { flex: none; margin: 0 2px 0 0; width: 15px; height: 15px; }
/* narrow column: small ▶ and ⋯ */
.results .qrow > button.icon { padding: 5px 4px; }
.results .qrow > details.menu > summary { padding: 5px 5px; }
.results .entry { padding-left: 7px; padding-right: 7px; }
.results .bulk { position: sticky; bottom: -10px; z-index: 2; display: flex; flex-wrap: wrap; align-items: center; gap: 4px; margin: 8px -10px -10px; padding: 8px 10px 10px;
  background: var(--d-panel-solid); border-top: 1px solid var(--d-divider); font-size: 12.5px; }
.results .bulk > .grow { flex-basis: 100%; color: var(--d-muted); }
.results .bulk button { padding: 4px 8px; font-size: 12px; }
.results .bulk button.danger { color: var(--d-danger); }
/* keeps the bar in sight */
.col:has(.results .bulk) .visz-foot { position: static; }
`;
