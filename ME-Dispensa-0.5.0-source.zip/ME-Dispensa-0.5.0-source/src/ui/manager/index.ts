// The Dispensa window's frame (one shadow root): opening, the header, the selected
// tab, set and QR, and redrawing. Each tab's content is its own module.

import { STORAGE_LIMIT, STORAGE_SHOW_FROM, storageUsed } from "../../host/persisted-store";
import { LANG_NAMES, type LangChoice, langChoice, setLangChoice, t } from "../../shared/i18n";
import { textForAi } from "../../memo/markdown";
import type { Memo, MemoState } from "../../memo/model";
import { oneLine } from "../../util";
import type { SetNames } from "../../qr/import";
import { type QrItem, type QrSet, type QrState, newItem, newSet } from "../../qr/model";
import { type ChatScope, NO_CHAT } from "../../qr/scopes";
import { type SearchIndex, indexCache } from "../../qr/search";
import { el, icon, withIcons } from "../dom";
import { helpTip, segmented } from "../../shared/form";
import { MemoView } from "../memo-view";
import { BoardView } from "../board-view";
import { dropMenu } from "../menu";
import { ViszSettingsView } from "../visz-settings";
import { GalleryView } from "../gallery-view";
import type { ManagerContext, ManagerDeps, ManagerTab } from "./context";
import { QrFiles } from "./import-export";
import { ItemEditor } from "./item-editor";
import { itemColumn } from "./item-list";
import { setColumn } from "./set-column";
import { settingsPop } from "./settings-pop";
import { MANAGER_CSS } from "./style";
import { SEARCH_RESULTS_CSS } from "./search-results";
import { SEARCH_BOX_CSS } from "../search-box";

export type { ManagerDeps, ManagerTab } from "./context";

/** What the window redraws for. Script text and its marks are left out so typing never redraws (the box updates itself). */
const librarySlice = (state: QrState) => JSON.stringify(state, (key, value) => (key === "script" || key === "unsupported" ? undefined : value));
/** Memo text is left out for the same reason. */
const memoSlice = (state: MemoState) => JSON.stringify(state, (key, value) => (key === "text" ? undefined : value));

export class QrManager implements ManagerContext {
  private hostEl: HTMLElement | null = null;
  root: ShadowRoot | null = null;
  selectedSet: string | null = null;
  selectedItem: string | null = null;
  scope: ChatScope = NO_CHAT;
  private tab: ManagerTab = "qr";
  private unsubscribers: (() => void)[] = [];
  private readonly openParts = new Set<string>();
  private readonly viszView: ViszSettingsView | null;
  private readonly galleryView: GalleryView | null;
  /** ⚙ Dispensa settings are open under the header. */
  private settingsOpen = false;
  viszOpen: boolean | null;
  private readonly memoView: MemoView | null;
  private readonly boardView: BoardView | null;
  private readonly editor = new ItemEditor(this);
  private readonly files = new QrFiles(this);
  /** The window slides in on open, not on every redraw. */
  private entering = false;
  private readonly names = new Map<string, string>();
  private scrollToEditor = false;
  searchQuery = "";
  searchActive = 0;
  readonly searchPicked = new Set<string>();
  /** Without sub menu entries: the Library doesn't list them. */
  private readonly index = indexCache({ menus: false });

  constructor(readonly deps: ManagerDeps) {
    this.viszOpen = deps.viszStore ? false : null;
    this.galleryView = deps.gallery ? new GalleryView({ ...deps.gallery, ui: deps.ui, close: () => this.close() }, true) : null;
    this.viszView = deps.viszStore
      ? new ViszSettingsView({
          store: deps.viszStore,
          ui: deps.ui,
          connections: async () => (await deps.connections()).map((c) => ({ id: c.id, name: c.name })),
          presets: () => deps.promptPresets?.() ?? Promise.resolve([]),
          rerender: () => this.render(),
        })
      : null;
    const memo = deps.memo;
    this.memoView = memo
      ? new MemoView({
          store: memo.store,
          ui: deps.ui,
          sendOoc: memo.sendOoc,
          putInInput: memo.putInInput,
          makePage: memo.makePage,
          toQr: (memo) => this.memoToQr(memo),
          oocSettings: () => this.viszView?.oocCards() ?? [],
          menu: (summary, label, entries) => dropMenu(summary, label, entries),
          close: () => this.close(),
          rerender: () => this.render(),
          scope: () => this.scope,
          fonts: memo.fonts,
          useFont: memo.useFont,
          openBoard: (id) => {
            this.boardView?.show(id);
            this.tab = "board";
            this.render();
          },
        })
      : null;
    this.boardView = memo
      ? new BoardView({
          store: memo.store,
          ui: deps.ui,
          rerender: () => this.render(),
          scope: () => this.scope,
          fonts: memo.fonts,
          useFont: memo.useFont,
          sendOoc: memo.sendOoc,
          putInInput: memo.putInInput,
          makePage: memo.makePage,
          runForGallery: memo.runForGallery,
          openGallery: () => this.open("gallery"),
          openPage: async (id) => {
            const ok = await memo.openPage(id);
            if (ok) this.close();
            return ok;
          },
          close: () => this.close(),
          openMemo: (id) => {
            this.memoView?.show(id);
            this.tab = "memo";
            this.render();
          },
          images: memo.images,
        })
      : null;
  }

  get state(): QrState {
    return this.deps.store.value;
  }

  readonly setName: SetNames = (id) => this.state.sets.find((s) => s.id === id)?.name;

  searchIndex(): SearchIndex {
    return this.index.get(this.state);
  }

  storageUsed(): number {
    return storageUsed([this.deps.store, this.deps.viszStore, this.deps.memo?.store]);
  }

  characterName(id: string, fallback = "…"): string {
    return this.names.get(id) ?? fallback;
  }

  /** A new plain QR with the memo as its script, in the Library's open set. */
  private memoToQr(memo: Memo): void {
    const item = newItem(memo.title?.trim() || oneLine(memo.text, 14), textForAi(memo.text));
    let setId = "";
    this.deps.store.update((st) => {
      let target = st.sets.find((x) => x.id === this.selectedSet);
      if (!target) {
        target = newSet(t("Memo QR", "메모 QR"));
        st.sets.push(target);
      }
      target.items.push(item);
      setId = target.id;
    });
    this.openItem(setId, item.id);
  }

  /** The chat on screen, for the chat and character switches. */
  setScope(scope: ChatScope): void {
    this.scope = scope;
    for (const id of scope.characterIds) {
      if (this.names.has(id)) continue;
      this.names.set(id, t("Character", "캐릭터"));
      void this.deps.characterName(id).then((name) => {
        this.names.set(id, name);
        this.render();
      });
    }
    this.render();
  }

  /** Adds a QR file's sets to the Library (Fornello's card bundles hand them over). */
  importQrs(json: unknown, name: string, characterId?: string): number {
    return this.files.importJson(json, name, characterId);
  }

  /** The memo boards tab, on one board when given. */
  openBoard(id?: string): void {
    if (id && id !== "new") this.boardView?.show(id);
    this.open("board");
    if (id === "new") void this.boardView?.makeBoard();
  }

  open(tab?: ManagerTab): void {
    // the visualizer and the Dock were tabs: now the Library's Visualizer panel and ⚙ settings
    if (tab === "visz") {
      if (this.viszOpen !== null) this.viszOpen = true;
      tab = "qr";
    } else if (tab === "dock") {
      this.settingsOpen = true;
      tab = undefined;
    } else if (tab === "qr" && this.viszOpen) this.viszOpen = false;
    if (tab) this.tab = tab;
    if (this.tab === "gallery") void this.galleryView?.load();
    if (this.hostEl) {
      this.render();
      return;
    }
    this.hostEl = el("div", { id: "dispensa-manager" });
    this.root = this.hostEl.attachShadow({ mode: "open" });
    document.body.append(this.hostEl);
    this.selectedSet ??= this.deps.store.value.sets[0]?.id ?? null;
    const redraw = () => this.render();
    // it may have changed while closed
    this.index.invalidate();
    this.unsubscribers = [
      this.deps.store.subscribe(() => this.index.invalidate()),
      this.deps.store.select(librarySlice, redraw),
      // a script changed elsewhere (a /qr-update while the window is open) shows in its open box
      this.deps.store.subscribe(() => this.editor.syncScripts()),
      this.deps.viszStore?.subscribe(redraw),
      this.deps.memo?.store.select(memoSlice, redraw),
    ].filter((off): off is () => boolean => !!off);
    document.addEventListener("keydown", this.onKey, true);
    this.entering = true;
    this.render();
    this.entering = false;
  }

  /** Redraws when open (after the screen language changed). */
  refresh(): void {
    if (this.hostEl) this.render();
  }

  /** Ctrl+click on the Dock: straight to that QR's editor. */
  openItem(setId: string, itemId: string): void {
    this.selectedSet = setId;
    this.selectedItem = itemId;
    this.settingsOpen = false;
    this.scrollToEditor = true;
    this.open("qr");
  }

  close(): void {
    this.settingsOpen = false;
    // the next opening starts on the set lists
    this.searchQuery = "";
    this.searchActive = 0;
    this.searchPicked.clear();
    this.memoView?.leave();
    this.editor.stopAll();
    for (const off of this.unsubscribers) off();
    this.unsubscribers = [];
    void this.deps.viszStore?.saveNow().catch(() => undefined);
    void this.deps.memo?.store.saveNow().catch(() => undefined);
    document.removeEventListener("keydown", this.onKey, true);
    this.hostEl?.remove();
    this.hostEl = this.root = null;
    void this.deps.store.saveNow().catch(() => undefined);
  }

  private readonly onKey = (e: KeyboardEvent) => {
    // Ctrl+F (⌘+F): the Library's search box, not the page's
    if ((e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey && e.key.toLowerCase() === "f" && this.tab === "qr") {
      e.preventDefault();
      e.stopPropagation();
      if (this.settingsOpen) {
        this.settingsOpen = false;
        this.render();
      }
      const box = this.root?.querySelector<HTMLInputElement>('[data-key="lib-search"]');
      box?.focus();
      box?.select();
      return;
    }
    if (e.key === "Escape" && !e.defaultPrevented) {
      const active = this.root?.activeElement;
      if (active && active.tagName === "TEXTAREA") return;
      const menu = this.root?.querySelector<HTMLDetailsElement>("details.menu[open]");
      e.stopPropagation();
      if (menu) {
        menu.open = false;
        return;
      }
      if (this.settingsOpen) {
        this.settingsOpen = false;
        this.render();
        return;
      }
      this.close();
    }
  };

  mutateSet(set: QrSet, fn: (s: QrSet, st: QrState) => void): void {
    this.deps.store.update((st) => {
      const target = st.sets.find((x) => x.id === set.id);
      if (target) fn(target, st);
    });
  }

  mutateItem(set: QrSet, item: QrItem, fn: (i: QrItem) => void): void {
    this.deps.store.update((st) => {
      const target = st.sets.find((s) => s.id === set.id)?.items.find((i) => i.id === item.id);
      if (target) fn(target);
    });
  }

  removeItem(set: QrSet, item: QrItem): void {
    this.mutateSet(set, (s) => (s.items = s.items.filter((i) => i.id !== item.id)));
    if (this.selectedItem === item.id) this.selectedItem = null;
    this.render();
  }

  fold(key: string, title: string, count: number, help: string | undefined, ...kids: (Node | null)[]): HTMLElement {
    const d = el("details", { class: "box" }, el("summary", {}, title, count ? el("span", { class: "count" }, `· ${count}`) : null, help ? helpTip(help, title) : null), ...kids);
    d.open = this.openParts.has(key);
    d.addEventListener("toggle", () => (d.open ? this.openParts.add(key) : this.openParts.delete(key)));
    return d;
  }

  render(): void {
    if (!this.root) return;
    // keep focus and caret in the editor across redraws
    const active = this.root.activeElement as HTMLInputElement | HTMLTextAreaElement | null;
    const focusKey = active?.dataset?.key;
    const caret = active && "selectionStart" in active ? [active.selectionStart, active.selectionEnd] : null;
    const scrolls = [...this.root.querySelectorAll<HTMLElement>(".col")].map((c) => c.scrollTop);
    this.editor.forgetGone();

    const style = el("style");
    style.textContent = MANAGER_CSS + SEARCH_BOX_CSS + SEARCH_RESULTS_CSS;
    const win = el("div", { class: `win${this.entering ? " d-enter" : ""}`, role: "dialog", "aria-modal": "true", "aria-label": "Dispensa" });
    if (this.tab === "memo" && this.memoView) win.append(this.header(), el("div", { class: "main single" }, this.memoView.render()));
    else if (this.tab === "board" && this.boardView) win.append(this.header(), el("div", { class: "main single board-main" }, this.boardView.render()));
    else if (this.tab === "gallery" && this.galleryView) win.append(this.header(), el("div", { class: "main single" }, this.galleryView.element));
    else win.append(this.header(), el("div", { class: "main" }, setColumn(this, this.files), this.viszOpen && this.viszView ? el("div", { class: "col" }, this.viszView.render()) : itemColumn(this, this.editor, this.files)));
    const backdrop = el("div", {
      class: `backdrop${this.entering ? " d-fade" : ""}`,
      onmousedown: (e: Event) => {
        if (e.target === backdrop) this.close();
      },
    });
    backdrop.append(win);
    this.root.replaceChildren(style, backdrop);

    [...this.root.querySelectorAll<HTMLElement>(".col")].forEach((c, i) => (c.scrollTop = scrolls[i] ?? 0));
    if (focusKey) {
      const target = this.root.querySelector<HTMLInputElement | HTMLTextAreaElement>(`[data-key="${focusKey}"]`);
      if (target) {
        target.focus({ preventScroll: true });
        if (caret && caret[0] !== null && "setSelectionRange" in target && target.type !== "checkbox" && target.type !== "color") target.setSelectionRange(caret[0], caret[1]);
      }
    }
    if (this.scrollToEditor) {
      this.scrollToEditor = false;
      requestAnimationFrame(() => this.root?.querySelector(".editor")?.scrollIntoView({ block: "start" }));
    }
  }

  private header(): HTMLElement {
    const size = this.storageUsed();
    const tabIcons: Record<string, string> = { qr: "square-sparkles", memo: "notebook-pen", board: "layout-dashboard", gallery: "images" };
    const tabOptions = [
        { value: "qr", label: "📚", title: t("QR library", "QR 보관함") },
        ...(this.memoView ? [{ value: "memo", label: "📝", title: t("Memo pad", "메모장") }] : []),
        ...(this.boardView ? [{ value: "board", label: "📋", title: t("Memo boards", "메모 보드") }] : []),
        ...(this.galleryView ? [{ value: "gallery", label: "🖼", title: t("Gallery", "갤러리") }] : []),
      ];
    const tabs = withIcons(
      segmented(
      "dispensa-tab",
      tabOptions,
      this.tab,
      (v) => this.open(v as ManagerTab),
      t("Dispensa tabs", "Dispensa 탭"),
      ),
      tabOptions.map((o) => tabIcons[o.value] ?? null),
    );
    return el(
      "header",
      {},
      el("h2", {}, "Dispensa"),
      el("div", { class: "row tabs" }, tabs),
      el("span", { class: "grow" }),
      el(
        "select",
        {
          class: "lang",
          title: t("Language", "언어"),
          "aria-label": t("Language", "언어"),
          "data-key": "lang",
          onchange: (e: Event) => setLangChoice((e.target as HTMLSelectElement).value as LangChoice),
        },
        ...(["auto", "en", "ko"] as LangChoice[]).map((c) => el("option", { value: c, selected: c === langChoice() }, `🌐 ${LANG_NAMES[c]()}`)),
      ),
      // the 1 MB storage only shows once it starts filling up
      size > STORAGE_SHOW_FROM ? el("span", { class: "warn", title: `${Math.round(size / 1024)} KB / ${STORAGE_LIMIT / 1000} KB` }, t(`Storage ${Math.round((size / STORAGE_LIMIT) * 100)}% used`, `저장 공간 ${Math.round((size / STORAGE_LIMIT) * 100)}% 사용`)) : el("span"),
      this.tab === "qr"
        ? el("button", { title: t("Import QR files (.json, .qr.json, .mqr.json)", "QR 파일 가져오기 (.json, .qr.json, .mqr.json)"), "aria-label": t("Import QRs", "QR 가져오기"), onclick: () => this.files.importFile() }, icon("download"), el("span", { class: "label" }, t("Import QRs", "QR 가져오기")))
        : el("span"),
      el(
        "button",
        {
          class: this.settingsOpen ? "on" : "",
          part: "dispensa-settings",
          "aria-pressed": String(this.settingsOpen),
          title: t("Dispensa settings", "Dispensa 설정"),
          "aria-label": t("Dispensa settings", "Dispensa 설정"),
          onclick: () => ((this.settingsOpen = !this.settingsOpen), this.render()),
        },
        icon("settings"),
      ),
      el("button", { class: "icon", title: t("Close", "닫기"), "aria-label": t("Close", "닫기"), onclick: () => this.close() }, icon("x")),
      this.settingsOpen
        ? settingsPop(this, { ai: this.viszView?.commonAi() ?? null, bubbles: [this.viszView?.dockBubble(), this.memoView?.dockBubble()].filter((x): x is HTMLElement => !!x) }, () => ((this.settingsOpen = false), this.render()))
        : null,
    );
  }
}
