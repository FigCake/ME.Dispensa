// The Dock: its own list of bubbles (sets and single QRs), the same in every chat.
// Where a set is on decides only where its QRs auto-run, not what the Dock shows.

import { DOCK_SPAN, type DockEntry, type DockFlow, type DockLayout, type QrItem, type QrSet, type QrState } from "./model";

/** A Dock entry with what it points at; entries whose set or QR is gone are left out. */
export type ShownEntry = { entry: DockEntry; set: QrSet; item?: QrItem };

export function shownDock(state: QrState): ShownEntry[] {
  const out: ShownEntry[] = [];
  for (const entry of state.dock ?? []) {
    if (entry.kind === "set") {
      const set = state.sets.find((s) => s.id === entry.setId);
      if (set) out.push({ entry, set });
      continue;
    }
    // a QR moved to another set keeps its bubble (ids are unique)
    for (const set of state.sets) {
      const item = set.items.find((i) => i.id === entry.itemId);
      if (item) {
        out.push({ entry, set, item });
        break;
      }
    }
  }
  return out;
}

const same = (a: DockEntry, b: DockEntry) => a.kind === b.kind && (a.kind === "set" ? a.setId === b.setId : a.itemId === (b as typeof a).itemId);

export function onDock(state: QrState, entry: DockEntry): boolean {
  return (state.dock ?? []).some((e) => same(e, entry));
}

/** Puts an entry on the Dock (at the end, or at `index`); one that is there already stays put. */
export function addToDock(state: QrState, entry: DockEntry, index?: number): void {
  const entries = (state.dock ??= []);
  if (entries.some((e) => same(e, entry))) return;
  entries.splice(index === undefined ? entries.length : Math.max(0, Math.min(index, entries.length)), 0, entry);
}

export function removeFromDock(state: QrState, entry: DockEntry): void {
  if (state.dock) state.dock = state.dock.filter((e) => !same(e, entry));
}

/** How a set entry sits on the Dock (one without a layout follows the set's display). */
export function layoutOf(entry: DockEntry, set: QrSet): DockLayout {
  if (entry.kind !== "set") return "folder";
  return entry.layout ?? (set.display === "inline" ? "row" : "folder");
}

export function setLayout(state: QrState, setId: string, layout: DockLayout): void {
  for (const e of state.dock ?? []) if (e.kind === "set" && e.setId === setId) e.layout = layout;
}

/** The Dock's overflow and its span (0 when wrapping). */
export function dockFlow(state: QrState): { flow: DockFlow; span: number } {
  const flow = state.dockFlow ?? "wrap";
  if (flow === "wrap") return { flow, span: 0 };
  const { min, max, default: fallback } = DOCK_SPAN[flow];
  const span = state.dockSpan;
  return { flow, span: typeof span === "number" ? Math.max(min, Math.min(max, Math.round(span))) : fallback };
}

/** What the Dock draws from the Library: all but the script text, so typing a script does not redraw the Dock. */
export function dockSlice(state: QrState): string {
  return JSON.stringify(state, (key, value) => (key === "script" ? typeof value === "string" && value.trim() !== "" : value));
}
