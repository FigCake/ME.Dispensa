// QRs run by hand, newest first. Kept in this browser, not in Marinara's storage,
// so a run doesn't re-save the Library.

import type { QrItem, QrSet, QrState } from "./model";

export interface RecentRun {
  setId: string;
  itemId: string;
  at: number;
}

export interface RecentStorage {
  read(): string | null;
  write(text: string): void;
}

export const RECENT_KEY = "dispensa:qr-recent";
export const RECENT_MAX = 20;

/** Anything broken reads as empty. */
export function parseRecent(text: string | null): RecentRun[] {
  if (!text) return [];
  try {
    const raw = JSON.parse(text) as unknown;
    if (!Array.isArray(raw)) return [];
    return raw
      .filter((r): r is RecentRun => !!r && typeof r === "object" && typeof r.setId === "string" && typeof r.itemId === "string" && typeof r.at === "number" && Number.isFinite(r.at))
      .map(({ setId, itemId, at }) => ({ setId, itemId, at }))
      .slice(0, RECENT_MAX);
  } catch {
    return [];
  }
}

/** A QR run again moves to the front. */
export function addRecent(list: RecentRun[], run: RecentRun): RecentRun[] {
  return [run, ...list.filter((r) => r.itemId !== run.itemId)].slice(0, RECENT_MAX);
}

/** Skips QRs that are gone; a moved QR is found by id. */
export function recentItems(state: QrState, list: RecentRun[], limit = RECENT_MAX): { set: QrSet; item: QrItem; at: number }[] {
  const out: { set: QrSet; item: QrItem; at: number }[] = [];
  for (const r of list) {
    if (out.length >= limit) break;
    const set = state.sets.find((s) => s.items.some((i) => i.id === r.itemId));
    const item = set?.items.find((i) => i.id === r.itemId);
    if (set && item) out.push({ set, item, at: r.at });
  }
  return out;
}

export class RecentRuns {
  constructor(
    private readonly storage: RecentStorage,
    private readonly now: () => number = Date.now,
  ) {}

  list(): RecentRun[] {
    try {
      return parseRecent(this.storage.read());
    } catch {
      return [];
    }
  }

  record(set: QrSet, item: QrItem): void {
    try {
      this.storage.write(JSON.stringify(addRecent(this.list(), { setId: set.id, itemId: item.id, at: this.now() })));
    } catch {
      // blocked or full: not worth an error
    }
  }

  shown(state: QrState, limit?: number): { set: QrSet; item: QrItem; at: number }[] {
    return recentItems(state, this.list(), limit);
  }
}

/** localStorage, or nothing when blocked. */
export function localRecentStorage(key = RECENT_KEY): RecentStorage {
  return {
    read: () => {
      try {
        return globalThis.localStorage?.getItem(key) ?? null;
      } catch {
        return null;
      }
    },
    write: (text) => {
      try {
        globalThis.localStorage?.setItem(key, text);
      } catch {
        // blocked or full
      }
    },
  };
}
